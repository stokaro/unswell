# fzf Documentation

## Overview

fzf is an interactive command-line filter for arbitrary text lists. It can search paths, command history, processes, hosts, bookmarks, commits, and other text supplied through standard input.

The project includes several components:

- The dependency-free `fzf` executable
- `fzf-tmux` for running fzf inside a tmux pane or popup
- Shell bindings for Bash, Zsh, and Fish
- Fuzzy completion for Bash and Zsh
- Vim and Neovim integration

The executable can be installed independently. fzf is distributed under the MIT license. Copyright is held by Junegunn Choi for 2013–2020.

## Installation

Homebrew and Linuxbrew provide the following installation command:

```sh
brew install fzf
```

To install useful shell key bindings and fuzzy completion as well, run:

```sh
$(brew --prefix)/opt/fzf/install
```

You can also install fzf by cloning the repository and running its installation script:

```sh
git clone --depth 1 https://github.com/junegunn/fzf.git ~/.fzf
~/.fzf/install
```

MacPorts, listed Linux and BSD package managers, and Windows package managers or binaries are also supported. The package-manager commands include:

| Package Manager | Linux Distribution      | Command                            |
| ---             | ---                     | ---                                |
| APK             | Alpine Linux            | `sudo apk add fzf`                 |
| APT             | Debian 9+/Ubuntu 19.10+ | `sudo apt-get install fzf`         |
| Conda           |                         | `conda install -c conda-forge fzf` |
| DNF             | Fedora                  | `sudo dnf install fzf`             |
| Nix             | NixOS, etc.             | `nix-env -iA nixpkgs.fzf`          |
| Pacman          | Arch Linux              | `sudo pacman -S fzf`               |
| pkg             | FreeBSD                 | `pkg install fzf`                  |
| pkg_add         | OpenBSD                 | `pkg_add fzf`                      |
| XBPS            | Void Linux              | `sudo xbps-install -S fzf`         |
| Zypper          | openSUSE                | `sudo zypper install fzf`          |

On Windows, Chocolatey and Scoop provide these commands:

| Package manager | Command             |
| ---             | ---                 |
| Chocolatey      | `choco install fzf` |
| Scoop           | `scoop install fzf` |

Package installation may leave shell bindings or completion disabled. Consult the instructions for the package you installed. Upgrades follow the installation method used for the initial installation. Exact upgrade commands and package tables accompany these installation notes. `BUILD.md` covers building fzf from source.

For Vim users, vim-plug can run `fzf#install()` as an optional update hook:

```vim
Plug 'junegunn/fzf', { 'do': { -> fzf#install() } }
```

## Interactive Search

fzf reads candidates from standard input and writes selected items to standard output. For example:

```sh
find * -type f | fzf > selected
```

When no pipe is present, fzf invokes `find` and excludes hidden files. If input is a terminal, `FZF_DEFAULT_COMMAND` replaces this default command. `FZF_DEFAULT_OPTS` supplies default options.

```sh
vim $(fzf)
```

The default layout is fullscreen and bottom-up. `--height` starts fzf below the cursor instead of using the full screen:

```sh
vim $(fzf --height 40%)
```

`--reverse` and `--layout` adjust the direction and layout:

```sh
vim $(fzf --height 40% --reverse)
```

Defaults can be configured through the environment:

```sh
export FZF_DEFAULT_OPTS='--height 40% --layout=reverse --border'
```

Navigate with `Ctrl-J` or `Ctrl-N` to move down and `Ctrl-K` or `Ctrl-P` to move up. Press Enter to accept a selection. `Ctrl-C`, `Ctrl-G`, and Escape exit fzf. In `-m` mode, Tab and Shift-Tab mark items. Mouse selection and scrolling are available, as are Emacs bindings.

### Queries

Extended queries combine space-separated terms. An unquoted term performs a fuzzy match. A quoted term performs an exact match. A leading caret performs a prefix-exact match, and a trailing dollar sign performs a suffix-exact match. A leading exclamation mark creates an inverse variant.

| Token     | Match type                 | Description                          |
| --------- | -------------------------- | ------------------------------------ |
| `sbtrkt`  | fuzzy-match                | Items that match `sbtrkt`            |
| `'wild`   | exact-match (quoted)       | Items that include `wild`           |
| `^music`  | prefix-exact-match         | Items that start with `music`        |
| `.mp3$`   | suffix-exact-match         | Items that end with `.mp3`           |
| `!fire`   | inverse-exact-match         | Items that do not include `fire`     |
| `!^music` | inverse-prefix-exact-match | Items that do not start with `music` |
| `!.mp3$`  | inverse-suffix-exact-match  | Items that do not end with `.mp3`    |

A standalone `|` is an OR operator. For example:

```text
^core go$ | rb$ | py$
```

The `--exact` or `-e` option makes terms exact. With this option enabled, the quote prefix reverses that behavior.

## tmux Integration

`fzf-tmux` opens a finder in a tmux pane or popup. Outside tmux, it ignores pane-placement flags and still runs fzf.

```sh
# usage: fzf-tmux [LAYOUT OPTIONS] [--] [FZF OPTIONS]

# See available options
fzf-tmux --help

# select git branches in horizontal split below (15 lines)
git branch | fzf-tmux -d 15

# select multiple words in vertical split on the left (20% of screen width)
cat /usr/share/dict/words | fzf-tmux -l 20% --multi --reverse
```

## Shell Integration

Shell bindings provide shortcuts for common searches:

- `Ctrl-T` inserts selected paths.
- `Ctrl-R` inserts command history. Pressing it again toggles relevance sorting.
- `Alt-C` changes to a selected directory.

These behaviors can be customized with `FZF_CTRL_T_COMMAND`, `FZF_CTRL_T_OPTS`, `FZF_CTRL_R_OPTS`, `FZF_ALT_C_COMMAND`, `FZF_ALT_C_OPTS`, and `FZF_TMUX_OPTS`.

For Bash and Zsh path completion, normally type `**` followed by Tab:

```sh
# Files under current directory
# - You can select multiple items with TAB key
vim **<TAB>

# Files under parent directory
vim ../**<TAB>

# Files under parent directory that match `fzf`
vim ../fzf**<TAB>

# Files under your home directory
vim ~/**<TAB>


# Directories under current directory (single-selection)
cd **<TAB>

# Directories under ~/github that match `fzf`
cd ~/github/fzf**<TAB>
```

Process completion uses Tab without a trigger:

```sh
# Can select multiple processes with <TAB> or <Shift-TAB> keys
kill -9 <TAB>
```

Hosts for SSH and Telnet completion come from `/etc/hosts` and `~/.ssh/config`:

```sh
ssh **<TAB>
telnet **<TAB>
```

Completion also covers environment variables and aliases:

```sh
unset **<TAB>
export **<TAB>
unalias **<TAB>
```

Bash enables a predefined command set. Extend it with `_fzf_setup_completion`:

```sh
# usage: _fzf_setup_completion path|dir|var|alias|host COMMANDS...
_fzf_setup_completion path ag git kubectl
_fzf_setup_completion dir tree
```

The completion trigger and fzf options can be changed:

```sh
# Use ~~ as the trigger sequence instead of the default **
export FZF_COMPLETION_TRIGGER='~~'

# Options to fzf command
export FZF_COMPLETION_OPTS='+c -x'
```

Completion path generation can use `fd`:

```sh
_fzf_compgen_path() {
  fd --hidden --follow --exclude ".git" . "$1"
}

_fzf_compgen_dir() {
  fd --type d --hidden --follow --exclude ".git" . "$1"
}
```

`_fzf_comprun` provides experimental advanced customization. Its first argument is the command name, and the remaining arguments must be passed to fzf:

```sh
_fzf_comprun() {
  local command=$1
  shift

  case "$command" in
    cd)           fzf "$@" --preview 'tree -C {} | head -200' ;;
    export|unset) fzf "$@" --preview "eval 'echo \$'{}" ;;
    ssh)          fzf "$@" --preview 'dig {}' ;;
    *)            fzf "$@" ;;
  esac
}
```

## Custom Completion

The experimental completion API defines `_fzf_complete_COMMAND` and calls `_fzf_complete`. Options before `--` are fzf options. Arguments after `--` preserve the original completion arguments. Process substitution supplies candidates.

```sh
# Custom fuzzy completion for "doge" command
#   e.g. doge **<TAB>
_fzf_complete_doge() {
  _fzf_complete --multi --reverse --prompt="doge> " -- "$@" < <(
    echo very
    echo wow
    echo such
    echo doge
  )
}
```

Zsh discovers completion names automatically. Bash requires completion registration:

```sh
[ -n "$BASH" ] && complete -F _fzf_complete_doge -o default -o bashdefault doge
```

A `_fzf_complete_COMMAND_post` function can process results:

```sh
_fzf_complete_foo() {
  _fzf_complete --multi --reverse --header-lines=3 -- "$@" < <(
    ls -al
  )
}

_fzf_complete_foo_post() {
  awk '{print $NF}'
}

[ -n "$BASH" ] && complete -F _fzf_complete_foo -o default -o bashdefault foo
```

## Previews and Display

`--preview` executes a command through the user's shell with the current line. The command's output appears in a scrollable split. In the command, `{}` is replaced with the single-quoted focused line:

```bash
# {} is replaced to the single-quoted string of the focused line
fzf --preview 'cat {}'
```

For highlighted file output, use `bat`:

```bash
fzf --preview 'bat --style=numbers --color=always --line-range :500 {}'
```

`--preview-window` controls the preview layout. `--color` controls colors, and ANSI highlighting is supported:

```bash
fzf --height 40% --layout reverse --info inline --border \
    --preview 'file {}' --preview-window down:1:noborder \
    --color 'fg:#bbccdd,fg+:#ddeeff,bg:#334455,preview-bg:#223344,border:#778899'
```

A file-specific preview should not be placed in universal `FZF_DEFAULT_OPTS`, because fzf input may contain processes, numbers, history, or other text that is not a list of files:

```sh
# *********************
# ** DO NOT DO THIS! **
# *********************
export FZF_DEFAULT_OPTS='--preview "bat --style=numbers --color=always --line-range :500 {}"'

# bat doesn't work with any input other than the list of files
ps -ef | fzf
seq 100 | fzf
history | fzf
```

## Sources and File Discovery

`find` can be replaced with `fd`, `rg`, or `ag`. These tools can respect `.gitignore`. For example:

```sh
# Feed the output of fd into fzf
fd --type f | fzf

# Setting fd as the default source for fzf
export FZF_DEFAULT_COMMAND='fd --type f'

# Now fzf (w/o pipe) will use fd instead of find
fzf

# To apply the command to CTRL-T as well
export FZF_CTRL_T_COMMAND="$FZF_DEFAULT_COMMAND"
```

Hidden files, symlink traversal, and Git exclusion can be configured together:

```sh
export FZF_DEFAULT_COMMAND='fd --type f --hidden --follow --exclude .git'
```

Fish uses the last command-line token as the recursive-search root for `Ctrl-T`. A custom `FZF_CTRL_T_COMMAND` uses the unexpanded directory variable and defaults to `.` when the directory is invalid:

```sh
set -g FZF_CTRL_T_COMMAND "command find -L \$dir -type f 2> /dev/null | sed '1d; s#^\./##'"
```

## Advanced Bindings

`execute` and `execute-silent` bindings launch external processes:

```bash
# Press F1 to open the file with less without leaving fzf
# Press CTRL-Y to copy the line to clipboard and aborts fzf (requires pbcopy)
fzf --bind 'f1:execute(less -f {}),ctrl-y:execute-silent(echo {} | pbcopy)+abort'
```

A `reload` binding updates candidates when a key or event occurs. This example reloads processes with `Ctrl-R`:

```sh
FZF_DEFAULT_COMMAND='ps -ef' \
  fzf --bind 'ctrl-r:reload($FZF_DEFAULT_COMMAND)' \
      --header 'Press CTRL-R to reload' --header-lines=1 \
      --height=50% --layout=reverse
```

The source can switch between files and directories:

```sh
FZF_DEFAULT_COMMAND='find . -type f' \
  fzf --bind 'ctrl-d:reload(find . -type d),ctrl-f:reload($FZF_DEFAULT_COMMAND)' \
      --height=50% --layout=reverse
```

A changing query can drive a ripgrep search. `{q}` expands to the current query. `--phony` prevents fzf from applying secondary filtering, while `|| true` suppresses warnings from ripgrep's no-match exit:

```sh
INITIAL_QUERY=""
RG_PREFIX="rg --column --line-number --no-heading --color=always --smart-case "
FZF_DEFAULT_COMMAND="$RG_PREFIX '$INITIAL_QUERY'" \
  fzf --bind "change:reload:$RG_PREFIX {q} || true" \
      --ansi --phony --query "$INITIAL_QUERY" \
      --height=50% --layout=reverse
```

`--ansi` slows initial scanning. `--nth` adds tokenization, and `--with-nth` also reconstructs lines. The default matching algorithm is `v2`; `--algo=v1` is a faster greedy alternative that may produce worse match ordering.

Wiki pages provide additional examples, binding tips, and related projects.
