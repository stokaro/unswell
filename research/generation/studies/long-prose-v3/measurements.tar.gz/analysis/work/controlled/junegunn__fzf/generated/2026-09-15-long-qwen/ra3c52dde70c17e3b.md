# fzf: Interactive Command-Line Filter Documentation

fzf is a powerful, interactive command-line filter designed for arbitrary text lists. It supports various data types including file paths, command history, processes, hosts, bookmarks, and git commits. The software consists of several key components: the core dependency-free executable, `fzf-tmux` for terminal multiplexer integration, shell bindings for Bash, Zsh, and Fish, fuzzy completion systems for Bash and Zsh, and Vim/Neovim integration. The core executable can be installed independently of the shell bindings. fzf is licensed under the MIT license, with copyright held by Junegunn Choi from 2013 to 2020.

## Installation

fzf can be installed through various package managers depending on the operating system. On macOS, users can install fzf via Homebrew or MacPorts. For Linux and BSD systems, a variety of package managers are supported. On Windows, binaries are available for direct download, or users can utilize Chocolatey or Scoop.

Using Homebrew, the installation is straightforward:
```sh
brew install fzf

# To install useful key bindings and fuzzy completion:
$(brew --prefix)/opt/fzf/install
```

Alternatively, users can clone the repository directly from GitHub. This method involves cloning the repository into a local directory and running the install script:
```sh
git clone --depth 1 https://github.com/junegunn/fzf.git ~/.fzf
~/.fzf/install
```

For Linux and BSD distributions, the following commands apply to specific package managers:

| Package Manager | Linux Distribution      | Command                            |
| ---             | ---                     | ---                                |
| APK             | Alpine Linux            | `sudo apk add fzf`                 |
| APT             | Debian 9+/Ubuntu 19.10+ | `sudo apt-get install fzf`         |
| Conda           |                         | `conda install -c conda-forge fzf` |
| DNF             | Fedora                  | `sudo dnf install fzf`             |
| Nix             | NixOS, etc.             | `nix-env -iA nixpkgs.fzf`          |
| Pacman          | Arch Linux              | `sudo pacman -S fzf`               |
| pkg             | FreeBSD                 | `pkg install fzf`                  |
| pkg_add         | OpenBSD                 | `pkg_add fzf`                      |
| XBPS            | Void Linux              | `sudo xbps-install -S fzf`         |
| Zypper          | openSUSE                | `sudo zypper install fzf`          |

On Windows, installation via Chocolatey or Scoop is performed as follows:

| Package manager | Command             |
| ---             | ---                 |
| Chocolatey      | `choco install fzf` |
| Scoop           | `scoop install fzf` |

For Vim or Neovim users utilizing vim-plug, fzf integration can be installed as an optional update hook:
```vim
Plug 'junegunn/fzf', { 'do': { -> fzf#install() } }
```

Note that package installations may leave shell bindings and fuzzy completion disabled by default. Users should consult the specific package instructions to enable these features. Source builds are covered in the `BUILD.md` file included in the repository.

## Core Usage and Navigation

The fzf finder reads candidates from standard input and writes selected items to standard output. When invoked without a pipe, it automatically invokes the `find` command to list files, excluding hidden files by default. This default command can be replaced using the `FZF_DEFAULT_COMMAND` environment variable when the input is a terminal. Default options can be supplied via `FZF_DEFAULT_OPTS`.

Navigation within fzf is intuitive. Users can move up and down using `Ctrl-J`/`Ctrl-K` or `Ctrl-N`/`Ctrl-P`. Pressing `Enter` accepts the current selection, while `Ctrl-C`, `Ctrl-G`, or `Escape` exits the interface. In multi-select mode (`-m`), items can be marked using `Tab` or `Shift-Tab`. Mouse selection and scrolling are also available, along with Emacs-style key bindings.

The default layout is fullscreen and bottom-up. The `--height` option allows users to start the interface below the cursor. The `--reverse` and `--layout` options adjust the direction of the list.

## Query Syntax

fzf supports extended queries that combine space-separated terms. Ordinary fuzzy text matches items containing the characters in any order. Quoted text enforces exact matches. The `^` prefix denotes a prefix-exact match, while `$` suffix denotes a suffix-exact match. The `!` character creates inverse variants. The `--exact` or `-e` flag makes all terms exact, and the quote prefix then reverses this behavior. A standalone `|` acts as an OR operator.

The following table details the query tokens:

| Token     | Match type                 | Description                          |
| --------- | -------------------------- | ------------------------------------ |
| `sbtrkt`  | fuzzy-match                | Items that match `sbtrkt`            |
| `'wild`   | exact-match (quoted)       | Items that include `wild`            |
| `^music`  | prefix-exact-match         | Items that start with `music`        |
| `.mp3$`   | suffix-exact-match         | Items that end with `.mp3`           |
| `!fire`   | inverse-exact-match        | Items that do not include `fire`     |
| `!^music` | inverse-prefix-exact-match | Items that do not start with `music` |
| `!.mp3$`  | inverse-suffix-exact-match | Items that do not end with `.mp3`    |

An example of combining these tokens is:
```
^core go$ | rb$ | py$
```

## Shell Integration and Bindings

fzf provides shell integration for Bash, Zsh, and Fish. The `fzf-tmux` script opens a pane or popup within a tmux session. Outside of tmux, it ignores pane-placement flags and runs normally.

```sh
# usage: fzf-tmux [LAYOUT OPTIONS] [--] [FZF OPTIONS]

# See available options
fzf-tmux --help

# select git branches in horizontal split below (15 lines)
git branch | fzf-tmux -d 15

# select multiple words in vertical split on the left (20% of screen width)
cat /usr/share/dict/words | fzf-tmux -l 20% --multi --reverse
```

Key bindings allow for seamless interaction. `Ctrl-T` inserts selected paths into the command line. `Ctrl-R` inserts command history and toggles relevance sorting on a repeat press. `Alt-C` changes to a selected directory. These behaviors can be customized using environment variables such as `FZF_CTRL_T_COMMAND`, `FZF_CTRL_T_OPTS`, `FZF_CTRL_R_OPTS`, `FZF_ALT_C_COMMAND`, `FZF_ALT_C_OPTS`, and `FZF_TMUX_OPTS`.

### Fuzzy Completion

Fuzzy completion is available for Bash and Zsh. Path completion normally uses `**` followed by `Tab`. For example:
```sh
# Files under current directory
# - You can select multiple items with TAB key
vim **<TAB>

# Files under parent directory
vim ../**<TAB>

# Files under parent directory that match `fzf`
vim ../fzf**<TAB>

# Files under your home directory
vim ~/**<TAB>

# Directories under current directory (single-selection)
cd **<TAB>

# Directories under ~/github that match `fzf`
cd ~/github/fzf**<TAB>
```

Process completion for `kill` uses `Tab` without a trigger:
```sh
# Can select multiple processes with <TAB> or <Shift-TAB> keys
kill -9 <TAB>
```

Host completion for `ssh` and `telnet` comes from `/etc/hosts` and `~/.ssh/config`:
```sh
ssh **<TAB>
telnet **<TAB>
```

Completion also covers environment variables and aliases:
```sh
unset **<TAB>
export **<TAB>
unalias **<TAB>
```

Bash enables a predefined command set, which can be extended using `_fzf_setup_completion`:
```sh
_fzf_setup_completion path ag git kubectl
_fzf_setup_completion dir tree
```

The experimental completion API allows users to define custom completions by naming a function `_fzf_complete_COMMAND` and calling `_fzf_complete`. Arguments before `--` are passed to fzf, while arguments after `--` preserve original completion arguments. Process substitution supplies candidates. Zsh discovers these names automatically, whereas Bash requires `complete` registration. A `_fzf_complete_COMMAND_post` function can process results.

Example custom completion for the "doge" command:
```sh
_fzf_complete_doge() {
  _fzf_complete --multi --reverse --prompt="doge> " -- "$@" < <(
    echo very
    echo wow
    echo such
    echo doge
  )
}

[ -n "$BASH" ] && complete -F _fzf_complete_doge -o default -o bashdefault doge
```

Another example demonstrating post-processing:
```sh
_fzf_complete_foo() {
  _fzf_complete --multi --reverse --header-lines=3 -- "$@" < <(
    ls -al
  )
}

_fzf_complete_foo_post() {
  awk '{print $NF}'
}

[ -n "$BASH" ] && complete -F _fzf_complete_foo -o default -o bashdefault foo
```

## Advanced Bindings and Previews

fzf supports advanced bindings and preview windows. The `--ansi` flag slows initial scanning but enables ANSI color codes. The `--nth` option adds tokenization, and `--with-nth` reconstructs lines. The `--algo=v1` option provides a faster greedy alternative to the default `v2` algorithm, though it may result in worse match ordering.

Bindings allow launching external processes. For example, pressing `F1` can open a file with `less`, and `Ctrl-Y` can copy the line to the clipboard:
```bash
fzf --bind 'f1:execute(less -f {}),ctrl-y:execute-silent(echo {} | pbcopy)+abort'
```

The `reload` binding updates candidates on a key press or event. This is useful for switching sources or performing dynamic searches. For example, reloading process lists or switching between file and directory searches:
```sh
FZF_DEFAULT_COMMAND='ps -ef' \
  fzf --bind 'ctrl-r:reload($FZF_DEFAULT_COMMAND)' \
      --header 'Press CTRL-R to reload' --header-lines=1 \
      --height=50% --layout=reverse
```

```sh
FZF_DEFAULT_COMMAND='find . -type f' \
  fzf --bind 'ctrl-d:reload(find . -type d),ctrl-f:reload($FZF_DEFAULT_COMMAND)' \
      --height=50% --layout=reverse
```

A change-bound ripgrep search uses `{q}` to substitute the query, `--phony` to avoid secondary filtering, and `|| true` to suppress warnings from ripgrep when no matches are found:
```sh
INITIAL_QUERY=""
RG_PREFIX="rg --column --line-number --no-heading --color=always --smart-case "
FZF_DEFAULT_COMMAND="$RG_PREFIX '$INITIAL_QUERY'" \
  fzf --bind "change:reload:$RG_PREFIX {q} || true" \
      --ansi --phony --query "$INITIAL_QUERY" \
      --height=50% --layout=reverse
```

The `--preview` option executes a command through the user's shell with the current line, displaying output in a scrollable split. ANSI highlighting is supported. Layout and colors are controlled by `--preview-window` and `--color`.

```bash
# {} is replaced to the single-quoted string of the focused line
fzf --preview 'cat {}'
```

```bash
fzf --preview 'bat --style=numbers --color=always --line-range :500 {}'
```

```bash
fzf --height 40% --layout reverse --info inline --border \
    --preview 'file {}' --preview-window down:1:noborder \
    --color 'fg:#bbccdd,fg+:#ddeeff,bg:#334455,preview-bg:#223344,border:#778899'
```

It is important to note that file-specific previews should not be placed in `FZF_DEFAULT_OPTS` because input may be other text, such as process lists or history. For example:
```sh
# *********************
# ** DO NOT DO THIS! **
# *********************
export FZF_DEFAULT_OPTS='--preview "bat --style=numbers --color=always --line-range :500 {}"'

# bat doesn't work with any input other than the list of files
ps -ef | fzf
seq 100 | fzf
history | fzf
```

Users can replace `find` with tools like `fd`, `rg`, or `ag` to respect `.gitignore` files. For example, setting `fd` as the default source:
```sh
# Feed the output of fd into fzf
fd --type f | fzf

# Setting fd as the default source for fzf
export FZF_DEFAULT_COMMAND='fd --type f'

# Now fzf (w/o pipe) will use fd instead of find
fzf

# To apply the command to CTRL-T as well
export FZF_CTRL_T_COMMAND="$FZF_DEFAULT_COMMAND"
```

To include hidden files and follow symlinks while excluding `.git`:
```sh
export FZF_DEFAULT_COMMAND='fd --type f --hidden --follow --exclude .git'
```

Fish shell users can use the last command-line token as the recursive-search root for `Ctrl-T`. Custom `FZF_CTRL_T_COMMAND` can use the unexpanded `$dir` variable, defaulting to `.` for an invalid directory. For example:
```sh
set -g FZF_CTRL_T_COMMAND "command find -L \$dir -type f 2> /dev/null | sed '1d; s#^\./##'"
```

Wiki pages provide additional examples, binding tips, and related projects for advanced usage.
