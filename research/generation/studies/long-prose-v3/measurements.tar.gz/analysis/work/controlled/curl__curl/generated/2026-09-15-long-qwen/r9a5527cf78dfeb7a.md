How curl Became Like This
=========================

Towards the end of 1996, Daniel Stenberg was writing an IRC bot for an Amiga-related channel on EFnet. He then conceived the idea to make currency-exchange calculations available to Internet Relay Chat (IRC) users. All the necessary data were published on the Web; he simply needed to automate their retrieval.

1996
----

Daniel adopted an existing command-line open-source tool, httpget, which Brazilian Rafael Sagula had written and recently released version 0.1 of. After a few minor adjustments, it performed exactly what he needed.

1997
----

HttpGet 1.0 was released on April 8th, 1997, featuring brand-new HTTP proxy support.

We soon found and fixed support for retrieving currencies over GOPHER. Once FTP download support was added, the project name was changed, and urlget 2.0 was released in August 1997. The days of being HTTP-only were already past.

1998
----

The project slowly grew larger. When upload capabilities were added and the name once again proved misleading, a second name change was made, and on March 20, 1998, curl 4 was released. (The version numbering from the previous names was retained.)

(Unrelated to this project, a company called Curl Corporation registered a US trademark on the name "CURL" on May 18, 1998. That company had already registered the curl.com domain back in November of the previous year. All this was revealed to us much later.)

SSL support was added, powered by the SSLeay library.

In August, there was the first announcement of curl on freshmeat.net.

In October, with the curl 4.9 release and the introduction of cookie support, curl was no longer released under the GPL license. Now that we were at 4000 lines of code, we switched over to the MPL license to restrict the effects of "copyleft".

In November, the configure script was added, and successful compiles were reported on several major operating systems. The never-quite-understood -F option was added, and curl could now simulate quite a lot of a browser. TELNET support was added.

Curl 5 was released in December 1998 and introduced the first ever curl man page. People started making Linux RPM packages out of it.

1999
----

In January, DICT support was added.

OpenSSL took over, and SSLeay was abandoned.

In May, the first Debian package was released.

In August, LDAP:// and FILE:// support was added. The curl website received 1300 visits weekly. The site was moved to curl.haxx.nu.

In September, curl 6.0 was released, consisting of 15000 lines of code.

On December 28, the project was added to Sourceforge, and its services were used for managing the project.

2000
----

In the spring, a major internal overhaul was performed to provide a suitable library interface. The first non-beta release was named 7.1 and arrived in August. This offered the easy interface and turned out to be the beginning of actually getting other software and programs to be based on and powered by libcurl. There were almost 20000 lines of code.

In June, the curl site moved to "curl.haxx.se".

In August, the curl website received 4000 visits weekly.

The PHP guys adopted libcurl already in the same month, when the first ever third-party libcurl binding showed up. CURL has been a supported module in PHP since the release of PHP 4.0.2. This would soon get followers. More than 16 different bindings existed at the time of this writing.

In September, kerberos4 support was added.

In November, work started on a test suite for curl. It was later rewritten from scratch again. The libcurl major SONAME number was set to 1.

2001
----

In January, Daniel released curl 7.5.2 under a new license again: MIT (or MPL). The MIT license is extremely liberal and can be combined with GPL in other projects. This finally put an end to the "complaints" from people involved in GPLed projects that were previously prohibited from using libcurl while it was released under MPL only (due to the fact that MPL is deemed "GPL incompatible").

On March 22, curl supported HTTP 1.1 starting with the release of 7.7. This also introduced libcurl's ability to do persistent connections. There were 24000 lines of code. The libcurl major SONAME number was bumped to 2 due to this overhaul. The first experimental ftps:// support was added.

In August, curl was bundled in Mac OS X, 10.1. It was already becoming more and more of a standard utility of Linux distributions and a regular in the BSD ports collections. The curl website received 8000 visits weekly. Curl Corporation contacted Daniel to discuss "the name issue". After Daniel's reply, they never got back in touch again.

In September, libcurl 7.9 introduced cookie jar and curl_formadd(). During the forthcoming 7.9.x releases, we introduced the multi interface slowly and without many whistles.

2002
----

In June, the curl website received 13000 visits weekly. curl and libcurl comprised 35000 lines of code. Successful compiles were reported on more than 40 combinations of CPUs and operating systems.

To estimate the number of users of the curl tool or libcurl library is next to impossible. Around 5000 downloaded packages each week from the main site gives a hint, but the packages are mirrored extensively, bundled with numerous OS distributions, and otherwise retrieved as part of other software.

On October 1, with the release of curl 7.10, it was released under the MIT license only.

Starting with 7.10, curl verifies SSL server certificates by default.

2003
----

In January, work started on distributed curl tests and autobuilds.

In February, the curl site averaged 20000 visits weekly. At any given moment, there was an average of 3 people browsing the website.

Multiple new authentication schemes were supported: Digest (May), NTLM (June), and Negotiate (June).

In November, curl 7.10.8 was released, consisting of 45000 lines of code. There were approximately 55000 unique visitors to the website and five official web mirrors.

In December, full-fledged SSL for FTP was supported.

2004
----

In January, curl 7.11.0 introduced large file support.

In June, curl 7.12.0 introduced IDN support. There were 10 official web mirrors.

This release bumped the major SONAME to 3 due to the removal of the curl_formparse() function.

In August, Curl and libcurl 7.12.1 were released:

    Public curl release number:                82
    Releases counted from the very beginning: 109
    Available command line options:            96
    Available curl_easy_setopt() options:     120
    Number of public functions in libcurl:     36
    Amount of public website mirrors:         12
    Number of known libcurl bindings:          26

2005
----

In April, GnuTLS could now optionally be used for the secure layer when curl is built.

In April, the multi_socket() API was added.

In September, TFTP support was added.

There were more than 100,000 unique visitors to the curl website and 25 mirrors.

In December, a security vulnerability occurred: libcurl URL Buffer Overflow.

2006
----

In January, we dropped support for Gopher. We found bugs in the implementation that turned out to have been introduced years ago, so with the conclusion that nobody had found out in all this time, we removed it instead of fixing it.

In March, a security vulnerability occurred: libcurl TFTP Packet Buffer Overflow.

In September, the major SONAME number for libcurl was bumped to 4 due to the removal of ftp third-party transfer support.

In November, SCP and SFTP support was added.

2007
----

In February, support was added for the Mozilla NSS library to do the SSL/TLS stuff.

In July, a security vulnerability occurred: libcurl GnuTLS insufficient cert verification.

2008
----

In November:

    Command line options:         128
    curl_easy_setopt() options:   158
    Public functions in libcurl:   58
    Known libcurl bindings:        37
    Contributors:                 683

There were 145,000 unique visitors and more than 100 GB downloaded.

2009
----

In March, a security vulnerability occurred: libcurl Arbitrary File Access.

In April, CMake support was added.

In August, a security vulnerability occurred: libcurl embedded zero in cert name.

In December, support was added for IMAP, POP3, and SMTP.

2010
----

In January, support was added for RTSP.

In February, a security vulnerability occurred: libcurl data callback excessive length.

In March, the project switched over to use git (hosted by GitHub) instead of CVS for source code control.

In May, support was added for RTMP and for PolarSSL to do the SSL/TLS stuff.

In August:

    Public curl releases:         117
    Command line options:         138
    curl_easy_setopt() options:   180
    Public functions in libcurl:   58
    Known libcurl bindings:        39
    Contributors:                 808

Gopher support was added (re-added actually, see January 2006).

2011
----

In February, support was added for the axTLS backend.

In April, the cyassl backend was added (later renamed to WolfSSL).

2012
----

In July, support was added for Schannel (native Windows TLS backend) and Darwin SSL (Native Mac OS X and iOS TLS backend). It supports metalink.

In October, SSH-agent support was added.

2013
----

In February, internals were cleaned up to always use the "multi" non-blocking approach internally and only expose the blocking API with a wrapper.

In September, first small steps were taken on supporting HTTP/2 with nghttp2.

In October, krb4 support was removed.

In December, Happy eyeballs support was added.

2014
----

In March, the first real release supporting HTTP/2 was released.

In September, the website had 245,000 unique visitors and served 236GB of data.

SMB and SMBS support was added.

2015
----

In June, support for multiplexing with HTTP/2 was added.

In August, support for HTTP/2 server push was added.

In December, the Public Suffix List was added.

2016
----

In January, the curl tool defaulted to HTTP/2 for HTTPS URLs.

In December, curl 7.52.0 introduced support for HTTPS-proxy!

First TLS 1.3 support was added.

2017
----

In July, OSS-Fuzz started fuzzing libcurl.

In September, Multi-SSL support was added.

The website served 3100 GB/month.

    Public curl releases:         169
    Command line options:         211
    curl_easy_setopt() options:   249
    Public functions in libcurl:  74
    Contributors:                 1609

In October, SSLKEYLOGFILE support and a new MIME API were added.

In October, Daniel received the Polhem Prize for his work on curl.

In November, brotli support was added.

2018
----

In January, a new SSH backend powered by libssh was added.

In March, starting with the 1803 release of Windows 10, curl is shipped bundled with Microsoft's operating system.

In July, curl shows headers using bold type face.

In October, DNS-over-HTTPS (DoH) and the URL API were added.

MesaLink is a new supported TLS backend.

libcurl now does HTTP/2 (and multiplexing) by default on HTTPS URLs.

curl and libcurl are installed in an estimated 5 *billion* instances world-wide.

On October 31, Curl and libcurl 7.62.0 were released:

    Public curl releases:         177
    Command line options:         219
    curl_easy_setopt() options:   261
    Public functions in libcurl:   80
    Contributors:                 1808

In December, axTLS support was removed.

2019
----

In March, experimental alt-svc support was added.

In August, the first HTTP/3 requests with curl were made.

In September, 7.66.0 was released, and the tool offered parallel downloads.

2020
----

curl and libcurl are installed in an estimated 10 *billion* instances world-wide.

In January, BearSSL support was added.

In March, support for PolarSSL was removed, and wolfSSH support was added.

In April, experimental MQTT support was added.

In August, zstd support was added.

In November, the website moved to www.curl.se. The website serves 10TB of data monthly.
