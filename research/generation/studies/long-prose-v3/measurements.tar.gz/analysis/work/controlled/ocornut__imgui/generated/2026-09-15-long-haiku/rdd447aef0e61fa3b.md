# Dear ImGui: Architecture, Integration, and Development

## Overview

Dear ImGui is a self-contained, renderer-independent C++ GUI library designed for programmers building creation, visualization, and debugging tools. The library has no external dependencies and is particularly well-suited for game-engine, real-time 3D, fullscreen, embedded, and console applications. Unlike comprehensive UI frameworks, Dear ImGui intentionally omits higher-level and end-user UI features, focusing instead on immediate-mode rendering that integrates seamlessly into existing graphics pipelines.

The library produces vertex buffers and command lists for rendering, allowing applications to incorporate GUI functionality directly into their 3D rendering pipelines. This architectural approach makes Dear ImGui fundamentally different from retained-mode UI systems and enables its use in contexts where traditional UI frameworks are impractical or inefficient.

## Core Architecture

Dear ImGui employs an immediate-mode UI paradigm that fundamentally changes how developers structure user interface code. In the immediate-mode model, GUI elements are not retained in a persistent structure between frames. Instead, they are defined procedurally during each frame's execution. This approach minimizes duplicated, synchronized, and retained application state, making it particularly effective for building dynamic interfaces.

A critical misconception about immediate-mode UI is that every widget generates an immediate GPU call. In reality, Dear ImGui batches rendering operations into a small list of draw calls and buffers these commands for later rendering. This means GUI calls can occur throughout the program loop, including within algorithms or rendering code, without directly altering graphics state. The actual rendering occurs at a point where the application controls the graphics pipeline.

The library's architecture makes it exceptionally valuable for temporary hot-reloaded controls, algorithm traces, data inspection, logs, profilers, debuggers, and various development tools. Because the UI state is not retained between frames, developers can easily toggle interface elements on and off, modify layouts dynamically, and respond immediately to changes without managing complex state synchronization.

## Integration and Compilation

Integrating Dear ImGui into an existing project requires minimal setup. Developers compile the root C++ files—imgui.cpp, imgui_demo.cpp, and imgui_draw.cpp—directly into their project. No special build system is required, making integration straightforward regardless of the project's existing build infrastructure.

The library's architecture separates concerns into two primary components: a backend and the core GUI system. A backend is responsible for feeding mouse, keyboard, and gamepad inputs to Dear ImGui and managing the rendering surface. The backend also loads one texture and supplies textured-triangle rendering capabilities. Official examples provide reference backends for various platforms and renderers, though custom backends are possible for specialized requirements.

The integration process is notably flexible. Because GUI calls can occur anywhere in the program loop without directly affecting graphics state, developers have considerable freedom in where and when to incorporate Dear ImGui function calls. This flexibility is crucial for adding debugging interfaces to existing rendering code or embedding UI systems into complex applications.

## Rendering and Platform Support

Dear ImGui supports an extensive array of rendering backends and platform integration layers. Official renderers include DirectX 9, DirectX 10, DirectX 11, DirectX 12, legacy OpenGL, modern OpenGL 3 with ES and ES2 support, Vulkan, and Metal. This breadth of rendering support ensures that Dear ImGui can integrate with virtually any modern graphics API.

Platform support includes GLFW, SDL2, Win32, GLUT, and OSX, providing input handling and window management integration across major operating systems and window frameworks. Additionally, framework support extends to Emscripten for web-based applications, Allegro5 for game development, and Marmalade for mobile platforms.

The recommended approach for most applications is combining existing platform and renderer backends rather than creating entirely custom solutions. This strategy leverages battle-tested integration points and reduces the burden of maintaining platform-specific code. The supplied reference documentation includes third-party language bindings and framework integrations.

Dear ImGui also provides C bindings through cimgui, which are automatically generated. These bindings expose JSON and Lua data structures that other binding generators can use to create language-specific interfaces. This approach has resulted in extensive third-party bindings including C#, Python, Rust, Go, Haskell, JavaScript, and many other languages. Framework-level bindings exist for Godot, Unity, Unreal Engine 4, and numerous other game engines and graphics frameworks.

## API and Features

The Dear ImGui API is straightforward and designed around immediate-mode principles. Basic widgets like text, buttons, and input fields are declared directly in code. The following code demonstrates fundamental API usage:

```cpp
ImGui::Text("Hello, world %d", 123);
if (ImGui::Button("Save"))
    MySaveFunction();
ImGui::InputText("string", buf, IM_ARRAYSIZE(buf));
ImGui::SliderFloat("float", &f, 0.0f, 1.0f);
```

More complex layouts combine multiple widgets within windows, menus, and layout containers. The following example demonstrates a windowed tool with a menu bar:

```cpp
ImGui::Begin("My First Tool", &my_tool_active, ImGuiWindowFlags_MenuBar);
if (ImGui::BeginMenuBar())
{
    if (ImGui::BeginMenu("File"))
    {
        if (ImGui::MenuItem("Open..", "Ctrl+O")) { /* Do stuff */ }
        if (ImGui::MenuItem("Save", "Ctrl+S"))   { /* Do stuff */ }
        if (ImGui::MenuItem("Close", "Ctrl+W"))  { my_tool_active = false; }
        ImGui::EndMenu();
    }
    ImGui::EndMenuBar();
}

ImGui::ColorEdit4("Color", my_color);

const float my_values[] = { 0.2f, 0.1f, 1.0f, 0.5f, 0.9f, 2.2f };
ImGui::PlotLines("Frame Times", my_values, IM_ARRAYSIZE(my_values));

ImGui::TextColored(ImVec4(1,1,0,1), "Important Stuff");
ImGui::BeginChild("Scrolling");
for (int n = 0; n < 50; n++)
    ImGui::Text("%04d: Some text", n);
ImGui::EndChild();
ImGui::End();
```

The API includes support for color editing, plotting and data visualization, scrolling regions, and hierarchical window management. The ImGui::ShowDemoWindow function displays implemented features through imgui_demo.cpp, providing both documentation and interactive examples of available functionality.

## Development and Roadmap

Dear ImGui's development roadmap outlines significant planned enhancements. The 2020 development plans include docking and multiple viewports with native OS window support, implemented on the dedicated docking branch. Gamepad and keyboard control improvements are planned to enhance input flexibility for non-mouse environments.

A Tables API is under development on the tables branch, designed to replace the existing Columns functionality with more robust data layout capabilities. Automated library and application testing infrastructure is planned to improve code quality and regression detection. Enhanced styles, fonts, and HiDPI examples are also scheduled, addressing visual fidelity and high-resolution display support.

These development plans actively solicit community feedback and represent the library's commitment to evolving based on user needs. The master and latest branches are recommended for most users as generally stable, while advanced users requiring cutting-edge features may use the regularly synchronized docking branch.

## Documentation and Support

Dear ImGui provides comprehensive documentation including releases, interactive demos, a frequently asked questions document, a community wiki, paradigm articles, binding lists, user galleries, community quotes, and software listings demonstrating Dear ImGui in production use.

For users encountering setup, input, or font-related problems, the Dear ImGui Discord community provides peer support and direct assistance. Other questions, bug reports, feature requests, and general feedback should be directed to GitHub issues using the provided template. Businesses requiring priority assistance and guaranteed response times can obtain private support through direct contact at contact@dearimgui.com.

The master and latest branches are recommended for general use and are maintained as generally stable. Advanced developers and those requiring early access to new features may use the regularly synchronized docking branch, though this branch receives less formal testing than the master branch.

## Community Support and Contributions

Dear ImGui accepts help in multiple forms. Community members can contribute by answering questions in public forums, reporting issues, and submitting maintainable pull requests. Maintainers take ongoing responsibility for all accepted code contributions, ensuring long-term compatibility and stability.

Businesses may sponsor the project through support and maintenance contracts or other arrangements by contacting contact@dearimgui.com. Individual developers can support development through donations or Patreon contributions. From November 2014 through December 2019, ongoing development was financially supported by Patreon contributors and individual donors. The project maintains a detailed sponsor roster recording corporate support.

Free open-source services supporting Dear ImGui development include PVS-Studio for static analysis, GitHub Actions for continuous integration systems, and OpenCppCoverage for code coverage analysis.

## Sponsors and Credits

Dear ImGui has been supported by platinum-chocolate sponsors including Blizzard, Google, Nvidia, and Ubisoft. Double-chocolate and salty caramel sponsors include Activision, Arkane Studios, Dotemu, Framefield, Hexagon, Kylotonn, Media Molecule, Mesh Consultants, Mobigame, Nadeo, Next Level Games, RAD Game Tools, Supercell, Remedy Entertainment, and Unit 2 Games.

Omar Cornut developed Dear ImGui with contributions from the community. The library was initially supported by Media Molecule and used in Tearaway on PlayStation Vita. Rokas Kupstys and Ben Carter were recurring contributors in 2020. The library draws inspiration from Atman Binstock's earlier implementation encountered at Q-Games, which Cornut later rewrote during his time at Media Molecule. Credits include Casey Muratori and early feedback and testing contributors documented in the source code.

Embedded assets include ProggyClean.ttf by Tristan Grimmer under MIT license. Dear ImGui also incorporates stb_textedit.h, stb_truetype.h, and stb_rect_pack.h by Sean Barrett, identified as public domain. Dear ImGui itself is licensed under MIT.

## Conclusion

Dear ImGui provides a sophisticated, production-tested immediate-mode UI system for developers building specialized tools and interfaces. Its architecture, emphasizing renderer independence and integration into existing graphics pipelines, makes it uniquely suited to the constraints of real-time 3D applications, game engines, and specialized development tools. The extensive platform and renderer support, combined with active development and community engagement, ensures that Dear ImGui remains a practical choice for diverse development contexts.
