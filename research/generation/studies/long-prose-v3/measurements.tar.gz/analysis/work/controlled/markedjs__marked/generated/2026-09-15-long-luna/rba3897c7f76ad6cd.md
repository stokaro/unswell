## Extending Marked

Marked is designed to support extensions while following the single-responsibility and open/closed principles. Use the APIs below to add custom functionality.

<h2 id="use">marked.use()</h2>

`marked.use(options)` is the recommended extension method. The options object accepts any [option](/using_advanced#options) available in marked.

The `renderer` and `tokenizer` options can contain objects whose functions are merged into the renderer and tokenizer. These functions can return `false` to fall back to the previous implementation.

`walkTokens` is called for every token before rendering. If `use` is called multiple times with different `walkTokens` functions, they run in reverse assignment order. All other options overwrite previously assigned options.

<h2 id="renderer">The renderer</h2>

The renderer defines parser output. Override renderer methods by passing a `renderer` object:

```js
const marked = require('marked');

const renderer = {
  heading(text, level) {
    const escapedText = text.toLowerCase().replace(/[^\w]+/g, '-');
    return `<h${level}><a name="${escapedText}" class="anchor" href="#${escapedText}">${text}</a></h${level}>`;
  }
};

marked.use({ renderer });
console.log(marked('# heading+'));
```

### Block-level renderer methods

- `code(string code, string infostring, boolean escaped)`
- `blockquote(string quote)`, `html(string html)`
- `heading(string text, number level, string raw, Slugger slugger)`
- `hr()`, `list(string body, boolean ordered, number start)`
- `listitem(string text, boolean task, boolean checked)`, `checkbox(boolean checked)`
- `paragraph(string text)`, `table(string header, string body)`
- `tablerow(string content)`, `tablecell(string content, object flags)`

`slugger.slug(value)` creates unique IDs: `foo`, `foo-1`, and `foo-2`. With `{ dryrun: true }`, it returns the next ID without changing state. `flags` contains `header` and `align`, whose values are Boolean and `center`, `left`, or `right`.

### Inline-level renderer methods

- `strong(string text)`, `em(string text)`, `codespan(string code)`, `br()`
- `del(string text)`, `link(string href, string title, string text)`
- `image(string href, string title, string text)`, `text(string text)`

<h2 id="tokenizer">The tokenizer</h2>

The tokenizer converts Markdown text into tokens. A tokenizer override can return `false` to use the original method. For example, a `codespan` override can match `$...$` and return a `codespan` token with `type`, `raw`, and `text`.

### Block-level tokenizer methods

`space`, `code`, `fences`, `heading`, `nptable`, `hr`, `blockquote`, `list`, `html`, `def`, `table`, `lheading`, `paragraph`, and `text`.

### Inline-level tokenizer methods

`escape`, `tag`, `link`, `reflink`, `strong`, `em`, `codespan`, `br`, `del`, `autolink`, `url`, and `inlineText`.

`mangle` converts text to HTML character references. `smartypants` converts ASCII punctuation to typographic punctuation HTML entities.

<h2 id="walk-tokens">Walk Tokens</h2>

`walkTokens` receives every token by reference. Child tokens are visited before sibling tokens, and updates persist when the parser receives the token. Its return value is ignored.

<h2 id="lexer">The lexer</h2>

The lexer accepts Markdown text and calls tokenizer methods.

<h2 id="parser">The parser</h2>

The parser accepts tokens and calls renderer methods.

<h2 id="extend">Access to lexer and parser</h2>

Access the lexer and parser directly:

```js
const tokens = marked.lexer(markdown, options);
console.log(marked.parser(tokens, options));
```

`new marked.Lexer(options)` exposes `lex(markdown)`, token output, and block and inline tokenizer rules. `marked.Lexer.rules` exposes all block and inline rules. The lexer builds the token array, which the parser processes into HTML.
