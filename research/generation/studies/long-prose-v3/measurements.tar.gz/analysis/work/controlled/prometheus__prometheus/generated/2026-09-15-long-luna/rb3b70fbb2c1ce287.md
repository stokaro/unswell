# Releases

This page describes the release process, the planned schedule for upcoming releases, and the respective release shepherd. Release shepherds are chosen on a voluntary basis.

## Release schedule

The cadence for cutting the first pre-releases is six weeks.

| release series | date of first pre-release (year-month-day) | release shepherd                            |
|----------------|--------------------------------------------|---------------------------------------------|
| v2.4           | 2018-09-06                                 | Goutham Veeramachaneni (GitHub: @gouthamve) |
| v2.5           | 2018-10-24                                 | Frederic Branczyk (GitHub: @brancz)         |
| v2.6           | 2018-12-05                                 | Simon Pasquier (GitHub: @simonpasquier)     |
| v2.7           | 2019-01-16                                 | Goutham Veeramachaneni (GitHub: @gouthamve) |
| v2.8           | 2019-02-27                                 | Ganesh Vernekar (GitHub: @codesome)         |
| v2.9           | 2019-04-10                                 | Brian Brazil (GitHub: @brian-brazil)        |
| v2.10          | 2019-05-22                                 | Björn Rabenstein (GitHub: @beorn7)          |
| v2.11          | 2019-07-03                                 | Frederic Branczyk (GitHub: @brancz)         |
| v2.12          | 2019-08-14                                 | Julius Volz (GitHub: @juliusv)              |
| v2.13          | 2019-09-25                                 | Krasi Georgiev (GitHub: @krasi-georgiev)    |
| v2.14          | 2019-11-06                                 | Chris Marchbanks (GitHub: @csmarchbanks)    |
| v2.15          | 2019-12-18                                 | Bartek Plotka (GitHub: @bwplotka)           |
| v2.16          | 2020-01-29                                 | Callum Styan (GitHub: @cstyan)              |
| v2.17          | 2020-03-11                                 | Julien Pivotto (GitHub: @roidelapluie)      |
| v2.18          | 2020-04-22                                 | Bartek Plotka (GitHub: @bwplotka)           |
| v2.19          | 2020-06-03                                 | Ganesh Vernekar (GitHub: @codesome)         |
| v2.20          | 2020-07-15                                 | Björn Rabenstein (GitHub: @beorn7)          |
| v2.21          | 2020-08-26                                 | Julien Pivotto (GitHub: @roidelapluie)      |
| v2.22          | 2020-10-07                                 | Frederic Branczyk (GitHub: @brancz)         |
| v2.23          | 2020-11-18                                 | Ganesh Vernekar (GitHub: @codesome)         |
| v2.24          | 2020-12-30                                 | Björn Rabenstein (GitHub: @beorn7)          |
| v2.25          | 2021-02-10                                 | **searching for volunteer**                 |

If you are interested in volunteering, create a pull request against the [prometheus/prometheus](https://github.com/prometheus/prometheus) repository and propose yourself for the release series of your choice.

## Release shepherd responsibilities

The release shepherd is responsible for the entire release series of a minor release, including all pre-releases and patch releases. The process formally starts with the initial pre-release, but some preparations should be completed a few days in advance.

* We aim to keep the master branch in a working state at all times. In principle, it should be possible to cut a release from master at any time. In practice, things might not work out as well. A few days before the scheduled pre-release, the shepherd should check the state of master. Using their best judgment, the shepherd should try to expedite bug fixes that are still in progress but should be included in the release. On the other hand, the shepherd may hold back last-minute invasive and risky changes that are better suited for the next minor release.
* On the date listed in the table above, the release shepherd cuts the first pre-release, using the suffix `-rc.0`, and creates a new branch called `release-<major>.<minor>` starting at the commit tagged for the pre-release. In general, a pre-release is considered a release candidate—that is what `rc` stands for—and should therefore not contain any known bugs planned to be fixed in the final release.
* With the pre-release, the release shepherd is responsible for running and monitoring a benchmark of the pre-release for three days. If it succeeds, the pre-release is promoted to a stable release.
* If regressions or critical bugs are detected, they must be fixed before cutting a new pre-release, such as `-rc.1`, `-rc.2`, and so on.

See the next section for details on cutting an individual release.

## How to cut an individual release

These instructions are currently valid for the Prometheus server, that is, the [prometheus/prometheus repository](https://github.com/prometheus/prometheus). Applicability to other Prometheus repositories depends on the current state of each repository. We aspire to unify the release procedures as much as possible.

### Branch management and versioning strategy

We use [Semantic Versioning](https://semver.org/).

We maintain a separate branch for each minor release, named `release-<major>.<minor>`, such as `release-1.1` or `release-2.0`.

Note that branch protection is automatically enabled for branches whose names start with `release-`. Never use names starting with `release-` for branches that are not release branches.

The usual flow is to merge new features and changes into the master branch and bug fixes into the latest release branch. Bug fixes are then merged into master from the latest release branch. The master branch should always contain all commits from the latest release branch. As long as master has not deviated from the release branch, new commits can also go to master, followed by merging master back into the release branch.

If a bug fix was accidentally merged into master after non-bug-fix changes, the bug-fix commits must be cherry-picked into the release branch, which must then be merged back into master. Try to avoid this situation.

Maintaining release branches for older minor releases occurs on a best-effort basis.

### 0. Updating dependencies

A few days before a major or minor release, consider updating the dependencies.

Then create a pull request against the master branch.

After updating dependencies, look for any unexpected behavior that might have occurred. This includes, but is not limited to, flaky tests, differences in resource usage, and panics.

If there is any doubt or an issue cannot be resolved in a reasonable amount of time, you can skip the dependency update or update only selected dependencies. In that case, create an issue or pull request in the GitHub project for later follow-up.

#### Updating Go dependencies

```
make update-go-deps
git add go.mod go.sum vendor
git commit -m "Update dependencies"
```

#### Updating React dependencies

Either upgrade the dependencies within their existing version constraints, as specified in the `package.json` file (see https://docs.npmjs.com/files/package.json#dependencies):

```
cd web/ui/react-app
yarn upgrade
git add yarn.lock
```

Alternatively, update all dependencies to their latest major versions. This is potentially more disruptive and will require more follow-up fixes, but should be done periodically using your best judgment:

```
cd web/ui/react-app
yarn upgrade --latest
git add package.json yarn.lock
```

### 1. Prepare your release

At the start of a new major or minor release cycle, create the corresponding release branch from the master branch. For example, if releasing `2.17.0` when the previous stable release is `2.16.0`, create a `release-2.17` branch. Note that all releases are handled in protected release branches; see the above `Branch management and versioning` section. Release candidates and patch releases for a given major or minor release use the same `release-<major>.<minor>` branch. Do not create `release-<version>` for patch or release candidate releases.

Changes for a patch release or release candidate should be merged into the previously mentioned release branch through a pull request.

Bump the version in the `VERSION` file and update `CHANGELOG.md`. Do this in a proper pull request targeting the release branch so that others can comment on the release generally and on the changelog additions specifically. For a release candidate, append something such as `-rc.0` to the version, with the corresponding changes to the tag name, release name, and so on.

`CHANGELOG.md` should document only changes relevant to Prometheus users, including external API changes, performance improvements, and new features. Do not document changes to internal interfaces, code refactorings and cleanups, build-process changes, or similar items. People interested in those changes should refer to the Git history.

For release candidates, still update `CHANGELOG.md`. When cutting the final release later, combine all changes from the pre-releases into one final update.

Entries in `CHANGELOG.md` should appear in this order:

* `[CHANGE]`
* `[FEATURE]`
* `[ENHANCEMENT]`
* `[BUGFIX]`

### 2. Draft the new release

Tag the new release with the following commands:

```bash
$ tag="v$(< VERSION)"
$ git tag -s "${tag}" -m "${tag}"
$ git push origin "${tag}"
```

Optionally, you can use this `.gitconfig` alias:

```ini
[alias]
  tag-release = "!f() { tag=v${1:-$(cat VERSION)} ; git tag -s ${tag} -m ${tag} && git push origin ${tag}; }; f"
```

Then run `git tag-release`.

Signing a tag with a GPG key is appreciated. If you cannot add a GPG key to your GitHub account using the following [procedure](https://help.github.com/articles/generating-a-gpg-key/), you can replace the `-s` flag with the `-a` flag in the `git tag` command to annotate the tag without signing it.

Once a tag is created, the release process through CircleCI is triggered for that tag, and CircleCI drafts the GitHub release using the `prombot` account.

Finally, wait for the tag's build step to finish. This ensures that tarballs are uploaded to the GitHub release and container images are pushed to Docker Hub and Quay.io. Once that has happened, click _Publish release_. This makes the release publicly visible and creates a GitHub notification.

**Note:** For a release candidate, ensure that the _This is a pre-release_ box is checked when drafting the release in the GitHub UI. The CI job should handle this, but it is a good idea to double-check before clicking _Publish release_.

### 3. Wrapping up

For release candidate versions, such as `v2.16.0-rc.0`, run the benchmark for three days using the `/prombench vX.Y.Z` command, where `vX.Y.Z` is the latest stable patch release tag from the previous minor release series, such as `v2.15.2`.

If the release was made from the latest release branch, merge the changes into master.

Once the binaries have been uploaded, announce the release on `prometheus-announce@googlegroups.com`. Do not use `prometheus-users@googlegroups.com` for announcements anymore. Review previous announcement emails for inspiration.
