# fzf Release History: 0.9.3–0.24.3

This document records the behavior, interface, rendering, integration, and performance changes introduced in fzf from version 0.9.3 through version 0.24.3. The notes are organized by release so that version-specific behavior and compatibility details remain visible.

## 0.24.3

Version 0.24.3 adds the `--padding` option. Padding can be used together with margins and borders to control the space around the finder and its contents.

```sh
fzf --margin 5% --padding 5% --border --preview 'cat {}' \
    --color bg:#222222,preview-bg:#333333
```

The example combines a five-percent margin, five-percent padding, a border, and a preview window. The preview background is configured independently from the general background.

## 0.24.2 and 0.24.1

Version 0.24.2 contains fixes and improvements.

Version 0.24.1 repairs `--color=bw` and `--color=no`. These color-disabled modes can therefore be used without the behavior affected by the earlier defect.

## 0.24.0

Version 0.24.0 changes preview rendering so that preview output is rendered in real time. The preview window can display output before the preview command completes.

```sh
# fzf can render preview window before the command completes
fzf --preview 'sleep 1; for i in $(seq 100); do echo $i; sleep 0.01; done'
```

The preview window also processes ANSI escape sequences. The following command uses CSI `2 J` to clear the display periodically while output continues:

```sh
# Preview window can process ANSI escape sequence (CSI 2 J) for clearing the display
fzf --preview 'for i in $(seq 100000); do
  (( i % 200 == 0 )) && printf "\033[2J"
  echo "$i"
  sleep 0.01
done'
```

The release adds regular, bold, dim, underline, italic, reverse, and blink color styles. Multiple style attributes can be combined, and `-1` preserves the original color.

```sh
# * Set -1 to keep the original color
# * Multiple style attributes can be combined
# * Italic style may not be supported by some terminals
rg --line-number --no-heading --color=always "" |
  fzf --ansi --prompt "Rg: " \
      --color fg+:italic,hl:underline:-1,hl+:italic:underline:reverse:-1 \
      --color pointer:reverse,prompt:reverse,input:159 \
      --pointer '  '
```

Vertical, top, bottom, left, and right borders are added. Vim borders are adapted to the new border styles. Vim floating windows can use popup dimensions and border directions, including horizontal, vertical, top, and left borders.

```vim
" Floating popup window in the center of the screen
let g:fzf_layout = { 'window': { 'width': 0.9, 'height': 0.6 } }

" Popup with 100% width
let g:fzf_layout = { 'window': { 'width': 1.0, 'height': 0.5, 'border': 'horizontal' } }

" Popup with 100% height
let g:fzf_layout = { 'window': { 'width': 0.5, 'height': 1.0, 'border': 'vertical' } }

" Similar to 'down' layout, but it uses a popup window and doesn't affect the window layout
let g:fzf_layout = { 'window': { 'width': 1.0, 'height': 0.5, 'yoffset': 1.0, 'border': 'top' } }

" Opens on the right;
"   'highlight' option is still supported but it will only take the foreground color of the group
let g:fzf_layout = { 'window': { 'width': 0.5, 'height': 1.0, 'xoffset': 1.0, 'border': 'left', 'highlight': 'Comment' } }
```

Multi-selection mode now displays a zero selected count. The count distinguishes the total candidates from selected candidates and, when a selection limit is present, from the maximum allowed selections.

```sh
seq 100 | fzf
  # 100/100
seq 100 | fzf --multi
  # 100/100 (0)
seq 100 | fzf --multi 5
  # 100/100 (0/5)
```

Version 0.24.0 also starts uploading binaries to GitHub Releases.

## 0.23.1 and 0.23.0

Version 0.23.1 adds the `preview-window` options `nocycle`, `nohidden`, `nowrap`, and `default`. It builds with Go 1.14.9 after performance regression #40727.

Version 0.23.0 adds preview offsets relative to the window height. It also adds `sharp` and `cycle` preview options, reduces padding when borders are absent, and adds half-page preview actions. Vim popup sizes become absolute. The `fzf#exec` function is added for locating and downloading the binary.

The release builds with Go 1.15.2 and stops providing 32-bit binaries.

Preview offsets can use fields from the input. In the following example, the preview scroll offset is based on the line number in `git grep` output, minus five lines:

```sh
# Initial scroll offset is set to the line number of each line of
# git grep output *minus* 5 lines
git grep --line-number '' |
  fzf --delimiter : --preview 'nl {1}' --preview-window +{2}-5
```

## 0.22.0

Version 0.22.0 adds the `backward-eof`, `refresh-preview`, and `preview` bindings.

`backward-eof` can be used to assign an action when backward deletion reaches an empty query. This example aborts the finder in that situation:

```sh
# Aborts when you delete backward when the query prompt is already empty
fzf --bind backward-eof:abort
```

`refresh-preview` reruns the preview command. The following command refreshes a random value when `?` is pressed:

```sh
# Rerun preview command when you hit '?'
fzf --preview 'echo $RANDOM' --bind '?:refresh-preview'
```

Preview bindings can provide an additional preview command, even when a default preview command exists. They can also provide the only preview command, or begin with the preview window hidden.

```sh
# Default preview command with an extra preview binding
fzf --preview 'file {}' --bind '?:preview:cat {}'

# A preview binding with no default preview command
# (Preview window is initially empty)
fzf --bind '?:preview:cat {}'

# Preview window hidden by default, it appears when you first hit '?'
fzf --bind '?:preview:cat {}' --preview-window hidden
```

The release adds initial preview scroll offsets. ANSI prompts are supported. Matching accented characters becomes smart: an unaccented query matches both accented and unaccented text, while an accented query requires accents.

Vim gains a tmux layout:

```vim
let g:fzf_layout = { 'tmux': '-p90%,60%' }
```

## 0.21.1

Version 0.21.1 deduplicates Ctrl-R history entries and adds tmux 3.2 or later popup support.

It fixes Windows traversal, ANSI handling with `--keep-right`, and Zsh completion through `_fzf_complete`. The release builds with Go 1.14.1.

## 0.21.0

Version 0.21.0 makes `--height` available on Windows. It adds `--pointer`, `--marker`, and `--keep-right`. The latter keeps the right end of a line visible when the line is too long.

The border style changes to rounded corners around the finder. The previous horizontal-line style remains available through `--border=horizontal`. A Unicode spinner is added, along with more bindings for `--bind`.

A PowerShell script is provided for downloading the Windows binary. The Vim plugin gains built-in floating-window support.

```vim
let g:fzf_layout = { 'window': { 'width': 0.9, 'height': 0.6 } }
```

Bash Ctrl-R begins with the existing input and supports multiline commands.

The fuzzy-completion API changes from passing all fzf arguments as one string to accepting multiple fzf arguments before `--`. The previous form remains supported but is deprecated.

```sh
# Previous: fzf arguments given as a single string argument
# - This style is still supported, but it's deprecated
_fzf_complete "--multi --reverse --prompt=\"doge> \"" "$@" < <(
  echo foo
)

# New API: multiple fzf arguments before "--"
# - Easier to write multiple options
_fzf_complete --multi --reverse --prompt="doge> " -- "$@" < <(
  echo foo
)
```

## 0.20.0

Version 0.20.0 adds preview foreground and background colors. It adds `clear-query` and `clear-selection`.

Composite bindings can be distributed across multiple `--bind` options by using a leading `+`. The following two forms are equivalent for composing two `up` actions:

```sh
fzf --bind 'ctrl-a:up+up'

# Can be now written as
fzf --bind 'ctrl-a:up' --bind 'ctrl-a:+up'
```

The leading `+` is useful when an `execute` or `reload` form must be written separately to avoid parsing errors while adding more actions to the same key.

```sh
fzf --multi --bind 'ctrl-l:select-all+execute:less {+f}' --bind 'ctrl-l:+deselect-all'
```

The same action sequence can also be written as one composite binding:

```sh
fzf --multi --bind 'ctrl-l:select-all+execute(less {+f})+deselect-all'
```

This release removes reload flicker and fixes `+` parsing in `execute` and `reload`, reload behavior when there are no matches, and clearing of unfilled header lines.

## 0.19.0

Version 0.19.0 adds `--phony` for selector-only use and `reload` for replacing candidates. The following example starts with no candidates and reloads results as the query changes:

```sh
: | fzf --bind 'change:reload:seq {q}' --phony
```

`--multi` accepts a selection cap. The `f` placeholder flag uses a temporary file for large selections that might exceed `ARG_MAX`.

`deselect-all` now affects only matching items. Other additions include the Bash completion setup helper, `default`, `inline`, and `hidden` info styles, borderless previews, trimming of trailing spaces from `nth`, and Ctrl-backslash, Ctrl-bracket, Ctrl-caret, and Ctrl-slash bindings.

The completion setup helper has this form:

```sh
# usage: _fzf_setup_completion path|dir COMMANDS...
_fzf_setup_completion path git kubectl
```

## 0.18.0 and 0.17.5

Version 0.18.0 adds zero-based index placeholders `{n}` and `{+n}`, gutter color, and ASCII borders through `--no-unicode`. It adds `FZF_PREVIEW_LINES` and `FZF_PREVIEW_COLUMNS` alongside `LINES` and `COLUMNS`. The release uses Go 1.12.1.

Version 0.17.5 permits queries wider than the screen, up to 300 characters, and uses Go 1.11.1.

## 0.17.4 through 0.17.0

Version 0.17.4 adds `layout=reverse-list`, with aliases for `reverse` and `default`. Preview refresh works without matches when placeholders are nonempty. More shifted and Alt arrow keys are supported. The fallback works without `/dev/tty`.

The release changes Windows default-command behavior, fixes Bash and Zsh issues, and adds `--xdg` installation paths.

Version 0.17.3 exports preview dimensions and improves command errors. It reverts filesystem-loop duplicate behavior and requires `find -fstype`. Mouse buttons are distinguished, with right-click assigned to toggle. The release adds `replace-query` and `accept-non-empty`.

Version 0.17.1 fixes preview and Windows backgrounds and supports `cmd.exe` execution without extra parsing or escaping. Vim8 gains a terminal-window layout.

Versions 0.17.0-2 change auxiliary scripts only. The changes cover experimental Vim8 and GVim terminal use, Fish shell handling, and fzf-tmux output and `tput` fixes.

Version 0.17.0 optimizes performance, matches escaped literal spaces, and makes `--expect` additive.

## 0.16.11 through 0.16.0

Version 0.16.11 fixes missed preview updates and optimizes performance. Version 0.16.10 repairs preview ANSI handling and improves `--ansi`.

Version 0.16.9 reports about a 20% general speed improvement, up to fivefold faster ANSI processing, and up to 50% lower memory usage. These are release-note claims, not new measurements. The release also adds bracketed-paste handling, command-error display, preview rendering improvements, and improvements to repeated `--no-clear`.

Version 0.16.8 adds `change` and `top` actions. It fixes `nth` tiebreaks, prompt tabs, and page-cycle overshoot. `--version` includes the Git revision. Cygwin and Windows integration improves.

Version 0.16.7 adds Ctrl-Alt letters, Ctrl-Z and SIGSTOP handling, and `FZF_PREVIEW_WINDOW`.

Version 0.16.6 adds `--no-clear`. Version 0.16.5 adds `toggle-preview-wrap` and uses Go 1.8. Version 0.16.4 adds the original horizontal border.

Version 0.16.3 fixes trimmed-tab rendering, adds `+` multi-selection placeholders, adds `execute-silent` without alternate-screen switching, and adds a Ctrl-Space binding.

Version 0.16.2 removes ncurses, provides FreeBSD, OpenBSD, and ARM binaries, supports 24-bit color and `+-`-chained actions, and permits zero-size hidden-preview execution.

Version 0.16.1 fixes height backgrounds, adds half-page actions, and adds `-L` to `find`.

Version 0.16.0 introduces `--height`. Preview output is truncated by default, with optional wrapping. Latin accent normalization is added, with `--literal` as the opt-out. The release adds `--filepath-word`.

## 0.15.9 through 0.15.0

Version 0.15.9 fixes rendering regressions and sets a 50-millisecond escape delay, configurable through `ESCDELAY`. Overflowing preview indicators are always shown. ncurses6 and tcell gain extra color and italic features.

Version 0.15.8 expands VT100 and WSL handling. It adds `--no-bold`, `--bold`, Alt digits, F11, and F12.

Version 0.15.7 fixes a panic involving disabled colors and ANSI headers.

Version 0.15.6 introduces Windows binaries. It fixes header clearing, control-character display, and WSL escape sequences, with waiting of up to 100 milliseconds.

Version 0.15.5 stops foreground changes from forcing a black background. End tiebreaking becomes relative. `g:fzf_colors` is honored in wrap.

Version 0.15.4 adds field ranges and `{q}` placeholders, supports Unicode whitespace, and adds preview scroll indicators. Exact inverse matching becomes the default. Inverse fuzzy matching remains available using the documented quote prefix.

Version 0.15.3 supports more ANSI styles and fixes toggle-preview races. Version 0.15.2 adds scrollable previews and preview actions, plus intensity and VT100 handling. Version 0.15.1 fixes matches beyond column `2^15` and delays in rendering very long lines.

Version 0.15.0 changes scoring through `--algo=v1|v2` and adds NUL input and output through `--read0` and `--print0`.

## 0.13.5 through 0.13.0

Version 0.13.5 reports up to twice the speed and half the memory.

Version 0.13.4 reports 60% lower memory use for ASCII strings, a 15–20% query improvement, and up to 45% faster nonregex `nth` delimiters. It also fixes hidden previews.

Versions 0.13.3, 0.13.2, and 0.13.1 fix duplicate preview lines, clearing races, and large ANSI output.

Version 0.13.0 introduces preview windows, supports single quotes in `execute` placeholders, and ignores bracketed-paste control characters.

## 0.12.2 through 0.11.0

Version 0.12.2 detects 256 colors without requiring a substring in `TERM`. It adds `print-query`, F1 through F10, Alt slash, Alt space, Alt Enter, `jump`, and `jump-accept`.

Version 0.12.1 applies the new ranking universally and fixes exact-cache references. Version 0.12.0 introduces that ranking.

Version 0.11.4 sets the default `--hscroll-off` value to 10.

Version 0.11.3 handles SIGTERM gracefully, uses the selected shell for `execute` and default commands, and changes completion-generation and postprocessing APIs.

Version 0.11.2 accepts ordered, distinct tiebreak criteria. `index` is implicit and last; the default is `length,index`. `begin` ignores leading whitespace. `toggle-in` and `toggle-out` adapt to reversed layout.

When `tac` is absent, the initial ongoing-input rendering delay drops from up to 100 milliseconds to 20 milliseconds.

Version 0.11.1 adds `tabstop`.

Version 0.11.0 adds OR and `execute-multi`, and fixes wide-character prompt positioning.

## 0.10.9 through 0.10.0

Version 0.10.9 makes extended search the default and replaces `extended-exact` with orthogonal `--exact`. Nonprinting characters are suppressed. Double-click is added, and resize handling improves.

Version 0.10.8 fixes setting colors after colors have been disabled.

Version 0.10.7 serializes execute interrupts and uses trimmed `nth` length for tiebreaks.

Version 0.10.6 replaces `header-file` with `header`, combines `header` and `header-lines`, defines exit statuses as 0 for success, 1 for no match, 2 for error, and 130 for interruption, and statically links Linux ncurses.

Version 0.10.5 adds quote-prefix unquoting and backward end scans. Version 0.10.4 removes ANSI codes from `with-nth` output.

Version 0.10.3 optimizes delimiters by treating nonspecial patterns as literal and simplifying regular expressions.

Version 0.10.2 improves query and rune conversion and `nth` ranking, exits cleanly when ncurses initialization fails, and handles filenames beginning with a dash.

Version 0.10.1 adds margins, sticky headers, `cancel`, and `delete-char-eof`. It fixes colon and comma bindings and multiline ANSI.

Version 0.10.0 adds `select`, `deselect`, and `toggle-all`; `ignore`; execute delimiters; history with a default of 1,000 entries; history keys; and `cycle`. It also fixes spinner, marker, and anchored-query behavior.

The colon form of `execute` requires no closing delimiter and must end the binding list.

## 0.9.13 through 0.9.3

Version 0.9.13 adds color customization and fixes reader termination above 64 KB.

Version 0.9.12 adds `bind` and fixes resize information and ANSI offsets.

Version 0.9.11 adds `inline-info` and fixes case mutation, per-terminal smart case, and double-click behavior after scrolling.

Version 0.9.10 reduces memoization and memory usage and adds light colors.

Version 0.9.9 adds tiebreaking, `no-hscroll`, and toggle-sort indication.

Version 0.9.8 fixes Unicode case handling and `RuneError`.

Version 0.9.7 adds `toggle-sort` and fixes expect output and comma handling.

Version 0.9.6 adds `--expect` keys and prints the accepting key before the results. This enables callers such as Vim integrations to choose how to open a result. The release also ignores an ANSI erase-line sequence.

```sh
fzf --expect=ctrl-v,ctrl-t,alt-s,f1,f2,~,@
```

Version 0.9.5 adds optional ANSI interpretation and stripping. Truecolor is not supported at this version. Startup pointer copying is reduced, and a panic caused by an empty no-sort filter is fixed.

Version 0.9.4 adds streaming `tac` reversal and removes the implicit reverse order from no-sort. Filter and no-sort results stream unless `tac` or `sync` requires buffering. Streaming is sequential; `--sync` restores buffered parallel filtering.

```sh
history | fzf +s --tac
```

Version 0.9.3 adds `sync` and starts the finder promptly when `select-1` or `exit-0` conditions cannot be met.
