# How curl Became Like This

Towards the end of 1996, Daniel Stenberg was writing an IRC bot for an Amiga-related channel on EFnet. He came up with the idea to make currency-exchange calculations available to Internet Relay Chat (IRC) users. All the necessary data were published on the Web; he just needed to automate their retrieval.

## 1996

Daniel adopted an existing command-line open-source tool, httpget, which Brazilian developer Rafael Sagula had written and recently released as version 0.1. After a few minor adjustments, it did exactly what he needed.

## 1997

HttpGet 1.0 was released on April 8, 1997 with new HTTP proxy support.

Support for getting currencies over GOPHER was soon added. Once FTP download support was added, the project name became misleading, and urlget 2.0 was released in August 1997. The HTTP-only period had ended.

## 1998

The project slowly grew larger. When upload capabilities were added and the name again became misleading, a second name change was made, and curl 4 was released on March 20, 1998. (The version numbering from the previous names was retained.)

(Unrelated to this project, a company called Curl Corporation registered a US trademark on the name "CURL" on May 18, 1998. The company had registered the curl.com domain in November of the previous year. All this was revealed to us much later.)

SSL support was added, powered by the SSLeay library.

August: First announcement of curl on Freshmeat.

October: With the curl 4.9 release and the introduction of cookie support, curl was no longer released under the GPL license. Now at 4,000 lines of code, the project switched to the MPL license to limit the effects of copyleft. The -F option was added, enabling curl to simulate many browser functions. TELNET support was added.

November: A configure script was introduced, and successful compiles were reported on several major operating systems.

Curl 5 was released in December 1998 and introduced the first curl man page. People began creating Linux RPM packages from the code.

## 1999

January: DICT support added.

OpenSSL took over as SSLeay was abandoned.

May: First Debian package released.

August: LDAP:// and FILE:// support added. The curl website received 1,300 visits weekly. The site moved to curl.haxx.nu.

September: Curl 6.0 released with 15,000 lines of code.

December 28: The project was added to Sourceforge, and the site began using its services for project management.

## 2000

Spring: A major internal overhaul was performed to provide a suitable library interface. The first non-beta release, named 7.1, arrived in August. This release provided the easy interface and marked the beginning of other software using libcurl. The codebase reached approximately 20,000 lines of code.

June: The curl site moved to curl.haxx.se.

August: The curl website received 4,000 visits weekly.

PHP developers adopted libcurl that same month, and the first third-party libcurl binding appeared. CURL became a supported module in PHP with the release of PHP 4.0.2. Other projects would soon follow suit. More than 16 different bindings existed by this point.

September: Kerberos4 support was added.

November: Work began on a test suite for curl, which was later rewritten from scratch. The libcurl major SONAME number was set to 1.

## 2001

January: Daniel released curl 7.5.2 under a new license: MIT (or MPL). The MIT license is highly permissive and can be combined with GPL in other projects. This addressed the concerns from GPL project developers who previously could not use libcurl when it was released under MPL only, as MPL is deemed GPL-incompatible.

March 22: Curl added HTTP 1.1 support starting with release 7.7. This also introduced libcurl's ability to perform persistent connections. The codebase reached 24,000 lines of code. The libcurl major SONAME number was incremented to 2 due to this overhaul. The first experimental ftps:// support was added.

August: Curl was bundled in Mac OS X 10.1. It was becoming increasingly standard in Linux distributions and regular in BSD ports collections. The curl website received 8,000 visits weekly. Curl Corporation contacted Daniel to discuss the name issue. After his reply, they did not contact him again.

September: Libcurl 7.9 introduced cookie jar functionality and curl_formadd(). During subsequent 7.9.x releases, the multi interface was introduced gradually.

## 2002

June: The curl website received 13,000 visits weekly. Curl and libcurl comprised 35,000 lines of code. Successful compiles were reported on more than 40 CPU and operating system combinations.

Estimating the number of users of the curl tool or libcurl library is nearly impossible. Approximately 5,000 downloaded packages each week from the main site provides an indication, but packages are mirrored extensively, bundled with numerous OS distributions, and retrieved as part of other software.

October 1: Curl 7.10 was released under the MIT license only.

Starting with 7.10, curl verifies SSL server certificates by default.

## 2003

January: Work began on distributed curl tests and autobuilds.

February: The curl site averaged 20,000 visits weekly. At any given moment, an average of 3 people were browsing the website.

Multiple new authentication schemes were supported: Digest (May), NTLM (June), and Negotiate (June).

November: Curl 7.10.8 was released with 45,000 lines of code. The website received approximately 55,000 unique visitors. Five official web mirrors were established.

December: Full SSL support for FTP was added.

## 2004

January: Curl 7.11.0 introduced large file support.

June: Curl 7.12.0 introduced IDN support. Ten official web mirrors were established.

This release incremented the major SONAME to 3 due to the removal of the curl_formparse() function.

August: Curl and libcurl 7.12.1

    Public curl release number:              82
    Releases counted from the very beginning: 109
    Available command-line options:         96
    Available curl_easy_setopt() options:   120
    Number of public functions in libcurl:  36
    Amount of public website mirrors:       12
    Number of known libcurl bindings:       26

## 2005

April: GnuTLS became optionally available as the secure layer when curl was built.

April: The multi_socket() API was added.

September: TFTP support was added.

More than 100,000 unique visitors to the curl website. Twenty-five mirrors.

December: Security vulnerability: libcurl URL Buffer Overflow.

## 2006

January: Support for Gopher was dropped. Bugs were discovered in the implementation that had been introduced years earlier. Since no one had discovered these bugs in all that time, the feature was removed rather than fixed.

March: Security vulnerability: libcurl TFTP Packet Buffer Overflow.

September: The major SONAME number for libcurl was incremented to 4 due to the removal of FTP third-party transfer support.

November: SCP and SFTP support was added.

## 2007

February: Support for the Mozilla NSS library for SSL/TLS functionality was added.

July: Security vulnerability: libcurl GnuTLS insufficient certificate verification.

## 2008

November:

    Command-line options:         128
    curl_easy_setopt() options:   158
    Public functions in libcurl:   58
    Known libcurl bindings:        37
    Contributors:                 683

145,000 unique visitors. More than 100 GB downloaded.

## 2009

March: Security vulnerability: libcurl Arbitrary File Access.

April: CMake support was added.

August: Security vulnerability: libcurl embedded zero in certificate name.

December: Support for IMAP, POP3, and SMTP was added.

## 2010

January: RTSP support was added.

February: Security vulnerability: libcurl data callback excessive length.

March: The project switched from CVS to git (hosted on GitHub) for source code control.

May: RTMP support was added.

PolarSSL support for SSL/TLS functionality was added.

August:

    Public curl releases:         117
    Command-line options:         138
    curl_easy_setopt() options:   180
    Public functions in libcurl:   58
    Known libcurl bindings:        39
    Contributors:                 808

Gopher support was re-added (originally dropped in January 2006).

## 2011

February: Support for the axTLS backend was added.

April: Support for the cyassl backend was added (later renamed to WolfSSL).

## 2012

July: Support for Schannel (native Windows TLS backend) and Darwin SSL (native Mac OS X and iOS TLS backend) was added.

Metalink support was added.

October: SSH-agent support was added.

## 2013

February: Internals were cleaned up to always use the "multi" non-blocking approach internally with only the blocking API exposed through a wrapper.

September: Initial steps toward HTTP/2 support with nghttp2 were begun.

October: Kerberos 4 support was removed.

December: Happy Eyeballs was implemented.

## 2014

March: The first real HTTP/2 release was made.

September: The website received 245,000 unique visitors and served 236 GB of data.

SMB and SMBS support was added.

## 2015

June: Support for multiplexing with HTTP/2 was added.

August: Support for HTTP/2 server push was added.

December: Public Suffix List support was added.

## 2016

January: The curl tool defaults to HTTP/2 for HTTPS URLs.

December: Curl 7.52.0 introduced HTTPS-proxy support.

First TLS 1.3 support was added.

## 2017

July: OSS-Fuzz began fuzzing libcurl.

September: Multi-SSL support was added.

The website served 3,100 GB per month.

    Public curl releases:         169
    Command-line options:         211
    curl_easy_setopt() options:   249
    Public functions in libcurl:   74
    Contributors:                 1,609

October: SSLKEYLOGFILE support and a new MIME API were added. Daniel received the Polhem Prize for his work on curl.

November: Brotli support was added.

## 2018

January: A new SSH backend powered by libssh was introduced.

March: Starting with the 1803 release of Windows 10, curl was bundled with Microsoft's operating system.

July: Curl began displaying headers using bold typeface.

October: DNS-over-HTTPS (DoH) and the URL API were added. MesaLink was introduced as a new supported TLS backend.

Libcurl now performs HTTP/2 (and multiplexing) by default on HTTPS URLs.

Curl and libcurl are installed in an estimated 5 billion instances worldwide.

October 31: Curl and libcurl 7.62.0

    Public curl releases:         177
    Command-line options:         219
    curl_easy_setopt() options:   261
    Public functions in libcurl:   80
    Contributors:                 1,808

December: axTLS support was removed.

## 2019

March: Experimental alt-svc support was added.

August: The first HTTP/3 requests with curl were made.

September: Version 7.66.0 was released, offering parallel downloads.

## 2020

Curl and libcurl are installed in an estimated 10 billion instances worldwide.

January: BearSSL support was added.

March: PolarSSL support was removed, and wolfSSH support was added.

April: Experimental MQTT support was added.

August: Zstd support was added.

November: The website moved to www.curl.se. The website served 10 TB of data monthly.
