# Bat: Syntax Highlighting and Display Documentation

## Overview and Core Functionality

Bat is a cat clone with wings. It is designed to display files with syntax highlighting, Git-index modification markers, optional nonprinting-character display, and automatic paging. It serves as a drop-in replacement for `cat` in many scenarios, offering a more visually informative way to view file contents. When output is redirected to a file or pipe, bat provides plain file contents, ensuring cat-like behavior without syntax highlighting artifacts. This dual behavior allows bat to be used seamlessly in scripts where visual enhancement is desired in terminals but plain text is required in pipelines.

The tool supports concatenating multiple files into a single output stream. It also features automatic paging when the output exceeds the terminal height, utilizing a pager such as `less` to navigate large files. Standard-input detection can utilize a shebang line to determine syntax, or users can explicitly set the syntax using the `-l` or `--language` flag. For debugging or inspecting raw file contents, the `-A` or `--show-all` flag highlights nonprinting characters, making it easier to identify control characters and whitespace issues.

## Integrations and Workflow Enhancements

Bat is designed to integrate smoothly into various command-line workflows. It can be used with `find` to display file contents recursively. For example, using `find` with `-exec bat {} +` allows for the display of multiple files found by the search command. Similarly, `fd` can be integrated using `fd ... -X bat` to execute bat on batches of found files.

For searching within files, `batgrep` provides a wrapper for `ripgrep` results, displaying matches with context and syntax highlighting. When working with live logs, bat can be used with `tail -f`. In this scenario, paging should be disabled using `--paging=never`, and the log syntax should be explicitly set using the `-l log` flag to ensure correct highlighting.

Version control integration is supported through `git show`. Users can pipe historical file contents from git into bat, explicitly setting the language if detection fails. For instance, `git show v0.6.0:src/main.rs | bat -l rs` displays the content of a specific file from a past commit.

Bat does not support diff highlighting natively; instead, it references `delta` for diff-related tasks. However, bat can be used to copy file contents to the clipboard without gutters by piping the output to `xclip`. This is achieved by running `bat main.cpp | xclip`, which avoids copying the line numbers and syntax highlighting markers.

For manual pages, bat can be used as a pager. Setting the `MANPAGER` environment variable to use bat allows for colored manual pages. The command `export MANPAGER="sh -c 'col -bx | bat -l man -p'"` configures this. Note that `man 2 select` can then be used to view the manual page with bat. While `batman` wraps this use case, it is important to note that Mandoc's man implementation is unsupported by bat. Additionally, `MANROFFOPT=-c` may be used to fix formatting issues in manual pages when using bat as a pager.

For code formatting, `prettybat` combines formatters such as `prettier`, `shfmt`, and `rustfmt` with bat, allowing for formatted and highlighted output.

## Installation and Package Management

Bat is available for a wide range of operating systems and package managers. The following sections detail the installation methods for various platforms.

### Linux Distributions

On Ubuntu 19.10 and later, as well as Debian Sid, bat can be installed using the standard package manager. The command `apt install bat` installs the package. Note that on Debian-family systems, the executable may be named `batcat` due to a name clash with another package. To restore the `bat` command, users can create a symlink or alias. For example:
```bash
mkdir -p ~/.local/bin
ln -s /usr/bin/batcat ~/.local/bin/bat
```
Alternatively, downloaded `.deb` archives can be installed using `dpkg`. The command `sudo dpkg -i bat_0.16.0_amd64.deb` installs the package, with the version number and architecture adapted as necessary.

On Alpine Linux, bat is available via the `apk` package manager. The command `apk add bat` installs the software.

Arch Linux users can install bat using `pacman`. The command `pacman -S bat` retrieves and installs the package.

Fedora Modular users can install bat using `dnf`. The command `dnf install bat` handles the installation.

Gentoo users can install bat using `emerge`. The command `emerge sys-apps/bat` builds and installs the package.

Void Linux users can install bat using `xbps-install`. The command `xbps-install -S bat` installs the package.

### BSD and macOS

On FreeBSD, bat is available via packages or ports. Users can install the package using `pkg install bat`. Alternatively, users can build from ports using `cd /usr/ports/textproc/bat` followed by `make install`.

On macOS, bat can be installed using Homebrew with the command `brew install bat`. MacPorts users can use `port install bat`.

### Windows

On Windows, bat can be installed using Chocolatey with the command `choco install bat`. Scoop users can install bat using `scoop install bat`.

It is important to note that Windows requires the Visual C++ Redistributable to run bat. Release archives include many architectures and MUSL static builds for compatibility. On Windows, the `more` command is limited, so installing `less` and adding it to the PATH is recommended. Chocolatey installs `less` automatically. Windows 10 version 1511 and later support colors in Command Prompt and PowerShell, as do newer Bash versions. Older Windows systems can use Cmder or ConEmu for color support. Note that Git/MSYS `less` may misinterpret colors.

To disable paging on Windows, users can set `--paging=never` or set `BAT_PAGER` to an empty string. Native bat cannot interpret Cygwin `/cygdrive` paths; a wrapper script is supplied to convert them. The wrapper script iterates through arguments, converting file paths using `cygpath --windows`.

### Nix and openSUSE

Nix users can install bat using `nix-env -i bat`. openSUSE users can install bat using `zypper`. The command `zypper install bat` installs the package.

### Source Builds

Building bat from source requires Rust 1.40 or later. Users can clone the repository recursively to retrieve all submodules using `git clone --recursive https://github.com/sharkdp/bat`. After cloning, users can build the binary using `cargo build --bins`. To run unit tests and integration tests, use `cargo test`. For installation, users can run `cargo install --locked`.

When building from source, Cargo generates man and completion files in the target build directory but does not install them automatically. Users can build a bat binary with modified syntaxes and themes using `bash assets/create.sh` followed by `cargo install --locked --force`.

## Configuration and Customization

Bat allows extensive customization through themes, styles, and configuration files.

### Themes

Users can list available themes using `--list-themes`. A theme can be selected using `--theme` or by setting the `BAT_THEME` environment variable. Examples of themes include `TwoDark`, `GitHub`, and `OneHalfLight`. Dark backgrounds are the default assumption for themes.

Themes vary in color depth. `ansi-dark` and `ansi-light` use basic three-bit colors. `base16` uses four-bit colors following base16 styling. `base16-256` maps some bright colors into slots 16–21 for `base16-shell`. Note that `base16-256` is not a generic choice for every 256-color terminal. Restricted themes track terminal palette changes and blend with other terminal software.

Users can also list themes with a preview using `bat --list-themes | fzf --preview="bat --theme={} --color=always /path/to/file"`.

To use custom themes, users should place `.tmTheme` files in the themes directory. The directory can be found using `bat --config-dir`. For example:
```bash
mkdir -p "$(bat --config-dir)/themes"
cd "$(bat --config-dir)/themes"
git clone https://github.com/greggb/sublime-snazzy
bat cache --build
```

### Syntax Highlighting

Bat uses `syntect` to read Sublime `.sublime-syntax` files and themes. Users can place custom definitions and themes in the documented config directories. After adding files, users should build the binary cache using `bat cache --build` and verify the additions with `--list-languages` and `--list-themes`. To return to defaults, users can clear the cache using `bat cache --clear`.

Custom syntaxes can be added by cloning repositories into the syntaxes directory. For example:
```bash
mkdir -p "$(bat --config-dir)/syntaxes"
cd "$(bat --config-dir)/syntaxes"
git clone https://github.com/tellnobody1/sublime-purescript-syntax
```

Users can map file extensions to specific syntaxes using `--map-syntax`. For example, `--map-syntax "*.ino:C++"` uses C++ syntax for `.ino` files, and `--map-syntax ".ignore:Git Ignore"` uses ".gitignore"-style highlighting for `.ignore` files.

### Styles

The `--style` flag selects output elements. For example, `--style="numbers,changes,header"` shows line numbers, Git modifications, and the file header, but not the grid. The `BAT_STYLE` environment variable or configuration file can make this persistent.

Other style options include `--italic-text=always`, which uses italic text on the terminal (not supported on all terminals).

### Pager Configuration

Pager precedence is `BAT_PAGER` over `PAGER`, with `less` as the fallback. The `--pager` flag provides another configuration route. When using `less` without explicit arguments, bat supplies `-R` for ANSI colors and `-F` to quit if the output fits on one screen. For `less` versions older than 530, bat adds `-X` to work around a quit-if-one-screen issue, at the cost of mouse-wheel support. Selecting only `-R` on those older versions restores wheel use but disables the automatic short-output quit.

Users can set `BAT_PAGER` to `less -RF` to enable raw output and quit-on-one-screen. For example:
```bash
export BAT_PAGER="less -RF"
```

Bat expands tabs to four spaces before paging. The `--tabs` flag changes the width, and `--tabs=0` passes tabs through to the pager. Pager tab-stop settings cannot affect already expanded spaces.

On macOS, users can select a default or GitHub theme according to the OS dark/light appearance using an alias. For example:
```bash
alias cat="bat --theme=$(defaults read -globalDomain AppleInterfaceStyle &> /dev/null && echo default || echo GitHub)"
```

### Configuration File

Users can print the platform-dependent config path using `bat --config-file`. The `BAT_CONFIG_PATH` environment variable can select another file. The `--generate-config-file` flag creates defaults. The configuration file format is a list of CLI arguments with `#`-prefixed comments. For example:
```bash
export BAT_CONFIG_PATH="/path/to/bat.conf"
```

The configuration file can include settings such as:
```
# Set the theme to "TwoDark"
--theme="TwoDark"

# Show line numbers, Git modifications and file header (but no grid)
--style="numbers,changes,header"

# Use italic text on the terminal (not supported on all terminals)
--italic-text=always

# Use C++ syntax for .ino files
--map-syntax "*.ino:C++"

# Use ".gitignore"-style highlighting for ".ignore" files
--map-syntax ".ignore:Git Ignore"
```

## Technical Details and Platform Limits

### Color Support

Truecolor terminals should expose `COLORTERM=truecolor` or `24bit`. If not, bat falls back to eight-bit colors. Users should use restricted themes when appropriate. `OneHalfDark` and `OneHalfLight` have brighter grid and line colors.

### Encoding

Bat supports UTF-8 and UTF-16 natively. To convert other encodings, users can use `iconv` and specify the syntax if detection fails. For example:
```bash
iconv -f ISO-8859-1 -t UTF-8 my-file.php | bat
```

### Usage Examples

Basic usage involves passing file names as arguments. For example:
```bash
bat README.md
```
Multiple files can be concatenated:
```bash
bat src/*.rs
```
Bat can read from standard input. For example:
```bash
curl -s https://sh.rustup.rs | bat
```
Syntax can be explicitly set for standard input:
```bash
yaml2json .travis.yml | json_pp | bat -l json
```
Nonprinting characters can be displayed:
```bash
bat -A /etc/hosts
```
Bat can create new files:
```bash
bat > note.md
```
Files can be concatenated into a new file:
```bash
bat header.md content.md footer.md > document.md
```
Line numbers can be shown exclusively:
```bash
bat -n main.rs
```
Bat can handle stdin mixed with files:
```bash
bat f - g
```
This outputs `f`, then stdin, then `g`.

### Limitations and Workarounds

On Windows, `more` is limited, so installing `less` is recommended. Windows 10 version 1511+ supports colors in Command Prompt and PowerShell. Older Windows can use Cmder or ConEmu. Git/MSYS `less` may misinterpret colors.

Native bat cannot interpret Cygwin `/cygdrive` paths. A wrapper script is supplied to convert them.

Diff highlighting is unsupported; `delta` is referenced for this purpose.

Mandoc's man implementation is unsupported.

### Maintainers and License

The project is maintained by sharkdp and eth-p. The project aims for syntax highlighting, Git integration, POSIX-cat replacement, and a usable CLI. Alternatives are documented in the project repository. The license choice is MIT or Apache 2.0, with copyright held by bat-developers from 2018 to 2020.
