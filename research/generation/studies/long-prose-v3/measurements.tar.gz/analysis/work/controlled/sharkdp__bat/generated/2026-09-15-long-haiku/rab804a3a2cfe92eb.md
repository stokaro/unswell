# bat - a cat clone with syntax highlighting and Git integration

**bat** is a cat(1) clone with syntax highlighting and Git integration. It provides beautiful advanced syntax highlighting, integrates with Git to show file modifications, serves as a drop-in replacement for POSIX cat, and offers a user-friendly command-line interface.

## Key Features

### Syntax highlighting

bat supports syntax highlighting for a large number of programming and markup languages.

### Git integration

bat communicates with git to show modifications relative to the index, displayed in the left side bar.

### Show non-printable characters

Use the `-A`/`--show-all` option to display and highlight non-printable characters.

### Automatic paging

bat can pipe its output to a pager (such as less) if the output exceeds one screen.

### File concatenation

bat acts as a drop-in replacement for cat when it detects a non-interactive terminal (such as when piping to another process or into a file), falling back to printing plain file contents.

## How to Use

Display a single file:

```bash
bat README.md
```

Display multiple files:

```bash
bat src/*.rs
```

Read from stdin with automatic syntax detection (note: highlighting requires syntax detection from the first line, usually through a shebang such as `#!/bin/sh`):

```bash
curl -s https://sh.rustup.rs | bat
```

Read from stdin with explicit language specification:

```bash
yaml2json .travis.yml | json_pp | bat -l json
```

Show and highlight non-printable characters:

```bash
bat -A /etc/hosts
```

Use as a cat replacement:

```bash
bat > note.md

bat header.md content.md footer.md > document.md

bat -n main.rs

bat f - g
```

### Integration with other tools

#### find or fd

Use the `-exec` option of find to preview search results with bat:

```bash
find … -exec bat {} +
```

With fd, use the `-X`/`--exec-batch` option:

```bash
fd … -X bat
```

#### ripgrep

Use batgrep with ripgrep search results:

```bash
batgrep needle src/
```

#### tail -f

Combine bat with tail -f to continuously monitor a file with syntax highlighting:

```bash
tail -f /var/log/pacman.log | bat --paging=never -l log
```

Paging must be disabled for this to work. The syntax is specified explicitly since auto-detection is not possible.

#### git

Combine bat with git show to view older versions with syntax highlighting:

```bash
git show v0.6.0:src/main.rs | bat -l rs
```

Syntax highlighting within diffs is not currently supported.

#### xclip

Prevent line numbers and Git modification markers from being copied by using the `-p`/`--plain` option or piping into xclip:

```bash
bat main.cpp | xclip
```

bat detects redirection and prints plain file contents.

#### man

Use bat as a colorizing pager for man by setting the MANPAGER environment variable:

```bash
export MANPAGER="sh -c 'col -bx | bat -l man -p'"
man 2 select
```

Setting `MANROFFOPT="-c"` may be necessary for formatting. Alternatively, use batman for a bundled command.

The Manpage syntax is developed in this repository and requires additional work. This approach does not work with Mandocs man implementation.

#### prettier, shfmt, rustfmt

The prettybat script formats code and prints it with bat.

## Installation

### Ubuntu

bat is available in the Ubuntu package repository beginning with Eoan 19.10 and on the Debian unstable branch.

```bash
apt install bat
```

The executable may be installed as batcat instead of bat due to a name clash. Create a symlink or alias for consistency:

```bash
mkdir -p ~/.local/bin
ln -s /usr/bin/batcat ~/.local/bin/bat
```

Alternatively, download the latest .deb package from the release page and install it:

```bash
sudo dpkg -i bat_0.16.0_amd64.deb
```

### Alpine Linux

Install the bat package from official sources:

```bash
apk add bat
```

### Arch Linux

Install the bat package from official sources:

```bash
pacman -S bat
```

### Fedora

Install the bat package from the Fedora Modular repository:

```bash
dnf install bat
```

### Gentoo Linux

Install the bat package from official sources:

```bash
emerge sys-apps/bat
```

### Void Linux

Install bat using xbps-install:

```bash
xbps-install -S bat
```

### FreeBSD

Install a precompiled bat package with pkg:

```bash
pkg install bat
```

Or build from the FreeBSD ports:

```bash
cd /usr/ports/textproc/bat
make install
```

### nix

Install bat using the nix package manager:

```bash
nix-env -i bat
```

### openSUSE

Install bat with zypper:

```bash
zypper install bat
```

### macOS

Install bat with Homebrew:

```bash
brew install bat
```

Or install with MacPorts:

```bash
port install bat
```

### Windows

Install the Visual C++ Redistributable package first.

With Chocolatey:

```bash
choco install bat
```

With Scoop:

```bash
scoop install bat
```

Or download prebuilt binaries from the release page. Statically-linked binaries with musl are available.

### From source

Requires Rust 1.40 or higher. Build with cargo:

```bash
cargo install --locked bat
```

Additional files such as the man page and shell completion files are generated by cargo and available in the cargo target folder.

## Customization

### Highlighting theme

List available themes:

```bash
bat --list-themes
```

Select a theme with the `--theme` option or set the BAT_THEME environment variable:

```bash
export BAT_THEME="TwoDark"
```

Use the configuration file for permanent settings. Preview themes with fzf:

```bash
bat --list-themes | fzf --preview="bat --theme={} --color=always /path/to/file"
```

bat looks good on dark backgrounds by default. For light backgrounds, use themes such as GitHub or OneHalfLight. Custom themes can be added following the 'Adding new themes' section below.

### 8-bit themes

bat includes four themes using 8-bit colors:

- `ansi-dark`: Suitable for terminals with dark backgrounds, using 3-bit colors.
- `ansi-light`: For terminals with light backgrounds.
- `base16`: Designed for base16 terminal themes, using 4-bit colors.
- `base16-256`: Designed for base16-shell, using 8-bit colors from 16 to 21. Do not use this for 256-color terminals not using base16-shell.

These themes harmonize better with other terminal software using 3-bit or 4-bit colors and update to match when terminal themes change.

### Output style

Control the appearance with the `--style` option:

```bash
bat --style=numbers,changes
```

Set BAT_STYLE for permanent changes or use the configuration file.

### Adding new syntaxes

bat uses the syntect library, which reads Sublime Text `.sublime-syntax` files. Create a folder for syntax definitions:

```bash
mkdir -p "$(bat --config-dir)/syntaxes"
cd "$(bat --config-dir)/syntaxes"
git clone https://github.com/tellnobody1/sublime-purescript-syntax
```

Parse the files into a binary cache:

```bash
bat cache --build
```

Verify new languages are available:

```bash
bat --list-languages
```

To restore defaults:

```bash
bat cache --clear
```

### Adding new themes

Create a folder for themes:

```bash
mkdir -p "$(bat --config-dir)/themes"
cd "$(bat --config-dir)/themes"
git clone https://github.com/greggb/sublime-snazzy
bat cache --build
```

Verify new themes are available:

```bash
bat --list-themes
```

### Using a different pager

bat uses the PAGER environment variable, defaulting to less. Override with BAT_PAGER:

```bash
export BAT_PAGER="less -RF"
```

Use the configuration file for the `--pager` option.

By default with less, bat passes `-R`/`--RAW-CONTROL-CHARS`, `-F`/`--quit-if-one-screen`, and `-X`/`--no-init` options. The `-R` option interprets ANSI colors. The `-F` option exits immediately if output is smaller than the terminal height. The `-X` option fixes a bug in old less versions but breaks mouse-wheel support.

For mouse-wheel scrolling on older less versions, pass only `-R` to disable quit-if-one-screen. For less 530 or newer, mouse support works by default.

### Indentation

bat expands tabs to 4 spaces by default. Change this with the `--tabs` argument:

```bash
bat --tabs=8
```

Setting `--tabs=0` allows the pager to handle tabs. Pager tab stops are not applied because the pager receives expanded spaces.

### Dark mode

Configure bat to use different themes based on macOS dark mode:

```bash
alias cat="bat --theme=\$(defaults read -globalDomain AppleInterfaceStyle &> /dev/null && echo default || echo GitHub)"
```

## Configuration file

Get the default configuration file location:

```bash
bat --config-file
```

Override with the BAT_CONFIG_PATH environment variable:

```bash
export BAT_CONFIG_PATH="/path/to/bat.conf"
```

Generate a default configuration file:

```bash
bat --generate-config-file
```

### Format

The configuration file is a list of command-line arguments. Use `bat --help` for available options. Add comments with `#`.

Example configuration file:

```bash
--theme="TwoDark"
--style="numbers,changes,header"
--italic-text=always
--map-syntax "*.ino:C++"
--map-syntax ".ignore:Git Ignore"
```

## Using bat on Windows

bat works on Windows with some features requiring configuration.

### Prerequisites

Install the Visual C++ Redistributable package.

### Paging

Windows includes only a limited pager. Download a less binary from its homepage or through Chocolatey, place it in PATH, or define an environment variable. The Chocolatey package installs less automatically.

### Colors

Windows 10 supports colors in conhost.exe and PowerShell since v1511, as well as in newer bash versions. On earlier Windows versions, use Cmder, which includes ConEmu.

Git and MSYS versions of less do not correctly interpret colors on Windows. Disable paging with `--paging=never` or set BAT_PAGER to empty.

### Cygwin

bat does not natively support Cygwin's unix-style paths. Solve this by adding a wrapper function to `.bash_profile`:

```bash
bat() {
    local index
    local args=("$@")
    for index in $(seq 0 ${#args[@]}) ; do
        case "${args[index]}" in
        -*) continue;;
        *)  [ -e "${args[index]}" ] && args[index]="$(cygpath --windows "${args[index]}")";;
        esac
    done
    command bat "${args[@]}"
}
```

## Troubleshooting

### Terminals and colors

bat handles terminals with and without truecolor support. Most syntax highlighting themes optimize for 24-bit colors. Use a terminal with 24-bit truecolor support (terminator, konsole, iTerm2) or basic 8-bit themes designed for restricted colors.

Ensure your terminal sets COLORTERM to `truecolor` or `24bit`. Otherwise, bat defaults to 8-bit colors.

### Line numbers and grid visibility

Use `bat --list-themes` to find a better theme. OneHalfDark and OneHalfLight provide brighter grid and line colors.

### File encodings

bat supports UTF-8 and UTF-16 natively. For other encodings, convert to UTF-8 first using iconv:

```bash
iconv -f ISO-8859-1 -t UTF-8 my-file.php | bat
```

Use `-l`/`--language` if syntax cannot be auto-detected.

## Development

Clone the repository:

```bash
git clone --recursive https://github.com/sharkdp/bat
cd bat
```

Build the debug version:

```bash
cargo build --bins
```

Run tests:

```bash
cargo test
```

Install the release version:

```bash
cargo install --locked
```

Build with modified syntaxes and themes:

```bash
bash assets/create.sh
cargo install --locked --force
```

## Project goals and alternatives

bat achieves the following goals: provide beautiful advanced syntax highlighting, integrate with Git to show file modifications, be a drop-in replacement for POSIX cat, and offer a user-friendly command-line interface. See the alternatives document for comparisons with similar programs.

## License

Copyright (c) 2018-2020 bat-developers.

bat is made available under the MIT License or the Apache License 2.0, at your option. See LICENSE-APACHE and LICENSE-MIT for details.
