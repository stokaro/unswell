# Lazy pulling stargz/eStargz base images (Experimental)

This document describes the configuration that allows buildkit to lazily pull [stargz](https://github.com/google/crfs/blob/master/README.md#introducing-stargz)/[eStargz](https://github.com/containerd/stargz-snapshotter/blob/master/docs/stargz-estargz.md)-formatted images from registries.

By default, buildkit does not pull images until they are strictly needed.
For example, during a build, buildkit does not pull the base image until it runs commands on it (such as `RUN` Dockerfile instructions) or until it exports stages as tarballs.

Additionally, if the image is formatted as stargz/eStargz, buildkit with the configuration described here can skip pulling that image even when it is needed (such as on `RUN` and `COPY` instructions).
Instead, it *mounts* that image from the registry to the node and *lazily* fetches necessary files (or chunks for large files) contained in that image on demand.
This can reduce the time required for the build.
This document describes the configuration and usage of this feature.

For more details about the stargz/eStargz image format, see the [Stargz and eStargz image formats](#stargz-and-estargz-image-formats) section.

## Known limitations

- For OCI worker, `~/.docker/config.json`-based authentication cannot be used for stargz/eStargz-based lazy pulling.
- For containerd worker, the stargz snapshotter (`containerd-stargz-grpc`) must be run and configured separately.
- Rootless execution is currently unsupported.

## Enabling lazy pulling of stargz/eStargz images

Buildkit supports two ways to enable lazy pulling of stargz/eStargz images.

### Using builtin support (recommended)

OCI worker has built-in support for stargz/eStargz.
You can enable this feature by running `buildkitd` with the option `--oci-worker-snapshotter=stargz`.

```
buildkitd --oci-worker-snapshotter=stargz
```

This is the easiest way to use this lazy pull feature on buildkit.
Currently, this configuration is unsupported for containerd worker.

#### Example of building an image with lazy pull

Once `buildkitd` starts with the above configuration, stargz/eStargz images can be lazily pulled.
For example, the following golang binary is built with buildkit.

```golang
package main

import "fmt"

func main() {
	fmt.Println("Hello, world!")
}
```

The example Dockerfile that leverages an eStargz-formatted base image is as follows.

```Dockerfile
# Uses eStargz-formatted golang image as the base image. This is not pulled here.
FROM ghcr.io/stargz-containers/golang:1.15.3-buster-esgz AS dev

# Copies the source code from the context. The base image is mounted and lazily pulled.
COPY ./hello.go /hello.go

# Runs the go compiler on the base image. The base image is mounted and lazily pulled.
RUN go build -o /hello /hello.go

FROM scratch

# Harvests the result binary.
COPY --from=dev /hello /
```

This image can be built while skipping the pull of `ghcr.io/stargz-containers/golang:1.15.3-buster-esgz`.
Instead, this image is mounted from the registry to the node, and necessary chunks of contents (such as the `go` command binary and libraries) are partially fetched from that registry on demand.

```
$ buildctl build --frontend dockerfile.v0 \
                 --local context=/tmp/hello \
                 --local dockerfile=/tmp/hello \
                 --output type=local,dest=./
$ ./hello
Hello, world!
```

Note that when a stage is exported (for example, to the registry), the base image (even if formatted as stargz/eStargz) of that stage must be pulled to copy it to the destination.
However, if the destination is a registry and the target repository already contains some blobs of that image, or if [cross repository blob mount](https://docs.docker.com/registry/spec/api/#cross-repository-blob-mount) can be used, buildkit keeps these blobs lazy.

Also note that although registry configuration in `/etc/buildkit/buildkitd.toml` is applied to lazy pulling as well, `~/.docker/config.json`-based authorization is currently not supported.
Integration work is in progress.

### Using proxy (standalone) snapshotter

This is another way to enable stargz-based lazy pull.
[Stargz Snapshotter (`containerd-stargz-grpc`)](https://github.com/containerd/stargz-snapshotter) must be installed.
Note that buildkit's registry configuration does not propagate to stargz snapshotter, so it must be configured separately when using private or mirror repositories.

This configuration is for users of containerd worker and those trying other versions of stargz snapshotter than the one built into OCI worker.

#### With OCI worker

Spawn `containerd-stargz-grpc` as a separate process.
Then run `buildkitd` with the option `--oci-worker-proxy-snapshotter-path=/run/containerd-stargz-grpc/containerd-stargz-grpc.sock`, which makes it recognize this snapshotter via the socket.

```
containerd-stargz-grpc
buildkitd --oci-worker-snapshotter=stargz \
          --oci-worker-proxy-snapshotter-path=/run/containerd-stargz-grpc/containerd-stargz-grpc.sock
```

#### With containerd worker

Configure containerd's config.toml (default = `/etc/containerd/config.toml`) to recognize stargz snapshotter as a [proxy snapshotter](https://github.com/containerd/containerd/blob/master/PLUGINS.md#proxy-plugins).

```toml
[proxy_plugins]
  [proxy_plugins.stargz]
    type = "snapshot"
    address = "/run/containerd-stargz-grpc/containerd-stargz-grpc.sock"
```

Then spawn `containerd-stargz-grpc` and `containerd`, and run `buildkitd` with the option `--containerd-worker-snapshotter=stargz`, which tells `containerd` to use the stargz snapshotter.

```
containerd-stargz-grpc
containerd
buildkitd --containerd-worker-snapshotter=stargz --oci-worker=false --containerd-worker=true
```

#### Registry-related configurations for standalone stargz snapshotter

When using a standalone stargz snapshotter, registry configuration must be done separately for the stargz snapshotter process.
Create a configuration TOML file that contains the registry configuration for stargz snapshotter (for example, `/etc/containerd-stargz-grpc/config.toml`).
The configuration format [**differs** from buildkit](https://github.com/containerd/stargz-snapshotter/blob/master/cmd/containerd-stargz-grpc/config.go).
For more information about this format, see the [documentation in the repository](https://github.com/containerd/stargz-snapshotter/blob/master/docs/overview.md#registry-related-configuration).

```toml
[[resolver.host."exampleregistry.io".mirrors]]
host = "examplemirror.io"
```

Then pass this file to the stargz snapshotter through the `--config` option.

```
containerd-stargz-grpc --config=/etc/containerd-stargz-grpc/config.toml
```

## Stargz and eStargz image formats

[Stargz](https://github.com/google/crfs/blob/master/README.md#introducing-stargz) and [eStargz](https://github.com/containerd/stargz-snapshotter/blob/master/docs/stargz-estargz.md) are OCI/Docker-compatible image formats that can be lazily pulled from standard registries (such as Docker Hub or GitHub Container Registry).
Because they are backwards-compatible with OCI/Docker images, they can run on standard runtimes (such as Docker or containerd).
Stargz is proposed by the [Google CRFS project](https://github.com/google/crfs).
eStargz is an extended format of stargz developed by the [Stargz Snapshotter project](https://github.com/containerd/stargz-snapshotter).
It includes [additional features](https://github.com/containerd/stargz-snapshotter/blob/master/docs/stargz-estargz.md#estargz-archive-format) such as chunk verification and prefetch, which help avoid the overhead of on-demand fetching.
For more details about lazy pull with stargz/eStargz images, refer to the documentation in these repositories.

### Getting stargz/eStargz formatted images

Pre-converted stargz/eStargz images are available at the [`ghcr.io/stargz-containers` repository](https://github.com/containerd/stargz-snapshotter/blob/master/docs/pre-converted-images.md) (mainly for testing purposes).

You can also create any stargz/eStargz image by converting an OCI/Docker image to a stargz/eStargz-formatted image using one of the following tools.

- [`ctr-remote`](https://github.com/containerd/stargz-snapshotter#creating-stargz-images-and-further-optimization), developed in the stargz snapshotter project.
- [`stargzify`](https://github.com/google/crfs/tree/master/stargz/stargzify), developed in the CRFS project (creating eStargz images is unsupported).

For more details about these tools, refer to the documentation in these repositories.
