# The Evolution of Curl: A Technical Chronicle (1996–2020)

## Introduction

Curl is a versatile command-line tool and library for transferring data with URLs. Since its inception in 1996, it has grown from a simple utility for retrieving web currency into a comprehensive solution supporting numerous protocols, including HTTP, HTTPS, FTP, FTPS, SCP, SFTP, TFTP, LDAP, DICT, TELNET, FILE, IMAP, POP3, SMTP, RTSP, and RTMP. This document recounts the development chronology of curl, highlighting key technical milestones, architectural shifts, and community growth from its origins through 2020.

## Early Origins and Foundation (1996–1998)

The genesis of curl lies in 1996, when Daniel Stenberg required an automated method to retrieve web currency for an Amiga-channel IRC bot on the EFnet network. To fulfill this need, Stenberg adapted Rafael Sagula’s open-source httpget 0.1. By April 8, 1997, HttpGet 1.0 was released, introducing support for HTTP proxies and repairing GOPHER currency retrieval. Subsequent FTP support led to the renaming of the project to urlget 2.0 in August 1997.

The transition to the name "curl" occurred in 1998, prompted by the addition of upload support. Curl 4 was released on March 20, retaining the numbering scheme established by its predecessors. During this period, the project faced external pressure when the unrelated Curl Corporation registered the CURL trademark in the US on May 18, having acquired curl.com the previous November. Despite this, development accelerated. SSLeay was integrated to provide SSL support, and a freshmeat announcement was made in August.

By October 1998, curl 4.9 introduced cookie support and changed the license from GPL to MPL, with the codebase reaching approximately 4,000 lines. November saw the addition of the configure script, broader operating system builds, the -F flag, and TELNET support. The release of curl 5 in December marked a significant milestone by introducing a man page and RPM packaging, establishing a more professional distribution framework.

## Expansion and Stabilization (1999–2002)

The year 1999 brought substantial protocol expansion and community adoption. January saw the addition of DICT support, followed by the replacement of SSLeay with OpenSSL. In May, the first Debian package was created, signaling growing Linux integration. August introduced LDAP and FILE support, with the project experiencing approximately 1,300 weekly site visits and migrating to curl.haxx.nu. The major release of 6.0 in September expanded the codebase to roughly 15,000 lines. By December 28, SourceForge was adopted as the primary hosting platform.

In 2000, curl underwent an internal library-interface overhaul, leading to the non-beta release of 7.1 in August, which introduced the easy interface. The codebase grew to about 20,000 lines. The project’s website moved to curl.haxx.se in June, reaching 4,000 weekly visits by August. PHP adopted libcurl in version 4.0.2, spawning a wave of additional language bindings. Kerberos4 support arrived in September. Testing infrastructure work began in November, and libcurl established its SONAME as 1.

The release of 7.5.2 in January 2001 offered users a choice between MIT or MPL licensing. Version 7.7, released on March 22, added HTTP/1.1 persistent connections, experimental FTPS, and brought the line count to roughly 24,000, incrementing SONAME to 2. Mac OS X 10.1 bundled curl in August, coinciding with the site reaching 8,000 weekly visits. Although Curl Corporation contacted Daniel Stenberg regarding naming rights, the matter did not proceed further. September’s 7.9 introduced cookie jars and curl_formadd, while the multi interface development commenced during the 7.9.x series.

By mid-2002, curl supported successful builds on over 40 CPU/OS combinations. The site recorded 13,000 weekly visits, and the codebase reached 35,000 lines. Approximately 5,000 weekly direct package downloads were recorded, though total user numbers were higher due to mirrors and distribution bundling. On October 1, 2002, version 7.10 became MIT-only and enabled SSL certificate verification by default, enhancing security posture.

## Maturity and Security Focus (2003–2008)

In January 2003, distributed autobuild testing was initiated to improve reliability. By February, site activity reached 20,000 weekly visits with approximately three concurrent readers. Digest authentication arrived in May, followed by NTLM/Negotiate support in June. By November, version 7.10.8 contained 45,000 lines of code, attracted roughly 55,000 unique visitors, and utilized five official mirrors. December 2003 completed FTP-over-SSL support.

The 2004 release of 7.11.0 in January introduced large file support. June’s 7.12.0 added IDN support and removed curl_formparse, increasing SONAME to 3. Statistical data from August 7.12.1 recorded releases, options, functions, mirrors, and bindings. In 2005, optional GnuTLS and multi_socket support arrived in April, along with TFTP in September. The project surpassed 100,000 site visitors and expanded to 25 mirrors. However, December 2005 saw a URL-buffer-overflow vulnerability, highlighting the ongoing need for rigorous security audits.

January 2006 saw the removal of Gopher support due to long-standing, unnoticed bugs. A TFTP packet overflow was reported in March. In September, the removal of FTP third-party transfer functionality increased SONAME to 4. SCP and SFTP support arrived in November. The 2007 release cycle introduced an NSS backend in February and addressed a GnuTLS certificate-verification vulnerability in July.

By 2008, the project’s scale was evident in its statistics: 128 CLI options, 158 setopt options, 58 functions, 37 bindings, 683 contributors, 145,000 visitors, and over 100 GB downloaded.

## Modernization and Protocol Advancement (2009–2015)

The period from 2009 to 2015 marked significant architectural and security improvements. March 2009 saw an arbitrary-file-access vulnerability, while April introduced CMake support. An embedded-zero certificate-name vulnerability was identified in August. December 2009 added IMAP, POP3, and SMTP support.

In 2010, RTSP support arrived in January, followed by an excessive data-callback-length vulnerability fix in February. Git and GitHub replaced CVS in March, modernizing the version control workflow. RTMP support was added in May, along with PolarSSL support. Gopher was restored in August. By August 2010, statistics recorded 117 releases, 138 CLI options, 180 setopt options, 58 functions, 39 bindings, and 808 contributors.

The years 2011 and 2012 focused on SSL backend diversity. axTLS was added in February 2011, followed by cyassl (later WolfSSL) in April. In July 2012, Schannel and Darwin SSL backends were introduced. Metalink support and SSH-agent were added in October 2012.

A major internal shift occurred in February 2013 with the introduction of an internally nonblocking multi-based implementation, accompanied by a blocking wrapper. Initial nghttp2 HTTP/2 work began in September. Kerberos 4 support was removed in October, and Happy Eyeballs was added in December.

March 2014 saw the first released HTTP/2 support. By September, site traffic reached 245,000 unique visitors and 236 GB of data. SMB and SMBS support were added. In June 2015, HTTP/2 multiplexing was introduced, followed by server push in August. The Public Suffix List was added in December.

## Recent Developments and Scale (2016–2020)

The final phase of this chronology highlights curl’s integration into modern web infrastructure. In January 2016, tool defaults shifted to HTTP/2 for HTTPS. December’s 7.52.0 added HTTPS proxies and initial TLS 1.3 support.

July 2017 introduced OSS-Fuzz for continuous fuzzing, and Multi-SSL support was added in September. Site traffic reached 3,100 GB/month. Statistics from this period showed 169 releases, 211 CLI options, 249 setopt options, 74 functions, and 1,609 contributors. October added SSLKEYLOGFILE and the MIME API, and Daniel Stenberg received the Polhem Prize. November added Brotli compression support.

In January 2018, a libssh backend was introduced. Windows 10 version 1803 bundled curl from March. July introduced bold headers, and October added DNS-over-HTTPS and the URL API, along with the MesaLink backend. HTTP/2 multiplexing became the default for libcurl HTTPS. By this time, estimated installations reached five billion. Statistics from October 31, 2018, listed 177 releases, 219 CLI options, 261 setopt options, 80 functions, and 1,808 contributors. axTLS was removed in December.

The 2019 release cycle included experimental alt-svc in March and the first HTTP/3 requests in August. Parallel CLI downloads were added in September’s 7.66.0.

In 2020, estimated installations reached ten billion. BearSSL was added in January. PolarSSL was removed and wolfSSH was added in March. Experimental MQTT support arrived in April, and zstd compression was added in August. In November, the website moved to www.curl.se, serving 10 TB monthly.

## Technical Statistics Summary

Throughout its history, curl’s API and feature set have expanded significantly. The following data points illustrate the growth in functionality and community contribution:

**Early Statistics (Circa 2008):**
*   Command line options: 128
*   curl_easy_setopt() options: 158
*   Public functions in libcurl: 58
*   Known libcurl bindings: 37
*   Contributors: 683

**2010 Statistics:**
*   Public curl releases: 117
*   Command line options: 138
*   curl_easy_setopt() options: 180
*   Public functions in libcurl: 58
*   Known libcurl bindings: 39
*   Contributors: 808

**2017 Statistics:**
*   Public curl releases: 169
*   Command line options: 211
*   curl_easy_setopt() options: 249
*   Public functions in libcurl: 74
*   Contributors: 1609

**2018 Statistics (October 31):**
*   Public curl releases: 177
*   Command line options: 219
*   curl_easy_setopt() options: 261
*   Public functions in libcurl: 80
*   Contributors: 1808

**Current Release Statistics:**
*   Public curl release number: 82
*   Releases counted from the very beginning: 109
*   Available command line options: 96
*   Available curl_easy_setopt() options: 120
*   Number of public functions in libcurl: 36
*   Amount of public website mirrors: 12
*   Number of known libcurl bindings: 26

From a small IRC bot utility to a critical component of the internet infrastructure, curl’s development reflects a continuous commitment to protocol support, security, and open-source collaboration.
