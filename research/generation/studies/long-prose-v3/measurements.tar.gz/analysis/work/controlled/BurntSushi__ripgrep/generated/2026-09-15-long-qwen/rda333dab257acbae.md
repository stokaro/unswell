# Ripgrep Technical Documentation

## Purpose and Scope

This documentation serves as a comprehensive reference for software developers utilizing ripgrep. It addresses critical aspects of the tool’s operation, including search semantics, performance characteristics, configuration options, Windows-specific usage considerations, and project policy. The material is derived strictly from the provided facts and technical source code examples, offering a precise guide for integrating and optimizing ripgrep in various development environments.

## Configuration and Encoding

Configuration details and encoding behaviors are primarily documented in the `GUIDE.md` file, while changes to the software are tracked in `CHANGELOG.md`. It is important to note that volunteers publish updates on a best-effort basis without fixed release dates. While serious regressions may motivate a patch, the project does not make any timing promises regarding fixes.

When `asciidoctor` or `asciidoc` is installed, the build process generates a man page from the argument parser located in the build output. Specifically, the generated man page can be found under the target directory. Binary releases include this documentation. For option details, users can consult `rg --help`, which provides equivalent information to the man page. Alternatively, `rg -h` offers a condensed view, listing each flag on a single line for quick reference.

## Shell Completions

Builds and releases of ripgrep include shell completions to enhance the user experience across different command-line environments. The implementation varies by shell:

*   **Zsh**: A separately maintained file named `complete/_rg` provides completion support.
*   **Bash**: Completions are available in `rg.bash`. Users should place this file in either `$XDG_CONFIG_HOME/bash_completion` or `/etc/bash_completion.d`.
*   **Fish**: Completions are provided in `~/.config/fish/completions/rg.fish`.
*   **Zsh (Alternative)**: The `_rg` file can be installed in the `fpath` variable for completion.
*   **PowerShell**: Profiles should dot-source `_rg.ps1`. If the script is not available on the `PATH`, the full path must be used.

## Search Semantics and Parallelism

Parallel search is a core feature of ripgrep, designed to maximize performance on multi-core systems. However, developers must be aware that parallel search produces nondeterministic result order. To achieve consistent ordering, users can employ the `--sort path` option. It is important to note that using `--sort path` disables parallelism. In smaller repositories, this disabling of parallelism may result in little to no noticeable slowdown.

The `-z` or `--search-zip` option allows ripgrep to handle compressed files directly. It supports gzip, bzip2, xz, lzma, lz4, Brotli, and Zstd formats by invoking installed decompressor processes. Developers should note that this option does not search archive formats such as `tar.gz`; it only handles individual compressed files.

For searches that require matching patterns spanning multiple lines, the `-U` or `--multiline` flag must be used. This option allows results to span lines, which significantly impacts performance and memory usage, as detailed in the Performance section.

## Regular Expression Engines

Ripgrep utilizes two primary regular expression engines: a default engine and the optional PCRE2 engine.

### Default Engine

The default regex engine uses finite-state machines for matching. This approach provides linear worst-case matching time, ensuring predictable performance even on complex patterns. However, this engine does not implement backreferences or look-around assertions. It is designed for speed and simplicity in common search scenarios.

### PCRE2 Engine

The `-P` or `--pcre2` flag selects the optional PCRE2 engine. PCRE2 is a backtracking engine that supports additional regex features, including backreferences and look-around assertions. Most project release binaries enable PCRE2 support. However, builds obtained through package managers may differ in their configuration. Users relying on package-manager builds should contact the package maintainer to confirm if PCRE2 is enabled.

The source code supplies a palindrome example and demonstrates the error message produced when attempting to use unsupported features with the default engine. For instance, attempting to use a backreference with the default engine will result in an error.

### Engine Selection and Newline Handling

The default line-only search mode is designed to prevent matches from spanning newlines. The default engine exposes syntax analysis capabilities that allow it to remove newline characters from character classes, such as `\s`. This optimization enables ripgrep to search buffers without scanning each line separately, maintaining high performance.

In contrast, explicit unsupported newline literals cause an error in the default engine. This behavior ensures that patterns intended to match newlines are handled correctly or rejected if they violate the line-only constraint.

When using PCRE2, equivalent introspection is unavailable to ripgrep. Consequently, ripgrep is forced to perform line-by-line search in modes where newline handling is critical for PCRE2 patterns. This difference in engine capabilities means that certain optimizations available in the default engine are not possible with PCRE2.

## Color Configuration

Ripgrep provides extensive control over output coloring through the `--color` and `--colors` options.

### Color Modes

The `--color` option determines when colors appear in the output:
*   `never`: Disables color output.
*   `auto`: The default setting. Colors are enabled only for terminal outputs.
*   `always`: Forces color output regardless of the output destination.
*   `ansi`: Enables ANSI color codes, useful for piping to other tools that support ANSI.

### Color Configuration

The `--colors` option allows for detailed configuration of path, line, column, and match elements. Users can specify foreground (`fg`), background (`bg`), and style (`style`) attributes.

Style values include:
*   `bold` / `nobold`
*   `intense` / `nointense`
*   `underline` / `nounderline`

Colors can be specified using eight named colors, decimal or hexadecimal indices from 0 to 255, or comma-separated RGB triples. To reset the styling of a specific element, users can use `type:none`.

#### Examples

A bold white text on a blue background can be achieved with:
```
rg somepattern \
    --colors 'match:none' \
    --colors 'match:bg:0x33,0x66,0xFF' \
    --colors 'match:fg:white' \
    --colors 'match:style:bold'
```

A Silver Searcher-like scheme can be configured as follows:
```
rg --colors line:fg:yellow      \
   --colors line:style:bold     \
   --colors path:fg:green       \
   --colors path:style:bold     \
   --colors match:fg:black      \
   --colors match:bg:yellow     \
   --colors match:style:nobold  \
   foo
```

RGB values can also be used directly in the foreground or background attributes:
```
rg somepattern --colors 'match:fg:0x33,0x66,0xFF'
```

To reset all styling and then apply a specific foreground color:
```
rg somepattern --colors 'match:none' --colors 'match:fg:0x33,0x66,0xFF'
```

#### Configuration Files

Users can activate a configuration file using the `RIPGREP_CONFIG_PATH` environment variable. This allows for persistent color settings without typing long command-line arguments.

Example configuration file (`$HOME/.config/ripgrep/rc`):
```
--colors=line:fg:yellow
--colors=line:style:bold
--colors=path:fg:green
--colors=path:style:bold
--colors=match:fg:black
--colors=match:bg:yellow
--colors=match:style:nobold
```

Usage:
```
RIPGREP_CONFIG_PATH=$HOME/.config/ripgrep/rc rg foo
```

The syntax for specifying colors in the command line or config file follows the pattern `--colors '{type}:{attribute}:{value}'`.

## Windows-Specific Considerations

Windows terminals present unique challenges for color output and truecolor support.

### Truecolor Support

*   **Cygwin**: May support truecolor directly.
*   **Pre-Windows-10 Consoles**: There is no known route to truecolor support in ordinary pre-Windows-10 consoles.
*   **Windows 10**: Supports VT100 escapes for truecolor. However, developers must clear the default match styling first if bold formatting interferes with truecolor VT100 escapes.

### Color Restoration

After interrupted output, the color state in `cmd.exe` may be altered. The `color` command in `cmd` or a Unix reset escape can restore the color. For PowerShell users, a supplied `Reset-ForegroundColor` function and alias provide a convenient way to reset the color.

Example PowerShell function:
```powershell
$OrigFgColor = $Host.UI.RawUI.ForegroundColor
function Reset-ForegroundColor {
	$Host.UI.RawUI.ForegroundColor = $OrigFgColor
}
Set-Alias -Name color -Value Reset-ForegroundColor
```

Earlier handling of these issues changed through Pull Request 187 and Issue 281.

## Regex Size Limits and Cache Management

Large compiled regular expressions can hit a size limit, even if the source pattern is short. For example, a Unicode-letter class repeated 1,000 times can exceed the limit.

### Regex Size Limit

The `--regex-size-limit` option raises the approximate compilation allowance for regexes. For example:
```
rg '\pL{1000}'
Compiled regex exceeds size limit of 10485760 bytes.

rg '\pL{1000}' --regex-size-limit 1G
```
Note that specifying a 1 GB allowance does not automatically allocate 1 GB of memory. It only increases the limit for compilation.

### DFA Size Limit

When many patterns are supplied using `-f` or `--file` (which reads one pattern per line and matches their union), the fast engine's cache may be exhausted, triggering a slower engine. The `--dfa-size-limit` option raises this cache allowance. Similar to `--regex-size-limit`, setting `--dfa-size-limit 1G` does not automatically allocate 1 GB of memory.

## Unicode and Encoding Handling

Ripgrep handles Unicode and encoding with specific behaviors to ensure correctness and performance.

### PCRE2 Unicode Mode

PCRE2 Unicode mode requires valid UTF-8 input. The default engine can search arbitrary bytes while refusing invalid sequences for Unicode-only patterns.

By default, ripgrep transcodes invalid UTF-8 to replacement characters before performing a PCRE2 search. It also disables redundant PCRE2 checks to improve performance. Passing invalid data directly to PCRE2 would produce errors and stop the search for that file.

The `--no-encoding` option skips ripgrep's conversion but re-enables PCRE2 validation. This can be slower and may expose invalid-UTF-8 errors.

Example of invalid UTF-8 handling:
```
$ cat invalid-utf8
foobar
$ xxd invalid-utf8
00000000: 666f 6fff 6261 720a                      foo.bar.
$ rg foo invalid-utf8
1:foobar
$ rg -P foo invalid-utf8
1:foo�bar
$ rg -P foo invalid-utf8 --no-encoding
invalid-utf8: PCRE2: error matching: UTF-8 error: illegal byte (0xfe or 0xff)
```

### Locale Independence

Ripgrep's Unicode behavior does not depend on locale settings. This ensures consistent behavior across different system configurations.

## Performance Analysis

Performance is a key focus of ripgrep. The tool employs various strategies to optimize search speed, including parallel processing, memory mapping, and efficient regex engines.

### Memory Mapping and Multiline Search

Multiline search (`-U`) requires the whole file to be in memory because a match can be arbitrarily long. Ripgrep normally uses a memory map to supply this data. However, UTF-8 conversion requires a heap copy, which can impact performance.

The default engine can recognize a pattern that cannot cross lines and keep its fast incremental strategy even with `-U`. With PCRE2, combining `-U` and `--no-pcre2-unicode` can avoid both line-by-line searching and decoding, allowing mapping and JIT speed when Unicode semantics and cross-line restrictions are unnecessary. Disabling Unicode can miss non-ASCII word characters, so users should weigh the trade-offs.

### Performance Experiments

The following experiment uses a large file and the pattern `^\w{42}$` with one hit and no literal shortcut.

Default engine performance:
```
$ time rg '^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.783s
user    0m1.731s
sys     0m0.051s
```

PCRE2 engine performance:
```
$ time rg -P '^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m2.458s
user    0m2.419s
sys     0m0.038s
```

PCRE2 with `--no-encoding`:
```
$ time rg -P '^\w{42}$' subtitles2016-sample --no-encoding
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m3.074s
user    0m3.021s
sys     0m0.051s
```

Multiline search with default engine:
```
$ time rg -U '^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.803s
user    0m1.748s
sys     0m0.054s
```

Multiline search with PCRE2:
```
$ time rg -P -U '^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m2.962s
user    0m2.246s
sys     0m0.713s
```

Optimized multiline search with default engine (no unicode):
```
$ time rg '(?-u)^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.714s
user    0m1.669s
sys     0m0.044s
```

Optimized multiline search with PCRE2 (`--no-pcre2-unicode`):
```
$ time rg -P '^\w{42}$' subtitles2016-sample --no-pcre2-unicode
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.997s
user    0m1.958s
sys     0m0.037s
```

Multiline search with default engine (no unicode):
```
$ time rg -U '(?-u)^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.714s
user    0m1.655s
sys     0m0.058s
```

Multiline search with PCRE2 (`--no-pcre2-unicode`):
```
$ time rg -P -U '^\w{42}$' subtitles2016-sample --no-pcre2-unicode
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.121s
user    0m1.071s
sys     0m0.048s
```

### Tracing Performance

The `--trace` flag distinguishes between fast and slow line search and decoding strategies.

Default engine trace:
```
$ rg '^\w{42}$' subtitles2016-sample --trace
[... snip ...]
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:622: Some("subtitles2016-sample"): searching via memory map
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:712: slice reader: searching via slice-by-line strategy
TRACE|grep_searcher::searcher::core|grep-searcher/src/searcher/core.rs:61: searcher core: will use fast line searcher
[... snip ...]
```

PCRE2 trace:
```
$ rg -P '^\w{42}$' subtitles2016-sample --trace
[... snip ...]
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:622: Some("subtitles2016-sample"): searching via memory map
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:705: slice reader: needs transcoding, using generic reader
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:685: generic reader: searching via roll buffer strategy
TRACE|grep_searcher::searcher::core|grep-searcher/src/searcher/core.rs:63: searcher core: will use slow line searcher
[... snip ...]
```

Possible differences in UTF-8 validation include `encoding_rs` SIMD optimizations. This is an explanation considered by the author, not a proven universal PCRE2 limitation.

## PowerShell Integration

PowerShell users may encounter specific behaviors related to argument propagation and input piping.

### Wrapper Functions

PowerShell wrappers must propagate arguments and only pipe input when input exists. Piping an empty input object makes ripgrep search empty stdin.

Example wrapper function:
```powershell
function grep {
    $count = @($input).Count
    $input.Reset()

    if ($count) {
        $input | rg.exe --hidden $args
    }
    else {
        rg.exe --hidden $args
    }
}
```

The profile path is exposed by the `profile` variable, and its script runs at startup.

### Output Encoding

PowerShell's `OutputEncoding` controls bytes piped to native processes. The documented default is US-ASCII, which turns unsupported characters into question marks.

To persist UTF-8 encoding, users should set a `.NET UTF8Encoding` or the console output encoding in their profile. `Console.OutputEncoding` can separately be set to UTF-8 for display.

## Unexpected Behavior and Aliases

Unexpected ripgrep behavior may come from another executable or alias. A notable example is Oh My Zsh, which may map `rg` to `rails generate`.

To inspect this, users can use `which rg`. Options to resolve the issue include:
*   Disabling the plugin.
*   Using the command `rg` explicitly.
*   Escaping or quoting the invocation.
*   Using a full executable path.
*   Running `unalias rg`.
*   Creating a distinct ripgrep alias.

## File Modification and Replacement

Ripgrep never edits files. It is designed for searching, not modifying. However, it can list matching paths for use with tools like `xargs` and `sed` to modify files.

### GNU sed

GNU sed uses the `-i` option with a substitution.

Example:
```
rg foo --files-with-matches | xargs sed -i 's/foo/bar/g'
```

### BSD sed

BSD sed requires a backup-extension argument. An empty string disables backups.

Example:
```
rg foo --files-with-matches | xargs sed -i '' 's/foo/bar/g'
```

### Paths with Whitespace

Paths containing whitespace require NUL-delimited ripgrep output and `xargs -0` to handle correctly.

Example:
```
rg foo --files-with-matches -0 | xargs -0 sed -i 's/foo/bar/g'
```

### Alternative Tools

`fastmod` is another replacement tool that shares some underlying libraries with ripgrep.

## Project Policy and Licensing

### Licensing

Users may choose between the MIT License and the Unlicense for their contributions or usage. The author favors the Unlicense for its copyright-disclaimer goal but offers familiar MIT terms for adoption. All direct and transitive dependencies must remain permissively licensed. GPL, LGPL, MPL, and Creative Commons ShareAlike licenses are excluded, even when described as weak copyleft.

### Name History

The name "ripgrep" has a specific history. Earlier names included `rep` and `xrep`. `rustgrep` and `rgrep` were also considered. The name `rip` was chosen to suggest fast searching while retaining an `r` associated with Rust. The interpretation of "RIP" as a "grep-killer" was noticed only after release and was not the intended meaning.

### Donations

The author declines donations to preserve a personally sustainable volunteer relationship with the project. Instead, the author suggests supporting organizations such as the Internet Archive, Rails Girls, or Wikipedia.

## Comparison with Other Tools

Ripgrep can replace some `grep` uses, especially for recursive code search with ignore files, Unicode/UTF-16 support, and parallel large-directory searches. However, it is not a complete behavior-compatible replacement for `grep`. It is not POSIX conformant and is less ubiquitous for portable scripts.

GNU `grep` with filters, wrappers, and parallel `xargs` may be sufficient for some use cases. Missing required features remain a reason to use another tool. Developers should evaluate their specific needs when choosing between ripgrep and other search tools.

## Additional Technical Details

### Regex Examples

Backreferences are supported only with the PCRE2 engine.

Example with backreference:
```
$ rg -P '(\w{10})\1'
tests/misc.rs
483:    cmd.arg("--max-filesize").arg("44444444444444444444");
globset/src/glob.rs
1206:    matches!(match7, "a*a*a*a*a*a*a*a*a", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
```

Attempting to use backreferences with the default engine results in an error:
```
$ rg -P '(\w{10})\1'
PCRE2 is not available in this build of ripgrep
```

### Newline Literals

Explicit newline literals are not allowed in the default engine.

Example:
```
$ rg '\n'
the literal '"\n"' is not allowed in a regex
```

### Man Page Generation

The man page is generated from the argument parser. The build output location can be found using:

```
$ find ./target -name rg.1 -print0 | xargs -0 ls -t | head -n1
./target/debug/build/ripgrep-79899d0edd4129ca/out/rg.1
```

### Sample Data

For testing purposes, sample data can be downloaded and processed.

Example:
```
$ curl -O 'https://burntsushi.net/stuff/subtitles2016-sample.gz'
$ gzip -d subtitles2016-sample
$ md5sum subtitles2016-sample
e3cb796a20bbc602fbfd6bb43bda45f5   subtitles2016-sample
```

This documentation provides a comprehensive overview of ripgrep's capabilities, limitations, and configuration options. By understanding these details, developers can effectively integrate ripgrep into their workflows and troubleshoot any issues that may arise.
