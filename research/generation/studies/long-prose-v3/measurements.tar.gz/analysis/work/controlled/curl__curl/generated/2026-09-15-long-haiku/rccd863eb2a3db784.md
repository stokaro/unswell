# Curl Security Vulnerability Handling and Disclosure

## Vulnerability Publication

Published curl and libcurl vulnerabilities are documented and maintained on curl.se/docs/security.html, serving as the authoritative public registry of all disclosed security issues affecting the curl project. This resource provides users, system administrators, and downstream distributors with comprehensive information necessary to understand and remediate known vulnerabilities.

## Reporting Undisclosed Vulnerabilities

Undisclosed vulnerabilities must never be reported in curl's public issue tracker or discussed on public project mailing lists. The proper channel for reporting potential security issues is through HackerOne at hackerone.com/curl. Reports submitted through HackerOne reach a selected group of trusted maintainers who have been designated to handle security matters. Messages unrelated to reporting or managing undisclosed curl or libcurl vulnerabilities submitted through HackerOne will receive no action, focusing the channel on legitimate security concerns.

## Security Team Investigation and Response

When a vulnerability report is received, a security-team member acknowledges receipt, conducts an investigation of the submission, and then either accepts or rejects the report. If the report is rejected, the rejection includes an explanation of why the submission does not qualify as a vulnerability according to project policy. If the report is accepted, the reporter receives notification that work on developing a security fix has begun.

## Impact Assessment and Fix Development

After accepting a report, the security team assesses the impact of the vulnerability, develops a fix addressing the issue, and proposes timing for public disclosure. The reporter is involved in this process where possible. Coordinated disclosure should occur promptly, typically through a scheduled release that contains the fix. However, if the next scheduled release is too distant to permit appropriate disclosure timing, the security team may prepare and release an earlier separate release specifically to address the vulnerability.

## Advisory Preparation

The draft advisory prepared during the security response process must include several key elements: a clear statement of the problem, a description of the impact on affected systems and users, identification of all versions of curl and libcurl that are affected, specification of available fixes and workarounds, documentation of the planned release timing, and appropriate credit to the reporter.

As part of advisory preparation, the security team identifies the relevant Common Weakness Enumeration (CWE) classification corresponding to the vulnerability. The team also requests a CVE identifier through HackerOne. Once HackerOne assigns a CVE number, it is added to the advisory document.

## Distribution Coordination

Before public disclosure, the security team should consider notifying the distros@openwall mailing list with the draft advisory. This notification allows downstream software distributions to prepare their own patches and coordinate their release schedules. The distros@openwall list enforces specific constraints: it accepts embargoes lasting no more than 14 days, and it does not accept notifications for vulnerabilities affecting only Windows-based software. This policy ensures that the embargo list focuses on issues relevant to broadly distributed platforms.

## Commit and Branching Strategy

The security fix is committed on a private branch rather than in the public repository during the coordination period. The private commit message should contain the assigned CVE identifier for reference and tracking purposes. Before public disclosure occurs, the fix on the private branch is normally shared with relevant distribution maintainers, allowing them to begin their own preparation and testing efforts.

Public commit messages must not identify changes as security fixes prior to coordinated disclosure. This requirement prevents premature public awareness of the vulnerability while the fix is being prepared and coordinated.

## Public Merge and Release

The fix is merged and pushed to the public master branch no more than 48 hours before the scheduled release. Public access to the fixed code begins at the moment of this push to the public repository. The release follows promptly after final testing and comprehensive review. The released version must contain the security fix to ensure users receive the remediation.

## Announcement and Documentation

The release and vulnerability are announced through curl's standard communication channels: the curl-announce, curl-library, and curl-users mailing lists. The public security documentation page is updated to reflect the newly disclosed vulnerability. A private discussion list, curl-security at haxx.se, supports extended coordination among authorized participants. Membership in curl-security is based on sustained involvement with the project and demonstrated understanding of curl's governance and processes. Membership is granted through invitation or explicit request; no public membership roster is maintained because membership evolves over time.

## Publication Workflow

The advisory is written in Markdown format using customary section subtitles. The advisory file is named after the assigned CVE identifier. An entry is prepended to curl-www/docs/vuln.pm to document the new advisory. The advisory file itself is added to curl-www/docs. Before release, run make in the local website checkout and carefully inspect the rendered output to verify correct formatting. On the release day, push the curl-www repository's master branch to publish the advisory.

## Post-Publication Disclosure Policy

After the vulnerability becomes public, request disclosure of the HackerOne issue, carefully redacting any sensitive information from the original report or discussion threads. The project policy emphasizes releasing as much information as possible promptly after a vulnerability is publicly disclosed, supporting transparency and community understanding.

Complete information about curl's bug bounty program is available at curl.se/docs/bugbounty.html. The procedures described above represent the historically documented workflow requirements for curl security handling.
