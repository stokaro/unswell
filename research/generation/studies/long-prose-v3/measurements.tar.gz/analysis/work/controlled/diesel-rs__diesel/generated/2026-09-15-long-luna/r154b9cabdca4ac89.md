# Contributing to Diesel

Diesel accepts suggestions, bug reports, and pull requests. Before filing an issue, questions and requests for help can be discussed in the Diesel Gitter channel. The code of conduct applies in all Diesel spaces, not only on GitHub.

## Reporting Bugs and Requesting Features

Before reporting a bug or requesting a feature, search both open and closed issues for the same subject or a similar one. An existing issue may already describe the problem, document a workaround, or explain the status of a requested change.

A bug report should include:

- The Rust version.
- The Diesel version.
- The enabled feature flags.
- The intended result.
- The full error.
- A reproduction containing enough code to demonstrate the problem, or a public repository or Gist.
- The relevant database schema.

A complete reproduction and schema help contributors understand the behavior without reconstructing the surrounding project.

A feature request should explain the goal and the support or implementation being proposed. It should also describe alternatives and the disadvantages of the proposed approach. These details make it possible to evaluate the request and compare possible solutions.

## Setting Up Local Development

Local development starts with Rust. Install Rust through `rustup`, which supports switching between toolchains. This snapshot supports the stable, nightly, and beta toolchains.

Install the database system libraries for the backends being tested. All drivers allow the full test suite. On macOS, SQLite requires no additional installation, and PostgreSQL’s `libpq` is already present. The documented shortcut for installing MySQL and PostgreSQL servers is:

```bash
brew install postgresql mysql
```

Follow the server setup instructions for the databases being used.

Clone the repository, then put the database connection details in a `.env` file at the repository root. Use `.env.sample` as a guide.

The MySQL tests fail on MySQL 5.6 or earlier in this snapshot. If upgrading MySQL locally is not possible, Docker provides an alternative. The selected MySQL test user may need privileges on databases matching `diesel_%`.

The source includes Docker commands that create the `diesel_test` and `diesel_unit_test` databases:

```bash
#!/usr/bin/env sh
set -e
docker run -d --name diesel.mysql -p 3306:3306 -e MYSQL_ALLOW_EMPTY_PASSWORD=true mysql
while
  sleep 1;
  ! echo 'CREATE DATABASE diesel_test; CREATE DATABASE diesel_unit_test;' | docker exec -i diesel.mysql mysql
do sleep 1; done

docker run -d --name diesel.postgres -p 5432:5432 postgres
while
  sleep 1;
  ! echo 'CREATE DATABASE diesel_test;' | docker exec -i diesel.postgres psql -U postgres
do :; done
```

Docker Compose is another option:

```bash
$ docker-compose up
```

After configuring Rust, database libraries, connection details, and servers, run `bin/test` to verify the local setup. The first compilation may take time.

## Formatting, Lints, and Pull Requests

Source formatting follows the Rust Style Guide and `rustfmt`. Select the toolchain from `rust-toolchain`, then install the formatting and linting components:

```bash
rustup component add rustfmt-preview
rustup component add clippy-preview
```

Run Clippy with:

```bash
cargo clippy
```

Pull requests must compile without warnings.

To check formatting without changing files, run:

```bash
cargo fmt --all -- --check
```

This command displays formatting differences and succeeds silently when formatting matches. Unexpected differences in untouched code can indicate that the wrong `rustfmt` version is being used. To apply formatting corrections, run:

```bash
cargo fmt --all
```

Editor integration for formatting is also available.

## Common Type Abbreviations

Diesel source code uses several common abbreviations. `ST` means SQL type and is generally constrained by `NativeSqlType`. `DB` means database and is generally constrained by `Backend`. `QS` means query source; it is often unconstrained, but is sometimes constrained by `QuerySource`.

`PK` means primary key. `Lhs` and `Rhs` mean the left-hand side and right-hand side, respectively. `Conn` means connection.

Prefer descriptive type names. For example, use `Lhs` and `Rhs` for the sides of a binary expression rather than unrelated names such as `T` and `U`. Consistent, descriptive names make the relationships between types clearer while preserving the established abbreviations used throughout Diesel.
