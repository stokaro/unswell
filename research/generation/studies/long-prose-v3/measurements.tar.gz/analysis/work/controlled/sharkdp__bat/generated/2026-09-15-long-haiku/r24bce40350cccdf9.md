# bat Changelog: CLI, Syntax, Library API, and Packaging Through v0.16.0

## v0.16.0

v0.16.0 extends command-line functionality and improves display behavior. The NO_COLOR environment variable is now supported, allowing users to disable colorization globally. A new `-P` flag disables paging, and the `--force-colorization` flag (short form `-f`) forces color output even to non-TTY destinations. These options address cases where redirected output previously failed to display non-printing characters correctly, and resolve conflicts between language extensions and syntax detection.

The display format now uses the middle-dot character (U+00B7) to represent spaces in output, improving visibility. Zsh shell integration has been enhanced with dedicated completion, help, and man page guidance.

Syntax highlighting improvements include updates to AsciiDoc, GLSL, Nginx and Apache configuration files, crypttab (accessed via fstab syntax definition), and XDG Git configuration files. Two new themes are added: Gruvbox and base16-256.

The library API gains an `InputDescription` type and support for providing `PrettyPrinter` with direct `Input` objects. The `Input::theme_preview_file` method is removed. The build dependency on the liquid template engine is removed.

## v0.15.4

v0.15.4 restores previously removed Solarized themes and fixes highlighting behavior in Haskell syntax.

## v0.15.3

Fixes address relative path handling and SSH user names beginning with digits. The SML (Standard ML) syntax is added.

## v0.15.2

Fixes correct syntax mapping for Rails Gemfiles, symlinked files, and files identified by name only. Header padding can now be applied without rendering grid lines. Invalid-syntax-related error messages are added. The `vcs_modification_markers` configuration option is deprecated when Git is not available. The underlying Syntect parser is upgraded to version 4.2, and the onig library is used instead, eliminating the build-time bindgen and libclang requirements.

## v0.15.1

Fixes address Markdown parsing in base16 themes. Three new syntaxes are added: Fortran, email, and QML. On Windows systems with SSH, the ansi-dark and ansi-light themes are recommended to address palette problems.

## v0.15.0

The `--diff` flag (short form `-d`) and `--diff-context` option enable display of Git-tracked changes with specified context lines, showing neighborhoods of modified lines. Interleaved file-reading errors are now handled correctly. Custom cache startup performance improves to approximately twice the previous speed. Solarized themes receive updates. Low-level configuration and error-handler APIs change to include a mutable writer argument, but the high-level API remains unchanged.

## v0.14.0

The `--file-name` flag specifies a file name for syntax detection when reading from stdin. The `--generate-config-file` flag generates a configuration template in the platform-appropriate directory. Performance is repaired for C# and Makefile syntax highlighting. Ruby heredocs and Rust syntax bugs are fixed. Short output on Windows that previously disappeared from display is restored. The `highlight-line` feature now works correctly with `--tabs` set to 0 and `--wrap` set to never. Cache metadata is recorded in a `metadata.yaml` file that tracks version compatibility and rejects incompatible cached assets.

The library API adds a new high-level interface that is recommended but remains in beta; the low-level API is refactored. The default application feature enables executable dependencies; library consumers can disable it. Paging and Git features are optional, and older syntect versions can be supported. Rego and Stylo syntaxes are added.

## v0.13.0

v0.13.0 marks the first release of bat as a public library, with acknowledgment that documentation is incomplete and the API will likely change. The `--map-syntax` flag uses glob patterns and introduces a breaking change requiring users to update existing syntax mappings. For example, `--map-syntax <glob-pattern>:<syntax-name>` maps files matching the glob pattern to a specified syntax name. Files matching patterns like `.ignore`, `PKGBUILD`, and `Podfile` can be mapped to syntaxes such as `.gitignore`, `bash`, and `ruby` respectively.

Highlight-line ranges are now supported, allowing specification of line ranges for highlighting. Wide-character Unicode text is wrapped correctly. The `BAT_CACHE_PATH` environment variable allows custom cache directory location. Combining character styles are supported. Numerous fixes address new-less initialization behavior, cache-command precedence, Scala `.sc` files, man page names containing underscores or dashes, empty lines, redirected output wrapping, non-Unicode filenames, empty-file grid display, and build file shebangs.

Man page and completion command names are parameterized for customization. Link-Time Optimization (LTO) is enabled, providing a reported approximately 10% speed improvement. The default theme is now accepted as a valid option. Added syntaxes include Jinja2, SaltStack, fstab, group, passwd, proc files, Nim, Vue, and CoffeeScript. Three new themes are added: Dracula, Nord, and Solarized. Ubuntu, Debian, and MacPorts packages are now available. Fish shell completions are installed to the `vendor_completions.d` directory. eth-p joins the maintenance team.

## v0.12.1

A CreateFile2 API failure affecting older Windows systems is fixed.

## v0.12.0

The `-A` flag displays binary data without suppressing it. Man pager integration is added. Line-range separators are implemented. A new `-L` flag is introduced. Fixes address grid layout balancing, cache file naming, absent cache directories, and parsing of negative terminal width values. Fish shell completion enters distribution via DEB packages. New syntaxes include Org, requirements files, `.env`, SSH, hosts files, GraphQL, Verilog, SCSS, Sass, and strace. Gentoo, Alpine, and Fedora packaging is documented.

## v0.11.0

Three new themes are added: ansi-light, ansi-dark, and base16. Fish shell completion is implemented as a handwritten script. Pressing `-p` twice disables paging when the plain style is active. Explicit less arguments are preserved through invocation. Warning messages are displayed when interactive binary files are encountered on input. Empty-file headers are restored to display. Terminal width of 0 is rejected. Cache-file ambiguity is resolved. Tests are added. Rust 2018 edition is adopted. F# and Fish syntax definitions are updated. Chocolatey distribution begins.

## v0.10.0

The `highlight-line` feature is introduced. On macOS, the configuration directory moves from `~/Library/Preferences/bat` to `~/.config/bat`; users must manually copy existing configurations. Completion generation during build is disabled. Less flag handling is improved. Missing-file error messages improve. Pager behavior for nonexistent files is corrected. The cache subcommand renames `--init` to `--build` and relocates the `--config-dir` and `--cache-dir` hidden flags. Fixes address trailing plain-text lines and repeated stdin EOF handling. New syntaxes include Twig, desktop entry files, AsciiDoc, assembly, log files, Protocol Buffers, Terraform, Jsonnet, and Varlink. A Japanese README is added.

## v0.9.0

The `show-all` flag is added to reveal non-printing characters. A `pager` configuration option enables custom pager selection. The `BAT_CONFIG_PATH` environment variable specifies the configuration file location. Style and line-range options can be repeated. Terminal-width values accept offsets. Italics become opt-in rather than default. Tab display defaults to 4 spaces instead of 8. The Sublime Snazzy theme is added. Completion scripts stop shipping with releases. Recursion prevention is added when `PAGER=bat` is set. OpenSUSE and Chinese language documentation is added. Tab and integration tests are improved.

## v0.8.0

Configuration file support is introduced with argument-list syntax. On Linux, the configuration directory becomes `~/.config/bat`. The `--config-file` flag specifies an alternate configuration location. The `BAT_OPTS` environment variable is respected and takes precedence over other settings. Custom syntax mappings allow binding file patterns to syntax definitions. Pager-specific arguments can be configured. Windows wildcard expansion is supported. First-line language detection is implemented. UTF-16LE and UTF-16BE encodings are handled. The Robot syntax is added. Interactive binary files are detected and suppressed from display. JavaDoc and Haskell highlighting bugs are fixed. Completions are generated from source during the build process. Tests are added. Distribution includes Termux, Nix, and Docker packages. Configuration and mapping examples are provided in documentation.

## v0.7.1

Eight-bit color approximation is improved. Haskell syntax highlighting panic and plain-mode wrapping issues are fixed. Ansible and Cygwin usage instructions are added.

## v0.7.0

Tab handling is exposed via the `--tabs` flag and `BAT_TABS` environment variable. The `BAT_STYLE` environment variable allows setting output style. The OneHalf theme is added. New syntaxes include CSV, JSX, TSX, Cabal, Dart, F#, PureScript, Swift, Crystal, and PowerShell. Git queries are made conditional based on context. Plain output mode disables text wrapping. Fixes address cache-named file handling, Windows and less detection, wrapnever decorations, and directory headers. ARMv7 and aarch64 architecture builds are released. Scoop package manager support is added.

## v0.6.1

The `list-languages` output correctly handles piping to `head`. Color settings are honored when displaying lists. Windows Git modification markers are enabled. Automated Windows release building begins.

## v0.6.0

Theme preview functionality is added. The `-p` flag controls paging. Exact-byte redirected output is supported. New syntaxes include Elm, Kotlin, Puppet, TypeScript, and Zenburn. Custom themes are added without requiring a Default symlink. Cache deduplication bugs are fixed. The first man page is created. Development and troubleshooting documentation is added.

## v0.5.0

The `--line-range` flag specifies which lines to display. The `BAT_THEME` environment variable sets the active theme. The `PAGER` and `BAT_PAGER` environment variables control pager selection. Independent additive sets of syntax and theme definitions are supported. Theme-based gutter colors are rendered. Fixes address escape character stripping, isolated Git snapshot testing, and Markdown and JavaScript highlighting. ARMv7 release builds are added. Arch Linux packaging is established. Color conversion improvements are made.

## v0.4.1

Tests are fixed to run outside a Git repository checkout.

## v0.4.0

Output wrapping is implemented. Styles and themes are introduced, with new syntax definitions for Julia, Dockerfile, VimL, CMake, INI, and Less. Bold, italic, and underline text formatting is supported. 32-bit architecture support is added. The `-u` and `-n` flags are introduced. Windows 10 ANSI escape sequence support is enabled. The custom syntax folder is renamed from `custom-syntax` to `syntaxes`. Markdown syntax uses the Sublime Text default definition. Output listings are sorted. Flags can override earlier instances of themselves. Fixes address tiny terminals, filename detection, invalid UTF-8 byte sequences, general error handling, less Unicode support, and nightly builds. Tests, logo design, alternative documentation, and code refactoring are added.

## v0.3.0

Automatic less pager invocation is implemented. Standard input, redirected output, and color mode detection are added. Language listing and selection functionality is introduced. Output style options are provided. TOML configuration file support is added. The `cache` subcommand replaces `init-cache`. Git context is derived from the input file path. Process substitution works correctly.

## v0.2.3

MUSL-based static binaries are released.

## v0.2.2

The OpenSSL dependency is removed.

## v0.2.1

The Elixir syntax is added. The libcurl backend is changed.

## v0.2.0

Custom syntax definitions and extended Markdown support are added. Git modification markers in child directories are fixed.

## v0.1.0

This is the initial release.

## Configuration File Format

Configuration files use TOML syntax and support argument-list style with line comments. Tab width, theme selection, syntax mapping, and wrap behavior can be configured. Example configuration entries include `--tabs=4`, `--theme="Sublime Snazzy"`, and `--map-syntax .ignore:.gitignore`. Multiple directives can be placed on a single line such as `--wrap=never --paging=never`. Comments are prefixed with the hash symbol and extend to the end of the line.

## Library API Summary

The high-level library API is the recommended interface for programmatic use, though it remains subject to change. An `InputDescription` type is provided for describing input sources. Direct `Input` objects can be supplied to `PrettyPrinter`. The low-level configuration and error-handler APIs accept mutable writer arguments. The `Input::theme_preview_file` method has been removed. Library consumers can disable the default application feature, with paging and Git features available as optional additions. Support for older syntect parser versions can be configured at build time.

## Packaging and Distribution

Bat is distributed through multiple package managers and formats. Ubuntu, Debian, and MacPorts official packages are available. Arch Linux, Gentoo, Alpine, and Fedora maintain community packages. Chocolatey provides Windows binaries. Scoop is supported on Windows. Termux, Nix, and Docker distribution channels exist. Fish shell completions are installed to the `vendor_completions.d` directory on supported systems. Automated release builds for Windows are generated. ARMv7, aarch64, 32-bit, and MUSL-based static binary releases are provided.

## Build Dependencies

v0.16.0 removes the liquid template engine as a build dependency. v0.15.2 eliminates bindgen and libclang build requirements by adopting Syntect 4.2 with onig. Link-Time Optimization (LTO) is enabled to provide performance improvements. The default application feature includes executable dependencies; library users can selectively enable or disable features including paging, Git support, and older syntect compatibility.
