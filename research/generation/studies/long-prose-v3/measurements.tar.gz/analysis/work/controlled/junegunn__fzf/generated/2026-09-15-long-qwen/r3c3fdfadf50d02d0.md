# Vim Integration API and Configuration

This documentation describes the integration of `fzf` with Vim and Neovim, covering installation, global settings, layout configurations, and the programmatic API for custom commands. The integration allows developers to leverage `fzf` as a powerful fuzzy finder within the editor environment, supporting various window layouts, color schemes, and custom actions.

## Installation and Setup

To enable `fzf` within Vim, the `fzf` directory must be added to Vim’s `runtimepath`. The specific location depends on the package manager used. For installations via Homebrew, the path is typically `/usr/local/opt/fzf`. For manual Git installations, it is often `~/.fzf`.

```vim
" If installed using Homebrew
set rtp+=/usr/local/opt/fzf

" If installed using git
set rtp+=~/.fzf
```

When using `vim-plug`, users can specify the installed package directly or fetch the latest version from GitHub. The plugin requires an `fzf` executable on the system `PATH`. If the executable is absent, the plugin may ask for permission to download one. An optional update hook can keep the binary current.

```vim
Plug 'junegunn/fzf'
Plug 'junegunn/fzf', { 'do': { -> fzf#install() } }
```

## Global Settings

Several global variables control the behavior and appearance of `fzf` in Vim.

### Opening Actions (`g:fzf_action`)

The `g:fzf_action` variable defines key bindings for opening selected files. By default, `Enter` opens the file in the current window. Additional actions can be mapped to `Ctrl-T` (tab split), `Ctrl-X` (horizontal split), and `Ctrl-V` (vertical split). Actions can be strings representing Vim commands or function references for custom processing. Note that `g:fzf_action` applies only when no custom `sink` or `sink*` is provided in the run specification.

```vim
" Default extra key bindings
let g:fzf_action = {
  \ 'ctrl-t': 'tab split',
  \ 'ctrl-x': 'split',
  \ 'ctrl-v': 'vsplit' }

" Custom function example
function! s:build_quickfix_list(lines)
  call setqflist(map(copy(a:lines), '{ "filename": v:val }'))
  copen
  cc
endfunction

let g:fzf_action = {
  \ 'ctrl-q': function('s:build_quickfix_list'),
  \ 'ctrl-t': 'tab split',
  \ 'ctrl-x': 'split',
  \ 'ctrl-v': 'vsplit' }
```

### Layout (`g:fzf_layout`)

The `g:fzf_layout` variable controls window placement. It supports popup windows defined by width and height fractions or integers, as well as directional layouts (`up`, `down`, `left`, `right`). Width must be a fraction between 0 and 1 or an integer at least 8. Height must be a fraction between 0 and 1 or an integer at least 4. Offsets default to 0.5. Border styles include `rounded`, `sharp`, `horizontal`, `vertical`, specific sides, or `none`.

```vim
" Default fzf layout
" - Popup window
let g:fzf_layout = { 'window': { 'width': 0.9, 'height': 0.6 } }

" - down / up / left / right
let g:fzf_layout = { 'down': '40%' }

" - Window using a Vim command
let g:fzf_layout = { 'window': 'enew' }
let g:fzf_layout = { 'window': '-tabnew' }
let g:fzf_layout = { 'window': '10new' }

" Tmux integration
if exists('$TMUX')
  let g:fzf_layout = { 'tmux': '-p90%,60%' }
else
  let g:fzf_layout = { 'window': { 'width': 0.9, 'height': 0.6 } }
endif
```

### Colors (`g:fzf_colors`)

The `g:fzf_colors` variable maps visual elements to Vim highlight groups. It translates these mappings into `--color` options for `fzf`. Each entry maps an element to a component (foreground, background, or highlight) and a list of Vim highlight groups to try in order. The table below details the supported elements:

| Element               | Description                                           |
| ---                   | ---                                                   |
| `fg`  / `bg`  / `hl`  | Item (foreground / background / highlight)            |
| `fg+` / `bg+` / `hl+` | Current item (foreground / background / highlight)    |
| `hl`  / `hl+`         | Highlighted substrings (normal / current)             |
| `gutter`              | Background of the gutter on the left                  |
| `pointer`             | Pointer to the current line (`>`)                     |
| `marker`              | Multi-select marker (`>`)                             |
| `border`              | Border around the window (`--border` and `--preview`) |
| `header`              | Header (`--header` or `--header-lines`)               |
| `info`                | Info line (match counters)                            |
| `spinner`             | Streaming input indicator                             |
| `prompt`              | Prompt before query (`> `)                            |

```vim
let g:fzf_colors =
\ { 'fg':      ['fg', 'Normal'],
  \ 'bg':      ['bg', 'Normal'],
  \ 'hl':      ['fg', 'Comment'],
  \ 'fg+':     ['fg', 'CursorLine', 'CursorColumn', 'Normal'],
  \ 'bg+':     ['bg', 'CursorLine', 'CursorColumn'],
  \ 'hl+':     ['fg', 'Statement'],
  \ 'info':    ['fg', 'PreProc'],
  \ 'border':  ['fg', 'Ignore'],
  \ 'prompt':  ['fg', 'Conditional'],
  \ 'pointer': ['fg', 'Exception'],
  \ 'marker':  ['fg', 'Keyword'],
  \ 'spinner': ['fg', 'Label'],
  \ 'header':  ['fg', 'Comment'] }
```

### History (`g:fzf_history_dir`)

Setting `g:fzf_history_dir` enables per-command query history. History files are stored in the specified directory. When enabled, `Ctrl-N` and `Ctrl-P` are bound to history navigation instead of moving down and up.

```vim
let g:fzf_history_dir = '~/.local/share/fzf-history'
```

## API Functions

### `fzf#run(spec)`

The `fzf#run` function launches the finder using a specification dictionary. The `spec` can include:

*   `source`: A shell command string or a Vim list providing input. If absent, `find` or `FZF_DEFAULT_COMMAND` is used.
*   `sink`: A Vim command string or function reference to handle each selected item.
*   `sink*`: A function reference to handle all output lines at once.
*   `options`: A string or list of options. Lists are preferred to avoid escaping issues.
*   `dir`: The working directory.
*   `window`/`up`/`down`/`left`/`right`: Layout specifications.
*   `tmux`: Options for `fzf-tmux`.

```vim
" Look for files under current directory
call fzf#run({'sink': 'e'})

" Custom source and sink
call fzf#run({'source': 'git ls-files', 'sink': 'e'})

" Using options list to avoid escaping
call fzf#run({'options': ['--reverse', '--prompt', 'C:\Program Files\']})

" Layout examples
call fzf#run({'source': 'git ls-files', 'sink': 'e', 'left': '40%'})
call fzf#run({'source': 'git ls-files', 'sink': 'e', 'window': '30vnew'})
```

### `fzf#wrap([name], [spec], [fullscreen])`

This function wraps a specification with global preferences. It returns a spec extended with settings from `g:fzf_layout`, `g:fzf_colors`, `g:fzf_action`, and `g:fzf_history_dir`. The `name` argument is optional and used to key the history file. The `fullscreen` argument defaults to 0 and accepts 0 or 1.

```vim
call fzf#run(fzf#wrap({'source': 'ls'}))
```

## Custom Commands

Users can define custom Vim commands using `fzf#run` and `fzf#wrap`. The following example demonstrates a command `LS` that accepts arguments and supports bang expansion for fullscreen mode.

```vim
" Basic command
command! LS call fzf#run(fzf#wrap({'source': 'ls'}))

" With bang for fullscreen
command! -bang LS call fzf#run(fzf#wrap({'source': 'ls'}, <bang>0))

" With directory argument and history name
command! -bang -complete=dir -nargs=* LS
    \ call fzf#run(fzf#wrap('ls', {'source': 'ls', 'dir': <q-args>}, <bang>0))
```

## Terminal Buffer and Autocmds

On Neovim, GVim, and terminal Vim with non-default layouts, `fzf` uses a terminal buffer. The filetype is set to `fzf`, allowing customization via `FileType` autocmds. For non-popup layouts, it is common to temporarily hide the status line.

```vim
if has('nvim') && !exists('g:fzf_layout')
  autocmd! FileType fzf
  autocmd  FileType fzf set laststatus=0 noshowmode noruler
    \| autocmd BufLeave <buffer> set laststatus=2 showmode ruler
endif
```

## Built-in Commands

The `:FZF` command provides a basic file selector built on the API. It accepts options and paths.

```vim
" Look for files under current directory
:FZF

" Look for files under your home directory
:FZF ~

" With fzf command-line options
:FZF --reverse --info=inline /tmp

" Bang version starts fzf in fullscreen mode
:FZF!
```
