NATS Server Roadmap

Overview

The NATS Server roadmap is a draft document that evolves as milestones are completed and new plans emerge. The roadmap is managed through several coordinated resources: the server wiki tracks releases, while a separate NATS roadmap wiki coordinates projects. The Open-Source Planning Process defines the roadmap direction; GitHub milestones track work in progress. Project wiki pages record milestone goals and current progress. Releases may contain multiple milestones. Features or fixes outside a milestone are considered unscheduled and have no defined release date.

Near-Term Plans

Two primary initiatives are planned for the near term. The first is configuration reload capability: the server will support reloading a subset of gnatsd configuration without restarting the instance, tracked by GitHub issue #338. This capability reduces required downtime during configuration updates. The second initiative involves monitoring integration: work on exporting monitoring data through Prometheus is underway and tracked by GitHub issue #345. Prometheus integration allows monitoring infrastructure to collect and analyze server metrics.

Later-Term Plans

Several significant features are planned for future releases.

Authentication and authorization interfaces will be extended to support external providers. The system will permit configuration for third-party authentication and authorization services, enabling integration with existing external security infrastructure. This work is tracked under GitHub issue #434.

A major initiative involves isolating subject namespaces by tenant, account, or organization. This multi-tenant capability ensures subject isolation: when tenant A publishes on subject FOO.BAR, that publication must remain invisible to tenant B subscribers on the same subject, and conversely, tenant B publications must remain invisible to tenant A subscribers. This critical requirement is tracked under GitHub issues #347 and #348.

Publisher rate limiting has been implemented on an internal project branch and is proposed for public release, tracked by GitHub issue #346.

Atomic auto-unsubscribe functionality would combine current SUB and UNSUB operations into a single atomic action. Currently, subscribing with a message limit requires two separate operations: SUB foo 1 and UNSUB foo 1 1. The proposed feature would allow encoding this behavior directly in a single subscription command, optionally as SUB foo 1 1. This enhancement is tracked by GitHub issue #344.

Cluster Management

The NATS architecture already supports client and server auto-discovery, which permits dynamic cluster expansion without manual reconfiguration. An additional enhancement is proposed: optional connection pruning and rebalancing across larger clusters would optimize resource utilization across expanded deployments. This capability is tracked by GitHub issue #343.

Naming Convention

The original NATS Server, written in Ruby, was named nats-server. The Go implementation, introduced for improved performance, was named gnatsd to distinguish it from the Ruby version. A proposed rename, tracked by GitHub issue #226, would align the Go implementation's name back to nats-server. This change would standardize naming across all NATS components.
