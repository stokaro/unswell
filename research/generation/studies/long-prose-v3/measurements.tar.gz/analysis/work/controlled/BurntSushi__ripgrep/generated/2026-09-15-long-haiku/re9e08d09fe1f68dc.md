# Ripgrep Technical Reference

## Documentation and Help Resources

Configuration options and encoding behavior are documented in GUIDE.md, with version changes tracked in CHANGELOG.md. The project operates on a volunteer basis without guaranteed release dates. Serious regressions may motivate a patch release, but no timing guarantees apply.

Binary releases and builds with asciidoctor or asciidoc installed include a man page generated from the argument parser. This man page is located in the target build output directory. The man page file can be located with commands like:

```
find ./target -name rg.1 -print0 | xargs -0 ls -t | head -n1
```

For command-line reference without generating documentation, use `rg --help` for complete option details. The condensed version `rg -h` displays each flag on one line.

## Shell Completions

Ripgrep builds include shell completion scripts for multiple shell environments. Installation locations and configuration vary by shell:

**Zsh:** The separately maintained completion file `_rg` must be placed in the fpath. Zsh reads completion files from directories in this variable at startup.

**Bash:** The completion script `rg.bash` is installed in `$XDG_CONFIG_HOME/bash_completion` or `/etc/bash_completion.d` depending on system configuration.

**Fish:** The completion file `rg.fish` is placed in `~/.config/fish/completions/`.

**PowerShell:** The completion script `_rg.ps1` is loaded in the profile by dot-sourcing its full path. If the script is not on PATH, the complete path must be specified.

## Search Semantics and Core Behavior

### Parallel Search and Result Ordering

By default, ripgrep searches files in parallel, which produces nondeterministic result order across runs. When consistent ordering is required, `--sort path` applies path-based sorting but disables parallelism. In smaller repositories, the performance impact of this sorting may be negligible.

### Compressed File Search

The `-z` or `--search-zip` option enables searching through compressed files. Supported formats include gzip, bzip2, xz, lzma, lz4, Brotli, and Zstd. The tool invokes installed decompressor processes to extract data. Archive formats such as tar.gz are not supported; the `-z` flag works on individual compressed files, not archive containers.

### Multiline Patterns

The `-U` or `--multiline` option allows search patterns to match across line boundaries. When enabled, a single match can span multiple lines in the output.

## Regex Engines and Pattern Matching

### Default Engine Characteristics

The default regex engine uses finite-state machines to achieve linear worst-case time complexity for pattern matching. This design does not support backreferences or lookaround assertions. Patterns requiring these features cannot be used with the default engine.

A simple example of an unsupported feature:
```
$ rg -P '(\w{10})\1'
tests/misc.rs
483:    cmd.arg("--max-filesize").arg("44444444444444444444");
globset/src/glob.rs
1206:    matches!(match7, "a*a*a*a*a*a*a*a*a", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
```

When PCRE2 is not available in a build:
```
$ rg -P '(\w{10})\1'
PCRE2 is not available in this build of ripgrep
```

### PCRE2 Availability

The `-P` or `--pcre2` option selects the optional PCRE2 engine, which is a backtracking engine supporting additional regex features including backreferences and lookaround. Most project binary releases enable PCRE2 support. Builds from package managers may not include it; consulting the package maintainer is necessary to determine availability.

When a pattern is compiled to an intermediate form, its size may exceed limits despite short source code. For example, a Unicode letter class repeated many times:

```
$ rg '\pL{1000}'
Compiled regex exceeds size limit of 10485760 bytes.
```

The `--regex-size-limit` option raises the approximate compilation allowance:

```
$ rg '\pL{1000}' --regex-size-limit 1G
```

The specified allocation does not cause automatic memory use of the full amount; it raises the compilation threshold.

## Output Formatting and Colors

### Color Control Options

The `--color` option determines when color output appears. Valid values are:
- `never`: Disable all colors
- `auto`: Default; enable colors only for terminals
- `always`: Enable colors regardless of output type
- `ansi`: Use ANSI color codes

### Detailed Color Configuration

The `--colors` option configures colors for specific output elements. The format is:

```
--colors '{type}:{attribute}:{value}'
```

Element types include `path`, `line`, `column`, and `match`. Attributes are:
- `fg`: Foreground color
- `bg`: Background color
- `style`: Text style

Style values are `bold`, `nobold`, `intense`, `nointense`, `underline`, and `nounderline`. Colors accept eight standard names, decimal or hexadecimal indices from 0–255, or comma-separated RGB triples. The `type:none` syntax resets that element to default styling.

Multiple `--colors` options can configure different elements:

```
$ rg somepattern \
    --colors 'match:none' \
    --colors 'match:bg:0x33,0x66,0xFF' \
    --colors 'match:fg:white' \
    --colors 'match:style:bold'
```

Styles are reset and then applied in order, so type:none early in a chain removes styling that later options add:

```
$ rg somepattern --colors 'match:none' --colors 'match:fg:0x33,0x66,0xFF'
```

This resets all match styling, then applies only the foreground color. Alternatively:

```
$ rg somepattern --colors 'match:fg:0x33,0x66,0xFF'
```

This applies the foreground color to existing match styling without resetting.

### Silver Searcher-like Color Scheme

A complete Silver Searcher-compatible color configuration:

```
rg --colors line:fg:yellow      \
   --colors line:style:bold     \
   --colors path:fg:green       \
   --colors path:style:bold     \
   --colors match:fg:black      \
   --colors match:bg:yellow     \
   --colors match:style:nobold  \
   foo
```

### Configuration Files

The `RIPGREP_CONFIG_PATH` environment variable specifies a config file containing default options. Each line should contain one option in long form:

```
$ cat $HOME/.config/ripgrep/rc
--colors=line:fg:yellow
--colors=line:style:bold
--colors=path:fg:green
--colors=path:style:bold
--colors=match:fg:black
--colors=match:bg:yellow
--colors=match:style:nobold
$ RIPGREP_CONFIG_PATH=$HOME/.config/ripgrep/rc rg foo
```

### Windows Terminal Color Considerations

Windows terminals present special color handling challenges. On Cygwin, truecolor may be directly supported. Ordinary pre-Windows-10 consoles have no known truecolor support. On Windows 10, if bold formatting interferes with truecolor VT100 escape sequences, clear the default match styling first using `--colors 'match:none'`.

After interrupted output produces corrupted colors, cmd's `color` command or a Unix reset escape can restore color. PowerShell provides a helper function and alias:

```powershell
$OrigFgColor = $Host.UI.RawUI.ForegroundColor
function Reset-ForegroundColor {
	$Host.UI.RawUI.ForegroundColor = $OrigFgColor
}
Set-Alias -Name color -Value Reset-ForegroundColor
```

Changes to color handling through history include PR187 and issue281.

## Pattern Compilation and Caching

### Regex Size Limits

When a compiled regex exceeds the internal size limit, compilation fails even if the source pattern is concise. This occurs with patterns like Unicode character classes with high repetition counts. The `--regex-size-limit` option raises the approximate compilation allowance:

```
$ rg '\pL{1000}'
Compiled regex exceeds size limit of 10485760 bytes.
```

Increasing the limit:

```
$ rg '\pL{1000}' --regex-size-limit 1G
```

The `1G` specification does not automatically allocate 1 gigabyte; it sets the threshold for compilation.

### Pattern Cache and Multiple Patterns

The `-f` or `--file` option reads one pattern per line and matches their union. When many patterns are provided, the fast engine's internal cache may be exhausted, triggering a slower fallback engine. The `--dfa-size-limit` option raises this cache allowance:

```
--dfa-size-limit 1G
```

Like `--regex-size-limit`, this raises the threshold without automatic full allocation.

## Encoding and Unicode Handling

### Default Engine Line Boundaries

The default regex engine in line-only search mode prevents matches from spanning newlines. The engine exposes syntax analysis to remove newline from character classes such as `\s`, enabling efficient buffer-based search without scanning lines separately.

Attempting to match a literal newline produces an error:

```
$ rg '\n'
the literal '"\n"' is not allowed in a regex
```

### PCRE2 Encoding Requirements

PCRE2 is a backtracking engine requiring valid UTF-8 in Unicode mode. The default engine can search arbitrary bytes while refusing invalid sequences only for Unicode-specific patterns. Ripgrep automatically transcodes invalid UTF-8 to replacement characters before passing data to PCRE2, then disables redundant PCRE2 validation to avoid redundant error checking.

If invalid UTF-8 is passed directly to PCRE2 without transcoding, errors occur and file search stops:

```
$ cat invalid-utf8
foobar

$ xxd invalid-utf8
00000000: 666f 6fff 6261 720a                      foo.bar.

$ rg foo invalid-utf8
1:foobar

$ rg -P foo invalid-utf8
1:foo�bar

$ rg -P foo invalid-utf8 --no-encoding
invalid-utf8: PCRE2: error matching: UTF-8 error: illegal byte (0xfe or 0xff)
```

### The --no-encoding Option

The `--no-encoding` option skips ripgrep's transcoding step, re-enabling PCRE2's internal UTF-8 validation. This approach can be slower and may expose invalid UTF-8 errors that ripgrep's conversion would otherwise handle. Use this option when transcoding overhead is problematic and UTF-8 validity is guaranteed.

## Performance Characteristics

### Measurement Methodology

Performance comparisons use a large file with a pattern that has one match and no literal prefix shortcut. The following example demonstrates exact commands and timings:

```
$ curl -O 'https://burntsushi.net/stuff/subtitles2016-sample.gz'
$ gzip -d subtitles2016-sample
$ md5sum subtitles2016-sample
e3cb796a20bbc602fbfd6bb43bda45f5   subtitles2016-sample
```

### Default Engine vs PCRE2 Performance

The default engine typically performs faster than PCRE2 for equivalent searches:

```
$ time rg '^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.783s
user    0m1.731s
sys     0m0.051s

$ time rg -P '^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m2.458s
user    0m2.419s
sys     0m0.038s
```

### Trace Analysis

The `--trace` option reveals the search strategy used. The default engine uses a fast line searcher with memory mapping:

```
$ rg '^\w{42}$' subtitles2016-sample --trace
[... snip ...]
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:622: Some("subtitles2016-sample"): searching via memory map
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:712: slice reader: searching via slice-by-line strategy
TRACE|grep_searcher::searcher::core|grep-searcher/src/searcher/core.rs:61: searcher core: will use fast line searcher
[... snip ...]
```

PCRE2 search with the same pattern requires transcoding, using a slower line searcher:

```
$ rg -P '^\w{42}$' subtitles2016-sample --trace
[... snip ...]
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:622: Some("subtitles2016-sample"): searching via memory map
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:705: slice reader: needs transcoding, using generic reader
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:685: generic reader: searching via roll buffer strategy
TRACE|grep_searcher::searcher::core|grep-searcher/src/searcher/core.rs:63: searcher core: will use slow line searcher
[... snip ...]
```

### Encoding Conversion Overhead

PCRE2 without transcoding is slower than the default engine but faster with transcoding disabled:

```
$ time rg -P '^\w{42}$' subtitles2016-sample --no-encoding
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m3.074s
user    0m3.021s
sys     0m0.051s
```

The `--trace` output and experimental results suggest UTF-8 validation differences may explain slowdowns, such as SIMD acceleration in encoding_rs. This represents one considered explanation rather than a proven universal limitation.

## Multiline Search Performance

Multiline search requires the entire file in memory because a match can be arbitrarily long. A memory map normally supplies this, but UTF-8 conversion requires a heap copy:

```
$ time rg -U '^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.803s
user    0m1.748s
sys     0m0.054s

$ time rg -P -U '^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m2.962s
user    0m2.246s
sys     0m0.713s
```

The default engine can recognize patterns that cannot cross lines and retain its fast incremental strategy even with `-U` enabled. PCRE2 lacks equivalent introspection, forcing line-by-line search when multiline is enabled.

### Disabling Unicode Semantics for Performance

Combining `-U` with `--no-pcre2-unicode` avoids both line-by-line searching and transcoding, allowing memory mapping and JIT compilation when Unicode semantics are unnecessary:

```
$ time rg '(?-u)^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.714s
user    0m1.669s
sys     0m0.044s

$ time rg -P '^\w{42}$' subtitles2016-sample --no-pcre2-unicode
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.997s
user    0m1.958s
sys     0m0.037s
```

With multiline enabled:

```
$ time rg -U '(?-u)^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.714s
user    0m1.655s
sys     0m0.058s

$ time rg -P -U '^\w{42}$' subtitles2016-sample --no-pcre2-unicode
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.121s
user    0m1.071s
sys     0m0.048s
```

Disabling Unicode can miss non-ASCII word characters. The source acknowledges that alternative APIs and designs could produce different performance characteristics.

## Troubleshooting Unexpected Behavior

### Alias and Wrapper Conflicts

Unexpected ripgrep behavior can originate from another executable or alias with the same name. Notable examples include Oh My Zsh's Rails plugin mapping `rg` to `rails generate`. The `which rg` command helps identify the actual executable being invoked.

Resolution options include:

- Disabling the conflicting shell plugin
- Using the `command` builtin: `command rg`
- Escaping the command: `\rg` or `'rg'`
- Specifying the full executable path
- Removing the alias: `unalias rg`
- Creating a distinct ripgrep alias with a different name

### PowerShell Input and Output

PowerShell wrappers must properly propagate arguments and conditionally pipe input. Piping an empty input object to ripgrep makes it search empty stdin instead of files:

```powershell
function grep {
    $count = @($input).Count
    $input.Reset()

    if ($count) {
        $input | rg.exe --hidden $args
    }
    else {
        rg.exe --hidden $args
    }
}
```

The wrapper counts input objects before passing them. If input exists, it is piped to ripgrep. If no input exists, ripgrep operates on command arguments without piping.

### PowerShell Output Encoding

PowerShell's `OutputEncoding` variable controls the character encoding for bytes piped to native processes. The documented default is US-ASCII, which converts unsupported characters to question marks. Set `OutputEncoding` to a UTF-8 encoding:

```powershell
[System.Console]::OutputEncoding = [System.Text.Encoding]::UTF8
```

Alternatively, use a .NET UTF8Encoding object. Additionally set `Console.OutputEncoding` to UTF-8 for display consistency. Place these settings in the PowerShell profile for persistence. The profile location is exposed by the `$PROFILE` variable, and its script runs at startup.

## File Modification Workflows

Ripgrep never edits files directly. To modify matching files, ripgrep can list paths for use with standard Unix tools like `xargs` and `sed`.

### Basic Replacement with xargs

Use `--files-with-matches` to list paths containing matches:

```
rg foo --files-with-matches
```

Pipe results to `xargs` with `sed` to perform replacements:

```
rg foo --files-with-matches | xargs sed -i 's/foo/bar/g'
```

GNU `sed` supports `-i` for in-place editing. BSD `sed` requires a backup extension argument, with an empty string disabling backups:

```
rg foo --files-with-matches | xargs sed -i '' 's/foo/bar/g'
```

### Handling Paths with Whitespace

Paths containing spaces, tabs, or newlines require NUL-delimited output and the `-0` flag for `xargs`:

```
rg foo --files-with-matches -0 | xargs -0 sed -i 's/foo/bar/g'
```

The `-0` flag outputs results terminated by NUL bytes, and `xargs -0` interprets them accordingly.

### Alternative Tools

The `fastmod` tool provides another replacement option, sharing some underlying libraries with ripgrep.

## Project Policy and Licensing

### Licensing Terms

Ripgrep is available under MIT or Unlicense. The author favors the Unlicense approach, which aims to disclaim copyright while providing familiar MIT terms for adoption convenience. All direct and transitive dependencies must remain permissively licensed. GPL, LGPL, MPL, and Creative Commons ShareAlike licenses are excluded, including variants described as weak copyleft.

### Use Cases and Limitations

Ripgrep effectively replaces some grep use cases, particularly for recursive code search with ignore files, Unicode and UTF-16 support, and parallel large-directory searches. It is not a complete behavior-compatible grep replacement, does not conform to POSIX standards, and is less ubiquitous for portable scripts.

GNU grep with filters, wrappers, or parallel xargs invocation may be sufficient for some tasks. Missing required features remain valid reasons to use alternative tools. Ripgrep's Unicode behavior is independent of locale settings.

### Name and Branding

The project name history includes earlier names `rep`, then `xrep`. Candidates `rustgrep` and `rgrep` were considered. The final name `rip` was chosen to suggest fast searching while retaining an association with Rust. The interpretation of `rip` as "RIP grep" (suggesting grep's death) was noticed only after release and was not the intended meaning.

### Donations and Support

The author declines donations to preserve a personally sustainable volunteer relationship with the project. Instead, donations are suggested to the Internet Archive, Rails Girls, or Wikipedia.
