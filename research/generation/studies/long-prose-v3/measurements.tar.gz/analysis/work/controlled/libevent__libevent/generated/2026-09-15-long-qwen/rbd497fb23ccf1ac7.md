# Libevent Build Systems and Installation Guide

This document provides technical documentation for software developers regarding the build systems, installation flags, community resources, and acknowledgments for Libevent. The project supports two primary build environments: Autoconf and CMake. While Autoconf is the mature and supported build environment in this snapshot, the CMake workflow is described as new and experimental.

## Autoconf Build System

For developers using the traditional Autoconf-based build system, the process begins with generating the configure script if working from a Git checkout. Execute `autogen.sh` to generate the necessary configuration files. The standard build sequence involves running `./configure`, followed by `make`. To ensure system stability and correctness, regression tests should be run before reporting any problems. This can be achieved by executing `make verify`, which is an optional step. Finally, installation is performed by running `make install` as the root user.

To enable low-level tracing during the build process, developers can set the `CFLAGS` environment variable to `-DUSE_DEBUG` before configuring. The command structure is as follows:

```bash
$ CFLAGS=-DUSE_DEBUG ./configure [...]
```

### Configure Options

The `./configure` script accepts several options to tailor the build. Key options include:

*   `--disable-shared`: This flag ensures that only static libraries are built.
*   `--prefix`: This option specifies the installation root directory, installing all files relative to this directory.
*   `--enable-gcc-warnings`: Enables extra compiler checking with GCC.
*   `--disable-malloc-replacement`: Prevents applications from replacing Libevent's memory management functions.
*   `--disable-openssl`: Disables support for OpenSSL encryption.
*   `--disable-thread-support`: Disables support for multithreaded environments.

A typical basic build command is:

```bash
$ ./configure && make
```

## CMake Build System

CMake supports builds on both Windows and Unix platforms. It allows for out-of-source builds, which enables multiple configurations from a single source tree. Developers can use the CMake GUI to choose source and output directories or utilize command-line tools.

### Windows Builds

Windows users must first install CMake. After installation, create a build directory, navigate into it, and choose a Visual Studio generator. The `cmake --help` command can be used to list available generators. Once the solution is generated, open it using the `start` command.

Example commands for Windows:

```bash
$ cd <libevent source dir>
$ mkdir build && cd build
$ cmake -G "Visual Studio 10" ..
$ start libevent.sln
```

### Unix Builds

On Unix systems, CMake defaults to Unix Makefiles. After creating and entering a build directory, run `cmake ..` to configure the project. Then, execute `make` to build the library and `make verify` to run optional regression tests.

Example commands for Unix:

```bash
$ mkdir build && cd build
$ cmake ..
$ make
$ make verify
```

To list all available CMake settings, use the `-LAH` flag:

```bash
$ cmake -LAH <sourcedir_path>
```

### CMake Variables

The CMake workflow records project options and their default values. Below are the key variables available for configuration:

*   `EVENT__LIBRARY_TYPE`: Defines the type of library to build (SHARED or STATIC). The default is SHARED for MSVC, and BOTH otherwise.
*   `EVENT_INSTALL_CMAKE_DIR`: Sets the installation directory for CMake files. Default is `lib/cmake/libevent`.
*   `EVENT__COVERAGE`: Enables running gcov to get a test coverage report. This only works with GCC/CLang and requires `-DCMAKE_BUILD_TYPE=Debug`. Default is OFF.
*   `EVENT__DISABLE_BENCHMARK`: Defines if Libevent should build without benchmark executables. Default is OFF.
*   `EVENT__DISABLE_DEBUG_MODE`: Defines if Libevent should build without support for a debug mode. Default is OFF.
*   `EVENT__DISABLE_MM_REPLACEMENT`: Defines if Libevent should not allow replacing the mm functions. Default is OFF.
*   `EVENT__DISABLE_OPENSSL`: Defines if Libevent should build without support for OpenSSL encryption. Default is OFF.
*   `EVENT__DISABLE_REGRESS`: Disables the regress tests. Default is OFF.
*   `EVENT__DISABLE_SAMPLES`: Disables sample files. Default is OFF.
*   `EVENT__DISABLE_TESTS`: Defines if tests should be compiled or not. Default is OFF.
*   `EVENT__DISABLE_THREAD_SUPPORT`: Defines if Libevent should not be compiled with thread support. Default is OFF.
*   `EVENT__ENABLE_VERBOSE_DEBUG`: Enables verbose debugging. Default is OFF.
*   `EVENT__FORCE_KQUEUE_CHECK`: When cross-compiling, forces running a test program that verifies that Kqueue works with pipes. This requires manually running the test program on the cross-compilation target. Default is OFF.

## Community Resources

Developers can access various resources for support and development. Releases are available at libevent.org. A work-in-progress book on Libevent is maintained by Nick Mathewson. The source code, pull requests, and issues are hosted on GitHub. For direct communication, the libevent-users mailing-list archives are available at archives.seul.org/libevent/users. Git patches and bug reports may also be submitted to this mailing list.

## Acknowledgments

The project credits the following individuals for their ideas, suggestions, code, and bug fixes. If your name has been omitted, please contact the maintainers.

**Contributors:**

*   Samy Al Bahra
*   Antony Antony
*   Jacob Appelbaum
*   Arno Bakker
*   Weston Andros Adamson
*   William Ahern
*   Ivan Andropov
*   Sergey Avseyev
*   Avi Bab
*   Joachim Bauch
*   Andrey Belobrov
*   Gilad Benjamini
*   Stas Bekman
*   Denis Bilenko
*   Julien Blache
*   Kevin Bowling
*   Tomash Brechko
*   Kelly Brock
*   Ralph Castain
*   Adrian Chadd
*   Lawnstein Chan
*   Shuo Chen
*   Ka-Hing Cheung
*   Andrew Cox
*   Paul Croome
*   George Danchev
*   Andrew Danforth
*   Ed Day
*   Christopher Davis
*   Mike Davis
*   Frank Denis
*   Antony Dovgal
*   Mihai Draghicioiu
*   Alexander Drozdov
*   Mark Ellzey
*   Shie Erlich
*   Leonid Evdokimov
*   Juan Pablo Fernandez
*   Christophe Fillot
*   Mike Frysinger
*   Remi Gacogne
*   Artem Germanov
*   Alexander von Gernler
*   Diego Giagio
*   Artur Grabowski
*   Diwaker Gupta
*   Kuldeep Gupta
*   Sebastian Hahn
*   Dave Hart
*   Greg Hazel
*   Nicholas Heath
*   Michael Herf
*   Savg He
*   Mark Heily
*   Maxime Henrion
*   Michael Herf
*   Greg Hewgill
*   Andrew Hochhaus
*   Aaron Hopkins
*   Tani Hosokawa
*   Jamie Iles
*   Xiuqiang Jiang
*   Claudio Jeker
*   Evan Jones
*   Marcin Juszkiewicz
*   George Kadianakis
*   Makoto Kato
*   Phua Keat
*   Azat Khuzhin
*   Alexander Klauer
*   Kevin Ko
*   Brian Koehmstedt
*   Marko Kreen
*   Ondřej Kuzník
*   Valery Kyholodov
*   Ross Lagerwall
*   Scott Lamb
*   Christopher Layne
*   Adam Langley
*   Graham Leggett
*   Volker Lendecke
*   Philip Lewis
*   Zhou Li
*   David Libenzi
*   Yan Lin
*   Moshe Litvin
*   Simon Liu
*   Mitchell Livingston
*   Hagne Mahre
*   Lubomir Marinov
*   Abilio Marques
*   Nicolas Martyanoff
*   Abel Mathew
*   Nick Mathewson
*   James Mansion
*   Nicholas Marriott
*   Andrey Matveev
*   Caitlin Mercer
*   Dagobert Michelsen
*   Andrea Montefusco
*   Mansour Moufid
*   Mina Naguib
*   Felix Nawothnig
*   Trond Norbye
*   Linus Nordberg
*   Richard Nyberg
*   Jon Oberheide
*   John Ohl
*   Phil Oleson
*   Alexey Ozeritsky
*   Dave Pacheco
*   Derrick Pallas
*   Tassilo von Parseval
*   Catalin Patulea
*   Patrick Pelletier
*   Simon Perreault
*   Dan Petro
*   Pierre Phaneuf
*   Amarin Phaosawasdi
*   Ryan Phillips
*   Dimitre Piskyulev
*   Pavel Plesov
*   Jon Poland
*   Roman Puls
*   Nate R
*   Robert Ransom
*   Balint Reczey
*   Bert JW Regeer
*   Nate Rosenblum
*   Peter Rosin
*   Maseeb Abdul Qadir
*   Wang Qin
*   Alex S
*   Gyepi Sam
*   Hanna Schroeter
*   Ralf Schmitt
*   Mike Smellie
*   Steve Snyder
*   Nir Soffer
*   Dug Song
*   Dongsheng Song
*   Hannes Sowa
*   Joakim Soderberg
*   Joseph Spadavecchia
*   Kevin Springborn
*   Harlan Stenn
*   Andrew Sweeney
*   Ferenc Szalai
*   Brodie Thiesfield
*   Jason Toffaletti
*   Brian Utterback
*   Gisle Vanem
*   Bas Verhoeven
*   Constantine Verutin
*   Colin Watt
*   Zack Weinberg
*   Jardel Weyrich
*   Jay R. Wren
*   Zack Weinberg
*   Mobai Zhang
*   Alejo
*   Alex
*   Taral
*   propanbutan
*   masksqwe
*   mmadia
*   yangacer
*   Andrey Skriabin
*   basavesh.as
*   billsegall
*   Bill Vaughan
*   Christopher Wiley
*   David Paschich
*   Ed Schouten
*   Eduardo Panisset
*   Jan Heylen
*   jer-gentoo
*   Joakim Söderberg
*   kirillDanshin
*   lzmths
*   Marcus Sundberg
*   Mark Mentovai
*   Mattes D
*   Matyas Dolak
*   Neeraj Badlani
*   Nick Mathewson
*   Rainer Keller
*   Seungmo Koo
*   Thomas Bernard
*   Xiao Bao Clark
*   zeliard
*   Zonr Chang
*   Kurt Roeckx
*   Seven
*   Simone Basso
*   Vlad Shcherban
*   Tim Hentenaar
*   Breaker
*   johnsonlee
*   Philip Prindeville
*   Vis Virial
*   Andreas Gustafsson
*   Andrey Okoshkin
*   an-tao
*   baixiangcpp
*   Bernard Spil
*   Bogdan Harjoc
*   Carlo Marcelo Arenas Belón
*   David Benjamin
*   David Disseldorp
*   Dmitry Alimov
*   Dominic Chen
*   dpayne
*   ejurgensen
*   Fredrik Strupe
*   Gonçalo Ribeiro
*   James Synge
*   Jan Beich
*   Jesse Fang
*   Jiri Luznicky
*   José Luis Millán
*   Kiyoshi Aman
*   Leo Zhang
*   lightningkay
*   Luke Dashjr
*   Marcin Szewczyk
*   Maximilian Brunner
*   Maya Rashish
*   Murat Demirten
*   Nathan French
*   Nikolay Edigaryev
*   Philip Herron
*   Redfoxmoon
*   stenn
*   SuckShit
*   The Gitter Badger
*   tim-le
*   Vincent JARDIN
*   Xiang Zhang
*   Xiaozhou Liu
*   yongqing.jiao
*   Enji Cooper
*   linxiaohui
*   Seong-Joong Kim
*   Tobias Stoeckmann
*   Yury Korzhetsky
*   zhuizhuhaomeng
*   Pierce Lopez
*   yuangongji
*   Keith Smiley
*   jeremyerb
*   Fabrice Fontaine
*   wenyg
*   Aleksandr-Melnikov
*   ayuseleznev
*   chenguolong
*   Dimo Markov
*   dota17
*   fanquake
*   Jan Kasiak
*   Kamil Rytarowski
*   Mario Emmenlauer
*   Michael Davidsaver
*   mohuang
*   Nick Grifka
*   Nicolas J. Bouliane
*   Paul Osborne
*   Philip Homburg
*   Wataru Ashihara
*   William A Rowe Jr
*   yangyongsheng
