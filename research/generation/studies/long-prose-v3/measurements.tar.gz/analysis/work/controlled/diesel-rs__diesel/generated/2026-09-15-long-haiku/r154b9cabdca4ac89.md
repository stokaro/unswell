# Contributing to Diesel

## Reporting Issues and Requesting Features

Diesel welcomes suggestions, bug reports, and pull requests from the community. Before opening an issue or submitting a pull request, visit the Gitter channel to ask questions and seek help. The Diesel code of conduct applies across all Diesel spaces, not only GitHub.

Before reporting a bug or requesting a feature, search both open and closed issues to determine whether the same or a similar subject has already been reported. This helps avoid duplicate discussions and keeps the issue tracker organized.

### Bug Reports

When submitting a bug report, include the following information:

- Your Rust version
- Your Diesel version
- Any feature flags you have enabled
- The result you expected
- The complete error message or output
- A minimal reproduction case with sufficient code to demonstrate the problem, or a link to a public repository or Gist containing the reproduction
- The relevant database schema

Providing these details helps maintainers understand and reproduce the issue quickly.

### Feature Requests

Feature requests should include:

- The goal you are trying to achieve
- Your proposed support or implementation approach
- Alternative approaches you have considered
- The disadvantages of your proposed solution and alternatives

This information helps the team evaluate the request and discuss implementation details.

## Local Development Setup

### Installing Rust

Begin by installing Rust through rustup, which allows you to switch between toolchains. This development environment supports stable, nightly, and beta releases.

### Installing Database System Libraries

Install the appropriate database system libraries for the backends you plan to test. All drivers allow running the full test suite.

On macOS:

- SQLite requires no additional installation
- PostgreSQL libpq is already present on the system
- To add MySQL and PostgreSQL servers, run `brew install postgresql mysql`

After installation, follow the server setup instructions for your chosen database systems.

### Cloning the Repository

Clone the Diesel repository to your local machine. Create a `.env` file in the repository root to store database connection details. Use `.env.sample` as a guide for the required format.

### Database Configuration

If using MySQL, note that the test suite fails on MySQL 5.6 or earlier. If you cannot upgrade locally, Docker provides an alternative approach.

For MySQL, ensure the test user has the necessary privileges on databases matching the pattern `diesel_%`.

The repository includes Docker commands for setting up test databases:

```bash
#!/usr/bin/env sh
set -e
docker run -d --name diesel.mysql -p 3306:3306 -e MYSQL_ALLOW_EMPTY_PASSWORD=true mysql
while
  sleep 1;
  ! echo 'CREATE DATABASE diesel_test; CREATE DATABASE diesel_unit_test;' | docker exec -i diesel.mysql mysql
do sleep 1; done

docker run -d --name diesel.postgres -p 5432:5432 postgres
while
  sleep 1;
  ! echo 'CREATE DATABASE diesel_test;' | docker exec -i diesel.postgres psql -U postgres
do :; done
```

Alternatively, you can use docker-compose by running:

```bash
docker-compose up
```

### Verifying Setup

After configuration, run `bin/test` to verify that your local setup is correct. The first compilation may take a significant amount of time.

## Code Style and Formatting

Diesel source code follows the Rust Style Guide and uses rustfmt for automatic formatting.

Install the formatting and linting tools:

```bash
rustup component add rustfmt-preview
rustup component add clippy-preview
```

Use Clippy to check for common mistakes:

```bash
cargo clippy
```

To check formatting without applying changes:

```bash
cargo fmt --all -- --check
```

This command displays any formatting differences and succeeds silently when the formatting matches. Unexpected differences in code you have not modified may indicate you are using the wrong rustfmt version.

Apply formatting corrections with:

```bash
cargo fmt --all
```

Many editors offer rustfmt integration for automatic formatting on save.

All pull requests must compile without warnings.

## Type Naming Conventions

Use descriptive type parameter names instead of generic placeholders. Common abbreviations used in Diesel code include:

- **ST**: SQL type, generally constrained by `NativeSqlType`
- **DB**: Database, generally constrained by `Backend`
- **QS**: Query source, often unconstrained but sometimes constrained by `QuerySource`
- **PK**: Primary key
- **Lhs/Rhs**: Left-hand side and right-hand side, respectively
- **Conn**: Connection

For binary expressions and similar constructs, prefer descriptive names such as `Lhs` and `Rhs` over unrelated generic names like `T` and `U`. This practice improves code readability and makes the intent clearer to other developers.
