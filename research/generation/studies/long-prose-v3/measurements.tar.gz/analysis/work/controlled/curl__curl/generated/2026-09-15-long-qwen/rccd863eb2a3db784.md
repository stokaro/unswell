# Curl Vulnerability Handling and Disclosure Procedures

This document outlines the historical workflow, security protocols, and publication procedures for managing vulnerabilities within the curl and libcurl projects. These guidelines are designed to ensure responsible disclosure, maintain security integrity, and provide timely updates to the user base. All information contained herein is based on documented historical requirements and serves as a reference for the established security culture of the project.

## Reporting and Initial Assessment

Vulnerabilities that have been publicly disclosed and resolved are archived and made available for review at curl.se/docs/security.html. However, for vulnerabilities that remain undisclosed, strict confidentiality is required. Reports of such issues must not be submitted to the public issue tracker, nor should they be discussed on public project mailing lists. Furthermore, public commit messages must not identify a code change as a security fix prior to coordinated disclosure.

All security reports should be directed to the designated channel at hackerone.com/curl. These reports are routed to a select group of trusted maintainers. It is important to note that messages unrelated to the reporting or management of an undisclosed curl or libcurl vulnerability will receive no action. Upon submission, a member of the security team acknowledges receipt of the report. The team then investigates the issue to determine its validity. The outcome of this investigation is either acceptance or rejection. If a report is rejected, an explanation is provided to the reporter. If accepted, the reporter is informed that work on a fix has officially begun.

## Fix Development and Timing

Once a report is accepted, the security team assesses the impact of the vulnerability. They develop a fix and propose a timing for disclosure, involving the reporter where possible. The goal is to ensure that disclosure happens promptly. This is typically achieved with a scheduled release that contains the fix. In scenarios where the scheduled release is too far away to adequately address the security risk, the team may consider an earlier, separate release dedicated to the fix.

## Advisory Preparation

A critical component of the process is the creation of a draft advisory. This document must clearly state the problem, the impact, the affected versions, any available fixes or workarounds, the release timing, and contributor credit. The advisory must identify the Common Weakness Enumeration (CWE) associated with the flaw. Additionally, a CVE (Common Vulnerabilities and Exposures) ID must be requested through HackerOne. Once the CVE is assigned, it must be added to the advisory text.

To assist the broader ecosystem, the team may consider notifying the distros@openwall mailing list with the draft advisory. This allows Linux distributions and other package maintainers to prepare their updates. The distros@openwall list accepts at most a 14-day embargo period. It is important to note that this list excludes Windows-only flaws; therefore, such vulnerabilities should not be shared via this channel.

## Code Commit and Release

The actual fix is committed on a private branch. The commit message for this private commit must contain the assigned CVE ID. This private code is normally shared with distribution maintainers before public disclosure to ensure they can prepare their packages. The code is merged and pushed to the public master branch no more than 48 hours before the release. Public access to the fix starts at the moment of the push. The release itself follows promptly after final testing and review. The release must contain the fix to be considered valid.

## Announcement and Publication

Following the release, the vulnerability and the new version are announced through the normal curl-announce, curl-library, and curl-users mailing lists. The public security page is also updated to reflect the new status. For internal coordination, curl-security at haxx.se serves as a private discussion list. Membership on this list depends on sustained involvement and a deep understanding of the project. Membership is granted through invitation or request. There is no public membership roster because membership changes frequently, and maintaining a public list would pose a security risk.

## Publication Steps

The technical steps for publishing the advisory involve specific file management within the project’s website repository. The advisory should be written in Markdown using customary subtitles. The file must be named after the CVE ID. An entry must be prepended in the file curl-www/docs/vuln.pm. The advisory file itself is added under curl-www/docs. After these changes, the team must run `make` in the local website checkout to generate the site and inspect the rendered result to ensure accuracy. Finally, the curl-www master branch is pushed on the advisory release day.

## Post-Publication and Policy

After publication, the team requests the disclosure of the HackerOne issue. This disclosure must redact sensitive report details or private discussion contents. The project policy favors releasing as much information as possible promptly after the vulnerability becomes public. This transparency helps the community understand the nature of the threat and the effectiveness of the fix. Details regarding the bug bounty program are available at curl.se/docs/bugbounty.html.

It is crucial to understand that these procedures represent historical documented workflow requirements. They describe how the project has managed security historically. They are not instructions to perform any disclosure now. Developers and maintainers should refer to the current active policies for real-time guidance, as security protocols may evolve. However, the principles of responsible disclosure, private handling of active issues, and coordinated release remain central to the curl project’s security posture. By adhering to these steps, the project ensures that users are protected without exposing them to risk during the development and testing phases. The balance between speed and security is maintained through the embargo periods and the structured communication channels provided.
