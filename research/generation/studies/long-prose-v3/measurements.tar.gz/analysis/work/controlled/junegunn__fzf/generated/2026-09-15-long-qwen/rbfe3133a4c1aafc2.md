# fzf Version History and Technical Documentation (0.9.3–0.24.3)

This document provides a comprehensive technical record of the changes, feature additions, and behavioral modifications in the fzf (fuzzy finder) utility, covering versions from 0.9.3 through 0.24.3. The evolution of fzf reflects a steady progression in performance optimization, user interface flexibility, and integration with various shell environments and terminal emulators. The following sections detail the specific updates, code examples, and technical nuances associated with each major release.

## Version 0.24.x: Preview Rendering and Border Customization

The 0.24.x series introduced significant enhancements to preview rendering, color styling, and border configurations, alongside binary distribution improvements.

### Version 0.24.3
Version 0.24.3 adds the `--padding` option. This feature allows users to specify the padding around the finder interface, providing finer control over the visual layout within the terminal window.

### Version 0.24.2
Version 0.24.2 contains general fixes and improvements. While no major new features were introduced in this specific release, it serves as a stability update addressing bugs present in previous iterations.

### Version 0.24.1
Version 0.24.1 repairs issues related to the `--color=bw` and `--color=no` options. These fixes ensure that black-and-white or no-color modes function correctly without unintended side effects on the terminal output.

### Version 0.24.0
Version 0.24.0 is a major update that introduces real-time preview output rendering. This change allows the preview window to update dynamically as the underlying command executes, rather than waiting for completion. The release also adds support for advanced color styles, including regular, bold, dim, underline, italic, reverse, and blink attributes.

Border customization is significantly enhanced in this version. Users can now configure vertical, top, bottom, left, and right borders independently. The release also adapts Vim borders for better integration with Vim plugins. In multi-selection mode, the interface now displays the zero selected count, providing clear feedback when no items are selected. Additionally, this version marks the beginning of uploading binaries directly to GitHub Releases, streamlining the installation process for users.

## Version 0.23.x: Preview Window Controls and Go Build Updates

The 0.23.x series focused on refining preview window behavior, adding specific options for preview handling, and updating the Go build environment.

### Version 0.23.1
Version 0.23.1 adds several options to the `preview-window` configuration: `nocycle`, `nohidden`, `nowrap`, and `default`. These options give users precise control over how the preview window cycles through content, remains hidden until invoked, wraps long lines, and resets to default states.

A critical technical change in this version is the rebuild with Go 1.14.9. This update was necessitated by a performance regression identified in issue #40727. The rebuild addresses the regression, restoring expected performance levels for fuzzy matching operations.

### Version 0.23.0
Version 0.23.0 introduces preview offsets relative to the window height. This allows the preview content to be positioned with greater flexibility. The release adds `sharp` and `cycle` options for preview behavior, reducing padding when borders are not displayed, and introducing half-page preview actions for quicker navigation.

Absolute Vim popup sizes are now supported, allowing for fixed-size preview windows in Vim environments. The release also introduces `fzf#exec`, a function designed for locating and downloading the fzf binary programmatically.

From a build perspective, version 0.23.0 builds with Go 1.15.2. A notable deprecation in this version is the cessation of providing 32-bit binaries, reflecting the industry shift toward 64-bit architectures.

## Version 0.22.x: EOF Handling and Preview Bindings

The 0.22.x series introduced advanced binding capabilities, improved preview interaction, and enhanced character matching logic.

### Version 0.22.0
Version 0.22.0 adds `backward-eof`, `refresh-preview`, and preview bindings. The `backward-eof` binding allows users to abort the search if they attempt to delete backward when the query prompt is empty. This can be configured using the following command:

```sh
fzf --bind backward-eof:abort
```

The `refresh-preview` binding enables rerunning the preview command when a specific key is hit. For example, pressing `?` can trigger a refresh:

```sh
fzf --preview 'echo $RANDOM' --bind '?:refresh-preview'
```

Preview bindings also allow for dynamic preview commands. A default preview command can be supplemented with additional bindings:

```sh
fzf --preview 'file {}' --bind '?:preview:cat {}'
```

Alternatively, a preview binding can be used without a default preview command, leaving the preview window initially empty:

```sh
fzf --bind '?:preview:cat {}'
```

The preview window can also be hidden by default and appear only when invoked:

```sh
fzf --bind '?:preview:cat {}' --preview-window hidden
```

Initial preview scroll offsets are now supported, allowing users to set an initial scroll position based on input data. For instance, when using `git grep`, one can set the scroll offset relative to the line number:

```sh
git grep --line-number '' |
  fzf --delimiter : --preview 'nl {1}' --preview-window +{2}-5
```

The release introduces ANSI prompts and smart accented-character matching. In this mode, unaccented queries match both accented and unaccented text, while accented queries require accents in the target text.

Vim integration is improved with the addition of tmux layout support. Users can configure tmux layouts using variables such as:

```vim
let g:fzf_layout = { 'tmux': '-p90%,60%' }
```

### Version 0.21.1
Version 0.21.1 deduplicates Ctrl-R history entries, ensuring that repeated commands do not clutter the history list. It adds tmux 3.2+ popup support, enhancing integration with newer tmux versions.

Bug fixes in this version include Windows traversal issues, `keep-right` ANSI color handling, and Zsh completion fixes. The release builds with Go 1.14.1.

## Version 0.21.x: Height Options and Vim Floating Windows

Version 0.21.0 brings significant platform parity and UI enhancements.

### Version 0.21.0
Version 0.21.0 enables the `--height` option on Windows, previously restricted to Unix-like systems. It adds `--pointer` and `--marker` options for customizing the selection indicator. The `--keep-right` option keeps the right end of long lines visible, preventing truncation on the left.

Border styles are updated: `--border` now prints rounded corners around the finder instead of horizontal lines. The old horizontal style remains selectable via `--border=horizontal`. A Unicode spinner replaces the ASCII spinner for smoother visual feedback.

More keys and actions are added for `--bind`. A PowerShell script is included for downloading the Windows binary, simplifying installation on Windows systems.

Vim plugin support is enhanced with built-in floating windows. Users can configure the layout using the `g:fzf_layout` variable. Examples include:

```vim
" Floating popup window in the center of the screen
let g:fzf_layout = { 'window': { 'width': 0.9, 'height': 0.6 } }

" Popup with 100% width
let g:fzf_layout = { 'window': { 'width': 1.0, 'height': 0.5, 'border': 'horizontal' } }

" Popup with 100% height
let g:fzf_layout = { 'window': { 'width': 0.5, 'height': 1.0, 'border': 'vertical' } }

" Similar to 'down' layout, but it uses a popup window and doesn't affect the window layout
let g:fzf_layout = { 'window': { 'width': 1.0, 'height': 0.5, 'yoffset': 1.0, 'border': 'top' } }

" Opens on the right;
"   'highlight' option is still supported but it will only take the foreground color of the group
let g:fzf_layout = { 'window': { 'width': 0.5, 'height': 1.0, 'xoffset': 1.0, 'border': 'left', 'highlight': 'Comment' } }
```

Bash Ctrl-R now begins with existing input and supports multiline commands.

The fuzzy-completion API changes in this version. The previous method of passing arguments as a single string is deprecated in favor of a new API that allows multiple arguments before `--`:

```sh
# Previous: fzf arguments given as a single string argument
# - This style is still supported, but it's deprecated
_fzf_complete "--multi --reverse --prompt=\"doge> \"" "$@" < <(
  echo foo
)

# New API: multiple fzf arguments before "--"
# - Easier to write multiple options
_fzf_complete --multi --reverse --prompt="doge> " -- "$@" < <(
  echo foo
)
```

## Version 0.20.x: Color Controls and Composite Bindings

### Version 0.20.0
Version 0.20.0 adds preview foreground and background color options. It introduces `clear-query` and `clear-selection` actions. Composite bindings are now supported, allowing multiple actions to be spread across `--bind` options using a leading `+`.

For example, multiple actions can be chained:

```sh
fzf --bind 'ctrl-a:up' --bind 'ctrl-a:+up'
```

This is particularly useful for combining special execute/reload forms with additional actions to avoid parse errors:

```sh
fzf --multi --bind 'ctrl-l:select-all+execute:less {+f}' --bind 'ctrl-l:+deselect-all'
```

The release removes reload flicker and fixes `+` parsing in execute/reload commands. It also addresses issues with reloading without matches and clearing unfilled header lines.

## Version 0.19.x: Selector-Only Use and Selection Caps

### Version 0.19.0
Version 0.19.0 adds `--phony` for selector-only use, allowing fzf to act as a pure selector without filtering. It also adds `reload` for replacing candidates dynamically.

The `--multi` option now accepts a selection cap, limiting the number of items that can be selected. For example:

```sh
seq 100 | fzf --multi 5
```

The `f` placeholder flag uses a temporary file for large selections that might exceed `ARG_MAX`. The `deselect-all` action now affects only matching items.

Other additions include a Bash completion setup helper, default/inline/hidden info styles, `noborder` previews, trimming with `--nth` trailing spaces, and bindings for Ctrl-backslash, bracket, caret, and slash.

Example usage of `--phony`:

```sh
: | fzf --bind 'change:reload:seq {q}' --phony
```

Example of using `--expect`:

```sh
fzf --expect=ctrl-v,ctrl-t,alt-s,f1,f2,~,@
```

## Version 0.18.x: Index Placeholders and ASCII Borders

### Version 0.18.0
Version 0.18.0 adds zero-based index placeholders `{n}` and `{+n}`. It introduces gutter color and ASCII borders via `--no-unicode`. The release exports `FZF_PREVIEW_LINES` and `FZF_PREVIEW_COLUMNS` alongside `LINES` and `COLUMNS`. It builds with Go 1.12.1.

### Version 0.17.5
Version 0.17.5 permits queries wider than the screen up to 300 characters. It builds with Go 1.11.1.

## Version 0.17.x: Layout Reversal and Preview Fixes

### Version 0.17.4
Version 0.17.4 adds `layout=reverse-list` plus aliases for reverse/default. It adds preview refresh without matches when placeholders are nonempty, more shifted/Alt arrows, fallback without `/dev/tty`, Windows default-command changes, Bash/Zsh fixes, and `--xdg` installation paths.

### Version 0.17.3
Version 0.17.3 exports preview dimensions, improves command errors, reverts filesystem-loop duplicate behavior, and requires `find -fstype`. It distinguishes mouse buttons with right-click toggle and adds `replace-query` and `accept-non-empty`.

### Version 0.17.1
Version 0.17.1 fixes preview/Windows backgrounds and `cmd.exe` execution without extra parsing/escaping. It adds Vim8 terminal-window layout.

### Version 0.17.0-2
Version 0.17.0-2 changes auxiliary scripts only: experimental Vim8/GVim terminal use, Fish shell handling, and `fzf-tmux` output/tput fixes.

### Version 0.17.0
Version 0.17.0 optimizes performance, matches escaped literal spaces, and makes `--expect` additive.

## Version 0.16.x: Performance and Border Styles

### Version 0.16.11
Version 0.16.11 fixes missed preview updates and optimizes performance.

### Version 0.16.10
Version 0.16.10 repairs preview ANSI handling and improves `--ansi`.

### Version 0.16.9
Version 0.16.9 reports about 20% general speed improvement, up to fivefold ANSI processing, and up to 50% lower memory. It adds bracketed-paste, command-error display, preview rendering, and repeated `--no-clear` improvements. These are release-note claims, not new measurements.

### Version 0.16.8
Version 0.16.8 adds change/top actions, fixes nth tiebreaks/prompt tabs/page-cycle overshoot, includes Git revision in `--version`, and improves Cygwin/Windows integration.

### Version 0.16.7
Version 0.16.7 adds Ctrl-Alt letters, Ctrl-Z/SIGSTOP, and `FZF_PREVIEW_WINDOW`.

### Version 0.16.6
Version 0.16.6 adds `--no-clear`.

### Version 0.16.5
Version 0.16.5 adds `toggle-preview-wrap` and uses Go 1.8.

### Version 0.16.4
Version 0.16.4 adds the original horizontal border.

### Version 0.16.3
Version 0.16.3 fixes trimmed tab rendering, adds `+` multi-selection placeholders, `execute-silent` without alternate-screen switching, and Ctrl-Space binding.

### Version 0.16.2
Version 0.16.2 removes ncurses, provides FreeBSD/OpenBSD/ARM binaries, supports 24-bit color and `+-chained` actions, and permits zero-size hidden preview execution.

### Version 0.16.1
Version 0.16.1 fixes height backgrounds, adds half-page actions, and adds `-L` to find.

### Version 0.16.0
Version 0.16.0 introduces `--height`, default preview truncation with optional wrap, Latin accent normalization with `--literal` opt-out, and `--filepath-word`.

## Version 0.15.x: Rendering and Color Features

### Version 0.15.9
Version 0.15.9 fixes rendering regressions, sets a 50 ms escape delay configurable by `ESCDELAY`, always shows overflowing preview indicators, and supports ncurses6/tcell extra color/italic features.

### Version 0.15.8
Version 0.15.8 expands VT100/WSL handling, adds `--no-bold/--bold`, Alt digits, and F11/F12.

### Version 0.15.7
Version 0.15.7 fixes color-disabled/header-ANSI panic.

### Version 0.15.6
Version 0.15.6 introduces Windows binaries and fixes header clearing, control-character display, and WSL escape sequences with up to 100 ms waiting.

### Version 0.15.5
Version 0.15.5 stops foreground changes forcing a black background, makes end tiebreak relative, and honors `g:fzf_colors` in wrap.

### Version 0.15.4
Version 0.15.4 adds field ranges and `{q}` placeholders, Unicode whitespace, preview scroll indicators, and exact inverse matching by default. Inverse fuzzy matching remains available using the documented quote prefix.

### Version 0.15.3
Version 0.15.3 supports more ANSI styles and fixes toggle-preview races.

### Version 0.15.2
Version 0.15.2 adds scrollable previews/actions and intensity/VT100 handling.

### Version 0.15.1
Version 0.15.1 fixes matches beyond column 2^15 and very long-line rendering delay.

### Version 0.15.0
Version 0.15.0 improves scoring with `--algo=v1|v2` and adds NUL input/output via `--read0/--print0`.

## Version 0.13.x: Speed and Memory Optimizations

### Version 0.13.5
Version 0.13.5 reports up to twice the speed and half the memory.

### Version 0.13.4
Version 0.13.4 reports 60% lower ASCII-string memory, 15–20% query improvement, and up to 45% faster nonregex nth delimiters. It fixes hidden previews.

### Version 0.13.3/0.13.2/0.13.1
These versions fix duplicate preview lines, clearing races, and large ANSI output.

### Version 0.13.0
Version 0.13.0 introduces preview windows, single-quotes execute placeholders, and ignores bracketed-paste control characters.

## Version 0.12.x: Ranking and Color Detection

### Version 0.12.2
Version 0.12.2 detects 256 colors without a TERM substring, adds `print-query`, F1–F10/Alt slash-space-enter, and jump/jump-accept.

### Version 0.12.1
Version 0.12.1 applies the new ranking universally and fixes exact-cache references.

### Version 0.12.0
Version 0.12.0 introduces the new ranking system.

## Version 0.11.x: Tiebreaks and Shell Integration

### Version 0.11.4
Version 0.11.4 adds `--hscroll-off` default 10.

### Version 0.11.3
Version 0.11.3 handles SIGTERM gracefully, uses the selected shell for execute/default commands, and changes completion generation/postprocessing APIs.

### Version 0.11.2
Version 0.11.2 accepts ordered distinct tiebreak criteria, with index last and implicit; default is length,index. `begin` ignores leading whitespace. `toggle-in/out` adapt to reversed layout. Initial ongoing-input rendering delay drops from up to 100 ms to 20 ms when `tac` is absent.

### Version 0.11.1
Version 0.11.1 adds `tabstop`.

### Version 0.11.0
Version 0.11.0 adds OR/execute-multi and fixes wide-character prompt position.

## Version 0.10.x: Search Modes and Execution

### Version 0.10.9
Version 0.10.9 makes extended search default, replaces extended-exact with orthogonal `--exact`, suppresses nonprinting characters, adds double-click, and improves resize handling.

### Version 0.10.8
Version 0.10.8 fixes setting colors after disabling them.

### Version 0.10.7
Version 0.10.7 serializes execute interrupts and uses trimmed nth length for tiebreaks.

### Version 0.10.6
Version 0.10.6 replaces header-file with header, combines header/header-lines, sets exits to 0 success/1 no match/2 error/130 interruption, and statically links Linux ncurses.

### Version 0.10.5
Version 0.10.5 adds quote-prefix unquoting and backward end scans.

### Version 0.10.4
Version 0.10.4 removes ANSI codes from with-nth output.

### Version 0.10.3
Version 0.10.3 optimizes delimiters by treating nonspecial patterns as literal and simplifying regexes.

### Version 0.10.2
Version 0.10.2 improves query/rune conversion/nth ranking, exits cleanly on ncurses initialization failure, and handles dash-leading filenames.

### Version 0.10.1
Version 0.10.1 adds margins/sticky headers/cancel/delete-char-eof and fixes colon/comma bindings and multiline ANSI.

### Version 0.10.0
Version 0.10.0 adds select/deselect/toggle-all, ignore, execute delimiters, history with default 1,000 entries, history keys, cycle, and spinner/marker/anchored-query fixes. Execute's colon form requires no closer and must end the binding list.

## Version 0.9.x: Early Features and Stability

### Version 0.9.13
Version 0.9.13 adds color customization and fixes reader termination above 64 KB.

### Version 0.9.12
Version 0.9.12 adds bind and fixes resize info/ANSI offsets.

### Version 0.9.11
Version 0.9.11 adds inline-info and fixes case mutation, per-term smart case, and scrolled double-clicks.

### Version 0.9.10
Version 0.9.10 reduces memoization/memory and adds light colors.

### Version 0.9.9
Version 0.9.9 adds tiebreak/no-hscroll/toggle-sort indication.

### Version 0.9.8
Version 0.9.8 fixes Unicode case/RuneError.

### Version 0.9.7
Version 0.9.7 adds toggle-sort and fixes expect output/comma handling.

### Version 0.9.6
Version 0.9.6 adds `--expect` keys and prints the accepting key before results, enabling Vim opening choices. It ignores an ANSI erase-line sequence.

### Version 0.9.5
Version 0.9.5 adds optional ANSI interpretation/stripping without truecolor at that version, reduces startup pointer copying, and fixes no-sort empty-filter panic.

### Version 0.9.4
Version 0.9.4 adds streaming `tac` reversal, removes implicit reverse order from no-sort, and streams filter/no-sort results unless `tac`/`sync` requires buffering. Streaming is sequential, while `--sync` restores buffered parallel filtering.

### Version 0.9.3
Version 0.9.3 adds sync and starts the finder promptly when select-1/exit-0 conditions cannot be met. Exact retained examples accompany the version notes.

## Technical Examples and Usage Patterns

The following sections consolidate key code examples and technical patterns from the fzf documentation, illustrating advanced usage scenarios.

### Customizing Appearance and Borders

Users can customize the appearance of fzf using various color and border options. The `--padding` option allows for precise control over the interface margins.

```sh
fzf --margin 5% --padding 5% --border --preview 'cat {}' \
    --color bg:#222222,preview-bg:#333333
```

Advanced color styling supports multiple attributes. For instance, italic styles can be applied to specific elements, though support varies by terminal.

```sh
# * Set -1 to keep the original color
# * Multiple style attributes can be combined
# * Italic style may not be supported by some terminals
rg --line-number --no-heading --color=always "" |
  fzf --ansi --prompt "Rg: " \
      --color fg+:italic,hl:underline:-1,hl+:italic:underline:reverse:-1 \
      --color pointer:reverse,prompt:reverse,input:159 \
      --pointer '  '
```

### Real-Time Preview Rendering

fzf can render preview windows in real time, even before the underlying command completes. This is useful for long-running processes.

```sh
# fzf can render preview window before the command completes
fzf --preview 'sleep 1; for i in $(seq 100); do echo $i; sleep 0.01; done'
```

The preview window can also process ANSI escape sequences, such as clearing the display.

```sh
# Preview window can process ANSI escape sequence (CSI 2 J) for clearing the display
fzf --preview 'for i in $(seq 100000); do
  (( i % 200 == 0 )) && printf "\033[2J"
  echo "$i"
  sleep 0.01
done'
```

### Multi-Selection and Counters

In multi-selection mode, fzf displays the count of selected items. The zero count is displayed when no items are selected.

```sh
seq 100 | fzf
  # 100/100
seq 100 | fzf --multi
  # 100/100 (0)
seq 100 | fzf --multi 5
  # 100/100 (0/5)
```

### Preview Offsets and Scrolling

Preview windows can be scrolled to specific offsets based on input data. This is particularly useful for code browsing.

```sh
git grep --line-number '' |
  fzf --delimiter : \
      --preview 'bat --style=numbers --color=always --highlight-line {2} {1}' \
      --preview-window +{2}-/2
```

Initial scroll offsets can be set relative to the line number.

```sh
# Initial scroll offset is set to the line number of each line of
# git grep output *minus* 5 lines
git grep --line-number '' |
  fzf --delimiter : --preview 'nl {1}' --preview-window +{2}-5
```

### Bindings and Actions

Bindings allow for powerful interaction with fzf. The `backward-eof` binding aborts the search when the query is empty and the user attempts to delete backward.

```sh
# Aborts when you delete backward when the query prompt is already empty
fzf --bind backward-eof:abort
```

Preview commands can be refreshed dynamically using bindings.

```sh
# Rerun preview command when you hit '?'
fzf --preview 'echo $RANDOM' --bind '?:refresh-preview'
```

Preview bindings can also be used to change the preview command dynamically.

```sh
# Default preview command with an extra preview binding
fzf --preview 'file {}' --bind '?:preview:cat {}'

# A preview binding with no default preview command
# (Preview window is initially empty)
fzf --bind '?:preview:cat {}'

# Preview window hidden by default, it appears when you first hit '?'
fzf --bind '?:preview:cat {}' --preview-window hidden
```

Composite bindings allow multiple actions to be chained.

```sh
fzf --bind 'ctrl-a:up+up'

# Can be now written as
fzf --bind 'ctrl-a:up' --bind 'ctrl-a:+up'

# This is useful when you need to write special execute/reload form (i.e. `execute:...`)
# to avoid parse errors and add more actions to the same key
fzf --multi --bind 'ctrl-l:select-all+execute:less {+f}' --bind 'ctrl-l:+deselect-all'
```

### Integration with Ripgrep

fzf can be integrated with tools like ripgrep for advanced search capabilities.

```sh
# Using fzf as the selector interface for ripgrep
RG_PREFIX="rg --column --line-number --no-heading --color=always --smart-case "
INITIAL_QUERY="foo"
FZF_DEFAULT_COMMAND="$RG_PREFIX '$INITIAL_QUERY' || true" \
  fzf --bind "change:reload:$RG_PREFIX {q} || true" \
      --ansi --phony --query "$INITIAL_QUERY"
```

### Selection and Execution

fzf supports selecting multiple items and executing commands on them.

```sh
seq 100 | fzf --multi 3 --reverse --height 50%
```

Large selections can be processed using temporary files to avoid argument limits.

```sh
# Press CTRL-A to select 100K items and see the sum of all the numbers
seq 100000 | fzf --multi --bind ctrl-a:select-all \
                 --preview "awk '{sum+=\$1} END {print sum}' {+f}"
```

### Bash Completion Setup

Bash completion can be set up using helper functions.

```sh
# usage: _fzf_setup_completion path|dir COMMANDS...
_fzf_setup_completion path git kubectl
```

### Expect Keys

fzf supports expect keys, which allow the user to select an item and a specific key.

```sh
fzf --expect=ctrl-v,ctrl-t,alt-s,f1,f2,~,@
```

### History and Sorting

fzf can be used with history commands and sorting options.

```
history | fzf +s --tac
```

This documentation covers the technical details, code examples, and behavioral changes in fzf from version 0.9.3 to 0.24.3. It serves as a reference for developers and users seeking to understand the evolution and capabilities of the tool.
