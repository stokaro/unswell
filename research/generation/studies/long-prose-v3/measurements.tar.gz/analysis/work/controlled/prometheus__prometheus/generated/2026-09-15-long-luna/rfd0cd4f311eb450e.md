# Prometheus

[![CircleCI](https://circleci.com/gh/prometheus/prometheus/tree/master.svg?style=shield)][circleci]
[![Docker Repository on Quay](https://quay.io/repository/prometheus/prometheus/status)][quay]
[![Docker Pulls](https://img.shields.io/docker/pulls/prom/prometheus.svg?maxAge=604800)][hub]
[![Go Report Card](https://goreportcard.com/badge/github.com/prometheus/prometheus)](https://goreportcard.com/report/github.com/prometheus/prometheus)
[![CII Best Practices](https://bestpractices.coreinfrastructure.org/projects/486/badge)](https://bestpractices.coreinfrastructure.org/projects/486)
[![fuzzit](https://app.fuzzit.dev/badge?org_id=prometheus&branch=master)](https://fuzzit.dev)
[![Gitpod ready-to-code](https://img.shields.io/badge/Gitpod-ready--to--code-blue?logo=gitpod)](https://gitpod.io/#https://github.com/prometheus/prometheus)

Visit [prometheus.io](https://prometheus.io) for complete documentation, examples, and guides.

Prometheus, a [Cloud Native Computing Foundation](https://cncf.io/) project, is a systems and service monitoring system. It collects metrics from configured targets at specified intervals, evaluates rule expressions, displays the results, and can trigger alerts when specified conditions are observed.

The features that distinguish Prometheus from other metrics and monitoring systems include:

- A **multi-dimensional** data model (time series defined by a metric name and a set of key/value dimensions)
- PromQL, a **powerful and flexible query language** for leveraging this dimensionality
- No dependency on distributed storage; **single server nodes are autonomous**
- An HTTP **pull model** for collecting time series
- **Pushing time series** through an intermediary gateway for batch jobs
- Target discovery through **service discovery** or **static configuration**
- Multiple modes of **graphing and dashboarding support**
- Support for hierarchical and horizontal **federation**

## Architecture overview

![](https://cdn.jsdelivr.net/gh/prometheus/prometheus@c34257d069c630685da35bcef084632ffd5d6209/documentation/images/architecture.svg)

## Install

There are various ways to install Prometheus.

### Precompiled binaries

Precompiled binaries for released versions are available in the [*download* section](https://prometheus.io/download/) on [prometheus.io](https://prometheus.io). Using the latest production-release binary is the recommended way to install Prometheus. See the [Installing](https://prometheus.io/docs/introduction/install/) chapter in the documentation for details.

### Docker images

Docker images are available on [Quay.io](https://quay.io/repository/prometheus/prometheus) and [Docker Hub](https://hub.docker.com/r/prom/prometheus/).

You can launch a Prometheus container for testing with:

    $ docker run --name prometheus -d -p 127.0.0.1:9090:9090 prom/prometheus

Prometheus will then be reachable at http://localhost:9090/.

### Building from source

To build Prometheus from source, first ensure that you have a working Go environment with [version 1.14 or greater installed](https://golang.org/doc/install). You also need [Node.js](https://nodejs.org/) and [Yarn](https://yarnpkg.com/) installed to build the frontend assets.

You can use the `go` tool to download and install the `prometheus` and `promtool` binaries into your `GOPATH`:

    $ go get github.com/prometheus/prometheus/cmd/...
    $ prometheus --config.file=your_config.yml

*However*, when using `go get` to build Prometheus, Prometheus expects to read its web assets from local filesystem directories under `web/ui/static` and `web/ui/templates`. For these assets to be found, you must run Prometheus from the root of the cloned repository. These directories also do not include the new experimental React UI unless it has been built explicitly with `make assets` or `make build`.

An example configuration file is available [here.](https://github.com/prometheus/prometheus/blob/master/documentation/examples/prometheus.yml)

You can also clone the repository and build it with `make build`, which compiles the web assets into Prometheus so it can be run from anywhere:

    $ mkdir -p $GOPATH/src/github.com/prometheus
    $ cd $GOPATH/src/github.com/prometheus
    $ git clone https://github.com/prometheus/prometheus.git
    $ cd prometheus
    $ make build
    $ ./prometheus --config.file=your_config.yml

The Makefile provides several targets:

  * *build*: build the `prometheus` and `promtool` binaries, including web assets
  * *test*: run the tests
  * *test-short*: run the short tests
  * *format*: format the source code
  * *vet*: check the source code for common errors
  * *docker*: build a Docker container for the current `HEAD`
  * *assets*: build the new experimental React UI

## React UI Development

For more information about building, running, and developing the new React-based UI, see the React app's [README.md](https://github.com/prometheus/prometheus/blob/master/web/ui/react-app/README.md).

## More information

  * The source code is periodically indexed: [Prometheus Core](https://godoc.org/github.com/prometheus/prometheus).
  * You will find a CircleCI configuration in [`.circleci/config.yml`](.circleci/config.yml).
  * See the [Community page](https://prometheus.io/community) for ways to reach Prometheus developers and users through various communication channels.

## Contributing

Refer to [CONTRIBUTING.md](https://github.com/prometheus/prometheus/blob/master/CONTRIBUTING.md).

## License

Apache License 2.0; see [LICENSE](https://github.com/prometheus/prometheus/blob/master/LICENSE).


[hub]: https://hub.docker.com/r/prom/prometheus/
[circleci]: https://circleci.com/gh/prometheus/prometheus
[quay]: https://quay.io/repository/prometheus/prometheus
