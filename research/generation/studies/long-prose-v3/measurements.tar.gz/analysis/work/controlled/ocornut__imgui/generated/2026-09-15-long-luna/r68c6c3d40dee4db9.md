## Dear ImGui: Using Fonts

The code in `imgui.cpp` embeds a copy of `ProggyClean.ttf` by Tristan Grimmer, a 13-pixel-high, pixel-perfect font used by default. It is embedded in the source code so you can use Dear ImGui without file-system access. ProggyClean does not scale smoothly, so it is recommended that you load your own font when developing an application that aims to look polished and support multiple resolutions.

You may also load external `.TTF` and `.OTF` files. The [misc/fonts/](https://github.com/ocornut/imgui/tree/master/misc/fonts) folder contains several suggested fonts.

**Read the FAQ:** https://www.dearimgui.org/faq (see the Fonts section).

**Use the Discord server:** http://discord.dearimgui.org rather than the GitHub issue tracker for basic font-loading questions.

## Index

- [Readme First](#readme-first)
- [How should I handle DPI in my application?](#how-should-i-handle-dpi-in-my-application)
- [Fonts Loading Instructions](#font-loading-instructions)
- [Using Icons](#using-icons)
- [Using FreeType Rasterizer](#using-freetype-rasterizer)
- [Using Custom Glyph Ranges](#using-custom-glyph-ranges)
- [Using Custom Colorful Icons](#using-custom-colorful-icons)
- [Using Font Data Embedded in Source Code](#using-font-data-embedded-in-source-code)
- [About filenames](#about-filenames)
- [Credits/Licenses for Fonts Included in Repository](#creditslicenses-for-fonts-included-in-repository)
- [Font Links](#font-links)

---------------------------------------

## Readme First

- All loaded font glyphs are rendered into a single texture atlas ahead of time. Calling `io.Fonts->GetTexDataAsAlpha8()`, `io.Fonts->GetTexDataAsRGBA32()`, or `io.Fonts->Build()` builds the atlas.

- Use the style editor, `ImGui::ShowStyleEditor()`, in the “Fonts” section to browse your fonts and investigate problems. You can also open it through `Demo->Tools->Style Editor->Fonts`.

- Make sure your font-range data remains persistent and is available when calling `GetTexDataAsAlpha8()`, `GetTexDataAsRGBA32()`, or `Build()`.

- Use the C++11 `u8"my text"` syntax to encode literal strings as UTF-8. For example:
```cpp
u8"hello"
u8"こんにちは"   // This is encoded as UTF-8.
```

##### [Return to Index](#index)

## How should I handle DPI in my application?

See the [FAQ entry](https://github.com/ocornut/imgui/blob/master/docs/FAQ.md#q-how-should-i-handle-dpi-in-my-application).

##### [Return to Index](#index)

## Font Loading Instructions

**Load the default font:**
```cpp
ImGuiIO& io = ImGui::GetIO();
io.Fonts->AddFontDefault();
```

**Load a `.TTF` or `.OTF` file:**
```cpp
ImGuiIO& io = ImGui::GetIO();
io.Fonts->AddFontFromFileTTF("font.ttf", size_pixels);
```

If you get an assertion stating `Could not load font file!`, your font filename is probably incorrect. Read [About filenames](#about-filenames) carefully.

**Load multiple fonts:**
```cpp
ImGuiIO& io = ImGui::GetIO();
ImFont* font1 = io.Fonts->AddFontFromFileTTF("font.ttf", size_pixels);
ImFont* font2 = io.Fonts->AddFontFromFileTTF("anotherfont.otf", size_pixels);

// Select a font at runtime.
ImGui::Text("Hello"); // Uses the default font, which is the first loaded font.
ImGui::PushFont(font2);
ImGui::Text("Hello with another font");
ImGui::PopFont();
```

**For advanced options, create an `ImFontConfig` structure and pass it to `AddFont()`; it is copied internally:**
```cpp
ImFontConfig config;
config.OversampleH = 2;
config.OversampleV = 1;
config.GlyphExtraSpacing.x = 1.0f;
ImFont* font = io.Fonts->AddFontFromFileTTF("font.ttf", size_pixels, &config);
```

**Combine multiple fonts into one:**
```cpp
// Load a first font.
ImFont* font = io.Fonts->AddFontDefault();

// Add character ranges and merge them into the previous font.
// The ranges array is not copied by the AddFont* functions and is used lazily,
// so make sure it remains available when building or calling GetTexDataAsRGBA32().
static const ImWchar icons_ranges[] = { 0xf000, 0xf3ff, 0 };
ImFontConfig config;
config.MergeMode = true;
io.Fonts->AddFontFromFileTTF("DroidSans.ttf", 18.0f, &config,
                             io.Fonts->GetGlyphRangesJapanese());
io.Fonts->AddFontFromFileTTF("fontawesome-webfont.ttf", 18.0f, &config,
                             icons_ranges);
io.Fonts->Build();
```

**Bake only specific font ranges by providing a fourth parameter:**
```cpp
// Basic Latin and Extended Latin.
io.Fonts->AddFontFromFileTTF("font.ttf", size_pixels, NULL,
                             io.Fonts->GetGlyphRangesDefault());

// Default plus a selection of 2500 ideographs used by Simplified Chinese.
io.Fonts->AddFontFromFileTTF("font.ttf", size_pixels, NULL,
                             io.Fonts->GetGlyphRangesChineseSimplifiedCommon());

// Default plus Hiragana, Katakana, half-width characters, and a selection
// of 1946 ideographs.
io.Fonts->AddFontFromFileTTF("font.ttf", size_pixels, NULL,
                             io.Fonts->GetGlyphRangesJapanese());
```

See [Using Custom Glyph Ranges](#using-custom-glyph-ranges) to create your own ranges.

**Example: loading and using a Japanese font:**
```cpp
ImGuiIO& io = ImGui::GetIO();
io.Fonts->AddFontFromFileTTF("NotoSansCJKjp-Medium.otf", 20.0f, NULL,
                             io.Fonts->GetGlyphRangesJapanese());
```
```cpp
ImGui::Text(u8"こんにちは！テスト %d", 123);
if (ImGui::Button(u8"ロード"))
{
    // Do stuff.
}
ImGui::InputText("string", buf, IM_ARRAYSIZE(buf));
ImGui::SliderFloat("float", &f, 0.0f, 1.0f);
```

**Font atlas too large?**

- If you have a very large number of glyphs or multiple fonts, the texture may become too large for your graphics API. A typical result of failing to upload the texture is that every glyph appears as a white rectangle.
- In particular, using a large range such as `GetGlyphRangesChineseSimplifiedCommon()` is not recommended unless you set `OversampleH` and `OversampleV` to 1 and use a small font size.
- Some graphics drivers have texture-size limitations.
- If you are building a PC application, remember that your users may have hardware with lower limits than yours.

Possible solutions:

1. Reduce the glyph ranges by calculating them from your localization data. `ImFontGlyphRangesBuilder` can do this and usually provides the greatest improvement.
2. Reduce oversampling, for example: `font_config.OversampleH = font_config.OversampleV = 1`.
3. Set `io.Fonts.TexDesiredWidth` to specify a texture width and minimize texture height.
4. Set `io.Fonts.Flags |= ImFontAtlasFlags_NoPowerOfTwoHeight;` to prevent rounding the texture height to the next power of two.
5. Read about oversampling [here](https://github.com/nothings/stb/blob/master/tests/oversample).

##### [Return to Index](#index)

## Using Icons

Using an icon font, such as [FontAwesome](http://fontawesome.io) or [OpenFontIcons](https://github.com/traverseda/OpenFontIcons), is an easy and practical way to use icons in your Dear ImGui application. A common pattern is to merge the icon font with your main font so that you can embed icons directly in strings without switching fonts.

To refer to icon UTF-8 code points from C++ code, you can use the header files created by Juliette Foucaut: https://github.com/juliettef/IconFontCppHeaders.

You can then use `ICON_FA_SEARCH` as a string that renders as a “Search” icon.

**Example setup:**
```cpp
// Merge icons into the default tool font.
#include "IconsFontAwesome.h"
ImGuiIO& io = ImGui::GetIO();
io.Fonts->AddFontDefault();

ImFontConfig config;
config.MergeMode = true;
config.GlyphMinAdvanceX = 13.0f; // Use this to make the icon monospaced.
static const ImWchar icon_ranges[] = { ICON_MIN_FA, ICON_MAX_FA, 0 };
io.Fonts->AddFontFromFileTTF("fonts/fontawesome-webfont.ttf", 13.0f,
                             &config, icon_ranges);
```

**Example usage:**
```cpp
ImGui::Text("%s among %d items", ICON_FA_SEARCH, count);
ImGui::Button(ICON_FA_SEARCH " Search");
// C string literals can be concatenated at compile time.
// ICON_FA_SEARCH is a string literal, so this is equivalent to "A" "B"
// becoming "AB".
```

See the links below for other icon fonts and related tools.

##### [Return to Index](#index)

## Using FreeType Rasterizer

- Dear ImGui uses `imstb_truetype.h` to rasterize fonts, with optional oversampling. This technique and its implementation are not ideal for fonts rendered at small sizes, which may appear slightly blurry or difficult to read.
- An implementation of the `ImFontAtlas` builder using FreeType is available in [misc/freetype/](https://github.com/ocornut/imgui/tree/master/misc/freetype).
- FreeType supports auto-hinting, which tends to improve the readability of small fonts.
- Read the documentation in the [misc/freetype/](https://github.com/ocornut/imgui/tree/master/misc/freetype) folder.
- Correct blending in sRGB space has an important effect on font-rendering quality.

##### [Return to Index](#index)

## Using Custom Glyph Ranges

Use the `ImFontGlyphRangesBuilder` helper to create glyph ranges from text input. For example, if a game’s script is known, you can provide the entire script and build only the characters the game needs.
```cpp
ImVector<ImWchar> ranges;
ImFontGlyphRangesBuilder builder;
builder.AddText("Hello world"); // This contains 7 unique characters.
builder.AddChar(0x7262);
builder.AddRanges(io.Fonts->GetGlyphRangesJapanese());
builder.BuildRanges(&ranges); // Build ordered ranges containing all submitted characters.

io.Fonts->AddFontFromFileTTF("myfontfile.ttf", size_in_pixels, NULL,
                             ranges.Data);
io.Fonts->Build(); // Build while 'ranges' remains in scope.
```

##### [Return to Index](#index)

## Using Custom Colorful Icons

**This is a beta API. Use it only if you are familiar with Dear ImGui and your rendering back end.**

- Use `ImFontAtlas::AddCustomRect()` and `ImFontAtlas::AddCustomRectFontGlyph()` to register rectangles that will be packed into the font-atlas texture. Register them before building the atlas, then call `Build()`.
- Use `ImFontAtlas::GetCustomRectByIndex(int)` to query the position and size of a rectangle within the texture, then blit or copy graphics data into it.
- This API is beta because it may change to support multiple DPI scales across multiple viewports and monitors.

#### Pseudo-code:
```cpp
// Add a font, then register two custom 13x13 rectangles mapped to
// glyphs 'a' and 'b' in that font.
ImFont* font = io.Fonts->AddFontDefault();
int rect_ids[2];
rect_ids[0] = io.Fonts->AddCustomRectFontGlyph(font, 'a', 13, 13, 13 + 1);
rect_ids[1] = io.Fonts->AddCustomRectFontGlyph(font, 'b', 13, 13, 13 + 1);

// Build the atlas.
io.Fonts->Build();

// Retrieve the texture in RGBA format.
unsigned char* tex_pixels = NULL;
int tex_width, tex_height;
io.Fonts->GetTexDataAsRGBA32(&tex_pixels, &tex_width, &tex_height);

for (int rect_n = 0; rect_n < IM_ARRAYSIZE(rect_ids); rect_n++)
{
    int rect_id = rect_ids[rect_n];
    if (const ImFontAtlas::CustomRect* rect =
            io.Fonts->GetCustomRectByIndex(rect_id))
    {
        // Fill the custom rectangle with red pixels. In practice, you would
        // draw or copy your bitmap data here.
        for (int y = 0; y < rect->Height; y++)
        {
            ImU32* p = (ImU32*)tex_pixels + (rect->Y + y) * tex_width + rect->X;
            for (int x = rect->Width; x > 0; x--)
                *p++ = IM_COL32(255, 0, 0, 255);
        }
    }
}
```

##### [Return to Index](#index)

## Using Font Data Embedded in Source Code

- Compile and use [binary_to_compressed_c.cpp](https://github.com/ocornut/imgui/blob/master/misc/fonts/binary_to_compressed_c.cpp) to create a compressed C-style array that you can embed in source code.
- See the documentation in [binary_to_compressed_c.cpp](https://github.com/ocornut/imgui/blob/master/misc/fonts/binary_to_compressed_c.cpp) for instructions on using the tool.
- A precompiled Windows version, `binary_to_compressed_c.exe`, may be available instead of the demo binaries package; see the [README](https://github.com/ocornut/imgui/blob/master/docs/README.md).
- The tool can optionally output Base85 encoding to reduce source-code size, but the read-only arrays in the actual binary will be about 20% larger.

Then load the font with:
```cpp
ImFont* font = io.Fonts->AddFontFromMemoryCompressedTTF(
    compressed_data, compressed_data_size, size_pixels, ...);
```
or:
```cpp
ImFont* font = io.Fonts->AddFontFromMemoryCompressedBase85TTF(
    compressed_data_base85, size_pixels, ...);
```

##### [Return to Index](#index)

## About filenames

**Many new C/C++ users have trouble loading files because the filename they provide is incorrect.**

Two things to watch for:

- Make sure your IDE or debugger starts the executable in the correct working directory. In Visual Studio, you can change this in `Project Properties > General > Debugging > Working Directory`. Execution does not necessarily start in the project’s root folder; by default, it often starts in the folder containing the object or executable files.
```cpp
// A relative filename depends on the working directory.
io.Fonts->AddFontFromFileTTF("MyImage01.jpg", ...);

// Load from the parent of the working directory.
io.Fonts->AddFontFromFileTTF("../MyImage01.jpg", ...);
```

- In C/C++ and most programming languages, write a backslash as `\\` inside a string literal. Windows uses backslashes as path separators, so be careful.
```cpp
io.Fonts->AddFontFromFileTTF("MyFiles\MyImage01.jpg", ...);   // Incorrect.
io.Fonts->AddFontFromFileTTF("MyFiles\\MyImage01.jpg", ...);  // Correct.
```
In some situations, you may also use `/` as a path separator on Windows.

##### [Return to Index](#index)

## Credits/Licenses for Fonts Included in Repository

Some font files are available in the `misc/fonts/` folder:

```
Roboto-Medium.ttf
  Apache License 2.0
  by Christian Robertson
  https://fonts.google.com/specimen/Roboto

Cousine-Regular.ttf
  by Steve Matteson
  Digitized data copyright (c) 2010 Google Corporation.
  Licensed under the SIL Open Font License, Version 1.1
  https://fonts.google.com/specimen/Cousine

DroidSans.ttf
  Copyright (c) Steve Matteson
  Apache License, version 2.0
  https://www.fontsquirrel.com/fonts/droid-sans

ProggyClean.ttf
  Copyright (c) 2004, 2005 Tristan Grimmer
  MIT License
  Recommended loading settings: Size = 13.0, GlyphOffset.y = +1
  http://www.proggyfonts.net/

ProggyTiny.ttf
  Copyright (c) 2004, 2005 Tristan Grimmer
  MIT License
  Recommended loading settings: Size = 10.0, GlyphOffset.y = +1
  http://www.proggyfonts.net/

Karla-Regular.ttf
  Copyright (c) 2012 Jonathan Pinhorn
  SIL Open Font License, Version 1.1
```

##### [Return to Index](#index)

## Font Links

#### ICON FONTS

- C/C++ header for icon fonts (`#define` declarations with code points for use in source-code string literals): https://github.com/juliettef/IconFontCppHeaders
- FontAwesome: https://fortawesome.github.io/Font-Awesome
- OpenFontIcons: https://github.com/traverseda/OpenFontIcons
- Google Icon Fonts: https://design.google.com/icons/
- Kenney Icon Font (Game Controller Icons): https://github.com/nicodinh/kenney-icon-font
- IcoMoon — Custom Icon Font Builder: https://icomoon.io/app

#### REGULAR FONTS

- Google Noto Fonts (worldwide languages): https://www.google.com/get/noto/
- Open Sans Fonts: https://fonts.google.com/specimen/Open+Sans
- Japanese M+ fonts by Coji Morishita: http://mplus-fonts.sourceforge.jp/mplus-outline-fonts/index-en.html

#### MONOSPACE FONTS

**Pixel perfect:**

- Proggy Fonts by Tristan Grimmer: http://www.proggyfonts.net or http://upperbounds.net
- Sweet16 and Sweet16 Mono by Martin Sedlak (Latin, Supplemental, and Extended-A): https://github.com/kmar/Sweet16Font (also includes an `.inl` file for direct use in Dear ImGui)

**Regular:**

- Google Noto Mono Fonts: https://www.google.com/get/noto/
- Typefaces for source-code beautification: https://github.com/chrissimpkins/codeface
- Programming fonts: http://s9w.github.io/font_compare/
- Inconsolata: http://www.levien.com/type/myfonts/inconsolata.html
- Adobe Source Code Pro: https://github.com/adobe-fonts/source-code-pro
- Monospace/Fixed Width Programmer’s Fonts: http://www.lowing.org/fonts/

You can also use Arial Unicode or other Unicode fonts provided with Windows for broad character coverage; check their licensing.

##### [Return to Index](#index)
