# Mermaid Documentation

## Introduction

Mermaid is a JavaScript diagramming tool that enables developers to create diagrams and charts using markdown-inspired textual definitions. This approach allows diagram source code to be edited and included directly in scripts, helping keep diagrams synchronized with software development. The tool integrates with editors, wikis, and various applications, while the Mermaid Live Editor provides an interface for creating diagrams without programming. Introductory resources include tutorials, beginner overviews, usage guides, integration documentation, syntax references, and getting-started materials.

Mermaid received the 2019 JavaScript Open Source Award for The most exciting use of technology, recognizing its innovative approach to diagram creation.

## Supported Diagram Types

Mermaid supports a comprehensive range of diagram types suitable for different documentation and planning needs. Flowcharts enable visual representation of processes and decision logic. Sequence diagrams illustrate interactions between participants over time. Gantt charts display project timelines and task dependencies. Class diagrams model object-oriented designs and relationships. User journey diagrams map user experiences through scenarios.

Additionally, git graphs and entity-relationship diagrams are available as experimental features. Each diagram type uses a consistent markdown-inspired syntax that developers can write, review, and version control alongside their code.

## Browser Integration and CDN

Mermaid integrates into web pages without requiring a bundler. The CDN is hosted at unpkg.com/mermaid, where specific versions can be selected through the URL. The current reference points to version 8.8.0.

Browser installation requires two components. First, include Mermaid's JavaScript file using an absolute script URL:

```html
<script src="https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js"></script>
<script>mermaid.initialize({startOnLoad:true});</script>
```

The parser automatically reads diagram definitions in div elements with the class attribute set to mermaid and renders them as SVG charts.

Diagram definitions follow markdown-inspired syntax. A flowchart might be defined as:

```
graph TD;
    A-->B;
    A-->C;
    B-->D;
    C-->D;
```

Sequence diagrams show participant interactions with timing:

```
sequenceDiagram
    participant Alice
    participant Bob
    Alice->>John: Hello John, how are you?
    loop Healthcheck
        John->>John: Fight against hypochondria
    end
    Note right of John: Rational thoughts <br/>prevail!
    John-->>Alice: Great!
    John->>Bob: How about you?
    Bob-->>John: Jolly good!
```

Gantt charts display project schedules:

```
gantt
dateFormat  YYYY-MM-DD
title Adding GANTT diagram to mermaid
excludes weekdays 2014-01-10

section A section
Completed task            :done,    des1, 2014-01-06,2014-01-08
Active task               :active,  des2, 2014-01-09, 3d
Future task               :         des3, after des2, 5d
Future task2               :         des4, after des3, 5d
```

Class diagrams represent object-oriented structures:

```
classDiagram
Class01 <|-- AveryLongClass : Cool
Class03 *-- Class04
Class05 o-- Class06
Class07 .. Class08
Class09 --> C2 : Where am i?
Class09 --* C3
Class09 --|> Class07
Class07 : equals()
Class07 : Object[] elementData
Class01 : size()
Class01 : int chimp
Class01 : int gorilla
Class08 <--> C2: Cool label
```

Git graphs visualize version control workflows:

```
gitGraph:
options
{
    "nodeSpacing": 150,
    "nodeRadius": 10
}
end
commit
branch newbranch
checkout newbranch
commit
commit
checkout master
commit
commit
merge newbranch
```

Entity-relationship diagrams model database schemas:

```
erDiagram
    CUSTOMER ||--o{ ORDER : places
    ORDER ||--|{ LINE-ITEM : contains
    CUSTOMER }|..|{ DELIVERY-ADDRESS : uses
```

User journey diagrams map experience flows:

```
journey
    title My working day
    section Go to work
      Make tea: 5: Me
      Go upstairs: 3: Me
      Do work: 1: Me, Cat
    section Go home
      Go downstairs: 5: Me
      Sit down: 5: Me
```

## Related Projects and Community

Mermaid has several sibling projects that extend its functionality. The Mermaid Live Editor provides a web interface for creating diagrams. Mermaid CLI enables command-line diagram generation. Mermaid Webpack Demo and Mermaid Parcel Demo showcase bundler integration patterns.

The maintainer actively seeks core team members to help add new diagram types and improve existing ones. Team members receive repository write access and represent the project when addressing questions and issues.

## Contributing

Contributors must install Node.js v10 or later. Begin by installing Yarn and adding Mermaid:

```
yarn add mermaid
yarn add --dev mermaid
```

Install project dependencies:

```
yarn install
```

Build continuously during development:

```
yarn build:watch
```

Lint code using ESLint:

```
yarn lint
```

Run tests:

```
yarn test
```

Authorized release maintainers update the version in package.json and execute the publish command, which generates distribution files and publishes to npmjs.org:

```
npm publish
```

## Credits

Knut Sveidqvist created Mermaid. The project leverages d3 and dagre-d3 for layout and drawing, js-sequence-diagram for sequence diagram grammar, Jessica Peter for Gantt diagram foundations, and Tyler Long for maintenance support. The community includes numerous additional contributors and supporters.
