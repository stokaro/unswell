# Dear ImGui

Dear ImGui is a self-contained, renderer-independent C++ GUI library with no external dependencies. It produces vertex buffers and command lists that can be rendered through an application's 3D pipeline.

The library is intended for programmers building creation, visualization, and debugging tools. It is used in game-engine, real-time 3D, fullscreen, embedded, and console applications. Dear ImGui focuses on programmer-oriented interfaces; some higher-level and end-user UI features are absent.

## Usage

Dear ImGui is designed for interfaces that are created and updated directly by application code. A typical frame can contain text, buttons, input controls, and sliders:

```cpp
ImGui::Text("Hello, world %d", 123);
if (ImGui::Button("Save"))
    MySaveFunction();
ImGui::InputText("string", buf, IM_ARRAYSIZE(buf));
ImGui::SliderFloat("float", &f, 0.0f, 1.0f);
```

The library can also construct complete tools with menu bars, editable values, plots, and scrolling regions:

```cpp
// Create a window called "My First Tool", with a menu bar.
ImGui::Begin("My First Tool", &my_tool_active, ImGuiWindowFlags_MenuBar);
if (ImGui::BeginMenuBar())
{
    if (ImGui::BeginMenu("File"))
    {
        if (ImGui::MenuItem("Open..", "Ctrl+O")) { /* Do stuff */ }
        if (ImGui::MenuItem("Save", "Ctrl+S"))   { /* Do stuff */ }
        if (ImGui::MenuItem("Close", "Ctrl+W"))  { my_tool_active = false; }
        ImGui::EndMenu();
    }
    ImGui::EndMenuBar();
}

// Edit a color (stored as ~4 floats)
ImGui::ColorEdit4("Color", my_color);

// Plot some values
const float my_values[] = { 0.2f, 0.1f, 1.0f, 0.5f, 0.9f, 2.2f };
ImGui::PlotLines("Frame Times", my_values, IM_ARRAYSIZE(my_values));

// Display contents in a scrolling region
ImGui::TextColored(ImVec4(1,1,0,1), "Important Stuff");
ImGui::BeginChild("Scrolling");
for (int n = 0; n < 50; n++)
    ImGui::Text("%04d: Some text", n);
ImGui::EndChild();
ImGui::End();
```

## How it works

Dear ImGui uses an immediate-mode UI approach. This minimizes duplicated, synchronized, or retained application state and makes dynamic interfaces practical. Immediate mode does not mean that every widget causes an immediate GPU call. Dear ImGui builds a small draw-call list and associated buffers. Those results can be rendered later or remotely.

GUI calls can occur throughout the program loop, including inside algorithms or rendering code. They do not directly alter graphics state. This makes it possible to place controls and inspection interfaces close to the code and data they describe.

Typical uses include temporary controls that can be hot-reloaded, algorithm traces, data inspection, logs, profilers, debuggers, and editors. The approach is intended to support interfaces whose contents and structure change while a program is running.

## Releases

The `master` branch, described as the latest version, is generally stable and is the recommended branch for most users. Advanced users may use the regularly synchronized `docking` branch.

Development plans are subject to change and include feedback requests. The 2020 plans covered docking and multiple viewports or OS windows on the docking branch, gamepad and keyboard controls, and a Tables API on the tables branch to replace Columns. They also included automated library and application testing, along with improved styles, fonts, and HiDPI examples.

## Demo

`ImGui::ShowDemoWindow` displays features implemented in `imgui_demo.cpp`. The demo is a reference for the library's available interface elements and behavior.

Example builds are tested on Windows, macOS, and Linux. The supplied Windows download is version 1.78 WIP, dated September 18, 2020. Demo binaries are not DPI-aware. Applications can reload fonts at appropriate scales and call `style.ScaleAllSizes`; FAQ guidance covers DPI-related setup.

## Integration

Dear ImGui can be integrated into an existing C++ project by compiling the root `.cpp` files, including:

- `imgui.cpp`
- `imgui_demo.cpp`
- `imgui_draw.cpp`

No special build system is required.

A backend supplies mouse, keyboard, and gamepad inputs, as well as settings, and renders the vertices produced by Dear ImGui. Integration requires uploading one texture and providing textured-triangle rendering. Official examples provide platform and renderer backends, and custom backends are also possible.

Combining existing platform and renderer backends is recommended. The available official renderer backends include DirectX 9, DirectX 10, DirectX 11, DirectX 12, legacy OpenGL, modern OpenGL3/ES/ES2, Vulkan, and Metal.

Official platform backends include GLFW, SDL2, Win32, GLUT, and OSX. Supported frameworks include Emscripten, Allegro5, and Marmalade.

The supplied examples demonstrate how platform input and renderer output are connected. Applications can select the appropriate existing backends and combine them for their environment, or provide custom implementations when necessary.

## Language and framework bindings

The supplied reference lists third-party bindings for many languages and frameworks.

Languages include C, C#, Beef, ChaiScript, Crystal, D, Go, Haskell, Haxe/hxcpp, Java, JavaScript, Julia, Kotlin, Lua, Odin, Pascal, PureBasic, Python, Ruby, Rust, and Swift.

Framework bindings include AGS/Adventure Game Studio, Amethyst, bsf, Cinder, Cocos2d-x, Diligent Engine, Flexium, GML/Game Maker Studio2, Godot, GTK3+OpenGL3, Irrlicht Engine, LÖVE+LUA, Magnum, NanoRT, nCine, Nim Game Lib, Ogre, openFrameworks, OSG/OpenSceneGraph, Orx, Photoshop, px_render, Qt/QtDirect3D, SFML, Sokol, Unity, Unreal Engine 4, vtk, Win32 GDI, and WxWidgets.

C bindings are provided by [cimgui](https://github.com/cimgui/cimgui). These bindings are auto-generated, and their JSON or Lua output can be used to generate bindings for other languages.

The [Wiki](https://github.com/ocornut/imgui/wiki) contains additional links and ideas, including the [Bindings](https://github.com/ocornut/imgui/wiki/Bindings/) page.

## Support and frequently asked questions

Documentation includes release information, demos, the FAQ, the Wiki, paradigm articles, binding lists, galleries, user quotes, and software listings.

Beginners who need help with setup, input, or fonts can use Discord. Other questions, reports, requests, and feedback should use GitHub issues with the issue template. Paying businesses can obtain private support.

Community answers, issue discussions, and maintainable pull requests help support the project. Maintainers take ongoing responsibility for code that is accepted.

## Upcoming changes

The 2020 development plans identified several areas of work:

- Docking and multiple viewports or OS windows on the docking branch.
- Gamepad and keyboard controls.
- A Tables API replacing Columns on the tables branch.
- Automated testing of the library and applications.
- Improved styles, fonts, and HiDPI examples.

These items represent development plans rather than guarantees. Feedback was requested as the work progressed. Some automation and regression work remains unpublished.

## Gallery and software listings

The documentation includes a gallery, user quotes, and a listing of software using Dear ImGui. These materials, together with paradigm articles and the Wiki, provide additional references for understanding how the library is used.

The main documentation links include:

- [Wiki](https://github.com/ocornut/imgui/wiki)
- [Language and framework bindings](https://github.com/ocornut/imgui/wiki/Bindings)
- [Software using Dear ImGui](https://github.com/ocornut/imgui/wiki/Software-using-dear-imgui)
- [User quotes](https://github.com/ocornut/imgui/wiki/Quotes)

## How to help

Users can help through community answers, issue reports, feedback, and maintainable pull requests. Accepted code carries an ongoing maintenance responsibility for the maintainers.

Businesses can sponsor development through support or maintenance contracts by contacting `contact@dearimgui.com`. Individuals can contribute through donations. From November 2014 through December 2019, ongoing development was financially supported by users on Patreon and through individual donations.

Open-source services have also supported development:

- [PVS-Studio](https://www.viva64.com/en/b/0570/) provides static analysis.
- [GitHub Actions](https://github.com/features/actions) provides continuous integration systems.
- [OpenCppCoverage](https://github.com/OpenCppCoverage/OpenCppCoverage) provides code coverage analysis.

## Sponsors

The sponsor roster records corporate support.

### Platinum-chocolate sponsors

- [Blizzard](https://careers.blizzard.com/en-us/openings/engineering/all/all/all/1)
- [Google](https://github.com/google/filament)
- [Nvidia](https://developer.nvidia.com/nvidia-omniverse)
- [Ubisoft](https://montreal.ubisoft.com/en/ubisoft-sponsors-user-interface-library-for-c-dear-imgui/)

### Double-chocolate and Salty caramel sponsors

- [Activision](https://careers.activision.com/c/programmingsoftware-engineering-jobs)
- [Arkane Studios](https://www.arkane-studios.com)
- [Dotemu](http://www.dotemu.com)
- [Framefield](http://framefield.com)
- [Hexagon](https://hexagonxalt.com/the-technology/xalt-visualization)
- [Kylotonn](https://www.kylotonn.com)
- [Media Molecule](http://www.mediamolecule.com)
- [Mesh Consultants](https://www.meshconsultants.ca)
- [Mobigame](http://www.mobigame.net)
- [Nadeo](https://www.nadeo.com)
- [Next Level Games](https://www.nextlevelgames.com)
- [RAD Game Tools](http://www.radgametools.com/)
- [Supercell](http://www.supercell.com)
- [Remedy Entertainment](https://www.remedygames.com/)
- [Unit 2 Games](https://unit2games.com/)

See the [detailed list of Dear ImGui supporters](https://github.com/ocornut/imgui/wiki/Sponsors).

## Credits

Omar Cornut developed Dear ImGui with contributors. The project was initially supported by Media Molecule and used in *Tearaway* on PS Vita. Recurring contributors in 2020 included Rokas Kupstys and Ben Carter.

Cornut encountered Atman Binstock's implementation at Q-Games and later rewrote the library at Media Molecule. Credits also include Casey Muratori and early feedback and testing contributors listed in the source.

## License

Dear ImGui itself uses the MIT license.

The embedded `ProggyClean.ttf` font is by Tristan Grimmer and is provided under the MIT license. `stb_textedit.h`, `stb_truetype.h`, and `stb_rect_pack.h` are by Sean Barrett and are identified as public domain.
