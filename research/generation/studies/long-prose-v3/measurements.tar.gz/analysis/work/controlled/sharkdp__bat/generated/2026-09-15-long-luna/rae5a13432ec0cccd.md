# unreleased

## Features

## Bugfixes

## Other

## Syntaxes

## New themes

## `bat` as a library

## Packaging

# v0.16.0

## Features

- Added support for the `NO_COLOR` environment variable, see #1021 and #1031 (@eth-p)
- Added the `-P` short flag to disable paging, see #1075 and #1082 (@LordFlashmeow)
- Added the `--force-colorization`/`-f` flag as an alias for forced color and decoration output, see #1141 (@alexanderkarlis)

## Bugfixes

- Fixed the display of non-printable characters for redirected output, see #1061 (@gsomix)
- Handle file-extension conflicts in `--list-languages`, see #1076 and #1135 (@Kienyew)

## Other

- Switched from "•" (U+2022), Bullet, to "·" (U+00B7), Middle Dot, for non-printing spaces, see #1056 and #1100 (@LordFlashmeow)
- Added a zsh shell-completion script, see #1136 (@Kienyew)
- Improved the `--help` text (@sharkdp)
- Added custom-language and custom-theme sections to the man page (@eth-p)

## Syntaxes

- Updated the AsciiDoc syntax, see #1034 (@rxt1077)
- Added GLSL syntax (@caioalonso)
- Added Nginx and Apache configuration-file syntax, see #1137 (@kjmph, @niklasmohrin)
- Use `fstab` syntax for `crypttab` files, see #1073 (@sharkdp)
- Added syntax highlighting for files in `$XDG_CONFIG_HOME/git/`, see #1191 (@ahmedelgabri)

## New themes

- Added Gruvbox, see #1069 (@kyleondy)
- Added base16-256 for [base16-shell](https://github.com/chriskempson/base16-shell) users, see #1111 (@mk12)

## `bat` as a library

- Added APIs for providing `Input` descriptions with `InputDescription` (@eth-p)
- Added a function to provide `Input`s directly to `PrettyPrinter` (@eth-p)
- **Breaking:** `Input::theme_preview_file` is no longer available (@eth-p)

## Packaging

- Removed the build dependency on `liquid` (@sharkdp)

# v0.15.4

## Bugfixes

- Added the missing Solarized themes, see #1027
- Fixed a highlighting bug in Haskell source files, see #1026

# v0.15.3

## Bugfixes

- Fixed an issue that prevented `bat` from running with relative paths, see #1022
- Fixed incorrect highlighting of users whose names start with digits in SSH configuration files, see #984

## New syntaxes

- Added SML, see #1005 (@kopecs)

## Other

- Updated some syntaxes and themes to the latest version

# v0.15.2

## Bugfixes

- Fixed syntax detection for files named `rails`, see #1008
- Fixed potential errors during syntax detection for symlinked files, see #1001
- Fixed `--map-syntax` for names provided through `--file-name` (@eth-p)

## Other

- Added padding above headers when not using a grid, see #968 and #981 (@pt2121)
- `bat` now prints an error when an invalid syntax is specified with `-l` or `--map-syntax`, see #1004 (@eth-p)

## `bat` as a library

- Deprecated `PrettyPrinter::vcs_modification_markers` when building without the `git` feature, see #997 and #1020 (@eth-p, @sharkdp)

## Packaging

- Resolved compilation problems with `onig_sys` on various platforms by upgrading to `syntect 4.2`. This version includes a new `onig` version that allows `onig_sys` to be built without the `bindgen` dependency. As a result, `libclang(-dev)` is no longer required to compile `bat`. Package maintainers may remove `clang` as a build dependency. See #650 for more details.

# v0.15.1

## Bugfixes

- Fixed Markdown-file highlighting, see #963 and #977
- Fixed the `base16` theme, which had been broken since v0.14, see #972, #934, and #979 (@mk12). Users affected by #865 ("no color for bat in ssh from a Windows client") can now use the `ansi-dark` and `ansi-light` themes.

## New syntaxes

- Added Fortran, see #957
- Added email syntax (@mariozaizar)
- Added QML, see #962 (@pylipp)

# v0.15.0

## Features

- Added a new `--diff`/`-d` option that shows only lines surrounding Git changes: added, removed, or modified lines. The amount of additional context can be controlled with `--diff-context=N`. See #23 and #940.

## Bugfixes

- Fixed an error message being printed in the middle of another file's output, see #946
- Improved performance when using custom caches through `bat cache --build`; `bat` startup should now be twice as fast (@lzutao)

## Themes

- Updated the Solarized dark and light themes, see #941

## `bat` as a library

- The "low-level" API has changed in several ways. The `Config` struct has changed, and the error handler now requires an additional `&mut dyn Write` argument. The high-level API is unaffected.

# v0.14.0

## Features

- Added a new `--file-name <name>…` option to replace the displayed filenames in the header. This is useful when piping input into `bat`. See #654 and #892 (@neuronull).
- Added a new `--generate-config-file` option to create an initial configuration file in the correct location. See #870 (@jmick414).

## Bugfixes

- Fixed performance problems with C# source code, see #677 (@keith-hall)
- Fixed performance problems with Makefiles, see #750 (@keith-hall)
- Fixed a bug when highlighting Ruby files with unindented heredocs, see #914 (@keith-hall)
- Fixed a highlighting problem with Rust source code, see #924 (@keith-hall)
- Windows: fixed an issue where short files that did not require paging were displayed and then lost, see #887
- Fixed `--highlight-line` when used with `--tabs=0` and `--wrap=never`, see #937

## Other

- When saving or reading user-provided syntaxes or themes, `bat` now maintains a `metadata.yaml` file containing the `bat` version used to create the cached files. When loading cached files, `bat` now prints an error if they were created with an incompatible version. See #882.
- Updated the `liquid` dependency to 0.20, see #880 (@ignatenkobrain)

## `bat` as a library

- Added a completely new "high-level" API that is more convenient to use. See the updated code in the `examples` folder. The older "low-level" API remains available—essentially, everything outside the root `bat` module—but has been refactored substantially. When possible, use only the new "high-level" API, which will be easier to keep stable. This is still a "beta" release of `bat` as a library. For more details and screenshots of the example programs, see #936.
- Removed many binary-only dependencies, see #895 and #899 (@dtolnay).

  This introduces a `features = ["application"]` feature, enabled by default, that pulls in everything required by the `bat` application. When depending on `bat` as a library, downstream `Cargo.toml` files should disable this feature to remove inapplicable heavy dependencies:
  ```toml
  [dependencies]
  bat = { version = "0.14", default-features = false }
  ```
  Other optional functionality has also been placed behind features: `paging` and `git` support.
- Allowed the library to use older versions of syntect, see #896 and #898 (@dtolnay)

## New syntaxes

- Added Rego, see #872 (@patrick-east)
- Added Stylo, see #917

# v0.13.0

## `bat` as a library

Beginning with this release, `bat` can be used as a library (#423).

This was a substantial effort. Thank you to everyone who made it possible: @DrSensor, @mitsuhiko, @mre, and @eth-p.

- Initial attempt in #469 (@mitsuhiko)
- Complete restructuring of the `bat` crate in #679 (@DrSensor)
- Updates to the examples, public API, and error handling, plus further refactoring: #693, #873, and #875 (@sharkdp)

This is the library's first release. Its API is likely to change, and many things, including documentation, are still missing.

You can start using it now. See the example programs in [`examples/`](https://github.com/sharkdp/bat/tree/master/examples).

The API documentation is available at https://docs.rs/bat/.

## Features

- (**Breaking change**) Added glob-based syntax mapping, see #877 and #592. Users must update their `bat` configuration files (`bat --config-file`) if they have any `--map-syntax` settings.

  The option now has this form:
  ```bash
  --map-syntax <glob-pattern>:<syntax-name>
  ```

  For more information, see the `--help` text, the man page, or the README.

  This feature allows files such as these to be highlighted correctly:
  * `/etc/profile`
  * `~/.ssh/config`

- `--highlight-line` now accepts line ranges, see #809 (@lkalir)
- Added proper wrapping support for output containing wide Unicode characters, see #811, #787, and #815 (@Kogia-sima)
- Updated many existing syntaxes through #644 (@benwaffle, @keith-hall)
- `BAT_CACHE_PATH` can place cached `bat` assets in a non-standard path, see #829 (@neuronull)
- Added support for combining multiple styles, see #857 (@aslpavel)

## Bugfixes

- Do not pass `--no-init` to newer `less` versions, see #749 and #786 (@sharkdp)
- `bat cache` now takes precedence over existing files, see #666 (@sharkdp)
- Treat `.sc` files as Scala files, see #443 (@benwaffle)
- Allow underscores and dashes in page names, see #670 (@LunarLambda)
- Keep empty lines empty, see #601 (@mbarbar)
- Fixed wrapping when piping, see #758 (@fusillicode, @allevo, @gildo)
- Allow non-Unicode filenames, see #225 (@sharkdp)
- Fixed the incomplete grid produced by an empty file without a header, see #798 (@eth-p)
- Files named `build` now respect shebang lines, see #685 (@sharkdp)

## Other

- Added parameterized names for man-page and shell-completion files, see #659, #673, and #656 (@eth-p)
- Enabled LTO, making `bat` about 10% faster, see #719 (@bolinfest, @sharkdp)
- Added suggestions for configuring `bat` for macOS dark mode to the README (@jerguslejko)
- Extended the ["Integration with other tools"](https://github.com/sharkdp/bat#integration-with-other-tools) section (@eth-p)
- Updated [the instructions for using `bat` as a `man` pager](https://github.com/sharkdp/bat#man), see #652 and #667 (@sharkdp)
- Added a section about file encodings, see #688 and #568 (@sharkdp)
- Updated the sort order of command-line options in the `--help` text and man page, see #653 and #700 (@hrlmartins)
- Updated the man-page syntax, see #718 (@sharkdp)
- Updated the Japanese documentation (@k-ta-yamada, @sorairolake, and @wt-l00)
- Accept `"default"` as a theme, see #757 (@fvictorio)
- Updated the Windows installation instructions, see #852 (@sorenbug)
- Updated the man page, see #573 (@sharkdp)

## New syntaxes

- Added Jinja2, see #648 (@Martin819)
- Added SaltStack SLS, see #658 (@Martin819)
- Added `/etc/fstab`, see #696 (@flopp and @eth-p)
- Added `/etc/group` and `/etc/passwd`, see #698 (@argentite)
- Added `/proc/cpuinfo` and `/proc/meminfo`, see #593 (@sharkdp)
- Added Nim, see #542 (@sharkdp)
- Added Vue, see #826 (@chaaaaarlotte)
- Added CoffeeScript, see #833 (@sharkdp)

## New themes

- Added Dracula, see #687 (@clarfon)
- Added Nord, see #760 (@crabique)
- Added Solarized light and dark, see #768 (@hakamadare)

## Packaging

- `bat` is now in the official Ubuntu and Debian repositories, see #323 and #705 (@MarcoFalke)
- `bat` can now be installed through MacPorts, see #675 (@bn3t)
- Install fish completions into `vendor_completions.d`, see #651 (@sharkdp)

## Thanks

- Thank you to @eth-p for joining me as a maintainer. I am grateful for all the work you put into managing and responding to issues, improving deployment, adding pull-request and issue templates (#837), fixing bugs, and implementing new features.

# v0.12.1

## Bugfixes

- Fixed a bug affecting older Windows versions: *"The procedure entry point `CreateFile2` could not be located"*, see #643 (@rivy)

# v0.12.0

## Features

- Binary file content can now be viewed with `bat -A`, see #623 and #640 (@pjsier and @sharkdp)
- `bat` can now be used as a man pager. See the README and #523 for details.
- Added a new style component for separating multiple `--line-range`s, see #570 (@eth-p)
- Added `-L` as an alias for `--list-languages`

## Bugfixes

- Fixed unbalanced output when using `--style=grid,numbers` without `header`, see #571 (@eth-p)
- Fixed issues with filenames starting with `"cache"`, see #584
- Fixed an error that prevented building a cache with a new theme unless the cache directory already existed, see #576 (@frm)
- Fixed incorrect parsing of `--terminal-width -10`, see #611

## Other

- Added fish completions to the DEB package, see #554

## New syntaxes

- Added Emacs Org mode, see #36 (@bricewge)
- Added `requirements.txt`
- Added DotENV `.env`
- Added SSH configuration syntax (`-l ssh_config`), see #582 (@issmirnov)
- Added `/etc/hosts`, see #583 (@issmirnov)
- Added GraphQL, see #625 (@dandavison)
- Added Verilog, see #616
- Added SCSS and Sass, see #637
- Added `strace` syntax, see #599

## Packaging

- `bat` is now in the official Gentoo repositories, see #588 (@toku-sa-n)
- `bat` is now in the official Alpine Linux repositories, see #586 (@5paceToast)
- `bat` is now in the official Fedora repositories, see #610 (@ignatenkobrain)

# v0.11.0

## Features

- Added three special color themes: `ansi-light`, `ansi-dark`, and `base16`. These are useful for users who switch between dark and light terminal themes or want colors that match their terminal themes. See #543 and #490 (@mk12; implementation idea by @trishume).
- Added a hand-written auto-completion script for the Fish shell, see #524 and #555 (@ev-dev and @eth-p)
- The `-p`/`--plain` option can now be used twice, typically as `-pp`. The first `-p` switches `--style` to `"plain"`; the second disables the pager. See #560 and #552 (@eth-p)

## Bugfixes

- Do not replace `less` arguments when using `--pager`, see #509
- Binary files are now indicated by a warning in interactive mode, see #530, #466, and #550 (@maxfilov)
- Empty files are once again printed with a single header line, see #504 and #566 (@reidwagner and @sharkdp)
- `--terminal-width=0` is now disallowed, see #559 (@eth-p)
- Fixed accidental printing of files named `cache`, see #557

## Other

- Added new integration tests, see #500 and #502 (@reidwagner and @sharkdp)
- Added a new ["Integration with other tools"](https://github.com/sharkdp/bat#integration-with-other-tools) section to the README
- Migrated to Rust 2018 (@expobrain)

## New syntaxes

- Updated F# syntax, see #531 (@stroborobo)
- Added Fish shell syntax, see #548 (@sanga)

## Packaging

- `bat` is now available through Chocolatey, see #541 (@rasmuskriest)

# v0.10.0

## Features

- Added the `--highlight-line <N>` option, see #453, #346, and #175 (@tskinn and @sharkdp)

## Changes

- **Changed the default configuration directory on macOS** to `~/.config/bat`, see #442 (@lavifb). macOS users must copy their configuration directory from the previous location (`~/Library/Preferences/bat`) to the new location (`~/.config/bat`).
- Completely disabled shell-completion-file generation, see #372
- Properly set `less` arguments when the `PAGER` environment variable contains a value such as `less -F`, which lacks the `-R` option, see #430 (@majecty)
- Report the names of missing files, see #444 (@ufuji1984)
- Do not start the pager if a file does not exist, see #387
- Renamed `bat cache --init` to `bat cache --build`, see #498
- Moved the `--config-dir` and `--cache-dir` options from `bat cache` to `bat` and hid them from the help text

## Bugfixes

- Fixed the blank line at the end of output when using `--style=plain`, see #379
- EOF must be sent twice on stdin when no other input is sent, see #477 (@reidwagner)

## New syntaxes

- Added Twig (@ahmedelgabri)
- Added `.desktop` files (@jleclanche)
- Added AsciiDoc (@markusthoemmes)
- Added Assembly for x86_64 and ARM
- Added log files (@caos21)
- Added Protobuf and ProtobufText (@caos21)
- Added Terraform (@caos21)
- Added Jsonnet (@hfm)
- Added Varlink (@haraldh)

## Other

- Added a Japanese version of the README (@sh-tech and @object1037)
- Improved the code (@barskern)

# v0.9.0

## Features

- Added a new `-A`/`--show-all` option to show and highlight non-printable characters, analogous to the GNU `cat` option:

  ![](https://camo.githubusercontent.com/c3e769482ef3184f6be6adaa34bdc8d19c378254/68747470733a2f2f692e696d6775722e636f6d2f324b54486859542e706e67)

  See #395 and #381 for details.

- Added the `--pager` option to configure the pager from the configuration file, see #362 (@majecty)
- Added the `BAT_CONFIG_PATH` environment variable to set a non-default path for the `bat` configuration file, see #375 (@deg4uss3r)
- Allowed multiple occurrences of `--style` to configure styles from the configuration file, see #367 (@sindreij)
- Allowed multiple `--line-range` arguments, see #23
- The `--terminal-width` option can now accept offsets, see #376

## Changes

- Italics are now *disabled by default*, see #389. They can be re-enabled by adding `--italic-text=always` to the configuration file.
- Set the default tab width to 4
- Added the new "Sublime Snazzy" theme
- Shell completions are no longer shipped, see #372

## Bugfixes

- Avoided endless recursion when `PAGER="bat"`, see #383 (@rodorgas)

## Other

- `bat` is now available on openSUSE, see #405 (@dmarcoux)
- Added a section about the new configuration file to the README (@deg4uss3r)
- Added a Chinese translation of the README (@chinanf-boy)
- Rewrote tests for `--tabs` (@choznerol)
- Sped up integration tests, see #394

# v0.8.0

## Features

- Added support for a configuration file with this simple format:

  ```bash
  --tabs=4
  --theme="Sublime Snazzy"

  # A line comment
  --map-syntax .ignore:.gitignore
  --map-syntax PKGBUILD:bash
  --map-syntax Podfile:ruby

  # Flags and options can also be on a single line:
  --wrap=never --paging=never
  ```

  The configuration-file path is available through `bat --config-file`. On Linux, it is stored in `~/.config/bat/config`.

- Added support for the `BAT_OPTS` environment variable, using the format specified above on a single line. This takes precedence over the configuration file.

  See also #310.

- Added support for custom syntax mappings through the `-m`/`--map-syntax` option.

  This allows users to map file extensions or filenames to an existing syntax:

  ```bash
  bat --map-syntax .config:json ...
  ```

  The option can be used multiple times. These mappings can be made permanent by adding them to `bat`'s new configuration file.

  See #169.

- Added support for pager command-line arguments in `PAGER` and `BAT_PAGER`, see #352 (@Foxboron)
- Added support for wildcards in Windows CMD, see #309 (@zxey)
- Added first-line syntax detection for all input types, see #205
- Added encoding support for UTF-16LE and UTF-16BE, see #285
- Added Robot Framework syntax (@sanga)

## Changes

- Binary files are now detected and not displayed when output goes to an interactive terminal, see #205

## Bugfixes

- Fixed JavaDoc comments that broke syntax highlighting in `.java` files, see #81
- Fixed a panic on Haskell source code, see #314

## Other

- Improved the `-h` and `--help` text
- Updated the documentation for configuring `bat`'s pager
- Updated the documentation for light backgrounds, see #328 (@russtaylor)
- Generate shell completions during the build, see #115 (@davideGiovannini)
- Added many new tests
- `bat` is now available through [Termux](https://termux.com/), see #341 (@fornwall)
- `bat` is now available through [Nix](https://nixos.org/nix), see #344 (@mgttlinger)
- `bat` is now available through [Docker](https://hub.docker.com/r/danlynn/bat/), see #331 (@danlynn)

# v0.7.1

## Features

- Use the `ansi_colours` package by @mina86 for better true-color approximation on 8-bit color terminals, see #319 and #202

## Bugfixes

- Fixed a panic on Haskell source code, see #314
- Disabled wrapping when `--style=plain`/`-p` is used, see #289

## Other

- Added Ansible installation instructions (@aeimer)
- Added a section about Cygwin to the README (@eth-p)

# v0.7.0

## Features

- Tabs can now optionally be expanded to spaces. This is controlled by the new `--tabs` command-line option or the `BAT_TABS` environment variable. This also fixes bugs #166 and #184. For more information, see #302 (@eth-p).
- Added support for the `BAT_STYLE` environment variable, see #208 (@ms2300)
- Added the `OneHalf` theme for terminals with light-gray backgrounds, see #256
- Added syntax for CSV, JSX in JavaScript and TypeScript, Cabal, Dart, F#, PureScript, Swift, Crystal, and PowerShell. Many thanks to @tobenna and @mimadrid.

## Changes

- Query `git diff` only when needed, see #303 (@ShikChen)
- Disabled wrapping when `--plain` is used, see #289 (@eth-p)

## Bugfixes

- Can now read files named `cache`, see #275 (@BK1603)
- Fixed many Windows bugs, see #252 and #264
- Detect `less` reliably and portably, see #271 and #290 (@Aankhen)
- Fixed formatting of the last decoration line with `--wrap never`, see #299 (@Rogach)
- Do not show file headers for directories, see #292

## Other

- Enabled a new `aarch64` build target, see #258 (@rachitchokshi)
- Provided Debian packages for `armhf`, see #280 (@rachitchokshi)
- Added a README section about "`bat` on Windows" (@Aankhen)
- Added Windows installation through Scoop (@meltinglava)

# v0.6.1

## Bugfixes

- Fixed a panic when running `bat --list-languages | head`, see #232 (@mchlrhw)
- Respected `--color` settings for `--list-themes` and `--list-languages`, see #233
- Git modifications now work on Windows

## Other

- Windows releases are now generated automatically, starting with this version (@anykao)

# v0.6.0

## Features

- The `--list-themes` option now shows a preview for each highlighting theme (@ms2300)
- Added `-p`/`--plain` as an alias for `--style=plain`, see #212 (@ms2300)
- Major refactoring enabled progress on #150. In non-interactive mode, `bat` now copies input bytes 1:1.
- Added Elm, Kotlin, Puppet, and TypeScript, see #215, #216, #217, and #218
- Added the Zenburn syntax-highlighting theme (@colindean)

## Changes

- New themes in `$BAT_CONFIG_DIR/themes` are now loaded in addition to the default themes and may override them, see #172
- The `Default.tmTheme` symlink is no longer necessary

## Bugfixes

- Fixed duplicated syntaxes caused by `bat cache --init`, see #206

## Other

- Extended and cleaned up the `--help` text
- Added the initial version of a man page, see #52
- Added *Development* and *Troubleshooting* sections to the README, see #220

# v0.5.0

## Features

- Added the `--line-range n:m` option to print a range of lines, see #159 (@tskinn)
- The syntax-highlighting theme can now be controlled with the `BAT_THEME` environment variable, see the [README](https://github.com/sharkdp/bat#highlighting-theme) and #177 (@mandx)
- The `PAGER` and `BAT_PAGER` environment variables can control the pager used by `bat`, see #158 and the [new README section](https://github.com/sharkdp/bat#using-a-different-pager)
- Added syntax highlighting for Nix, see #180
- Added syntax highlighting for AWK (@Gert Hulselmans)

## Changes

- Syntax-set and theme-set customization is now separate. Syntax definitions are loaded in addition to those stored in the `bat` binary by default. See the new README sections: [Adding new syntaxes](https://github.com/sharkdp/bat#adding-new-syntaxes--language-definitions) and [Adding new themes](https://github.com/sharkdp/bat#adding-new-themes), as well as #172.
- The filename color is now the default foreground color. Grid and line-number colors are now determined by the syntax-highlighting theme, which also works with light backgrounds, see #178.

## Bugfixes

- Fixed partial stripping of escape sequences, see #182 (@eth-p)
- Use a separate Git repository for snapshot testing, see #165 and #161
- Fixed Markdown breaking on JavaScript, see #183

## Other

- Binaries for armv7 are now provided, see #196
- `bat` is now in the official [Arch package repositories](https://www.archlinux.org/packages/community/x86_64/bat/)
- Optimized RGB-to-8-bit conversion (@mina86)

# v0.4.1

This is a small bugfix release; see v0.4.0 for all features and changes.

## Bugfixes

- Fixed a problem with `cargo test` when `bat` is not checked out in a Git repository, see #161

# v0.4.0

## Features

- Added support for line wrapping, see #54 and #102 (@eth-p)
- Added a new and updated `--style` parameter, see #74 and the README (@pitkley)
- Added `--theme` and `--list-themes` options, see #89 (@rleungx)
- Added syntax highlighting for Julia (@iamed2), Dockerfiles, VimL, CMake, INI, and Less
- Added several popular Sublime Text highlighting themes, see #133
- Added support for bold, italic, and underlined font styles, see #96
- Added support for 32-bit systems, see #84
- Added `-u` and `-n` options, see #134
- Added ANSI color support on Windows 10

## Changes

- Renamed the customization folder for user syntaxes from `syntax` to `syntaxes`, see the README
- Changed Markdown syntax to the default Sublime Text syntax, see #157
- Sorted the language listing (@rleungx)
- Command-line arguments such as `--theme` and `--color` can now override themselves
- Improved the `--help` text

## Bugfixes

- Fixed crashes with very small terminal sizes, see #117 (@eth-p)
- Fixed syntax detection for `.bashrc`, `CMakeLists.txt`, and similar files, see #100
- Properly handled lines with invalid UTF-8, see #7 (@BrainMaestro)
- Improved error handling, see #17 (@rleungx and @sharkdp)
- Properly handled UTF-8 characters in `less`, see #98 (@ghuls)
- Fixed the build on nightly, see #148 (@tathanhdinh)

## Other

- Added a [comparison with alternative projects](https://github.com/sharkdp/bat/blob/master/doc/alternatives.md)
- Added a new "bat" logo to the README, see #119 (@jraulhernandezi)
- Added output test cases (@BrainMaestro)
- Added extensive refactoring work (@BrainMaestro)

# v0.3.0

## Features

- Added automatic paging through integration with `less`, see #29 (@BrainMaestro)
- Added support for reading from standard input, see #2
- Added support for writing to non-interactive terminals, including pipes and files; added the `--color=auto/always/never` option, see #26 (@BrainMaestro)
- Added the `--list-languages` option to print all available syntaxes, see #69 (@connorkuehl)
- Added `-l`/`--language` to specify the syntax, see #19 (@BrainMaestro)
- Added `--style` to control the output style, see #5 (@nakulcg)
- Added syntax highlighting for TOML files, see #37

## Changes

- Removed the `init-cache` subcommand. The cache can now be controlled through `bat cache`. See `bat cache -h` for all available commands.

## Bugfixes

- Get the Git repository from the file path instead of the current directory, see #22 (@nakulcg)
- Process substitution can now be used with `bat` (`bat <(echo a) <(echo b)`), see #80

## Thanks

Thank you to all contributors and everyone who provided feedback.

Special thanks to @BrainMaestro for extensive support with new features, bug reports, and code reviews.

# v0.2.3

- Added a statically linked version of `bat` (`..-musl-..`)

# v0.2.2

- Removed the OpenSSL dependency completely, see #30

# v0.2.1

- Added Elixir syntax, see #25
- Use libcurl-openssl instead of libcurl-gnutls, see #30

# v0.2.0

- Added support for custom syntaxes and the "Markdown extended" theme
- Fixed a bug where Git modifications were not shown from a child folder

# v0.1.0

Initial release
