# etcd

etcd is a distributed key-value store for critical system data. It is implemented in Go and uses the Raft consensus algorithm to provide a highly available, replicated log. The source lists a gRPC API, automatic TLS with optional client-certificate authentication, distributed reliability, and a benchmark of 10,000 writes per second. The benchmark is a reported measurement from the source, not a universal performance guarantee.

Production users include Kubernetes, locksmith, vulcand, and Doorman. Reliability is supported by functional testing. `etcdctl` is the command-line client for interacting with etcd.

The master branch may be unstable or broken during development, so releases are recommended when stable binaries are required. Prebuilt releases are available for macOS, Linux, Windows, and Docker. Building the latest master in this snapshot requires Go 1.12 or later. Features and bug fixes first land on master, and fixes are then ported to release branches according to the branch-management guidance. Additional installation and operations guides are available through `play.etcd.io` and the `Documentation` directory.

## Installation and a single-member cluster

For a single-member cluster, run the downloaded `etcd` binary from its installation location:

```bash
/tmp/etcd-download-test/etcd
```

Alternatively, move the binary onto `PATH` and run it:

```bash
mv /tmp/etcd-download-test/etcd /usr/local/bin/
etcd
```

After building from source, start the binary with:

```bash
./bin/etcd
```

Client communication uses port `2379`, while peer communication uses port `2380`.

Once the member is running, use `etcdctl` to write and read a value:

```text
etcdctl put mykey "this is awesome"
etcdctl get mykey
```

These commands put the supplied value under `mykey` and then retrieve it.

## Local multi-member startup

The supplied Procfile example can be managed with `goreman`. Start the local arrangement with:

```bash
goreman start
```

This launches three members named `infra1`, `infra2`, and `infra3`, together with an etcd gRPC proxy. The members and the proxy accept key-value reads and writes.

## APIs, operations, and security

Follow-on documentation covers the full API, multi-machine clusters, flags, environment variables, configuration, integrations, TLS security, and tuning. These materials provide the additional information needed to work with etcd beyond the single-member and local-cluster startup procedures.

Contribution, bug-report, issue-triage, and pull-request-management guidance is provided in separate linked documents. Security issues may be reported publicly only when appropriate. Otherwise, discuss them with the maintainers first.

## Historical community information

The historical community section announced a resumption on January 10, 2019. At that time, meetings were scheduled every four weeks on Thursday at 11:00 AM US Pacific. Agendas were placed in a shared document one day before meetings, and suggestions were welcome. These details describe the historical schedule rather than a current meeting calendar.

The historical meeting connection information included Zoom details:

```text
One tap mobile
+14086380986,,916003437# US (San Jose)
+16465588665,,916003437# US (New York)

Dial by location
        +1 408 638 0986 US (San Jose)
        +1 646 558 8665 US (New York)

Meeting ID: 916 003 437
```

## Contact and contribution channels

Community contact channels include the `etcd-dev` mailing list, the historical freenode etcd IRC channel, GitHub milestones and roadmap information, and GitHub issues. The project’s contribution documentation describes how to report bugs, triage issues, and manage pull requests. Features and fixes should follow the project’s master and release-branch guidance.

Emeritus maintainers named in the source are Fanmin Shi and Anthony Romano. etcd uses the Apache 2.0 license.
