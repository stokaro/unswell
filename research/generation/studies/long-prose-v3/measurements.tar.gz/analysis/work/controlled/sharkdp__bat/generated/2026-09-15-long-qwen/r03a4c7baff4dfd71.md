# bat Documentation

## Overview and Core Functionality

bat is a cat clone with wings. It supports syntax highlighting, Git integration, and automatic paging. The tool displays files with syntax highlighting, Git-index modification markers, optional nonprinting-character display, and automatic paging. It also concatenates files. When output is redirected, plain file contents provide cat-like behavior. The tool supports standard-input detection via a shebang. The `-A/--show-all` flag highlights nonprinting characters. The `-l/--language` flag sets syntax explicitly.

The project aims for syntax highlighting, Git integration, POSIX-cat replacement, and a usable CLI. Maintainers are sharkdp and eth-p. The license choice is MIT or Apache 2.0, copyright bat-developers 2018–2020.

## Basic Usage

The basic invocation of bat is straightforward. To display a single file, use:

```bash
> bat README.md
```

To display multiple files, specify them as arguments:

```bash
> bat src/*.rs
```

bat can process standard input. For example, to pipe output from curl and highlight it:

```bash
> curl -s https://sh.rustup.rs | bat
```

It can also handle data conversion pipelines. For instance, to convert YAML to JSON and highlight the output:

```bash
> yaml2json .travis.yml | json_pp | bat -l json
```

To show nonprinting characters, use the `-A` flag:

```bash
> bat -A /etc/hosts
```

bat supports creating new files or concatenating existing ones. To create a new file quickly:

```bash
bat > note.md  # quickly create a new file
```

To concatenate files into a new document:

```bash
bat header.md content.md footer.md > document.md
```

To show line numbers only:

```bash
bat -n main.rs  # show line numbers (only)
```

bat can output specific files, then stdin, then other files:

```bash
bat f - g  # output 'f', then stdin, then 'g'.
```

## Integrations

bat integrates with various command-line tools.

### Find and fd

bat can be used with `find` to process files:

```bash
find … -exec bat {} +
```

It works with `fd` using the `-X` flag:

```bash
fd … -X bat
```

### ripgrep

batgrep provides integration with ripgrep results:

```bash
batgrep needle src/
```

### Log Files

For live log monitoring, disable paging and specify the log syntax:

```bash
tail -f /var/log/pacman.log | bat --paging=never -l log
```

### Git

bat can display historical file contents from git:

```bash
git show v0.6.0:src/main.rs | bat -l rs
```

### Clipboard

To copy file contents to the clipboard without gutters, pipe to xclip:

```bash
bat main.cpp | xclip
```

### Man Pages

bat can color manual pages. Set the MANPAGER environment variable:

```bash
export MANPAGER="sh -c 'col -bx | bat -l man -p'"
```

Then use man normally:

```bash
man 2 select
```

Note that batman wraps this use, but Mandoc's man implementation is unsupported.

### Diff Highlighting

Diff highlighting is unsupported in bat. Use delta instead.

### Formatters

prettybat combines formatters such as prettier/shfmt/rustfmt with bat.

## Installation

### Ubuntu and Debian

Install bat via apt:

```bash
apt install bat
```

On Debian-family packages, the executable may be named `batcat` due to a clash. Create a symlink or alias to restore `bat`:

```bash
mkdir -p ~/.local/bin
ln -s /usr/bin/batcat ~/.local/bin/bat
```

### Downloaded Archives

Install from downloaded .deb archives:

```bash
sudo dpkg -i bat_0.16.0_amd64.deb  # adapt version number and architecture
```

### Alpine Linux

Install bat via apk:

```bash
apk add bat
```

### Arch Linux

Install bat via pacman:

```bash
pacman -S bat
```

### Fedora Modular

Install bat via dnf:

```bash
dnf install bat
```

### Gentoo

Install bat via emerge:

```bash
emerge sys-apps/bat
```

### Void Linux

Install bat via xbps-install:

```bash
xbps-install -S bat
```

### FreeBSD

Install bat via pkg:

```bash
pkg install bat
```

Or build from ports:

```bash
cd /usr/ports/textproc/bat
make install
```

### Nix

Install bat via nix-env:

```bash
nix-env -i bat
```

### openSUSE

Install bat via zypper:

```bash
zypper install bat
```

### macOS

Install bat via Homebrew:

```bash
brew install bat
```

Or via MacPorts:

```bash
port install bat
```

### Windows

Install bat via Chocolatey:

```bash
choco install bat
```

Or via Scoop:

```bash
scoop install bat
```

Windows requires Visual C++ Redistributable.

### Source Build

Build bat from source using Cargo:

```bash
cargo install --locked bat
```

Source builds require Rust 1.40+. Cargo builds generate man/completion files in the target build directory but do not install them automatically.

Development commands and every installation example accompany these notes.

## Configuration and Customization

### Themes

List available themes:

```bash
bat --list-themes | fzf --preview="bat --theme={} --color=always /path/to/file"
```

Select a theme with `--theme` or `BAT_THEME`. Examples include TwoDark, GitHub, and OneHalfLight. Dark backgrounds are the default assumption.

Themes include:
- ansi-dark/ansi-light: use basic three-bit colors.
- base16: use four-bit colors following base16 styling.
- base16-256: maps some bright colors into slots 16–21 for base16-shell. base16-256 is not a generic choice for every 256-color terminal.

Restricted themes track terminal palette changes and blend with other terminal software. OneHalfDark/OneHalfLight have brighter grid/line colors.

### Syntax and Language Definitions

syntect reads Sublime .sublime-syntax files and themes. Place custom definitions/themes in the documented config directories, build the binary cache, verify with `--list-languages`/`--list-themes`, and clear the cache to return to defaults.

To add a custom syntax:

```bash
mkdir -p "$(bat --config-dir)/syntaxes"
cd "$(bat --config-dir)/syntaxes"

# Put new '.sublime-syntax' language definition files
# in this folder (or its subdirectories), for example:
git clone https://github.com/tellnobody1/sublime-purescript-syntax
```

Then build the cache:

```bash
bat cache --build
```

To clear the cache:

```bash
bat cache --clear
```

To add a custom theme:

```bash
mkdir -p "$(bat --config-dir)/themes"
cd "$(bat --config-dir)/themes"

# Download a theme in '.tmTheme' format, for example:
git clone https://github.com/greggb/sublime-snazzy

# Update the binary cache
bat cache --build
```

### Style Options

`--style` selects output elements. For example, `numbers,changes` shows line numbers and Git changes without grid/header. `BAT_STYLE` or configuration makes this persistent.

Example configuration options:

```bash
# Set the theme to "TwoDark"
--theme="TwoDark"

# Show line numbers, Git modifications and file header (but no grid)
--style="numbers,changes,header"

# Use italic text on the terminal (not supported on all terminals)
--italic-text=always

# Use C++ syntax for .ino files
--map-syntax "*.ino:C++"

# Use ".gitignore"-style highlighting for ".ignore" files
--map-syntax ".ignore:Git Ignore"
```

### Pager Configuration

Pager precedence is BAT_PAGER over PAGER, with less as fallback; `--pager` is another configuration route. With less and no explicit arguments, bat supplies `-R` for ANSI colors and `-F` to quit for one screen. It adds `-X` only for less older than 530 to work around a quit-if-one-screen issue, at the cost of mouse-wheel support. Selecting only `-R` on those older versions restores wheel use but disables the automatic short-output quit.

To set a custom pager:

```bash
export BAT_PAGER="less -RF"
```

bat expands tabs to four spaces before paging; `--tabs` changes the width, and `--tabs=0` passes tabs through to the pager. Pager tab-stop settings cannot affect already expanded spaces.

### Configuration File

`--config-file` prints the platform-dependent config path. `BAT_CONFIG_PATH` selects another file; `--generate-config-file` creates defaults. The format is a list of CLI arguments with #-prefixed comments.

To view the config file path:

```
bat --config-file
```

To set a custom config path:

```bash
export BAT_CONFIG_PATH="/path/to/bat.conf"
```

To generate a default config file:

```bash
bat --generate-config-file
```

### macOS Integration

The supplied macOS snippet selects default or GitHub according to the OS dark/light appearance:

```bash
alias cat="bat --theme=\$(defaults read -globalDomain AppleInterfaceStyle &> /dev/null && echo default || echo GitHub)"
```

## Platform Limits and Workarounds

### Windows

Windows `more` is limited; install less and put it on PATH or configure the pager. Chocolatey installs less automatically. Windows 10 version 1511+ supports colors in Command Prompt/PowerShell, as do newer Bash versions; older Windows can use Cmder/ConEmu. Git/MSYS less may misinterpret colors. `--paging=never` or empty BAT_PAGER disables paging.

Native bat cannot interpret Cygwin `/cygdrive` paths; the supplied wrapper converts them:

```bash
bat() {
    local index
    local args=("$@")
    for index in $(seq 0 ${#args[@]}) ; do
        case "${args[index]}" in
        -*) continue;;
        *)  [ -e "${args[index]}" ] && args[index]="$(cygpath --windows "${args[index]}")";;
        esac
    done
    command bat "${args[@]}"
}
```

### Color Support

Truecolor terminals should expose COLORTERM=truecolor or 24bit; otherwise bat falls back to eight-bit colors. Use restricted themes when appropriate.

### Encoding

UTF-8 and UTF-16 are native; convert other encodings with iconv and specify syntax if detection fails:

```bash
iconv -f ISO-8859-1 -t UTF-8 my-file.php | bat
```

### Release Archives

Release archives include many architectures and MUSL static builds.

### Development Build

To build a bat binary with modified syntaxes and themes:

```bash
bash assets/create.sh
cargo install --locked --force
```

To build a debug version:

```bash
cd bat
cargo build --bins
```

To run tests:

```bash
cargo test
```

To install the release version:

```bash
cargo install --locked
```

To clone the repository recursively:

```bash
git clone --recursive https://github.com/sharkdp/bat
```
