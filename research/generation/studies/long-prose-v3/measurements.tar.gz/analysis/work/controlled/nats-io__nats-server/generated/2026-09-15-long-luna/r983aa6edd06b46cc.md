# Roadmap [DRAFT]

This is the roadmap for the NATS Server. Its purpose is to provide insight into major features we plan to implement in the near future. It is a living document and will change as goals and milestones are completed and new plans are created.

This project's release plan is maintained on [the wiki](https://github.com/nats-io/gnatsd/wiki).

A master release plan for all NATS projects can be found
[here](https://github.com/nats-io/roadmap/wiki).

### Planning and Tracking

An [Open-Source Planning Process](https://github.com/nats-io/gnatsd/wiki/Open-Source-Planning-Process) is used to define the roadmap.

This project is managed through GitHub [milestones](https://github.com/nats-io/gnatsd/milestones).
[Project Pages](https://github.com/nats-io/gnatsd/wiki) define the goals for each milestone and identify current progress.

Upcoming features and bug fixes will be added to the relevant milestone. One or more milestones will then be assigned to a release. If a feature or bug fix is not part of a milestone, it is currently unscheduled for implementation.

### Short Term

#### "Hot" configuration reload

We will enable changes to a subset of configuration items on a running `gnatsd` without requiring the instance to be restarted.

See [Issue #338](https://github.com/nats-io/gnatsd/issues/338).

#### Integrate Prometheus support

We have recently done some work to export NATS monitoring data through Prometheus. We plan to share this work in an upcoming release.

See [Issue #345](https://github.com/nats-io/gnatsd/issues/345).

### Further Out

#### Enable external authentication and authorization through an extensible auth provider

We will improve and extend the auth interfaces and configuration to support external auth endpoints.

See [Issue #434](https://github.com/nats-io/gnatsd/issues/434).

#### Namespace isolation by account/organization

Multi-tenancy is a popular discussion topic, and one requirement we often hear is the ability to isolate or encapsulate the subject namespace by "tenant" (for example, an account or organization). For example, messages published on `FOO.BAR` by tenant A would not be visible to tenant B's subscribers on `FOO.BAR`, and vice versa. We would like to support this efficiently and with good performance.

See [Issue #347](https://github.com/nats-io/gnatsd/issues/347) and [Issue #348](https://github.com/nats-io/gnatsd/issues/348).

#### Rate limiting

Another multi-tenancy concern is the ability to limit the rate at which publishers can publish messages to `gnatsd`. We have implemented this in a branch for an internal project but would like to make it public soon.

See [Issue #346](https://github.com/nats-io/gnatsd/issues/346).

#### Make auto-unsubscribe atomic in the SUB protocol

Currently, auto-unsubscribe requires two operations: `SUB foo 1`, followed by `UNSUB foo 1 1` (unsubscribe after one message). For simplicity, efficiency, and usability, we would like to make this an atomic protocol operation, optionally specifying the limit as part of the subscription, such as `SUB foo 1 1`.

See [Issue #344](https://github.com/nats-io/gnatsd/issues/344).

#### Rename `gnatsd` to `nats-server`

The original Ruby-based NATS server, now retired, was called `nats-server`, and the newer Go version needed a unique name, hence `gnatsd`. We have recently attempted to normalize names across all NATS projects to make them more predictable. Renaming `gnatsd` to `nats-server` would align it more closely with the other components in the NATS family.

See [Issue #226](https://github.com/nats-io/gnatsd/issues/226).

#### Client pruning/rebalancing

Now that cluster auto-discovery is implemented for both clients and servers, NATS clusters can be expanded dynamically as needed. When this happens, it would be useful to optionally rebalance client connections across the new, larger cluster.

See [Issue #343](https://github.com/nats-io/gnatsd/issues/343).
