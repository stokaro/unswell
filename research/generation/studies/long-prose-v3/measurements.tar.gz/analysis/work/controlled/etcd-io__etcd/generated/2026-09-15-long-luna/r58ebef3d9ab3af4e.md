# etcd

etcd is a distributed key-value store for critical system data. It is implemented in Go and uses the Raft consensus algorithm to provide a highly available, replicated log. The source lists a gRPC API, automatic TLS with optional client-certificate authentication, distributed reliability, and a reported benchmark of 10,000 writes per second. The benchmark is a measurement reported by the source, not a universal performance guarantee.

etcd is used in production by Kubernetes, locksmith, vulcand, and Doorman. Functional testing supports its reliability. `etcdctl` is the command-line client for interacting with an etcd cluster.

## Releases and installation

Prebuilt releases are available for macOS, Linux, Windows, and Docker. For stable binaries, use a release. The master branch can be unstable or broken during development.

To build the latest master in this snapshot, use Go 1.12 or later. Features and bug fixes first land on master. Fixes are then ported to release branches according to the project's branch-management guidance. Additional installation and operations guides are available through `play.etcd.io` and the `Documentation` directory.

After downloading a release, run the etcd binary from its installation location:

```bash
/tmp/etcd-download-test/etcd
```

Alternatively, move the binary onto `PATH` and run it:

```bash
mv /tmp/etcd-download-test/etcd /usr/local/bin/
etcd
```

After building from source, start the binary with:

```bash
./bin/etcd
```

A single-member cluster uses port `2379` for client communication and port `2380` for peer communication.

Use `etcdctl` to write and read a value:

```text
etcdctl put mykey "this is awesome"
etcdctl get mykey
```

## Local multi-member startup

`goreman` manages the supplied Procfile example. Start the local cluster with:

```bash
goreman start
```

This command launches three members named `infra1`, `infra2`, and `infra3`, together with an etcd gRPC proxy. The members and the proxy accept key-value reads and writes.

## APIs, operations, and security

Follow-on documentation covers the full API, multi-machine clusters, flags, environment variables, configuration, integrations, TLS security, and tuning. These documents provide the operational and integration details needed beyond a single-member or local-cluster setup.

Contribution, bug-report, issue-triage, and pull-request-management procedures are documented separately. Security issues may be reported publicly when appropriate. Otherwise, discuss them with the MAINTAINERS first.

## Historical community information

The historical community section announced that community activity would resume on January 10, 2019. It described meetings every four weeks on Thursday at 11:00 AM US Pacific. Agendas were placed in a shared document one day before each meeting, and suggestions were welcome. These details describe that historical announcement and should not be interpreted as a current meeting schedule.

The historical meeting connection information included the following Zoom details:

```text
One tap mobile
+14086380986,,916003437# US (San Jose)
+16465588665,,916003437# US (New York)

Dial by location
        +1 408 638 0986 US (San Jose)
        +1 646 558 8665 US (New York)

Meeting ID: 916 003 437
```

## Contribution and contact channels

Community contact channels include `etcd-dev`, the historical freenode etcd IRC channel, GitHub milestones and roadmap information, and GitHub issues. Contribution guidance is provided through the separate documentation, including procedures for reporting bugs, triaging issues, and managing pull requests.

The source names Fanmin Shi and Anthony Romano as emeritus maintainers. The project uses the Apache 2.0 license.
