# Ripgrep Technical Documentation

## Documentation and Configuration

Ripgrep's configuration and encoding behavior are documented in GUIDE.md, with changes tracked in CHANGELOG.md. The project relies on volunteer maintenance and publishes updates on a best-effort basis without guaranteed release dates. Serious regressions may motivate a patch release, but no specific timeline is promised for such releases.

Man page generation requires asciidoctor or asciidoc to be installed. The build system generates the man page from the argument parser, placing the output under the target's build directory. For example, a typical build output path resembles:

```
./target/debug/build/ripgrep-79899d0edd4129ca/out/rg.1
```

Binary releases include the generated man page. For quick reference without accessing the man page, `rg --help` displays complete option details, while `rg -h` condenses each flag to a single line for brevity.

## Shell Completion Support

Ripgrep distributions include shell completions for multiple shells. Setup varies by shell:

- **Zsh**: The completion file `_rg` is separately maintained and comprehensive. Installation places it in the zsh `fpath`.
- **Bash**: The completion file `rg.bash` should be placed in `$XDG_CONFIG_HOME/bash_completion` or `/etc/bash_completion.d` for automatic loading.
- **Fish**: The completion file `rg.fish` goes in `~/.config/fish/completions/`.
- **PowerShell**: The completion file `_rg.ps1` must be dot-sourced in the PowerShell profile. If the file is not on PATH, the full path must be specified in the profile.

## Core Search Capabilities

### Parallel Search and Result Ordering

Ripgrep performs parallel searches across multiple files and directories for improved performance on large codebases. However, parallel execution produces nondeterministic result ordering. To achieve consistent, reproducible ordering, use the `--sort path` flag, which enforces sorted output by file path. This flag disables parallelism as a side effect. For smaller repositories, the performance impact of disabling parallelism may be negligible.

### Compressed File Handling

The `-z` or `--search-zip` flag enables searching within compressed files. Ripgrep decompresses files through external decompressor processes, supporting gzip, bzip2, xz, lzma, lz4, Brotli, and Zstd formats. Note that `-z` handles gzip-compressed individual files, not archive formats such as tar.gz files.

### Multiline Search

The `-U` or `--multiline` flag allows patterns to match results spanning multiple lines. This feature has implications for memory usage and performance, discussed in detail in the performance section.

## Regex Engine Selection

### Default Regex Engine

Ripgrep uses a default regex engine based on finite-state automata, which guarantees linear worst-case time complexity for matching. This engine does not support backreferences or lookahead/lookbehind assertions. The trade-off enables predictable performance on all inputs.

The default engine can prevent matches from crossing newlines at the syntax level, enabling incremental line-by-line processing without scanning entire files. When analyzing regex syntax, the default engine removes newline characters from character classes such as `\s` and rejects explicit unsupported newline literals with an error:

```
$ rg '\n'
the literal '"\n"' is not allowed in a regex
```

This design allows searching buffers efficiently without requiring line-by-line iteration.

### PCRE2 Support

The `-P` or `--pcre2` flag selects the optional PCRE2 regex engine, which is a backtracking engine supporting advanced regex features including backreferences and lookahead/lookbehind. PCRE2 is not available in all builds. Most project release binaries include PCRE2 support, but package-manager builds may vary. Users should consult their package maintainer if PCRE2 is not available.

Example attempting PCRE2 usage on a build without support:

```
$ rg -P '(\w{10})\1'
PCRE2 is not available in this build of ripgrep
```

When PCRE2 is available, backreferences function as expected:

```
$ rg -P '(\w{10})\1'
tests/misc.rs
483:    cmd.arg("--max-filesize").arg("44444444444444444444");
globset/src/glob.rs
1206:    matches!(match7, "a*a*a*a*a*a*a*a*a", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
```

### Regex Compilation Limits

Large compiled regexes can exceed size limits even when the source pattern is concise. For example, a Unicode letter class repeated 1,000 times produces:

```
$ rg '\pL{1000}'
Compiled regex exceeds size limit of 10485760 bytes.
```

The `--regex-size-limit` flag increases the approximate compilation allowance. For instance:

```
$ rg '\pL{1000}' --regex-size-limit 1G
```

Note that specifying a limit such as 1 GB does not automatically allocate 1 GB of memory; the limit sets an upper bound for acceptance.

Multiple patterns via `-f` or `--file` are matched as a union. Many patterns may exhaust the default regex engine's fast cache and trigger a slower fallback engine. The `--dfa-size-limit` flag raises the cache allowance:

```
--dfa-size-limit 1G
```

As with `--regex-size-limit`, this sets an allowance without automatic full allocation.

## Color Configuration

### Color Output Control

The `--color` flag determines when colored output appears. Valid options are:

- `never`: No colors
- `auto`: Colors for terminals only (default)
- `always`: Force colors
- `ansi`: ANSI color codes

### Custom Color Schemes

The `--colors` flag configures colors for specific output elements. The format is:

```
--colors '{type}:{attribute}:{value}'
```

Types include `path`, `line`, `column`, and `match`. Attributes are `fg` (foreground), `bg` (background), and `style`.

Style values include:
- `bold` and `nobold`
- `intense` and `nointense`
- `underline` and `nounderline`

Color values accept eight standard color names (such as `white`, `yellow`, `green`, `black`), decimal or hexadecimal indices from 0 to 255, or comma-separated RGB triples.

The special value `type:none` resets styling for that element. For example, resetting match colors before applying new ones:

```
$ rg somepattern --colors 'match:none' --colors 'match:fg:0x33,0x66,0xFF'
```

Building a complete color scheme with multiple attributes:

```
$ rg somepattern \
    --colors 'match:none' \
    --colors 'match:bg:0x33,0x66,0xFF' \
    --colors 'match:fg:white' \
    --colors 'match:style:bold'
```

RGB triple example with hexadecimal values:

```
$ rg somepattern --colors 'match:fg:0x33,0x66,0xFF'
```

A Silver Searcher-like color scheme can be constructed with:

```
rg --colors line:fg:yellow      \
   --colors line:style:bold     \
   --colors path:fg:green       \
   --colors path:style:bold     \
   --colors match:fg:black      \
   --colors match:bg:yellow     \
   --colors match:style:nobold  \
   foo
```

### Configuration File

The `RIPGREP_CONFIG_PATH` environment variable activates a configuration file containing command-line flags, one per line. For example:

```
$ cat $HOME/.config/ripgrep/rc
--colors=line:fg:yellow
--colors=line:style:bold
--colors=path:fg:green
--colors=path:style:bold
--colors=match:fg:black
--colors=match:bg:yellow
--colors=match:style:nobold

$ RIPGREP_CONFIG_PATH=$HOME/.config/ripgrep/rc rg foo
```

## Windows-Specific Behavior

### Terminal Support and Truecolor

Windows terminal environments differ significantly in color support. Cygwin may support truecolor directly. Ordinary pre-Windows 10 consoles have no known working route to truecolor output. Windows 10 and later support VT100 escape sequences for advanced colors.

On Windows 10, if bold text interferes with truecolor VT100 escape sequences, clear the default match styling first using `--colors 'match:none'`.

### Restoring Console Colors

After interrupted output leaves colors in an unexpected state, the `cmd` command's `color` builtin or a Unix reset escape can restore default colors. PowerShell users can use a helper function and alias:

```powershell
$OrigFgColor = $Host.UI.RawUI.ForegroundColor
function Reset-ForegroundColor {
	$Host.UI.RawUI.ForegroundColor = $OrigFgColor
}
Set-Alias -Name color -Value Reset-ForegroundColor
```

After calling this function, the alias `color` restores the original foreground color.

### Output Encoding

PowerShell's `$OutputEncoding` variable controls the byte encoding for data piped to native processes. The documented default is US-ASCII, which converts unsupported characters to question marks. To use UTF-8:

```powershell
$OutputEncoding = [System.Text.UTF8Encoding]::new()
```

Place this setting in the PowerShell profile for persistence across sessions. Additionally, the `Console.OutputEncoding` property can be set to UTF-8 separately for display purposes.

### PowerShell Wrapper Functions

When wrapping ripgrep in a PowerShell function, arguments must be properly propagated, and input piping requires conditional logic. Piping an empty input object causes ripgrep to search empty stdin. The correct pattern detects whether input exists before piping:

```powershell
function grep {
    $count = @($input).Count
    $input.Reset()

    if ($count) {
        $input | rg.exe --hidden $args
    }
    else {
        rg.exe --hidden $args
    }
}
```

## Performance Characteristics

### Regex Engine Performance

The default regex engine and PCRE2 have different performance profiles. A performance experiment using a large file with pattern `^\w{42}$` demonstrates the difference:

```
$ time rg '^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.783s
user    0m1.731s
sys     0m0.051s

$ time rg -P '^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m2.458s
user    0m2.419s
sys     0m0.038s
```

The default engine is faster for this pattern due to its automata-based approach, while PCRE2's backtracking exhibits slower performance.

### Trace Output Analysis

The `--trace` flag distinguishes between fast and slow search strategies. Trace output for the default engine shows fast line search:

```
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:622: Some("subtitles2016-sample"): searching via memory map
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:712: slice reader: searching via slice-by-line strategy
TRACE|grep_searcher::searcher::core|grep-searcher/src/searcher/core.rs:61: searcher core: will use fast line searcher
```

PCRE2 with the same pattern triggers transcoding and slower search:

```
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:622: Some("subtitles2016-sample"): searching via memory map
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:705: slice reader: needs transcoding, using generic reader
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:685: generic reader: searching via roll buffer strategy
TRACE|grep_searcher::searcher::core|grep-searcher/src/searcher/core.rs:63: searcher core: will use slow line searcher
```

Possible performance differences include SIMD optimizations in UTF-8 validation via the encoding_rs library, though this is an author-noted explanation rather than a universal PCRE2 limitation.

## Encoding and Unicode Handling

### UTF-8 Conversion with PCRE2

PCRE2 requires valid UTF-8 input. The default regex engine can search arbitrary bytes, accepting invalid byte sequences only for patterns that do not use Unicode features. Ripgrep normally transcodes invalid UTF-8 to replacement characters before PCRE2 search, disabling redundant PCRE2 validation checks. Passing invalid data directly to PCRE2 produces errors and stops the file's search:

```
$ cat invalid-utf8
foobar

$ xxd invalid-utf8
00000000: 666f 6fff 6261 720a                      foo.bar.

$ rg foo invalid-utf8
1:foobar

$ rg -P foo invalid-utf8
1:foo�bar

$ rg -P foo invalid-utf8 --no-encoding
invalid-utf8: PCRE2: error matching: UTF-8 error: illegal byte (0xfe or 0xff)
```

The `--no-encoding` flag skips ripgrep's UTF-8 conversion but re-enables PCRE2 validation, which can be slower and expose invalid-UTF-8 errors:

```
$ time rg -P '^\w{42}$' subtitles2016-sample --no-encoding
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m3.074s
user    0m3.021s
sys     0m0.051s
```

### Unicode Mode in PCRE2

PCRE2's Unicode mode requires valid UTF-8. When using PCRE2 with multiline search (`-U`), the performance degrades significantly due to line-by-line searching requirements:

```
$ time rg -P -U '^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m2.962s
user    0m2.246s
sys     0m0.713s
```

Disabling Unicode semantics with `(?-u)` in the default engine or `--no-pcre2-unicode` with PCRE2 avoids transcoding when Unicode semantics are unnecessary:

```
$ time rg '(?-u)^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.714s
user    0m1.669s
sys     0m0.044s

$ time rg -P '^\w{42}$' subtitles2016-sample --no-pcre2-unicode
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.997s
user    0m1.958s
sys     0m0.037s
```

### Multiline Search with Unicode Optimization

Multiline search without Unicode mode allows memory mapping and JIT speed when cross-line restrictions and Unicode semantics are unnecessary:

```
$ time rg -U '(?-u)^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.714s
user    0m1.655s
sys     0m0.058s

$ time rg -P -U '^\w{42}$' subtitles2016-sample --no-pcre2-unicode
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.121s
user    0m1.071s
sys     0m0.048s
```

Disabling Unicode mode may miss non-ASCII word characters, so this optimization should only be used when such behavior is acceptable. The source code acknowledges that other APIs and designs could exhibit different performance characteristics.

## Multiline Search Memory Requirements

Multiline search requires the entire file to be held in memory because a match can be arbitrarily long and span any number of lines. Memory mapping normally supplies the file content, but UTF-8 conversion requires allocating and copying to heap memory.

The default regex engine can recognize patterns that cannot cross lines and maintain its fast incremental strategy even with `-U` enabled, avoiding unnecessary memory overhead. With PCRE2, combining `-U` and `--no-pcre2-unicode` allows memory mapping and JIT optimization when Unicode semantics and cross-line restrictions are not required.

## Troubleshooting Unexpected Behavior

### Conflicting Commands or Aliases

Unexpected ripgrep behavior may originate from another executable or alias on the system. Notably, the Oh My Zsh framework includes a Rails plugin that maps `rg` to `rails generate`. Inspect the actual command with `which rg`.

Resolution options include:

- Disabling the conflicting plugin
- Invoking with `command rg`, escaping the command (`\rg`), or quoting it (`'rg'`)
- Using the full executable path
- Removing the alias with `unalias rg`
- Creating a distinct ripgrep alias

## File Modification

Ripgrep never directly edits files. Instead, it can list matching file paths for use with other tools. The standard approach uses `--files-with-matches` to output matching paths:

```
rg foo --files-with-matches
```

Paths can then be piped to sed for substitution. GNU sed uses `-i` with no backup requirement:

```
rg foo --files-with-matches | xargs sed -i 's/foo/bar/g'
```

BSD sed requires a backup extension argument, with an empty string disabling backups:

```
rg foo --files-with-matches | xargs sed -i '' 's/foo/bar/g'
```

When file paths contain whitespace, NUL-delimited ripgrep output with xargs requires the `-0` flag:

```
rg foo --files-with-matches -0 | xargs -0 sed -i 's/foo/bar/g'
```

An alternative tool for similar workflows is fastmod, which shares some underlying libraries with ripgrep.

## Licensing

Users may choose between the MIT License and the Unlicense. The project author favors the Unlicense's copyright-disclaimer approach while acknowledging the Unlicense's unfamiliarity in some communities and offering MIT terms for broader adoption.

All direct and transitive dependencies must remain permissively licensed. GPL, LGPL, MPL, and Creative Commons ShareAlike licenses are excluded, even when described as weak copyleft. This ensures ripgrep remains freely usable without license propagation requirements.

## Comparison with Grep

Ripgrep can replace many grep use cases, particularly recursive code search with ignore file support, UTF-16 content, and parallel large-directory searches. However, ripgrep is not a complete behavior-compatible replacement for grep and does not comply with POSIX standards. It is also less ubiquitous than grep, making it less suitable for portable shell scripts.

GNU grep with filters, wrappers, or parallel xargs invocation may be sufficient for some tasks. Missing required features remain a valid reason to use alternative tools. Notably, ripgrep's Unicode behavior is locale-independent and does not depend on locale environment settings.

## Project History

The project underwent several name iterations. The initial name was "rep," followed by "xrep." Names "rustgrep" and "rgrep" were considered before settling on "rip." The name was chosen to suggest fast searching while retaining the "r" association with Rust. The "RIP" interpretation suggesting a "grep killer" was noticed only after release and was not the original intent.

The project author declines donations to maintain a personally sustainable volunteer relationship with the project. Those wishing to contribute financially are encouraged to support the Internet Archive, Rails Girls, or Wikipedia instead.
