# Contributing to Svelte

Svelte is a new way to build web applications. It is a compiler that takes declarative components and converts them into efficient JavaScript that surgically updates the DOM.

The [Open Source Guides](https://opensource.guide/) website provides resources for individuals, communities, and companies. These resources help people learn how to run and contribute to open source projects. Contributors and people who are new to open source may find these guides especially useful:

* [How to Contribute to Open Source](https://opensource.guide/how-to-contribute/)
* [Building Welcoming Communities](https://opensource.guide/building-community/)

## Get involved

There are many ways to contribute to Svelte, and many do not involve writing code. Here are a few ideas:

- Start using Svelte. Follow the [Getting Started](https://svelte.dev/blog/the-easiest-way-to-get-started) guide. Does everything work as expected? If not, we are always looking for improvements. Let us know by [opening an issue](#reporting-new-issues).
- Review the [open issues](https://github.com/sveltejs/svelte/issues). Provide workarounds, ask for clarification, or suggest labels. Help [triage issues](#triaging-issues-and-pull-requests).
- If you find an issue you would like to fix, [open a pull request](#your-first-pull-request).
- Read through our [tutorials](https://svelte.dev/tutorial/basics). If anything is confusing or could be improved, edit it by clicking “Edit this chapter” at the bottom left of the tutorial page.
- Review the [features requested](https://github.com/sveltejs/svelte/labels/enhancement) by the community. If you see something you want to work on, consider opening a pull request.

Contributions are very welcome. If you need help planning your contribution, contact us on Discord at [svelte.dev/chat](https://svelte.dev/chat) and let us know that you are looking for help.

### Triaging issues and pull requests

Helping triage issues and pull requests is a useful way to contribute without writing code.

- Ask for more information when an issue does not include all the details needed to solve it.
- Suggest [labels](https://github.com/sveltejs/svelte/labels) that help categorize issues.
- Flag issues that are stale or should be closed.
- Ask for test plans and review code.

## Bugs

We use [GitHub issues](https://github.com/sveltejs/svelte/issues) for public bug reports. Before reporting a problem, check whether someone has already opened an issue for it. If you are certain that the bug has not been reported, submit a [bug report](#reporting-new-issues).

If you have questions about using Svelte, contact us on Discord at [svelte.dev/chat](https://svelte.dev/chat). We will do our best to answer your questions.

If you would like something to be implemented, create a [feature request issue](https://github.com/sveltejs/svelte/issues/new?template=feature_request.md).

## Reporting new issues

When [opening a new issue](https://github.com/sveltejs/svelte/issues/new/choose), always complete the issue template. **This step is very important.** If you do not complete the template, your issue may not be managed promptly. Do not take this personally if that happens. You can open a new issue after gathering all the information required by the template.

- **One issue, one bug:** Report only one bug per issue.
- **Provide reproduction steps:** List every step needed to reproduce the issue. The reader should be able to follow the steps with minimal effort. If possible, use the [REPL](https://svelte.dev/repl) to create your reproduction.

## RFCs

To propose an implementation for a large new feature or change, [create an RFC](https://github.com/sveltejs/rfcs) to discuss it in advance.

## Installation

1. Ensure that [npm](https://www.npmjs.com/get-npm) is installed.
1. After cloning the repository, run `npm install` in its root.
1. Start a development server with `npm run dev`.

## Pull requests

### Your first pull request

If you decide to contribute code by opening a pull request, we appreciate the time you have invested. We will do our best to work with you and review the PR.

If you are working on your first pull request, learn how from this free video series:

[**How to Contribute to an Open Source Project on GitHub**](https://egghead.io/courses/how-to-contribute-to-an-open-source-project-on-github)

### Proposing a change

If you want to request a new feature or enhancement but are not ready to open a pull request, file an issue using the [feature template](https://github.com/sveltejs/svelte/issues/new?template=feature_request.md).

If you are fixing only a bug, you may submit a pull request immediately, but we still recommend filing an issue that describes what you are fixing. This helps us track the issue if we do not accept that specific fix.

### Sending a pull request

Small pull requests are easier to review and more likely to be merged. Each PR should do only one thing; if it does more, split it into separate pull requests.

Before submitting a pull request, make sure that:

1. You forked [the repository](https://github.com/sveltejs/svelte) and created your branch from `master`.
1. You described your **test plan** in the pull request description and tested your changes.
1. Your code passes linting (`npm run lint`).
1. Your tests pass (`npm run test`).

Open all pull requests against the `master` branch.

#### Test plan

A good test plan includes the exact commands you ran and their output. If the pull request changes the UI, include screenshots or videos.

- If you changed APIs, update the documentation.

#### Writing tests

All tests are located in the `/test` folder.

Test samples are kept in the `/test/xxx/samples` folder.

#### Running tests

1. Run the tests with `npm run test`.
1. To test a specific feature, use the `-g` (also called `--grep`) option. For example, to run only tests involving transitions, run `npm run test -- -g transition`.

##### Running a single test

1. To run only one test, rename its sample folder so that it ends with `.solo`. For example, to run only `test/js/samples/action`, rename it to `test/js/samples/action.solo`.
1. To run only one test suite, rename its suite folder so that it ends with `.solo`. For example, to run only the `test/js` suite, rename it to `test/js.solo`.
1. Rename the test folder back afterward. CI will fail if a solo test remains.

##### Updating `.expected` files

1. Test suites such as `css`, `js`, and `server-side-rendering` assert that generated output matches the content of an `.expected` file. For example, the `js` test suites compare generated JavaScript with `expected.js`.
1. To update an `.expected` file, run the test with the `--update` flag: `npm run test --update`.

#### Breaking changes

When adding a breaking change, use this template in your pull request:

```md
### New breaking change here

- **Who does this affect**:
- **How to migrate**:
- **Why make this breaking change**:
- **Severity (number of people affected x effort)**:
```

### What happens next?

The core Svelte team will monitor pull requests. Help us review yours by following these guidelines and making the pull request easy to understand.

## Style guide

[Eslint](https://eslint.org) catches most styling issues in your code. Check your code’s styling by running `npm run lint`.

### Code conventions

- Use `snake_case` for internal variable names and methods.
- Use `camelCase` for public variable names and methods.

## License

By contributing to Svelte, you agree that your contributions will be licensed under its [MIT license](https://github.com/sveltejs/svelte/blob/master/LICENSE).
