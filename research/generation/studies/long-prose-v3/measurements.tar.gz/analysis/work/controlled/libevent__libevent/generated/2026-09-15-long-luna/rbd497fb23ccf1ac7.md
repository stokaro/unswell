# Libevent Build, Installation, Resources, and Acknowledgments

## Autoconf

Autoconf is the mature, supported build environment in this snapshot. For a standard build, run `configure` and then `make`:

```sh
$ ./configure
$ make
```

After building, `make verify` can optionally run the regression tests:

```sh
$ make verify   # (optional)
```

Run the regression tests before reporting problems. To install the built files, use `make install` as root:

```sh
$ sudo make install
```

For a Git checkout, first run `autogen.sh` to generate the `configure` script, then configure and build the source:

```sh
$ ./configure && make
```

The installation root can be selected with `--prefix`. All installed files are placed relative to that directory. Use `--disable-shared` to build only static libraries:

```text
--disable-shared          Only build static libraries.
--prefix                  Install all files relative to this directory.
```

Additional configuration options include:

```text
--enable-gcc-warnings     Enable extra compiler checking with GCC.
--disable-malloc-replacement
                          Don't let applications replace our memory
                          management functions.
--disable-openssl         Disable support for OpenSSL encryption.
--disable-thread-support  Don't support multithreaded environments.
```

To enable low-level tracing, set `CFLAGS=-DUSE_DEBUG` while configuring:

```sh
$ CFLAGS=-DUSE_DEBUG ./configure [...]
```

## CMake

CMake supports Windows and Unix builds. In this snapshot, the CMake workflow is new and experimental. Autoconf remains the mature supported build environment.

CMake uses out-of-source builds, allowing multiple configurations to be created from one source tree. The CMake GUI can be used to choose the source directory and the output directory. On Unix, the default generator is Unix Makefiles:

```sh
$ mkdir build && cd build
$ cmake ..     # Default to Unix Makefiles.
$ make
$ make verify  # (optional)
```

On Windows, install CMake, create a build directory, select a Visual Studio generator, and open the generated solution. The command-line workflow is:

```sh
$ cd <libevent source dir>
$ mkdir build && cd build
$ cmake -G "Visual Studio 10" ..   # Or whatever generator you want to use cmake --help for a list.
$ start libevent.sln
```

The same workflow can be written as:

```sh
$ md build && cd build
$ cmake -G "Visual Studio 10" ..   # Or whatever generator you want to use cmake --help for a list.
$ start libevent.sln
```

NMake Makefiles provide another command-line build option. Use `cmake --help` to list available generators. To list available CMake settings, use:

```sh
$ cmake -LH ..
```

The expanded form `cmake -LAH <sourcedir_path>` also lists available settings.

## CMake Project Options

The supplied CMake-variable block records project options and their default values:

```text
# Type of the library to build (SHARED or STATIC)
# Default is: SHARED for MSVC, otherwise BOTH
EVENT__LIBRARY_TYPE:STRING=DEFAULT

# Installation directory for CMake files
EVENT_INSTALL_CMAKE_DIR:PATH=lib/cmake/libevent

# Enable running gcov to get a test coverage report (only works with
# GCC/CLang). Make sure to enable -DCMAKE_BUILD_TYPE=Debug as well.
EVENT__COVERAGE:BOOL=OFF

EVENT__DISABLE_BENCHMARK:BOOL=OFF
EVENT__DISABLE_DEBUG_MODE:BOOL=OFF
EVENT__DISABLE_MM_REPLACEMENT:BOOL=OFF
EVENT__DISABLE_OPENSSL:BOOL=OFF
EVENT__DISABLE_REGRESS:BOOL=OFF
EVENT__DISABLE_SAMPLES:BOOL=OFF
EVENT__DISABLE_TESTS:BOOL=OFF
EVENT__DISABLE_THREAD_SUPPORT:BOOL=OFF
EVENT__ENABLE_VERBOSE_DEBUG:BOOL=OFF
EVENT__FORCE_KQUEUE_CHECK:BOOL=OFF
```

The `EVENT__COVERAGE` option enables running gcov to produce a test coverage report and works only with GCC or CLang. It should be used with `-DCMAKE_BUILD_TYPE=Debug`. The disable options control benchmark executables, debug mode, mm-function replacement, OpenSSL encryption, regression tests, sample files, tests, and thread support.

When cross compiling, `EVENT__FORCE_KQUEUE_CHECK` forces a test program to verify that Kqueue works with pipes. The test program must be run manually on the cross-compilation target. The option refers to the CMake documentation for `try_run` for further details.

## Community Resources

Release information is available at `libevent.org`. Nick Mathewson's work-in-progress libevent book is another resource. The GitHub repository provides the source, pull requests, and issues:

```sh
$ git clone https://github.com/libevent/libevent.git
```

The libevent-users mailing-list archives are available at `archives.seul.org/libevent/users`. Git patches and reports may also be sent to the mailing list.

## Acknowledgments

The project credits the supplied acknowledgment roster for suggestions, ideas, code, and bug fixes. The roster includes Samy Al Bahra, Antony Antony, Jacob Appelbaum, William Ahern, Sergey Avseyev, Avi Bab, Joachim Bauch, Andrey Belobrov, Gilad Benjamini, Stas Bekman, Denis Bilenko, Kevin Bowling, Adrian Chadd, Shuo Chen, Andrew Cox, Frank Denis, Mike Frysinger, Remi Gacogne, Artur Grabowski, Diwaker Gupta, Nicholas Heath, Dave Hart, Greg Hazel, Michael Herf, Andrew Hochhaus, Aaron Hopkins, Evan Jones, George Kadianakis, Marko Kreen, Scott Lamb, Adam Langley, Graham Leggett, David Libenzi, Nick Mathewson, Nicholas Marriott, Felix Nawothnig, Linus Nordberg, Richard Nyberg, Jon Oberheide, Dave Pacheco, Patrick Pelletier, Dan Petro, Nate Rosenblum, Gyepi Sam, Dug Song, Hannes Sowa, Jason Toffaleti, Brian Utterback, Zack Weinberg, and many other named and pseudonymous contributors in the supplied roster.

If we have forgotten your name, please contact us.
