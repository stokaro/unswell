# Historical Visual C++ Build Procedure for curl and libcurl

This documentation outlines the historical build procedures and configuration options for compiling curl and libcurl using the Microsoft Visual C++ compiler. The instructions provided are based on legacy build systems and are intended for developers maintaining older codebases or specific Windows environments.

## Prerequisites and Environment Setup

Building curl requires the Microsoft Visual C++ compiler. Visual C++ version 6 is the minimum documented version, although newer versions are recommended for stability and feature support. Visual C++ is available through the Windows Platform SDK; therefore, installing the full Microsoft Visual Studio product is not strictly required solely for building curl. The source distribution includes links to the Windows SDK archive for reference.

Before compiling, ensure that optional dependencies such as zlib, OpenSSL, c-ares, and libSSH2 are available. These dependencies must be downloaded separately. The build system expects a specific directory structure where a `deps` directory is placed as a sibling to the `curl-src` directory. This `deps` directory should contain `lib`, `include`, and `bin` subdirectories. A parent directory may be shared between the source and dependencies. The `WITH_DEVEL` option allows specifying an alternative location for these dependencies.

If working with a Git checkout, it is mandatory to run `buildconf.bat` from the source root directory before proceeding. This script generates necessary build files. If using a released source archive, this preparation step is not required as the files are pre-generated.

To begin the build process, open a Visual Studio developer command prompt. The default target architecture in this environment is x86. If a different machine type is required, invoke `Vcvarsall.bat` with the appropriate parameters for the intended architecture. Some Visual Studio releases provide named command prompts for specific versions, platforms, or native/cross-compilation modes. The availability of these named prompts varies by Visual Studio version. For detailed instructions on setting up the command-line environment, refer to Microsoft's official documentation.

## Build Execution

Navigate to the `curl-src\winbuild` directory. Execute the build using the `nmake` utility with the `Makefile.vc` file. The command structure is as follows:

```cmd
nmake /f Makefile.vc mode=<static or dll> <options>
```

The `mode` parameter determines whether to build a static library (`static`) or a dynamic link library (`dll`). The resulting binaries and libraries are output to the `builds` directory located at the source root. Within this directory, outputs are organized into subdirectories named according to the specific build configuration.

## Configuration Options

The build system supports numerous options to customize the compilation process. These options control dependency linking, installation paths, and feature flags.

### Dependency Management

Dependencies such as SSL, HTTP/2, mbedTLS, c-ares, zlib, and SSH2 can be enabled with either dynamic linking (`dll`) or static linking (`static`). The following options control these dependencies:

*   `WITH_SSL=<dll/static>`: Enables OpenSSL support.
*   `WITH_NGHTTP2=<dll/static>`: Enables HTTP/2 support.
*   `WITH_MBEDTLS=<dll/static>`: Enables mbedTLS support.
*   `WITH_CARES=<dll/static>`: Enables c-ares support.
*   `WITH_ZLIB=<dll/static>`: Enables zlib support.
*   `WITH_SSH2=<dll/static>`: Enables libSSH2 support.

The `WITH_DEVEL` option specifies the path to development files for SSL, zlib, and other libraries. By default, this points to the sibling `deps` directory (`../deps`). Dependency archives can be fetched from https://windows.php.net/downloads/php-sdk/deps/. These archives must be uncompressed into the designated `deps` folder.

Custom paths for specific dependencies can be set using the following variables:
*   `CARES_PATH=<path>`: Custom path for c-ares.
*   `MBEDTLS_PATH=<path>`: Custom path for mbedTLS.
*   `NGHTTP2_PATH=<path>`: Custom path for nghttp2.
*   `SSH2_PATH=<path>`: Custom path for libSSH2.
*   `SSL_PATH=<path>`: Custom path for OpenSSL.
*   `ZLIB_PATH=<path>`: Custom path for zlib.

The `WITH_PREFIX` option determines the installation location for the build output.

### Feature Flags and Defaults

The following options control specific features and defaults:

*   `VC=<6,7,8,9,10,11,12,14,15>`: Specifies the Visual C++ version.
*   `ENABLE_SSPI=<yes/no>`: Enables SSPI support. Defaults to `yes`.
*   `ENABLE_IPV6=<yes/no>`: Enables IPv6 support. Defaults to `yes`.
*   `ENABLE_IDN=<yes/no>`: Enables Windows IDN APIs. Defaults to `yes`. This requires Windows Vista or later.
*   `ENABLE_SCHANNEL=<yes/no>`: Enables native Windows SSL support. Defaults to `yes` if SSPI is enabled and no other SSL library is selected.
*   `ENABLE_OPENSSL_AUTO_LOAD_CONFIG=<yes/no>`: Enables automatic loading of OpenSSL configuration. Defaults to `yes`.
*   `ENABLE_UNICODE=<yes/no>`: Enables UNICODE support. Defaults to `no`.
*   `GEN_PDB=<yes/no>`: Controls the generation of Program Database files for release builds.
*   `DEBUG=<yes/no>`: Enables debug builds.
*   `MACHINE=<x86/x64>`: Sets the target architecture. The default is `x86`.

## Runtime Considerations and Linking

By default, the build links the static libcurl library but does not request the static Microsoft C runtime. The standard C runtime is provided as a DLL. To force the use of the static C runtime, use the option `RTLIBCFG=static`. This option is rarely used and rarely tested. If you change `RTLIBCFG` for an already-built configuration, you must remove the configuration's build directory and rebuild from scratch to avoid conflicts.

Applications linking against static libcurl on Windows must define the `CURL_STATICLIB` preprocessor macro. Without this definition, the linker will search for dynamic import symbols, leading to link errors.

The default native SSL backend is Schannel, accessed via Windows SSPI. Note that on Windows XP or earlier systems, Schannel cannot connect to servers that reject legacy handshakes or algorithms associated with those older systems. Users targeting compatibility with Windows XP or earlier should select an alternative SSL backend, such as OpenSSL.
