# fzf Vim Integration

fzf’s Vim integration provides an API for launching the finder, applying global preferences, controlling its layout, and defining custom commands. The integration uses an fzf executable available on `PATH`. If no executable is available, the plugin asks for permission to download one. An optional `fzf#install()` update hook keeps the binary current.

## Installation and runtimepath

After installing fzf, add its directory to Vim’s runtimepath. The location depends on the package manager. For example, with Homebrew or a git installation:

```vim
" If installed using Homebrew
set rtp+=/usr/local/opt/fzf

" If installed using git
set rtp+=~/.fzf
```

vim-plug can use an already installed package:

```vim
" If installed using Homebrew
Plug '/usr/local/opt/fzf'

" If installed using git
Plug '~/.fzf'
```

Alternatively, vim-plug can fetch the newest plugin from GitHub:

```vim
Plug 'junegunn/fzf'
```

Add the update hook if the fzf binary should be kept current:

```vim
Plug 'junegunn/fzf', { 'do': { -> fzf#install() } }
```

## Basic file selection

`:FZF [options] [path]` is a basic file selector built on the fzf Vim APIs. Without a path, it looks for files under the current directory. A path can point to another directory, and command-line fzf options can be supplied:

```vim
" Look for files under current directory
:FZF

" Look for files under your home directory
:FZF ~

" With fzf command-line options
:FZF --reverse --info=inline /tmp

" Bang version starts fzf in fullscreen mode
:FZF!
```

The `fzf.vim` integration provides additional commands. In Vim, `Enter`, `Ctrl-T`, `Ctrl-X`, and `Ctrl-V` open selections in the current window, a tab, a horizontal split, and a vertical split, respectively. These opening actions can be changed globally with `g:fzf_action`.

`FZF_DEFAULT_COMMAND` and `FZF_DEFAULT_OPTS` also apply in Vim. When a run specification does not define a source, fzf uses `find` or `FZF_DEFAULT_COMMAND` to supply paths from the current directory.

## Global settings

`g:fzf_action` maps keys to actions for opening selected files or processing selections:

```vim
" This is the default extra key bindings
let g:fzf_action = {
  \ 'ctrl-t': 'tab split',
  \ 'ctrl-x': 'split',
  \ 'ctrl-v': 'vsplit' }
```

An action can reference a function. The function receives selected lines and can process them as needed:

```vim
function! s:build_quickfix_list(lines)
  call setqflist(map(copy(a:lines), '{ "filename": v:val }'))
  copen
  cc
endfunction

let g:fzf_action = {
  \ 'ctrl-q': function('s:build_quickfix_list'),
  \ 'ctrl-t': 'tab split',
  \ 'ctrl-x': 'split',
  \ 'ctrl-v': 'vsplit' }
```

`g:fzf_layout` controls window placement. A popup window can be configured with dimensions:

```vim
let g:fzf_layout = { 'window': { 'width': 0.9, 'height': 0.6 } }
```

The finder can instead open down, up, left, or right:

```vim
let g:fzf_layout = { 'down': '40%' }
```

A Vim command can define the window:

```vim
let g:fzf_layout = { 'window': 'enew' }
let g:fzf_layout = { 'window': '-tabnew' }
let g:fzf_layout = { 'window': '10new' }
```

`g:fzf_colors` maps fzf elements to a color component and an ordered list of Vim highlight groups. `fzf#wrap()` translates the definition into `--color` options:

```vim
let g:fzf_colors =
\ { 'fg':      ['fg', 'Normal'],
  \ 'bg':      ['bg', 'Normal'],
  \ 'hl':      ['fg', 'Comment'],
  \ 'fg+':     ['fg', 'CursorLine', 'CursorColumn', 'Normal'],
  \ 'bg+':     ['bg', 'CursorLine', 'CursorColumn'],
  \ 'hl+':     ['fg', 'Statement'],
  \ 'info':    ['fg', 'PreProc'],
  \ 'border':  ['fg', 'Ignore'],
  \ 'prompt':  ['fg', 'Conditional'],
  \ 'pointer': ['fg', 'Exception'],
  \ 'marker':  ['fg', 'Keyword'],
  \ 'spinner': ['fg', 'Label'],
  \ 'header':  ['fg', 'Comment'] }
```

Highlight groups are tried in order. If a group lacks a color, the next group is used as a fallback:

```vim
  'prompt':  ['fg', 'Conditional', 'Comment'],
```

The supported elements are:

| Element | Description |
| --- | --- |
| `fg` / `bg` / `hl` | Item foreground, background, and highlight |
| `fg+` / `bg+` / `hl+` | Current item foreground, background, and highlight |
| `hl` / `hl+` | Highlighted substrings, normal and current |
| `gutter` | Background of the gutter on the left |
| `pointer` | Pointer to the current line (`>`) |
| `marker` | Multi-select marker (`>`) |
| `border` | Border around the window, including `--border` and `--preview` |
| `header` | Header from `--header` or `--header-lines` |
| `info` | Info line containing match counters |
| `spinner` | Streaming input indicator |
| `prompt` | Prompt before the query (`> `) |

`g:fzf_history_dir` enables per-command query history:

```vim
let g:fzf_history_dir = '~/.local/share/fzf-history'
```

When configured, history files are stored in the specified directory. `Ctrl-N` and `Ctrl-P` are then bound to `next-history` and `previous-history` instead of `down` and `up`.

## Running fzf programmatically

`fzf#run(spec)` launches the finder. `fzf#wrap([name], [spec], [fullscreen])` returns a run specification extended with global preferences:

```vim
:echo fzf#wrap()
call fzf#run({'sink': 'e'})
call fzf#run({'sink': 'tabedit'})
call fzf#run({'source': 'git ls-files', 'sink': 'e'})
call fzf#run({'sink': 'tabedit', 'options': '--multi --reverse'})
```

A run specification may define a shell command or a Vim list as its source. The sink can be a Vim command, such as `e` or `tabedit`, or a function reference that processes each selected item. `sink*` is a function reference that receives all output lines together.

`options` accepts either a string or a list. A list avoids escaping issues:

```vim
call fzf#run({'options': '--reverse --prompt "C:\\Program Files\\"'})
call fzf#run({'options': ['--reverse', '--prompt', 'C:\Program Files\']})
```

`dir` sets the working directory. Layout fields include `up`, `down`, `left`, and `right`, each accepting a number or a string such as `20` or `50%`. `tmux` supplies fzf-tmux options. `window` can be a Vim command or a popup dictionary:

```vim
call fzf#run({'source': 'git ls-files', 'sink': 'e', 'left': '40%'})
call fzf#run({'source': 'git ls-files', 'sink': 'e', 'window': '30vnew'})
```

A Vim list can supply generated input:

```vim
call fzf#run({'source': map(split(globpath(&rtp, 'colors/*.vim')),
            \               'fnamemodify(v:val, ":t:r")'),
            \ 'sink': 'colo', 'left': '25%'})
```

## Layouts and popup windows

For Vim 8 and Neovim, `window` can be a command or a dictionary of popup settings. Popup width is a fraction from `0` to `1`, or an integer of at least `8`. Height is a fraction from `0` to `1`, or an integer of at least `4`. `xoffset` and `yoffset` default to `0.5`.

The border highlight defaults to `Comment`. The default border style is `rounded`. Supported alternatives are `sharp`, `horizontal`, `vertical`, `top`, `bottom`, `left`, `right`, and `none`:

```vim
let g:fzf_layout = { 'window': { 'width': 0.9, 'height': 0.6 } }
```

fzf can use a tmux popup when tmux is available. This requires tmux 3.2 or newer:

```vim
if exists('$TMUX')
  let g:fzf_layout = { 'tmux': '-p90%,60%' }
else
  let g:fzf_layout = { 'window': { 'width': 0.9, 'height': 0.6 } }
endif
```

fzf uses a terminal buffer on Neovim, GVim, and terminal Vim when the layout is not the default. The terminal buffer has the `fzf` filetype, so a `FileType` autocmd can customize it. For example, the status line can be hidden temporarily for nonpopup layouts:

```vim
if has('nvim') && !exists('g:fzf_layout')
  autocmd! FileType fzf
  autocmd  FileType fzf set laststatus=0 noshowmode noruler
    \| autocmd BufLeave <buffer> set laststatus=2 showmode ruler
endif
```

## Wrapping specifications and custom commands

The arguments to `fzf#wrap()` are optional. With no arguments, it returns a wrapped specification:

```vim
echo fzf#wrap()
echo fzf#wrap({'source': 'ls'})
call fzf#run(fzf#wrap({'source': 'ls'}))
```

The optional name identifies command history when `g:fzf_history_dir` is configured. The name is ignored when that setting is not defined. The optional fullscreen argument accepts `0` or `1`; it defaults to `0`. Wrapped specifications inherit global layout, colors, history, and opening actions.

`g:fzf_action` applies only when there is no custom `sink` or `sink*`. Arbitrary entries require their own handling.

A simple custom command is:

```vim
command! LS call fzf#run(fzf#wrap({'source': 'ls'}))
```

Use `-bang` to make fullscreen controlled by `!`:

```vim
" On :LS!, <bang> evaluates to '!', and '!0' becomes 1
command! -bang LS call fzf#run(fzf#wrap({'source': 'ls'}, <bang>0))
```

Add directory completion and pass the command argument as `dir`:

```vim
command! -bang -complete=dir -nargs=* LS
    \ call fzf#run(fzf#wrap({'source': 'ls', 'dir': <q-args>}, <bang>0))
```

Finally, provide a unique history name:

```vim
" The query history for this command will be stored as 'ls' inside g:fzf_history_dir.
" The name is ignored if g:fzf_history_dir is not defined.
command! -bang -complete=dir -nargs=* LS
    \ call fzf#run(fzf#wrap('ls', {'source': 'ls', 'dir': <q-args>}, <bang>0))
```

This pattern combines a source command, an optional working directory, bang-controlled fullscreen mode, inherited global preferences, and per-command history.
