# Mermaid Documentation

Mermaid is a powerful JavaScript diagramming tool that enables developers to create diagrams and charts using Markdown-inspired textual definitions. By allowing users to edit source text and include it directly in scripts, Mermaid helps keep diagrams aligned with development workflows. The tool offers integrations with various editors, wikis, and other applications. Additionally, the Mermaid Live Editor permits diagram creation without any programming knowledge. Introductory resources, including tutorials, a beginner overview, usage guides, integrations, syntax documentation, and getting-started materials, are available to assist new users.

## Supported Diagram Types

Mermaid supports a wide variety of diagram types to visualize different aspects of software architecture and processes. Standard supported examples include flowcharts, sequence diagrams, Gantt charts, class diagrams, and user journeys. Git graphs and entity-relationship diagrams are currently labeled as experimental features.

### Flowcharts
Flowcharts allow for the visualization of processes and decision trees. A simple flowchart definition might look like this:

```
graph TD;
    A-->B;
    A-->C;
    B-->D;
    C-->D;
```

### Sequence Diagrams
Sequence diagrams illustrate interactions between objects in a specific sequence. They are essential for understanding message passing and timing.

```
sequenceDiagram
    participant Alice
    participant Bob
    Alice->>John: Hello John, how are you?
    loop Healthcheck
        John->>John: Fight against hypochondria
    end
    Note right of John: Rational thoughts <br/>prevail!
    John-->>Alice: Great!
    John->>Bob: How about you?
    Bob-->>John: Jolly good!
```

### Gantt Charts
Gantt charts are used for project management to schedule tasks over time.

```
gantt
dateFormat  YYYY-MM-DD
title Adding GANTT diagram to mermaid
excludes weekdays 2014-01-10

section A section
Completed task            :done,    des1, 2014-01-06,2014-01-08
Active task               :active,  des2, 2014-01-09, 3d
Future task               :         des3, after des2, 5d
Future task2               :         des4, after des3, 5d
```

### Class Diagrams
Class diagrams represent the static structure of a system, showing classes, interfaces, and their relationships.

```
classDiagram
Class01 <|-- AveryLongClass : Cool
Class03 *-- Class04
Class05 o-- Class06
Class07 .. Class08
Class09 --> C2 : Where am i?
Class09 --* C3
Class09 --|> Class07
Class07 : equals()
Class07 : Object[] elementData
Class01 : size()
Class01 : int chimp
Class01 : int gorilla
Class08 <--> C2: Cool label
```

### Experimental Diagrams
Git graphs visualize git commit history, while entity-relationship diagrams model data structures.

```
gitGraph:
options
{
    "nodeSpacing": 150,
    "nodeRadius": 10
}
end
commit
branch newbranch
checkout newbranch
commit
commit
checkout master
commit
commit
merge newbranch
```

```
erDiagram
    CUSTOMER ||--o{ ORDER : places
    ORDER ||--|{ LINE-ITEM : contains
    CUSTOMER }|..|{ DELIVERY-ADDRESS : uses
```

### User Journeys
User journeys map out the steps a user takes to achieve a goal.

```markdown
journey
    title My working day
    section Go to work
      Make tea: 5: Me
      Go upstairs: 3: Me
      Do work: 1: Me, Cat
    section Go home
      Go downstairs: 5: Me
      Sit down: 5: Me
```

## Browser Integration

The Mermaid library is available via the CDN at unpkg.com/mermaid. The current page points to version 8.8.0, but a specific version can be selected in the URL using the format `https://unpkg.com/mermaid@<version>/dist/`.

For browser installation, Mermaid's JavaScript is added to the page. Without a bundler, rendering is activated by including an absolute script URL and an initialization call. The parser reads diagram definitions contained in `div` elements with the class `mermaid` and renders them as SVG charts.

Example integration:
```html
<script src="https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js"></script>
<script>mermaid.initialize({startOnLoad:true});</script>
```

## Contributor Commands and Procedures

Knut Sveidqvist created Mermaid. The project credits d3 and dagre-d3 for layout and drawing, js-sequence-diagram for the sequence grammar, and Jessica Peter for the Gantt starting point. Tyler Long provides maintenance help, with support from other contributors.

Mermaid won the 2019 JavaScript Open Source Award for The most exciting use of technology. Sibling projects include the Mermaid Live Editor, Mermaid CLI, Mermaid Webpack Demo, and Mermaid Parcel Demo. The maintainer is requesting a core team to help add diagram types and improve existing ones. Team members receive repository write access and represent the project when responding to questions and issues.

### Development Workflow

To contribute, developers must follow specific procedures:

1.  **Environment Setup**: You will need to install Node.js version 10 or 12, which includes npm.
2.  **Dependency Installation**: Install Yarn using npm.
    ```bash
    npm install -g yarn
    ```
3.  **Project Dependencies**: Enter the following command to install project dependencies:
    ```bash
    yarn install
    ```
4.  **Building**: To build the project, use:
    ```bash
    yarn build:watch
    ```
5.  **Linting**: Linting is performed with ESLint. Editor ESLint integration reports results while editing. To run linting manually:
    ```bash
    yarn lint
    ```
6.  **Testing**: Run tests using:
    ```bash
    yarn test
    ```
7.  **Manual Check**: A manual browser check can be performed by opening `dist/index.html`.

### Release Process

Authorized release maintainers are responsible for updates. To release, maintainers must update the version in `package.json` and then run the release command. This process generates the `dist` folder and publishes the package to npmjs.org.

```bash
npm publish
```
