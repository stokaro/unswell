# fzf Documentation

## Overview

fzf is an interactive command-line filter for arbitrary text lists. It processes candidates from standard input and writes selected items to standard output, making it suitable for filtering paths, history, processes, hosts, bookmarks, and commits. fzf is dependency-free and available under the MIT license, copyright Junegunn Choi 2013–2020.

The fzf project includes multiple components: the core executable, fzf-tmux for tmux integration, shell bindings for Bash, Zsh, and Fish, fuzzy completion support for Bash and Zsh, and integration with Vim and Neovim. The executable can be installed independently if other components are not needed.

## Installation

fzf can be installed through several methods depending on your platform and preference.

### Homebrew and Linuxbrew

On macOS and Linux systems with Homebrew or Linuxbrew installed:

```sh
brew install fzf

# To install useful key bindings and fuzzy completion:
$(brew --prefix)/opt/fzf/install
```

### Git Clone

Clone the repository directly and run the install script:

```sh
git clone --depth 1 https://github.com/junegunn/fzf.git ~/.fzf
~/.fzf/install
```

### Linux and BSD Package Managers

fzf is available in the official repositories of most Linux distributions and some BSD systems:

| Package Manager | Linux Distribution      | Command                            |
| ---             | ---                     | ---                                |
| APK             | Alpine Linux            | `sudo apk add fzf`                 |
| APT             | Debian 9+/Ubuntu 19.10+ | `sudo apt-get install fzf`         |
| Conda           |                         | `conda install -c conda-forge fzf` |
| DNF             | Fedora                  | `sudo dnf install fzf`             |
| Nix             | NixOS, etc.             | `nix-env -iA nixpkgs.fzf`          |
| Pacman          | Arch Linux              | `sudo pacman -S fzf`               |
| pkg             | FreeBSD                 | `pkg install fzf`                  |
| pkg_add         | OpenBSD                 | `pkg_add fzf`                      |
| XBPS            | Void Linux              | `sudo xbps-install -S fzf`         |
| Zypper          | openSUSE                | `sudo zypper install fzf`          |

Package installation through distribution repositories may leave bindings and completion disabled. Consult your package manager's instructions for enabling these features.

### Windows

On Windows, fzf can be installed using binary packages, Chocolatey, or Scoop:

| Package manager | Command             |
| ---             | ---                 |
| Chocolatey      | `choco install fzf` |
| Scoop           | `scoop install fzf` |

### Vim and Neovim Integration

vim-plug users can add fzf as a plugin. The optional update hook can run fzf#install:

```vim
Plug 'junegunn/fzf', { 'do': { -> fzf#install() } }
```

For source builds, consult BUILD.md in the fzf repository.

## Interactive Search Basics

The finder reads candidates from standard input and writes selected items to standard output. When invoked without a pipe, fzf runs the find command and excludes hidden files by default. The FZF_DEFAULT_COMMAND environment variable replaces this default command when input is a terminal.

The FZF_DEFAULT_OPTS environment variable supplies default options for all fzf invocations.

### Navigation and Selection

Users navigate the list with the following keys:

- Ctrl-J or Ctrl-N: move down
- Ctrl-K or Ctrl-P: move up
- Enter: accept the selection
- Ctrl-C, Ctrl-G, or Escape: exit without selection

In multi-selection mode (enabled with -m), Tab and Shift-Tab mark and unmark items. fzf also supports mouse selection and scrolling, as well as Emacs key bindings.

### Layout Options

The default layout displays fzf fullscreen and builds the list bottom-up. The --height option starts the finder below the cursor instead of taking the full screen:

```sh
fzf --height 40%
```

The --reverse flag inverts the search direction, displaying results in top-to-bottom order. The --layout option provides additional control over the presentation:

```sh
vim $(fzf --height 40% --reverse)
```

Configure defaults globally using FZF_DEFAULT_OPTS:

```sh
export FZF_DEFAULT_OPTS='--height 40% --layout=reverse --border'
```

### Query Syntax

Extended queries combine space-separated terms to match candidates precisely. Supported token types include:

| Token     | Match type                 | Description                          |
| --------- | -------------------------- | ------------------------------------ |
| `sbtrkt`  | fuzzy-match                | Items that match `sbtrkt`            |
| `'wild`   | exact-match (quoted)       | Items that include `wild`            |
| `^music`  | prefix-exact-match         | Items that start with `music`        |
| `.mp3$`   | suffix-exact-match         | Items that end with `.mp3`           |
| `!fire`   | inverse-exact-match        | Items that do not include `fire`     |
| `!^music` | inverse-prefix-exact-match | Items that do not start with `music` |
| `!.mp3$`  | inverse-suffix-exact-match | Items that do not end with `.mp3`    |

A standalone pipe (|) acts as an OR operator. For example:

```
^core go$ | rb$ | py$
```

The --exact or -e flag makes all terms exact by default. When --exact is enabled, the quote prefix reverses that behavior, allowing fuzzy matching within an exact-match context.

## Shell Integration

fzf provides shell bindings for Bash, Zsh, and Fish that integrate seamlessly with common command-line workflows.

### Key Bindings

The shell integration defines three main key bindings:

**Ctrl-T**: Inserts selected file paths into the command line. By default, fzf invokes find to list files in the current directory and subdirectories.

**Ctrl-R**: Inserts history entries. Pressing Ctrl-R again toggles between relevance and chronological sorting.

**Alt-C**: Changes to a selected directory.

Customize these behaviors with environment variables:

- FZF_CTRL_T_COMMAND: Command to generate file candidates
- FZF_CTRL_T_OPTS: Options for the Ctrl-T finder
- FZF_CTRL_R_OPTS: Options for the Ctrl-R finder
- FZF_ALT_C_COMMAND: Command to generate directory candidates
- FZF_ALT_C_OPTS: Options for the Alt-C finder
- FZF_TMUX_OPTS: Options for fzf-tmux behavior

### fzf-tmux

fzf-tmux opens a new pane or popup window within tmux. Outside of tmux, fzf-tmux ignores its pane-placement flags and runs normally. The syntax follows the pattern:

```sh
# usage: fzf-tmux [LAYOUT OPTIONS] [--] [FZF OPTIONS]
```

Layout options control the size and position of the tmux window. For example:

```sh
# See available options
fzf-tmux --help

# select git branches in horizontal split below (15 lines)
git branch | fzf-tmux -d 15

# select multiple words in vertical split on the left (20% of screen width)
cat /usr/share/dict/words | fzf-tmux -l 20% --multi --reverse
```

## Completion

fzf provides fuzzy completion for file paths, commands, and other completion contexts in Bash and Zsh.

### Path Completion

Path completion uses the trigger ** followed by Tab:

```sh
# Files under current directory
# - You can select multiple items with TAB key
vim **<TAB>

# Files under parent directory
vim ../**<TAB>

# Files under parent directory that match `fzf`
vim ../fzf**<TAB>

# Files under your home directory
vim ~/**<TAB>

# Directories under current directory (single-selection)
cd **<TAB>

# Directories under ~/github that match `fzf`
cd ~/github/fzf**<TAB>
```

### Process Completion

The kill command uses Tab for process completion without a special trigger:

```sh
# Can select multiple processes with <TAB> or <Shift-TAB> keys
kill -9 <TAB>
```

### Host Completion

SSH and telnet host completion reads from /etc/hosts and ~/.ssh/config:

```sh
ssh **<TAB>
telnet **<TAB>
```

### Environment and Alias Completion

fzf completion extends to environment variables and aliases:

```sh
unset **<TAB>
export **<TAB>
unalias **<TAB>
```

### Customizing Completion

Modify completion behavior with environment variables:

```sh
# Use ~~ as the trigger sequence instead of the default **
export FZF_COMPLETION_TRIGGER='~~'

# Options to fzf command
export FZF_COMPLETION_OPTS='+c -x'

# Use fd instead of the default find command for listing path candidates
_fzf_compgen_path() {
  fd --hidden --follow --exclude ".git" . "$1"
}

# Use fd to generate the list for directory completion
_fzf_compgen_dir() {
  fd --type d --hidden --follow --exclude ".git" . "$1"
}
```

The experimental completion API provides advanced customization via the _fzf_comprun function:

```sh
# (EXPERIMENTAL) Advanced customization of fzf options via _fzf_comprun function
_fzf_comprun() {
  local command=$1
  shift

  case "$command" in
    cd)           fzf "$@" --preview 'tree -C {} | head -200' ;;
    export|unset) fzf "$@" --preview "eval 'echo \$'{}" ;;
    ssh)          fzf "$@" --preview 'dig {}' ;;
    *)            fzf "$@" ;;
  esac
}
```

The _fzf_setup_completion function extends completion to additional commands:

```sh
# usage: _fzf_setup_completion path|dir|var|alias|host COMMANDS...
_fzf_setup_completion path ag git kubectl
_fzf_setup_completion dir tree
```

### Custom Completion

Define custom completion by implementing the _fzf_complete_COMMAND function. Before the -- separator, pass fzf options; after it, preserve original completion arguments. Use process substitution to supply candidates:

```sh
# Custom fuzzy completion for "doge" command
#   e.g. doge **<TAB>
_fzf_complete_doge() {
  _fzf_complete --multi --reverse --prompt="doge> " -- "$@" < <(
    echo very
    echo wow
    echo such
    echo doge
  )
}
```

For Bash, register the completion function:

```sh
[ -n "$BASH" ] && complete -F _fzf_complete_doge -o default -o bashdefault doge
```

Zsh discovers completion functions automatically by name. Optionally post-process results with a _fzf_complete_COMMAND_post function:

```sh
_fzf_complete_foo() {
  _fzf_complete --multi --reverse --header-lines=3 -- "$@" < <(
    ls -al
  )
}

_fzf_complete_foo_post() {
  awk '{print $NF}'
}

[ -n "$BASH" ] && complete -F _fzf_complete_foo -o default -o bashdefault foo
```

## Previews

The --preview option executes a command through the user's shell with the current line, displaying its output in a scrollable split window. The current line is available as {}:

```bash
fzf --preview 'cat {}'
```

ANSI color sequences are preserved in preview output. For large files, limit preview output:

```bash
fzf --preview 'bat --style=numbers --color=always --line-range :500 {}'
```

Control preview layout and colors with --preview-window and --color:

```bash
fzf --height 40% --layout reverse --info inline --border \
    --preview 'file {}' --preview-window down:1:noborder \
    --color 'fg:#bbccdd,fg+:#ddeeff,bg:#334455,preview-bg:#223344,border:#778899'
```

Do not include file-specific preview commands in the universal FZF_DEFAULT_OPTS because input may contain non-file text such as process lists or history. Instead, define previews in command-specific options or in custom functions.

## Advanced Bindings and Features

The --bind option attaches actions to key sequences. Actions include execute and execute-silent for launching external processes:

```bash
# Press F1 to open the file with less without leaving fzf
# Press CTRL-Y to copy the line to clipboard and aborts fzf
fzf --bind 'f1:execute(less -f {}),ctrl-y:execute-silent(echo {} | pbcopy)+abort'
```

The reload action updates candidates on a key press or event. Reloading is useful for dynamic sources such as process lists or toggling between search filters:

```sh
FZF_DEFAULT_COMMAND='ps -ef' \
  fzf --bind 'ctrl-r:reload($FZF_DEFAULT_COMMAND)' \
      --header 'Press CTRL-R to reload' --header-lines=1 \
      --height=50% --layout=reverse
```

Toggle between different candidate sources:

```sh
FZF_DEFAULT_COMMAND='find . -type f' \
  fzf --bind 'ctrl-d:reload(find . -type d),ctrl-f:reload($FZF_DEFAULT_COMMAND)' \
      --height=50% --layout=reverse
```

The --phony option prevents secondary filtering and forces reload on every query change. Combined with --ansi for ANSI color support, this enables real-time search with ripgrep:

```sh
INITIAL_QUERY=""
RG_PREFIX="rg --column --line-number --no-heading --color=always --smart-case "
FZF_DEFAULT_COMMAND="$RG_PREFIX '$INITIAL_QUERY'" \
  fzf --bind "change:reload:$RG_PREFIX {q} || true" \
      --ansi --phony --query "$INITIAL_QUERY" \
      --height=50% --layout=reverse
```

The || true suffix suppresses warnings from ripgrep when a query produces no matches.

Performance considerations apply when using --ansi, which slows initial scanning. The --nth and --with-nth options add tokenization; --nth filters on specified fields while --with-nth reconstructs output lines. The --algo=v1 option uses a faster greedy matching algorithm as an alternative to the default v2, though v2 may provide better match ordering.

Replace find with faster alternatives such as fd, rg, or ag to respect .gitignore patterns. Enable symlink traversal and hidden files when appropriate for your use case.

Fish shell Ctrl-T uses the last command-line token as the recursive-search root. Custom FZF_CTRL_T_COMMAND definitions use the unexpanded dir variable, which defaults to . if the directory is invalid. The fzf wiki provides additional examples, binding tips, and references to related projects.
