# Highlight.js 10 Breaking Changes by Integration Path

Highlight.js version 10.0 represents a major release that consolidates changes previously deferred to minor releases. The project defines breaking changes as any modification that could disrupt a user’s integration. While many users may not observe significant differences, specific groups must address targeted adjustments. For a comprehensive list of all modifications, refer to the complete `VERSION_10_BREAKING_CHANGES.md` file. This document outlines the specific impacts on various installation and integration methods.

## Core Client Users

Developers using the core client bundle must implement several structural changes. First, rename the `darkula.css` file to `darcula.css`. Second, update all references to minified filenames, changing the extension from `.pack.js` to `.min.js`. Third, account for the transition to ES2015 code, which means support for very old browsers, such as Internet Explorer 11, is no longer guaranteed.

Additionally, the mechanism for skipping syntax highlighting has changed. Previously, classes containing text or the class `plain` could prevent highlighting. In version 10, these classes no longer serve this purpose. Only `nohighlight` and `no-highlight` will successfully skip highlighting entirely.

## CDN Grammar Users

Users loading extra grammars via CDN must verify that language files have been renamed. For example, `nimrod.js` has become `nim.js`. It is critical to note that Version 9 CDN JavaScript language files are incompatible with version 10. Users must update their script sources to the new filenames. Furthermore, all core-client changes described above apply to these users as well.

## Node.js Users

Node.js users integrating Highlight.js through the full public API via `require('./highlight.js')` may require no integration changes. However, users who register only selected languages must review grammar renames and dependency changes. These users must also apply the client-side changes mentioned in the core section. Custom server integrations relying on specific internal behaviors should consult the full breaking-change list, as these are not covered by the general summary.

## Direct GitHub Source Usage

Using the raw GitHub source directly on the client side no longer functions without an appropriate build pipeline, such as Rollup. Developers relying on direct source imports must choose an alternative distribution method, such as static CDN builds, CDN release assets, or the distribution npm package specified in the source repository. Source-level custom integrations are outside the stability promise for npm and CDN builds, as well as the public API.

## Source Implementation and Future Stability

The source implementation has shifted to ES6 modules and utilizes a new build system. This architecture is expected to become more modular throughout the version-10 series. Source consumers should inspect breaking changes and possibly the commit history to understand evolving structures. Questions and technical problems should be directed to GitHub issues.

## Summary of Actions

To ensure a smooth transition to version 10, developers must:
1.  Update CSS and JS filenames as specified for core clients.
2.  Verify CDN grammar names for accuracy.
3.  Check language registration lists for renames and dependencies.
4.  Adopt a build pipeline if using raw source code.
5.  Consult the full breaking changes document for custom integrations.

By addressing these specific areas, developers can maintain functionality and stability while leveraging the improved modularity and modern standards of Highlight.js 10.
