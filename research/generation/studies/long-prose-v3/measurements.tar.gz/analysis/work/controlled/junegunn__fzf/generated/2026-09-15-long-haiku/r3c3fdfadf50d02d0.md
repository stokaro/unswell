# fzf Vim Integration

## Installation

fzf integration in Vim requires adding the fzf directory to Vim's runtimepath. The installation location depends on your package manager.

For manual installation, add the runtimepath directly in your Vim configuration:

```vim
" If installed using Homebrew
set rtp+=/usr/local/opt/fzf

" If installed using git
set rtp+=~/.fzf
```

When using vim-plug, you can reference either an existing fzf installation or allow the plugin manager to fetch the latest version from GitHub:

```vim
" Reference an existing installation
Plug '/usr/local/opt/fzf'
Plug '~/.fzf'

" Fetch from GitHub
Plug 'junegunn/fzf'
```

The plugin requires an fzf executable on your PATH. If absent, you will be prompted to download one. To ensure the binary remains current, add the optional `fzf#install()` update hook:

```vim
Plug 'junegunn/fzf', { 'do': { -> fzf#install() } }
```

## Core API

The fzf integration provides two primary functions for launching the finder. `fzf#run(spec)` launches fzf with a specification dictionary. `fzf#wrap([name], [spec], [fullscreen])` returns a spec extended with global preferences, allowing custom commands to inherit layout, colors, history, and opening actions.

The basic `:FZF [options] [path]` command provides file selection built on these APIs:

```vim
" Look for files under current directory
:FZF

" Look for files under your home directory
:FZF ~

" With fzf command-line options
:FZF --reverse --info=inline /tmp

" Bang version starts fzf in fullscreen mode
:FZF!
```

By default, selections open in the current window with the Enter key. Ctrl-T opens selections in new tabs, Ctrl-X in horizontal splits, and Ctrl-V in vertical splits. The `FZF_DEFAULT_COMMAND` and `FZF_DEFAULT_OPTS` environment variables apply in Vim as well.

## Global Settings

### File Opening Actions

The `g:fzf_action` dictionary maps key bindings to commands or functions that handle selected items:

```vim
let g:fzf_action = {
  \ 'ctrl-t': 'tab split',
  \ 'ctrl-x': 'split',
  \ 'ctrl-v': 'vsplit' }
```

Actions can reference functions that process selections. A function receives selected lines and can perform custom operations:

```vim
function! s:build_quickfix_list(lines)
  call setqflist(map(copy(a:lines), '{ "filename": v:val }'))
  copen
  cc
endfunction

let g:fzf_action = {
  \ 'ctrl-q': function('s:build_quickfix_list'),
  \ 'ctrl-t': 'tab split',
  \ 'ctrl-x': 'split',
  \ 'ctrl-v': 'vsplit' }
```

When a run spec includes a custom `sink` or `sink*`, `g:fzf_action` is not applied, since arbitrary entries require their own handling.

### Layout Control

The `g:fzf_layout` dictionary controls where and how fzf displays. It supports multiple layout styles:

```vim
" Popup window (default)
let g:fzf_layout = { 'window': { 'width': 0.9, 'height': 0.6 } }

" Bottom, top, left, or right placement
let g:fzf_layout = { 'down': '40%' }

" Window using a Vim command
let g:fzf_layout = { 'window': 'enew' }
let g:fzf_layout = { 'window': '-tabnew' }
let g:fzf_layout = { 'window': '10new' }
```

For tmux environments, use fzf-tmux options:

```vim
if exists('$TMUX')
  let g:fzf_layout = { 'tmux': '-p90%,60%' }
else
  let g:fzf_layout = { 'window': { 'width': 0.9, 'height': 0.6 } }
endif
```

### Color Customization

The `g:fzf_colors` dictionary maps fzf UI elements to Vim highlight groups. `fzf#wrap` translates these definitions to `--color` options:

```vim
let g:fzf_colors =
\ { 'fg':      ['fg', 'Normal'],
  \ 'bg':      ['bg', 'Normal'],
  \ 'hl':      ['fg', 'Comment'],
  \ 'fg+':     ['fg', 'CursorLine', 'CursorColumn', 'Normal'],
  \ 'bg+':     ['bg', 'CursorLine', 'CursorColumn'],
  \ 'hl+':     ['fg', 'Statement'],
  \ 'info':    ['fg', 'PreProc'],
  \ 'border':  ['fg', 'Ignore'],
  \ 'prompt':  ['fg', 'Conditional'],
  \ 'pointer': ['fg', 'Exception'],
  \ 'marker':  ['fg', 'Keyword'],
  \ 'spinner': ['fg', 'Label'],
  \ 'header':  ['fg', 'Comment'] }
```

Each element maps to a component and ordered Vim highlight groups. The system falls back when a group lacks a color. Supported elements include `fg`, `bg`, and `hl` for normal items; `fg+`, `bg+`, and `hl+` for the current item; `gutter` for the left background; `pointer` for the current-line indicator; `marker` for multi-select markers; `border` for window borders; `header` for headers; `info` for match counters; `spinner` for streaming input indicators; and `prompt` for the query prompt.

### Query History

Enable per-command history by setting `g:fzf_history_dir`:

```vim
let g:fzf_history_dir = '~/.local/share/fzf-history'
```

When configured, Ctrl-N and Ctrl-P bind to `next-history` and `previous-history` instead of `down` and `up`. History files are stored in the specified directory with command-specific names.

## Run Specification

The spec dictionary passed to `fzf#run()` controls behavior. Key options include:

**Source:** A shell command, Vim list, or omitted to use default behavior:

```vim
call fzf#run({'source': 'git ls-files', 'sink': 'e'})
call fzf#run({'source': map(split(globpath(&rtp, 'colors/*.vim'),
            \               'fnamemodify(v:val, ":t:r")'),
            \ 'sink': 'colo', 'left': '25%'})
```

When `source` is absent, `find` or `FZF_DEFAULT_COMMAND` supplies current-directory paths.

**Sink:** A Vim command or callback handling selections. Commands execute with each selection:

```vim
call fzf#run({'sink': 'e'})
call fzf#run({'sink': 'tabedit'})
```

Functions receive one selected line per invocation. `sink*` functions receive all output lines together as a list.

**Options:** Passed to fzf as a string or list. Lists avoid shell escaping issues:

```vim
call fzf#run({'sink': 'tabedit', 'options': '--multi --reverse'})

" Avoid escaping with list format
call fzf#run({'options': ['--reverse', '--prompt', 'C:\Program Files\']})
```

**Directory:** Set the working directory:

```vim
call fzf#run({'source': 'git ls-files', 'sink': 'e', 'dir': '/path'})
```

**Layout:** Specify placement with `up`, `down`, `left`, `right` (accepting number or percentage string), or `window` (Vim command or popup dictionary). Tmux layouts use `tmux`:

```vim
call fzf#run({'source': 'git ls-files', 'sink': 'e', 'left': '40%'})
call fzf#run({'source': 'git ls-files', 'sink': 'e', 'window': '30vnew'})
```

## Popup Window Configuration

Popup windows accept a dictionary with required and optional keys:

**Required:**
- `width`: Float from 0 to 1 or integer at least 8
- `height`: Float from 0 to 1 or integer at least 4

**Optional:**
- `xoffset`: Float from 0 to 1, defaults to 0.5
- `yoffset`: Float from 0 to 1, defaults to 0.5
- `highlight`: Vim highlight group for border (default `Comment`)
- `border`: Style: `rounded`, `sharp`, `horizontal`, `vertical`, `top`, `bottom`, `left`, `right`, or `none` (default `rounded`)

## Custom Commands

The `fzf#wrap()` function simplifies command creation by applying global settings. Arguments are optional:

```vim
command! LS call fzf#run(fzf#wrap({'source': 'ls'}))
```

Add bang support for fullscreen mode:

```vim
command! -bang LS call fzf#run(fzf#wrap({'source': 'ls'}, <bang>0))
```

Include directory argument and completion:

```vim
command! -bang -complete=dir -nargs=* LS
    \ call fzf#run(fzf#wrap({'source': 'ls', 'dir': <q-args>}, <bang>0))
```

Enable per-command history by providing a name as the first `fzf#wrap()` argument:

```vim
command! -bang -complete=dir -nargs=* LS
    \ call fzf#run(fzf#wrap('ls', {'source': 'ls', 'dir': <q-args>}, <bang>0))
```

The history name is ignored if `g:fzf_history_dir` is not defined.

## Terminal Buffer and Customization

fzf uses a terminal buffer on Neovim, GVim, and terminal Vim with non-default layouts. The buffer's filetype is `fzf`, enabling `FileType` autocmd customization. For non-popup layouts, you can temporarily hide the status line:

```vim
if has('nvim') && !exists('g:fzf_layout')
  autocmd! FileType fzf
  autocmd  FileType fzf set laststatus=0 noshowmode noruler
    \| autocmd BufLeave <buffer> set laststatus=2 showmode ruler
endif
```

Popup windows are supported on Vim 8, Neovim, and editor window scenarios. Tmux popup layouts require tmux 3.2 or later.
