# bat: File Display and Integration Guide

## Display Features

bat is a syntax-highlighting cat replacement that enhances file viewing with several powerful features. At its core, bat displays file contents with syntax highlighting automatically applied based on file extensions or explicit language specification. When displaying files, bat automatically enables paging when the output exceeds the terminal height, providing a smoother viewing experience than piping to a pager manually.

Beyond syntax highlighting, bat displays Git-index modification markers alongside line numbers, visually indicating which lines have been added, modified, or removed according to the repository state. This integration proves particularly valuable when reviewing changes in tracked files. The tool also supports optional nonprinting-character display through the -A or --show-all flag, which highlights tabs, spaces, newlines, and other invisible characters. This feature aids in detecting whitespace issues and understanding file formatting.

bat can concatenate multiple files in sequence, displaying each with full syntax highlighting applied. When output is redirected to a file or piped to another command, bat automatically falls back to plain text output, providing cat-like behavior. This design ensures compatibility with scripts and pipelines that expect unformatted content. For example, bat can quickly create new files, combine multiple files into a document, display line numbers, or interleave file contents with standard input:

```
bat > note.md
bat header.md content.md footer.md > document.md
bat -n main.rs
bat f - g
```

For input from standard input without a file extension, bat uses shebang detection to infer the appropriate syntax. Alternatively, the -l or --language flag allows explicit syntax specification, ensuring correct highlighting regardless of the input source. This is particularly useful when working with piped data or streams where filenames are unavailable.

## Integration with Other Tools

bat integrates seamlessly with various command-line utilities, extending its usefulness across different workflows. The find command can invoke bat using find's -exec option, applying syntax highlighting to search results:

```
find … -exec bat {} +
```

Similarly, the fd utility provides the --exec-batch flag for batch execution with bat:

```
fd … -X bat
```

batgrep is a specialized tool that displays ripgrep search results with syntax highlighting, combining searching and highlighting in a single operation:

```
batgrep needle src/
```

When monitoring log files with tail, bat can provide syntax highlighting for logs by disabling pagination and specifying the log syntax explicitly:

```
tail -f /var/log/pacman.log | bat --paging=never -l log
```

bat can display historical file versions from git repositories using git show, allowing developers to review past versions of source files with syntax highlighting:

```
git show v0.6.0:src/main.rs | bat -l rs
```

For copying file contents to the clipboard while avoiding the inclusion of line numbers and git modification gutters, piping bat output to xclip provides clean results:

```
bat main.cpp | xclip
```

Manual pages can be displayed with color and syntax highlighting by configuring the MANPAGER environment variable:

```
export MANPAGER="sh -c 'col -bx | bat -l man -p'"
man 2 select
```

This approach uses bat to color manual pages, though Mandoc's man implementation is not supported. The batman wrapper provides an alternative interface for this functionality, and MANROFFOPT=-c may resolve formatting issues in some configurations.

prettybat extends bat's capabilities by combining it with code formatters such as prettier, shfmt, and rustfmt, enabling viewing of formatted source code output.

Note that diff highlighting is not directly supported by bat; the delta tool is referenced as an alternative for this use case. Plain output mode or piping to clipboard utilities like xclip helps avoid copying line-number and modification gutters when needed.

## Installation

bat is available through numerous package managers across different operating systems, accommodating most development environments.

On Ubuntu 19.10 and later, bat is available through the standard repositories:

```
apt install bat
```

Debian Sid provides bat as well. On other Debian-family systems, pre-built .deb archives can be downloaded and installed directly:

```
sudo dpkg -i bat_0.16.0_amd64.deb
```

Note that some Debian-family distributions name the executable batcat due to a naming conflict. A symlink or alias restores the bat command:

```
mkdir -p ~/.local/bin
ln -s /usr/bin/batcat ~/.local/bin/bat
```

Alpine Linux provides bat through its repositories:

```
apk add bat
```

Arch Linux users can install bat using pacman:

```
pacman -S bat
```

Fedora Modular systems include bat:

```
dnf install bat
```

Gentoo provides bat through its package system:

```
emerge sys-apps/bat
```

Void Linux offers bat through xbps:

```
xbps-install -S bat
```

FreeBSD users can install bat using the package manager:

```
pkg install bat
```

Alternatively, FreeBSD ports provide source-based installation:

```
cd /usr/ports/textproc/bat
make install
```

Nix package manager users can install bat with:

```
nix-env -i bat
```

openSUSE provides bat through zypper:

```
zypper install bat
```

macOS users can install bat using Homebrew:

```
brew install bat
```

MacPorts also provides bat:

```
port install bat
```

Windows users can use Chocolatey:

```
choco install bat
```

Alternatively, Scoop provides installation on Windows:

```
scoop install bat
```

Chocolatey automatically installs less alongside bat, which is helpful for Windows paging functionality. Windows systems require Visual C++ Redistributable for bat to function. Release archives include binaries for many architectures and provide MUSL static builds for compatibility across different systems.

For installation from source, Rust 1.40 or later is required. The cargo tool builds bat with man and completion files generated in the target build directory, though these files are not installed automatically:

```
cargo install --locked bat
```

The complete development workflow includes building from a cloned repository:

```
git clone --recursive https://github.com/sharkdp/bat
cd bat
cargo build --bins
cargo test
cargo install --locked
```

For custom builds with modified syntaxes and themes, the assets creation script is available:

```
bash assets/create.sh
cargo install --locked --force
```

## Customization

bat supports extensive customization through themes, output styles, syntax definitions, and configuration files.

Available themes are displayed using --list-themes. Theme selection can be specified through the --theme flag or the BAT_THEME environment variable. Standard built-in themes include TwoDark, GitHub, and OneHalfLight. Dark backgrounds are the default assumption for most themes.

The ansi-dark and ansi-light themes use basic three-bit ANSI colors, while base16 themes use four-bit colors following base16 styling conventions. The base16-256 theme maps some bright colors into slots 16–21 for compatibility with base16-shell, though it is not a generic choice suitable for every 256-color terminal. Restricted themes track terminal palette changes and blend with other terminal software. OneHalfDark and OneHalfLight themes feature brighter grid and line colors compared to other themes.

Theme selection can be automated based on system preferences, particularly on macOS:

```
alias cat="bat --theme=\$(defaults read -globalDomain AppleInterfaceStyle &> /dev/null && echo default || echo GitHub)"
```

Interactive theme preview and selection can be accomplished using fzf:

```
bat --list-themes | fzf --preview="bat --theme={} --color=always /path/to/file"
```

Output style is controlled through --style, which selects specific elements to display. The numbers,changes option shows line numbers and Git modifications without grid or header. Style preferences can be made persistent using BAT_STYLE or configuration files. The header, grid, and other style components can be individually controlled.

Custom syntax definitions use the Sublime .sublime-syntax file format. Definitions should be placed in the platform-dependent config syntax directory:

```
mkdir -p "$(bat --config-dir)/syntaxes"
cd "$(bat --config-dir)/syntaxes"
git clone https://github.com/tellnobody1/sublime-purescript-syntax
```

After adding custom syntaxes, the binary cache must be rebuilt:

```
bat cache --build
```

Syntax definitions can be verified using --list-languages. When returning to default syntax definitions, the cache should be cleared:

```
bat cache --clear
```

Custom themes are added similarly, using .tmTheme format:

```
mkdir -p "$(bat --config-dir)/themes"
cd "$(bat --config-dir)/themes"
git clone https://github.com/greggb/sublime-snazzy
bat cache --build
```

syntect is the underlying library that reads Sublime .sublime-syntax files and themes, providing the syntax highlighting engine.

The pager is configurable through multiple precedence levels. BAT_PAGER takes highest priority, followed by PAGER, with less as the default fallback. The --pager flag provides command-line configuration. When less is used without explicit arguments, bat automatically supplies -R to preserve ANSI colors and -F to quit when output fits on one screen. For less versions older than 530, bat adds -X to work around quit-if-one-screen issues, though this disables mouse-wheel support:

```
export BAT_PAGER="less -RF"
```

Tab expansion is performed before paging, converting tabs to four spaces by default. The --tabs flag changes this width, while --tabs=0 passes tabs through to the pager without expansion. Note that pager tab-stop settings cannot affect already-expanded spaces.

Configuration files are located at platform-dependent paths, displayed using bat --config-file. Alternative configuration paths are selected through BAT_CONFIG_PATH:

```
export BAT_CONFIG_PATH="/path/to/bat.conf"
```

The --generate-config-file flag creates default configuration. Configuration files contain CLI arguments with #-prefixed comments. Example configuration entries include:

```
--theme="TwoDark"
--style="numbers,changes,header"
--italic-text=always
--map-syntax "*.ino:C++"
--map-syntax ".ignore:Git Ignore"
```

## Platform-Specific Considerations and Limits

Different platforms present unique challenges and requirements for bat functionality.

On Windows, the native more pager has significant limitations. Installing less and placing it on PATH improves paging functionality. Windows 10 version 1511 and later supports ANSI colors in Command Prompt and PowerShell, as do newer Bash versions. Older Windows versions can use Cmder or ConEmu for color support. Git and MSYS less may misinterpret colors in some cases.

Paging can be disabled entirely using --paging=never or by setting BAT_PAGER to an empty value. Native bat cannot interpret Cygwin /cygdrive paths; a wrapper function converts them:

```
bat() {
    local index
    local args=("$@")
    for index in $(seq 0 ${#args[@]}) ; do
        case "${args[index]}" in
        -*) continue;;
        *)  [ -e "${args[index]}" ] && args[index]="$(cygpath --windows "${args[index]}")";;
        esac
    done
    command bat "${args[@]}"
}
```

Color depth support depends on terminal capabilities. Truecolor terminals should expose COLORTERM=truecolor or 24bit; otherwise bat falls back to eight-bit colors. Restricted themes are appropriate when full color support is unavailable.

Character encoding support includes native UTF-8 and UTF-16. Other encodings should be converted using iconv before piping to bat:

```
iconv -f ISO-8859-1 -t UTF-8 my-file.php | bat
```

When detection fails, syntax can be specified explicitly with -l or --language.

The project maintainers are sharkdp and eth-p. The stated goals are providing syntax highlighting, Git integration, a POSIX cat replacement, and a usable command-line interface. Alternatives are documented for specialized use cases. The license is MIT or Apache 2.0, with copyright held by bat-developers from 2018–2020.
