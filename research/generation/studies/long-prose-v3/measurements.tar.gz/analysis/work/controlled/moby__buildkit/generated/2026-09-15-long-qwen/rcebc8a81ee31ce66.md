# Lazy Pulling Stargz/eStargz Base Images (Experimental)

This document describes the configuration that allows BuildKit to lazily pull [stargz](https://github.com/google/crfs/blob/master/README.md#introducing-stargz)/[eStargz](https://github.com/containerd/stargz-snapshotter/blob/master/docs/stargz-estargz.md)-formatted images from registries.

By default, BuildKit does not pull images until they are strictly needed. For example, during a build, BuildKit does not pull the base image until it runs commands on it (e.g., a `RUN` Dockerfile instruction) or until it exports stages as tarballs, etc.

Additionally, if the image is formatted as stargz/eStargz, BuildKit with the configuration described here can skip pulling that image even when it is needed (e.g., on `RUN` and `COPY` instructions). Instead, it *mounts* that image from the registry to the node and *lazily* fetches necessary files (or chunks for large files) contained in that image on demand. This can help reduce the time required for the build. This document describes the configuration and usage of this feature.

For more details about the stargz/eStargz image format, please see the [Stargz and eStargz Image Formats](#stargz-and-estargz-image-formats) section.

## Known Limitations

- For the OCI worker, `~/.docker/config.json`-based authentication cannot be used for stargz/eStargz-based lazy pulling.
- For the containerd worker, the stargz snapshotter (`containerd-stargz-grpc`) needs to be run and configured separately.
- Rootless execution is currently unsupported.

## Enabling Lazy Pulling of Stargz/eStargz Images

BuildKit supports two ways to enable lazy pulling of stargz/eStargz images.

### Using Builtin Support (Recommended)

The OCI worker has builtin support for stargz/eStargz. You can enable this feature by running `buildkitd` with the option `--oci-worker-snapshotter=stargz`.

```
buildkitd --oci-worker-snapshotter=stargz
```

This is the easiest way to use this lazy pull feature on BuildKit. Currently, this configuration is unsupported for the containerd worker.

#### Example of Building an Image with Lazy Pull

Once `buildkitd` starts with the above configuration, stargz/eStargz images can be lazily pulled. For example, we build the following Go binary with BuildKit.

```golang
package main

import "fmt"

func main() {
	fmt.Println("Hello, world!")
}
```

The example Dockerfile which leverages an eStargz-formatted base image will be as follows.

```Dockerfile
# Uses eStargz-formatted golang image as the base image. This isn't pulled here.
FROM ghcr.io/stargz-containers/golang:1.15.3-buster-esgz AS dev

# Copies the source code from the context. The base image is mounted and lazily pulled.
COPY ./hello.go /hello.go

# Runs go compiler on that base image. The base image is mounted and lazily pulled.
RUN go build -o /hello /hello.go

FROM scratch

# Harvesting the result binary.
COPY --from=dev /hello /
```

Then this can be built by skipping the pull of `ghcr.io/stargz-containers/golang:1.15.3-buster-esgz`. Instead, this image will be mounted from the registry to the node, and necessary chunks of contents (e.g., the `go` command binary, libraries, etc.) are partially fetched from that registry on demand.

```
$ buildctl build --frontend dockerfile.v0 \
                 --local context=/tmp/hello \
                 --local dockerfile=/tmp/hello \
                 --output type=local,dest=./
$ ./hello
Hello, world!
```

Note that when a stage is exported (e.g., to the registry), the base image (even stargz/eStargz) of that stage needs to be pulled to copy it to the destination. However, if the destination is a registry and the target repository already contains some blobs of that image or [cross-repository blob mount](https://docs.docker.com/registry/spec/api/#cross-repository-blob-mount) can be used, BuildKit keeps these blobs lazy.

Also note that although registry configuration in `/etc/buildkit/buildkitd.toml` is applied to lazy pulling as well, `~/.docker/config.json`-based authorization is currently not supported. We are working on this integration.

### Using Proxy (Standalone) Snapshotter

This is another way to enable stargz-based lazy pull. [Stargz Snapshotter (`containerd-stargz-grpc`)](https://github.com/containerd/stargz-snapshotter) needs to be installed. Note that BuildKit's registry configuration does not propagate to the stargz snapshotter, so it needs to be configured separately when you use private/mirror repositories.

This configuration is for users of the containerd worker and those trying other versions of the stargz snapshotter than built into the OCI worker.

#### With OCI Worker

Spawn `containerd-stargz-grpc` as a separate process. Then run `buildkitd` with the option `--oci-worker-proxy-snapshotter-path=/run/containerd-stargz-grpc/containerd-stargz-grpc.sock`, which makes it recognize this snapshotter via the socket.

```
containerd-stargz-grpc
buildkitd --oci-worker-snapshotter=stargz \
          --oci-worker-proxy-snapshotter-path=/run/containerd-stargz-grpc/containerd-stargz-grpc.sock
```

#### With Containerd Worker

Configure containerd's `config.toml` (default = `/etc/containerd/config.toml`) to make it recognize the stargz snapshotter as a [proxy snapshotter](https://github.com/containerd/containerd/blob/master/PLUGINS.md#proxy-plugins).

```toml
[proxy_plugins]
  [proxy_plugins.stargz]
    type = "snapshot"
    address = "/run/containerd-stargz-grpc/containerd-stargz-grpc.sock"
```

Then spawn `containerd-stargz-grpc` and `containerd`, and run `buildkitd` with the option `--containerd-worker-snapshotter=stargz`, which tells `containerd` to use the stargz snapshotter.

```
containerd-stargz-grpc
containerd
buildkitd --containerd-worker-snapshotter=stargz --oci-worker=false --containerd-worker=true
```

#### Registry-Related Configurations for Standalone Stargz Snapshotter

When you use a standalone stargz snapshotter, registry configuration needs to be done for the stargz snapshotter process separately. Create a configuration TOML file which contains the registry configuration for the stargz snapshotter (e.g., `/etc/containerd-stargz-grpc/config.toml`). The configuration format [**differs** from BuildKit](https://github.com/containerd/stargz-snapshotter/blob/master/cmd/containerd-stargz-grpc/config.go). For more information about this format, please see also [docs in the repository](https://github.com/containerd/stargz-snapshotter/blob/master/docs/overview.md#registry-related-configuration).

```toml
[[resolver.host."exampleregistry.io".mirrors]]
host = "examplemirror.io"
```

Then pass this file to the stargz snapshotter through the `--config` option.

```
containerd-stargz-grpc --config=/etc/containerd-stargz-grpc/config.toml
```

## Stargz and eStargz Image Formats

[Stargz](https://github.com/google/crfs/blob/master/README.md#introducing-stargz) and [eStargz](https://github.com/containerd/stargz-snapshotter/blob/master/docs/stargz-estargz.md) are OCI/Docker-compatible image formats that can be lazily pulled from standard registries (e.g., Docker Hub, GitHub Container Registry, etc.). Because they are backwards-compatible with OCI/Docker images, they can run on standard runtimes (e.g., Docker, containerd, etc.). Stargz is proposed by the [Google CRFS project](https://github.com/google/crfs). eStargz is an extended format of stargz by [Stargz Snapshotter](https://github.com/containerd/stargz-snapshotter). It comes with [additional features](https://github.com/containerd/stargz-snapshotter/blob/master/docs/stargz-estargz.md#estargz-archive-format), including chunk verification and prefetch, to avoid the overhead of on-demand fetching. For more details about lazy pull with stargz/eStargz images, please refer to the docs on these repositories.

### Getting Stargz/eStargz Formatted Images

Pre-converted stargz/eStargz images are available at the [`ghcr.io/stargz-containers` repository](https://github.com/containerd/stargz-snapshotter/blob/master/docs/pre-converted-images.md) (mainly for testing purposes).

You can also create any stargz/eStargz image by converting an OCI/Docker image into a stargz/eStargz-formatted one using one of the following tools.

- [`ctr-remote`](https://github.com/containerd/stargz-snapshotter#creating-stargz-images-and-further-optimization), developed in the stargz snapshotter project.
- [`stargzify`](https://github.com/google/crfs/tree/master/stargz/stargzify), developed in the CRFS project (creating eStargz images is unsupported).

For more details about these tools, please refer to the docs in these repositories.
