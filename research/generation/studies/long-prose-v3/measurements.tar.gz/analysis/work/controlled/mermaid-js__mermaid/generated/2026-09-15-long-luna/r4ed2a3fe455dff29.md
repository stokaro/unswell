# Mermaid

Mermaid is a JavaScript diagramming tool. It uses Markdown-inspired textual definitions to produce diagrams and charts. Because diagram source can be edited and included in scripts, diagrams can remain aligned with development. Editors, wikis, and other applications provide Mermaid integrations. The Mermaid Live Editor also permits diagram creation without programming.

Introductory resources include tutorials, a beginner overview, usage information, integrations, syntax documentation, and getting-started guides. Mermaid won the 2019 JavaScript Open Source Award for “The most exciting use of technology.”

## Diagram types

Mermaid supports flowcharts, sequence diagrams, Gantt charts, class diagrams, and user journeys. Git graphs and entity-relationship diagrams are experimental.

A flowchart can be defined as follows:

```mermaid
graph TD;
    A-->B;
    A-->C;
    B-->D;
    C-->D;
```

A sequence diagram can describe interactions among participants:

```mermaid
sequenceDiagram
    participant Alice
    participant Bob
    Alice->>John: Hello John, how are you?
    loop Healthcheck
        John->>John: Fight against hypochondria
    end
    Note right of John: Rational thoughts <br/>prevail!
    John-->>Alice: Great!
    John->>Bob: How about you?
    Bob-->>John: Jolly good!
```

Gantt diagrams define dates, sections, and task states:

```mermaid
gantt
dateFormat  YYYY-MM-DD
title Adding GANTT diagram to mermaid
excludes weekdays 2014-01-10

section A section
Completed task            :done,    des1, 2014-01-06,2014-01-08
Active task               :active,  des2, 2014-01-09, 3d
Future task               :         des3, after des2, 5d
Future task2              :         des4, after des3, 5d
```

Class diagrams express classes and relationships:

```mermaid
classDiagram
Class01 <|-- AveryLongClass : Cool
Class03 *-- Class04
Class05 o-- Class06
Class07 .. Class08
Class09 --> C2 : Where am i?
Class09 --* C3
Class09 --|> Class07
Class07 : equals()
Class07 : Object[] elementData
Class01 : size()
Class01 : int chimp
Class01 : int gorilla
Class08 <--> C2: Cool label
```

Git graphs and entity-relationship diagrams are experimental:

```mermaid
gitGraph:
options
{
    "nodeSpacing": 150,
    "nodeRadius": 10
}
end
commit
branch newbranch
checkout newbranch
commit
commit
checkout master
commit
commit
merge newbranch
```

```mermaid
erDiagram
    CUSTOMER ||--o{ ORDER : places
    ORDER ||--|{ LINE-ITEM : contains
    CUSTOMER }|..|{ DELIVERY-ADDRESS : uses
```

A user journey can describe activities and scores:

```markdown
journey
    title My working day
    section Go to work
      Make tea: 5: Me
      Go upstairs: 3: Me
      Do work: 1: Me, Cat
    section Go home
      Go downstairs: 5: Me
      Sit down: 5: Me
```

## Browser integration

The Mermaid CDN is `unpkg.com/mermaid`. A version can be selected in its URL; the page points to version 8.8.0. The distribution path is:

```text
https://unpkg.com/mermaid@<version>/dist/
```

Browser installation adds Mermaid’s JavaScript. Without a bundler, include an absolute script URL and initialize Mermaid:

```html
<script src="https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js"></script>
<script>mermaid.initialize({startOnLoad:true});</script>
```

The parser reads diagram definitions in `div` elements with `class=mermaid` and renders SVG charts.

## Projects and contributors

Sibling projects include Mermaid Live Editor, Mermaid CLI, Mermaid Webpack Demo, and Mermaid Parcel Demo. The maintainer requests a core team to help add diagram types and improve current ones. Team members receive repository write access and represent the project when responding to questions and issues.

Contributor procedures include dependency installation, building, linting with ESLint, and testing. Install dependencies with:

```text
yarn install
```

Build in watch mode with:

```text
yarn build:watch
```

Run linting and tests with:

```text
yarn lint
yarn test
```

Editor ESLint integration reports results while editing. For a manual browser check, open `dist/index.html`. Authorized release maintainers update `package.json`’s version, then run the release command, which generates `dist` and publishes to npmjs.org:

```text
npm publish
```

Mermaid was created by Knut Sveidqvist. Credits include d3 and dagre-d3 for layout and drawing, js-sequence-diagram for the sequence grammar, Jessica Peter for the Gantt starting point, Tyler Long for maintenance help, and other contributors and support participants.
