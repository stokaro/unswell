# fzf Vim Integration

fzf’s Vim integration provides an API for launching the finder, applying global preferences, controlling layouts, and defining custom commands. After fzf is installed, add its directory to Vim’s `runtimepath`. The location depends on the package manager.

If fzf was installed using Homebrew, add:

```vim
" If installed using Homebrew
set rtp+=/usr/local/opt/fzf
```

For a git installation, use:

```vim
" If installed using git
set rtp+=~/.fzf
```

vim-plug can use either installed package:

```vim
" If installed using Homebrew
Plug '/usr/local/opt/fzf'

" If installed using git
Plug '~/.fzf'
```

Alternatively, vim-plug can fetch the newest plugin from GitHub:

```vim
Plug 'junegunn/fzf'
```

An optional update hook keeps the fzf executable current:

```vim
Plug 'junegunn/fzf', { 'do': { -> fzf#install() } }
```

The plugin uses an fzf executable found on `PATH`. If no executable is available, it asks permission to download one. The `fzf#install()` hook can update the binary when the plugin is installed or updated.

## Finder Commands and API Functions

The `fzf#run(spec)` function launches the finder from a run specification. The `fzf#wrap([name], [spec], [fullscreen])` function returns a specification extended with global preferences.

The basic `:FZF [options] [path]` command is a file selector built on these APIs. For example:

```vim
" Look for files under current directory
:FZF

" Look for files under your home directory
:FZF ~

" With fzf command-line options
:FZF --reverse --info=inline /tmp

" Bang version starts fzf in fullscreen mode
:FZF!
```

fzf.vim provides additional commands. By default, Enter opens a selection in the current window. `Ctrl-T`, `Ctrl-X`, and `Ctrl-V` open selections in a new tab, a horizontal split, and a vertical split, respectively. The `FZF_DEFAULT_COMMAND` and `FZF_DEFAULT_OPTS` environment variables apply in Vim as well.

A direct call can specify a sink:

```vim
call fzf#run({'sink': 'e'})
```

This opens the selected item using the Vim `e` command. To open it in a tab, use:

```vim
call fzf#run({'sink': 'tabedit'})
```

A source can be an external command:

```vim
call fzf#run({'source': 'git ls-files', 'sink': 'e'})
```

Additional fzf options can be passed as a string or list:

```vim
call fzf#run({'sink': 'tabedit', 'options': '--multi --reverse'})
```

## Global Settings

Global variables define default actions, placement, colors, and history.

### Opening Actions

`g:fzf_action` changes the keys used to open selected files. This is the default extra key binding configuration:

```vim
let g:fzf_action = {
  \ 'ctrl-t': 'tab split',
  \ 'ctrl-x': 'split',
  \ 'ctrl-v': 'vsplit' }
```

An action can reference a function that processes selected lines. The following function creates a quickfix list:

```vim
function! s:build_quickfix_list(lines)
  call setqflist(map(copy(a:lines), '{ "filename": v:val }'))
  copen
  cc
endfunction

let g:fzf_action = {
  \ 'ctrl-q': function('s:build_quickfix_list'),
  \ 'ctrl-t': 'tab split',
  \ 'ctrl-x': 'split',
  \ 'ctrl-v': 'vsplit' }
```

`g:fzf_action` applies only when there is no custom `sink` or `sink*`. Arbitrary entries handled by a custom sink require their own processing.

### Layout

`g:fzf_layout` controls where the finder appears. A popup window can be configured as follows:

```vim
let g:fzf_layout = { 'window': { 'width': 0.9, 'height': 0.6 } }
```

The finder can instead be placed down, up, left, or right:

```vim
let g:fzf_layout = { 'down': '40%' }
```

A Vim command can create the window:

```vim
let g:fzf_layout = { 'window': 'enew' }
let g:fzf_layout = { 'window': '-tabnew' }
let g:fzf_layout = { 'window': '10new' }
```

The same layout keys are available in an individual run specification:

```vim
call fzf#run({'source': 'git ls-files', 'sink': 'e', 'left': '40%'})
call fzf#run({'source': 'git ls-files', 'sink': 'e', 'window': '30vnew'})
```

### Colors

`g:fzf_colors` maps an fzf element to a component and an ordered list of Vim highlight groups. `fzf#wrap` translates these definitions into `--color` options. When a highlight group does not provide a color, the next group in the list is used.

```vim
let g:fzf_colors =
\ { 'fg':      ['fg', 'Normal'],
  \ 'bg':      ['bg', 'Normal'],
  \ 'hl':      ['fg', 'Comment'],
  \ 'fg+':     ['fg', 'CursorLine', 'CursorColumn', 'Normal'],
  \ 'bg+':     ['bg', 'CursorLine', 'CursorColumn'],
  \ 'hl+':     ['fg', 'Statement'],
  \ 'info':    ['fg', 'PreProc'],
  \ 'border':  ['fg', 'Ignore'],
  \ 'prompt':  ['fg', 'Conditional'],
  \ 'pointer': ['fg', 'Exception'],
  \ 'marker':  ['fg', 'Keyword'],
  \ 'spinner': ['fg', 'Label'],
  \ 'header':  ['fg', 'Comment'] }
```

For example, this definition checks `Conditional`, then `Comment`:

```vim
  'prompt':  ['fg', 'Conditional', 'Comment'],
```

The supported elements are:

| Element | Description |
| --- | --- |
| `fg` / `bg` / `hl` | Item foreground, background, and highlight |
| `fg+` / `bg+` / `hl+` | Current item foreground, background, and highlight |
| `hl` / `hl+` | Highlighted substrings, normal and current |
| `gutter` | Background of the gutter on the left |
| `pointer` | Pointer to the current line (`>`) |
| `marker` | Multi-select marker (`>`) |
| `border` | Border around the window |
| `header` | Header |
| `info` | Info line and match counters |
| `spinner` | Streaming input indicator |
| `prompt` | Prompt before the query (`> `) |

### History

Set `g:fzf_history_dir` to enable per-command query history:

```vim
let g:fzf_history_dir = '~/.local/share/fzf-history'
```

History files are stored in the specified directory. When this variable is set, `Ctrl-N` and `Ctrl-P` are bound to `next-history` and `previous-history` instead of `down` and `up`.

## Run Specifications

A run specification’s `source` can be a shell command or a Vim list. If it is absent, `find` or `FZF_DEFAULT_COMMAND` supplies paths from the current directory. The `sink` can be a Vim command or a callback called for each selection. `sink*` receives all output lines together.

`options` accepts either a string or a list. Lists avoid escaping issues:

```vim
call fzf#run({'options': '--reverse --prompt "C:\\Program Files\\"'})
call fzf#run({'options': ['--reverse', '--prompt', 'C:\Program Files\']})
```

Other specification fields include `dir` for the working directory, `up`, `down`, `left`, and `right` for placement, and `tmux` for fzf-tmux options. The `window` field can be a Vim command or a popup dictionary.

A Vim list can provide finder input:

```vim
call fzf#run({'source': map(split(globpath(&rtp, 'colors/*.vim')),
            \               'fnamemodify(v:val, ":t:r")'),
            \ 'sink': 'colo', 'left': '25%'})
```

## Wrapping Specifications

The arguments to `fzf#wrap` are optional. These forms display or run a wrapped specification:

```vim
:echo fzf#wrap()
```

```vim
echo fzf#wrap({'source': 'ls'})
```

```vim
call fzf#run(fzf#wrap({'source': 'ls'}))
```

Wrapped specifications inherit global layout, colors, history, and opening actions. The optional `name` identifies query history only when `g:fzf_history_dir` is configured. The optional `fullscreen` argument defaults to `0` and accepts `0` or `1`.

A custom command can use the wrapper:

```vim
command! LS call fzf#run(fzf#wrap({'source': 'ls'}))
```

A bang-controlled command passes `<bang>0` to select fullscreen mode:

```vim
" On :LS!, <bang> evaluates to '!', and '!0' becomes 1
command! -bang LS call fzf#run(fzf#wrap({'source': 'ls'}, <bang>0))
```

The command can accept a directory:

```vim
command! -bang -complete=dir -nargs=* LS
    \ call fzf#run(fzf#wrap({'source': 'ls', 'dir': <q-args>}, <bang>0))
```

To assign a unique history name, pass the name as the first argument:

```vim
" The query history for this command will be stored as 'ls' inside g:fzf_history_dir.
" The name is ignored if g:fzf_history_dir is not defined.
command! -bang -complete=dir -nargs=* LS
    \ call fzf#run(fzf#wrap('ls', {'source': 'ls', 'dir': <q-args>}, <bang>0))
```

## Popup and Terminal Layouts

Popup width may be a fraction from `0` to `1`, or an integer of at least `8`. Height may be a fraction from `0` to `1`, or an integer of at least `4`. `xoffset` and `yoffset` default to `0.5`. The default border is `rounded`; supported alternatives include `sharp`, `horizontal`, `vertical`, `top`, `bottom`, `left`, `right`, and `none`.

```vim
let g:fzf_layout = { 'window': { 'width': 0.9, 'height': 0.6 } }
```

fzf uses a terminal buffer on Neovim, GVim, and terminal Vim when a nondefault layout is selected. The terminal buffer’s filetype is `fzf`, allowing `FileType` autocmd customization. For example, a nonpopup layout can temporarily hide the status line:

```vim
if has('nvim') && !exists('g:fzf_layout')
  autocmd! FileType fzf
  autocmd  FileType fzf set laststatus=0 noshowmode noruler
    \| autocmd BufLeave <buffer> set laststatus=2 showmode ruler
endif
```

For tmux popups, use the `tmux` layout setting. This requires tmux 3.2 or newer:

```vim
if exists('$TMUX')
  let g:fzf_layout = { 'tmux': '-p90%,60%' }
else
  let g:fzf_layout = { 'window': { 'width': 0.9, 'height': 0.6 } }
endif
```

Use `:echo fzf#wrap()` to inspect a wrapped specification, and combine `fzf#wrap` with `fzf#run` when defining commands or launching custom finders.
