# curl and libcurl Vulnerability Handling

Published curl and libcurl vulnerabilities are listed on the public security page at `curl.se/docs/security.html`. Vulnerabilities that have not yet been disclosed must be handled privately. They must not be reported in the public issue tracker or discussed on public project mailing lists. Before coordinated disclosure, public commit messages must not identify a change as a security fix.

## Reporting and Initial Review

Security reports are submitted through `hackerone.com/curl`, where they reach selected trusted maintainers. Messages that are unrelated to reporting or managing an undisclosed curl or libcurl vulnerability receive no action.

A member of the security team acknowledges receipt of a report, investigates it, and decides whether to accept or reject it. A rejection includes an explanation. If the report is accepted, the reporter is informed that work on a fix has begun.

The security team then assesses the vulnerability’s impact, develops a fix, and proposes a disclosure schedule. The reporter should be involved in this process where possible. Disclosure should happen promptly, normally through a scheduled release that contains the fix. If the planned release is too far away, the team should consider an earlier, separate release.

## Advisory Preparation

The team prepares a draft advisory describing the problem and its impact. The advisory identifies affected versions and documents available fixes or workarounds. It also records the planned release timing and gives credit to contributors.

The advisory must identify the applicable CWE. A CVE is requested through HackerOne, and the assigned CVE is added to the advisory.

The team may consider notifying `distros@openwall` with the draft advisory so distributions can prepare for disclosure. This notification is subject to the list’s limits: it accepts an embargo of no more than 14 days and does not cover Windows-only flaws.

## Private Fix and Coordinated Release

The fix is first committed on a private branch. The private commit message should contain the CVE. The fix is normally shared with distributions before disclosure.

The fix is merged and pushed to the public `master` branch no more than 48 hours before the release. Public access begins when the change is pushed. After that point, the release follows promptly, once final testing and review are complete. The release must contain the fix.

Before the public push, commit messages and other public project communication must not reveal that the change is a security fix. The private workflow preserves the coordinated nature of the disclosure while allowing the fix and release materials to be prepared.

## Communication and Security-Team Membership

The release and vulnerability are announced through the normal project mailing lists:

- `curl-announce`
- `curl-library`
- `curl-users`

The public security page is updated as part of the announcement process.

`curl-security at haxx.se` is a private discussion list. Membership depends on sustained involvement with the project and an understanding of the project’s work. A person may become a member through invitation or by making a request. There is no public membership roster because membership changes over time.

## Publishing the Advisory

The advisory publication process uses the curl website source checkout. Write the advisory in Markdown and use the customary subtitles. The advisory file is named after the CVE.

Add an entry at the beginning of `curl-www/docs/vuln.pm`. Add the advisory file under `curl-www/docs`. Run `make` in the local website checkout and inspect the rendered result to verify the published presentation. On advisory release day, push the `curl-www` master branch.

These steps ensure that the advisory is included in the website’s vulnerability listing and that the rendered page is reviewed before it becomes public.

## Post-Publication Disclosure

After publication, request disclosure of the corresponding HackerOne issue. Sensitive details from the report or its discussion must be redacted before disclosure.

The policy favors releasing as much information as possible promptly after the vulnerability is public. The public material should therefore provide the documented problem, impact, affected versions, fixes or workarounds, timing, CWE, CVE, and contributor credit, while excluding sensitive report or discussion details.

Bug-bounty information is documented separately at `curl.se/docs/bugbounty.html`.

This workflow describes the historical documented requirements for handling curl and libcurl vulnerabilities, coordinating fixes, preparing releases, publishing advisories, and disclosing related HackerOne issues. It is historical documentation of the project’s recorded process, not an instruction to perform any disclosure now.
