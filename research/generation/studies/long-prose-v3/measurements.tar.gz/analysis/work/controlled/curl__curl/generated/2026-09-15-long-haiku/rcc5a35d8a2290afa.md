# curl Development Chronology: 1996-2020

## Origins and Early Development (1996-1997)

curl's development began in 1996 when Daniel Stenberg required a solution for automated web currency retrieval on an Amiga-channel IRC bot operating on EFnet. Rather than developing from scratch, Stenberg adapted Rafael Sagula's open-source httpget 0.1 as the foundation for this new tool. The initial focus was narrow but purposeful: enabling data retrieval from web sources for a specific networked application.

Development progressed rapidly into 1997. HttpGet 1.0 was released on April 8, introducing HTTP proxy support, a critical feature for networked applications. During the same period, functionality for GOPHER currency retrieval was repaired. The addition of FTP support proved significant enough to warrant a name change; the tool became known as urlget 2.0 in August 1997, reflecting its expanded protocol coverage.

## Establishing the curl Identity (1998-1999)

The year 1998 marked a decisive transition. Upload support requirements prompted a final name change to curl, with curl 4 released on March 20. Notably, the version numbering from this point remained consistent. A trademark complication emerged when Curl Corporation registered CURL as a US trademark on May 18, 1998, after having obtained the curl.com domain in November 1997. However, this registration did not impede development of the open-source curl project.

Security capabilities expanded when SSLeay was added to curl. A freshmeat announcement in August 1998 increased visibility within the developer community. October's curl 4.9 release added cookie support and initiated a significant licensing change from GPL to MPL, reflecting the project's growing maturity at approximately 4,000 lines of code. November brought further infrastructure improvements: the configure system was implemented, broader operating system builds were enabled, and support for the -F option and TELNET protocol were added. December's curl 5 introduced a man page for improved documentation and RPM packaging for Linux distributions.

In 1999, the protocol support expanded further. DICT support arrived in January. OpenSSL replaced SSLeay as the cryptographic backend in February. The first Debian package was created in May, marking curl's entry into mainstream Linux distributions. August 1999 brought LDAP and FILE protocol support, accompanied by approximately 1,300 weekly site visits. The project relocated to curl.haxx.nu as its new domain. Version 6.0 was released in September at approximately 15,000 lines of code. The year concluded with adoption of SourceForge as the project's infrastructure platform on December 28.

## Maturation and Library Development (2000-2002)

The year 2000 initiated a major architectural transformation. An internal library-interface overhaul was completed, leading to the release of nonbeta version 7.1. Critically, the easy interface was introduced in August, enabling developers to integrate curl functionality into their applications more readily. This period saw the codebase grow to approximately 20,000 lines. The project's web presence expanded as the site relocated to curl.haxx.se in June, eventually reaching 4,000 weekly visits by August. PHP adopted libcurl in version 4.0.2, establishing curl as the HTTP backend for a major programming language. This decision prompted development of additional language bindings. Kerberos4 support arrived in September. Testing infrastructure development commenced in November and later underwent complete rewriting. The libcurl shared object name version (SONAME) was designated as 1.

In 2001, version 7.5.2 released in January offered dual licensing under MIT or MPL terms. Version 7.7 arrived on March 22, introducing HTTP/1.1 protocol support with persistent connections. Experimental FTPS support was added, and the codebase expanded to approximately 24,000 lines with SONAME incremented to 2. A significant distribution milestone occurred when Mac OS X 10.1 bundled curl with the operating system in August. Site traffic reached 8,000 weekly visits. Version 7.9 released in September introduced cookie jar functionality and the curl_formadd function, while the multi interface developed during the 7.9.x release series.

Statistics from June 2002 revealed 13,000 weekly site visits and a codebase of 35,000 lines. Successful compilation had been verified on over 40 different CPU and operating system combinations. Approximately 5,000 weekly direct package downloads were recorded, though this figure did not capture total users due to mirrors and distribution bundling. Version 7.10 was released on October 1, establishing MIT as the sole license and enabling SSL certificate verification by default—a security improvement that set standards for subsequent HTTPS implementations.

## Protocol Expansion and Security Enhancements (2003-2005)

Distributed autobuild testing commenced in January 2003, establishing systematic cross-platform verification. By February, site activity had grown to 20,000 weekly visits with approximately three concurrent readers. Digest authentication support was added in May, followed by NTLM and Negotiate authentication mechanisms in June. November's version 7.10.8 contained 45,000 lines of code, served approximately 55,000 unique visitors, and was distributed through five official mirrors. Full FTP-over-SSL support was completed in December.

Version 7.11.0, released in January 2004, introduced support for large file handling. June's version 7.12.0 added internationalized domain name (IDN) support and removed the curl_formparse function, necessitating an SONAME increment to 3. Statistics recorded in August 2004 documented the project's expansion across multiple dimensions of functionality and distribution.

During 2005, optional GnuTLS support and multi_socket functionality were added in April. TFTP protocol support arrived in September. Site traffic exceeded 100,000 visitors with 25 official mirrors. However, a URL-buffer-overflow vulnerability was discovered in December, highlighting the security scrutiny that would characterize subsequent development.

## Protocol Consolidation and Backend Diversification (2006-2008)

In January 2006, Gopher protocol support was removed due to long-standing unnoticed bugs. A TFTP packet overflow vulnerability was reported in March. September brought removal of FTP third-party transfer functionality and an SONAME increment to 4. SCP and SFTP support were added in November. The NSS cryptographic backend was introduced in February 2007. A GnuTLS certificate-verification vulnerability was discovered in July 2007.

By 2008, curl had achieved substantial breadth. Documentation from this period recorded 128 command-line options, 158 curl_easy_setopt() options, 58 public functions in libcurl, 37 language bindings, 683 contributors, 145,000 site visitors, and over 100 gigabytes downloaded.

## Modern Protocol Support and Expanded Backends (2009-2011)

An arbitrary-file-access vulnerability was discovered in March 2009. CMake build system support was added in April. An embedded-zero certificate-name vulnerability was found in August. IMAP, POP3, and SMTP protocol support was introduced in December. RTSP support arrived in January 2010, followed by an excessive data-callback-length vulnerability in February. Git and GitHub replaced CVS for version control in March. RTMP support was added in May, and PolarSSL backend support was implemented. Gopher protocol support was restored in August 2010. August 2010 statistics showed 117 releases, 138 command-line options, 180 curl_easy_setopt() options, 58 public functions, 39 language bindings, and 808 contributors.

During 2011, axTLS backend support was added in February. cyassl, later renamed WolfSSL, backend support was added in April.

## Modern HTTPS and HTTP/2 Era (2012-2016)

Schannel and Darwin SSL backends were added in July 2012. Metalink support and SSH-agent authentication were implemented in October 2012. An internally nonblocking multi-based implementation with blocking wrapper was introduced in February 2013. Initial HTTP/2 work using nghttp2 began in September 2013. krb4 support was removed in October 2013. Happy Eyeballs dual-stack connection establishment was implemented in December 2013.

First released HTTP/2 support arrived in March 2014. September 2014 site traffic recorded 245,000 unique visitors and 236 gigabytes transferred. SMB and SMBS protocol support was added. HTTP/2 multiplexing was implemented in June 2015, server push support in August 2015, and Public Suffix List support in December 2015. The command-line tool defaulted to HTTP/2 for HTTPS connections in January 2016. Version 7.52.0 added HTTPS proxy support in December 2016. Initial TLS 1.3 support was implemented during 2016.

## Recent Expansion and Recognition (2017-2020)

OSS-Fuzz integration for security testing was added in July 2017. Multi-SSL support enabling runtime cryptographic backend selection was implemented in September 2017. Site traffic had grown to 3,100 gigabytes per month. Statistics from 2017 documented 169 releases, 211 command-line options, 249 curl_easy_setopt() options, 74 public functions, and 1,609 contributors. SSLKEYLOGFILE support and the MIME API were added in October, and Daniel Stenberg received the prestigious Polhem Prize. Brotli compression support was added in November 2017.

libssh backend support was added in January 2018. Windows 10 version 1803 bundled curl beginning in March 2018. Bold headers were implemented in July 2018. DNS-over-HTTPS and a URL API were added in October 2018. MesaLink backend support was implemented, and HTTP/2 multiplexing became the default for libcurl HTTPS connections. Estimated installations reached five billion. October 31, 2018's version 7.62.0 statistics recorded 177 releases, 219 command-line options, 261 curl_easy_setopt() options, 80 public functions, and 1,808 contributors. axTLS support was removed in December 2018.

Experimental alt-svc support was added in March 2019. First HTTP/3 requests were completed in August 2019. Parallel command-line downloads were implemented in September 2019's version 7.66.0. By 2020, estimated installations reached ten billion. BearSSL backend support was added in January 2020. PolarSSL support was removed and wolfSSH support was added in March 2020. Experimental MQTT support was implemented in April 2020. zstd compression support was added in August 2020. The website moved to www.curl.se in November 2020 and served ten terabytes of data monthly.
