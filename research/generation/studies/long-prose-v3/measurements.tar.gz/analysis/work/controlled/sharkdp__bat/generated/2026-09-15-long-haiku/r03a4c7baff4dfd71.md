# bat Documentation

## Overview

bat is a cat clone with syntax highlighting, Git integration, automatic paging, and line numbering. It displays files with Git-index modification markers, optional nonprinting-character visibility, and seamless terminal integration. When output is redirected, bat functions as a standard cat replacement, outputting plain file contents without decorations.

## File Display

bat reads files and applies syntax highlighting based on file extension or explicit language specification. The tool automatically detects the programming language or file type and applies appropriate color schemes. Syntax detection works through file extension matching; when extension-based detection fails or produces incorrect results, the `-l` or `--language` flag explicitly sets the syntax definition.

Standard input detection can use a shebang line. When bat receives piped input beginning with a shebang, it extracts the language from that shebang rather than requiring manual specification. This enables natural piping of scripts without explicit flags.

```bash
> curl -s https://sh.rustup.rs | bat
```

bat's display output includes line numbers, Git modification indicators showing changes tracked in the Git index, and a file header with the filename. The grid separates line numbers from content. When output is not a terminal—such as when redirected to a file or piped to another command—bat outputs plain file contents without syntax highlighting, line numbers, or other decorative elements, providing cat-like behavior automatically.

The `-A` or `--show-all` flag highlights nonprinting characters such as spaces, tabs, and line endings. This visualization helps identify whitespace issues and invisible characters in files.

```bash
> bat -A /etc/hosts
```

bat automatically invokes a pager when output exceeds the terminal height, enabling scrolling through long files. Paging behavior can be controlled or disabled as needed.

## Concatenation

bat concatenates multiple files in sequence, combining their contents in the output. Files are processed in the order specified on the command line.

```bash
> bat src/*.rs
```

Multiple files can be concatenated with interleaved content. The `-n` flag displays only line numbers without other style elements.

```bash
bat header.md content.md footer.md > document.md

bat -n main.rs
```

stdin can be mixed into the output sequence. The dash character `-` represents stdin in the file list, allowing files, stdin, and additional files to be output in specified order.

```bash
bat f - g  # output 'f', then stdin, then 'g'.
```

This feature enables combining static content with dynamic input in a single pass.

## Integrations

bat integrates with several standard Unix tools and workflows.

The `find` command's `-exec` option works with bat:

```bash
find … -exec bat {} +
```

This executes bat once with all found files as arguments, displaying them in sequence.

The `fd` tool provides `-X` for batch execution, passing found files to bat:

```bash
fd … -X bat
```

`batgrep` displays ripgrep search results with bat's syntax highlighting. This tool runs ripgrep to find matches and displays matching files with context highlighting.

```bash
batgrep needle src/
```

Real-time file monitoring with `tail -f` can pipe to bat with paging disabled and explicit syntax specification:

```bash
tail -f /var/log/pacman.log | bat --paging=never -l log
```

The `--paging=never` flag prevents pager invocation; the `-l log` flag applies log file syntax highlighting.

`git show` outputs historical file contents from the Git repository. Piping to bat with explicit language specification provides highlighted display of previous file versions:

```bash
git show v0.6.0:src/main.rs | bat -l rs
```

Diff highlighting is not supported natively; the separate `delta` tool is recommended for unified diff display.

When copying highlighted output to clipboard, plaintext output avoids copying syntax highlighting escape sequences and the left gutter. The `--paging=never` flag disables paging and `-p` disables the file header. Piping through `xclip` copies the result to the clipboard:

```bash
bat main.cpp | xclip
```

bat can serve as a pager for manual page display. The `MANPAGER` environment variable configures the pager program. Setting `MANPAGER` to invoke bat with plain output `-p` and man syntax highlighting `-l man` colors manual pages while maintaining proper formatting. The `col -bx` command removes backspace-based formatting before piping to bat.

```bash
export MANPAGER="sh -c 'col -bx | bat -l man -p'"
man 2 select
```

The `batman` script wraps this configuration automatically. However, the Mandoc implementation of man does not support this integration.

The `MANROFFOPT=-c` setting may resolve formatting issues on some systems.

The `prettybat` tool combines code formatters such as prettier, shfmt, and rustfmt with bat, formatting code before syntax highlighting display.

## Installation

### Package Managers

bat is available through major Linux distributions and package managers.

On Ubuntu 19.10 and later:

```bash
apt install bat
```

On Debian Sid:

The package is available through standard installation. On Debian-family systems, the executable may be named `batcat` due to a name clash with another package. Create a symlink or alias to restore the `bat` command:

```bash
mkdir -p ~/.local/bin
ln -s /usr/bin/batcat ~/.local/bin/bat
```

Downloaded .deb archives can be installed directly with dpkg:

```bash
sudo dpkg -i bat_0.16.0_amd64.deb  # adapt version number and architecture
```

Alpine Linux:

```bash
apk add bat
```

Arch Linux:

```bash
pacman -S bat
```

Fedora (including Modular):

```bash
dnf install bat
```

Gentoo:

```bash
emerge sys-apps/bat
```

Void Linux:

```bash
xbps-install -S bat
```

FreeBSD provides both package and port installation:

```bash
pkg install bat
```

Or via ports:

```bash
cd /usr/ports/textproc/bat
make install
```

Nix:

```bash
nix-env -i bat
```

openSUSE:

```bash
zypper install bat
```

macOS via Homebrew:

```bash
brew install bat
```

macOS via MacPorts:

```bash
port install bat
```

Windows via Chocolatey:

```bash
choco install bat
```

Windows via Scoop:

```bash
scoop install bat
```

Windows builds require Visual C++ Redistributable. Chocolatey installs this dependency automatically. Release archives include binaries for many architectures and MUSL static builds for Alpine and other musl-based systems.

### Source Installation

Source builds require Rust 1.40 or later. The Cargo package manager builds and installs bat from source:

```bash
cargo install --locked bat
```

For development, clone the repository, build, and install:

```bash
git clone --recursive https://github.com/sharkdp/bat
cd bat
cargo build --bins
cargo test
cargo install --locked
```

Cargo builds generate man pages and shell completion files in the target build directory but do not install them automatically. These files must be copied manually to the appropriate system directories if desired.

The `--locked` flag uses locked dependency versions from Cargo.lock for reproducible builds.

## Customization

### Themes

The `--list-themes` flag displays available color schemes:

```bash
bat --list-themes | fzf --preview="bat --theme={} --color=always /path/to/file"
```

The `--theme` flag selects a theme for the current invocation:

```bash
--theme="TwoDark"
```

The `BAT_THEME` environment variable sets a default theme persistently.

Theme examples include TwoDark, GitHub, and OneHalfLight. bat assumes dark terminal backgrounds by default. The OneHalfDark and OneHalfLight themes feature brighter grid and line colors for improved visibility.

Base color schemes vary in complexity. ansi-dark and ansi-light use three-bit ANSI colors, supporting only eight colors. base16 uses four-bit colors (sixteen colors) following base16 styling conventions. base16-256 maps some bright colors into color slots 16–21 for compatibility with base16-shell, providing smoother integration with base16 terminal color schemes. base16-256 is not a generic choice for all 256-color terminals.

Restricted themes track terminal palette changes and blend with other terminal software when system colors are modified.

Custom themes in `.tmTheme` format can be installed in the configuration directory:

```bash
mkdir -p "$(bat --config-dir)/themes"
cd "$(bat --config-dir)/themes"
git clone https://github.com/greggb/sublime-snazzy
bat cache --build
```

After adding custom themes, the binary cache must be rebuilt with `bat cache --build`. Verify availability with `--list-themes`. To return to default themes, clear the cache with `bat cache --clear`.

### Styles and Output Elements

The `--style` flag controls which output elements appear. Comma-separated values select specific components:

```bash
--style="numbers,changes,header"
```

The `numbers` element shows line numbers. The `changes` element displays Git index modification indicators. The `header` shows the filename. The `grid` element draws dividing lines. Combining `numbers,changes` omits the grid and header for compact line-numbered output with Git markers.

The `BAT_STYLE` environment variable sets a default style persistently, and configuration files can specify styles.

### Syntax Highlighting

bat uses syntect, which reads Sublime .sublime-syntax files for syntax definitions. Custom language definitions can be placed in the configuration directory:

```bash
mkdir -p "$(bat --config-dir)/syntaxes"
cd "$(bat --config-dir)/syntaxes"
git clone https://github.com/tellnobody1/sublime-purescript-syntax
bat cache --build
```

After installing custom syntax definitions, rebuild the binary cache. Verify availability with `--list-languages`. Clearing the cache returns to built-in definitions.

The `--map-syntax` flag maps file patterns to specific syntax definitions:

```bash
--map-syntax "*.ino:C++"
--map-syntax ".ignore:Git Ignore"
```

### Tab Expansion

bat expands tabs to four spaces before paging by default. The `--tabs` flag changes the expansion width:

```bash
--tabs=8
```

Setting `--tabs=0` passes tabs through to the pager without expansion. Tabs are expanded before paging, so pager tab-stop settings cannot affect already-expanded spaces.

### Pager Configuration

bat uses a pager to display long files. Pager selection follows precedence: `BAT_PAGER` environment variable, then `PAGER` environment variable, then less as fallback. The `--pager` flag overrides environment variables.

```bash
export BAT_PAGER="less -RF"
```

When less is the pager and no explicit arguments are provided, bat supplies default arguments: `-R` enables ANSI color output, and `-F` enables quit-if-one-screen behavior (automatically exit if output fits on one screen).

For less versions older than 530, bat adds `-X` to work around a quit-if-one-screen bug, at the cost of disabling mouse-wheel support. Selecting only `-R` on those older versions restores wheel support but disables automatic short-output quit.

The `--paging=never` flag disables paging entirely, suitable for piping output or integration with other tools.

### Configuration Files

The `--config-file` flag prints the platform-dependent configuration directory path:

```bash
bat --config-file
```

The `BAT_CONFIG_PATH` environment variable selects an alternative configuration file:

```bash
export BAT_CONFIG_PATH="/path/to/bat.conf"
```

The `--generate-config-file` flag creates a default configuration file with example settings:

```bash
bat --generate-config-file
```

Configuration files contain a list of command-line arguments, one per line, with `#`-prefixed comments:

```
# Set the theme to "TwoDark"
--theme="TwoDark"

# Show line numbers, Git modifications and file header (but no grid)
--style="numbers,changes,header"

# Use italic text on the terminal (not supported on all terminals)
--italic-text=always

# Use C++ syntax for .ino files
--map-syntax "*.ino:C++"

# Use ".gitignore"-style highlighting for ".ignore" files
--map-syntax ".ignore:Git Ignore"
```

## Platform-Specific Considerations

### Windows

Windows Command Prompt, PowerShell, and Git Bash support ANSI colors in Windows 10 version 1511 and later. Newer Bash versions provide color support. Older Windows systems can use Cmder or ConEmu for color terminal emulation.

The native Windows `more` pager has limited functionality. Install less and add it to PATH, or configure an alternative pager:

```bash
export BAT_PAGER="less -RF"
```

Chocolatey installs less automatically when installing bat via `choco install bat`. Otherwise, install less separately.

Git or MSYS less may misinterpret ANSI color codes. If colors display incorrectly, disable paging with `--paging=never` or set `BAT_PAGER` to an empty string.

Native bat cannot interpret Cygwin `/cygdrive` paths. A shell wrapper converts Cygwin paths to Windows paths before invoking bat:

```bash
bat() {
    local index
    local args=("$@")
    for index in $(seq 0 ${#args[@]}) ; do
        case "${args[index]}" in
        -*) continue;;
        *)  [ -e "${args[index]}" ] && args[index]="$(cygpath --windows "${args[index]}")";;
        esac
    done
    command bat "${args[@]}"
}
```

### Color Support

Truecolor (24-bit color) support requires the terminal to expose the `COLORTERM=truecolor` or `COLORTERM=24bit` environment variable. If truecolor is not available, bat falls back to eight-bit colors (256 colors).

Restricted themes adjust color output based on detected terminal capabilities and should be selected when terminal color depth is limited.

### Encoding

bat natively supports UTF-8 and UTF-16 encoded files. Other encodings must be converted to UTF-8 before processing. The `iconv` tool converts between encodings:

```bash
iconv -f ISO-8859-1 -t UTF-8 my-file.php | bat
```

If encoding detection fails for converted files, specify syntax explicitly with `-l` to ensure correct highlighting.

### macOS Theme Selection

The supplied macOS snippet selects default or GitHub theme based on system dark/light appearance:

```bash
alias cat="bat --theme=\$(defaults read -globalDomain AppleInterfaceStyle &> /dev/null && echo default || echo GitHub)"
```

## Project Information

bat is maintained by sharkdp and eth-p. The project aims to provide syntax highlighting, Git integration, POSIX-cat replacement functionality, and a usable command-line interface. The license is dual: MIT or Apache 2.0. Copyright is held by bat-developers, 2018–2020.
