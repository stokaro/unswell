# Diesel Development and Contribution Guide

This documentation provides comprehensive instructions for reporting issues, requesting features, and setting up a local development environment for Diesel. By following these guidelines, contributors can ensure their work aligns with project standards and maintains code quality.

## Reporting Issues and Requesting Features

Diesel welcomes suggestions, bug reports, and pull requests from the community. Before submitting a new issue, contributors are encouraged to visit the Diesel Gitter channel to ask questions or seek help. This community space often resolves inquiries quickly and prevents duplicate reports. Please note that the Diesel Code of Conduct applies in all Diesel spaces, not just on GitHub.

### Bug Reports

To facilitate efficient debugging, bug reports must include specific details. Before filing a report, search both open and closed issues for similar subjects to avoid duplicates. A valid bug report must contain:
*   The versions of Rust and Diesel being used.
*   Any relevant feature flags enabled during compilation.
*   The intended result versus the actual behavior.
*   The full error message or output.
*   A reproduction case, which should include sufficient code, a public repository, or a Gist.
*   The relevant database schema used in the reproduction.

### Feature Requests

Feature requests should clearly explain the goal of the proposed change. Contributors should outline the proposed support or implementation strategy, discuss alternative approaches considered, and list any disadvantages or trade-offs associated with the new feature. This context helps maintainers evaluate the fit of the feature within the project’s roadmap.

## Local Development Setup

Developing Diesel locally requires a Rust installation managed by `rustup`. This tool allows for switching between stable, nightly, and beta toolchains, ensuring compatibility across different environments. This snapshot supports all three channels.

### Database Configuration

Before running tests, you must install the system libraries for the database backends you intend to test. While all drivers allow running the full test suite, specific setup steps apply to different operating systems. On macOS, SQLite requires no additional installation. PostgreSQL’s `libpq` is generally already present in the environment. For MySQL and PostgreSQL servers, you can use Homebrew by running `brew install postgresql mysql`. Follow the specific server setup instructions provided by your package manager to ensure the services are running correctly.

### Repository Cloning and Environment Variables

Clone the Diesel repository and navigate to the root directory. Copy the `.env.sample` file to `.env` and populate it with your database connection details. This file guides the test suite in connecting to the correct databases.

### Handling MySQL Compatibility

Note that in this snapshot, MySQL tests may fail on MySQL 5.6 or earlier versions. If you cannot upgrade MySQL locally, using Docker is a recommended alternative. The selected MySQL test user may require privileges on databases matching the pattern `diesel_%`. The source repository includes Docker commands to create the necessary `diesel_test` and `diesel_unit_test` databases. Alternatively, you can use `docker-compose up` to manage these services.

## Running Tests and Verifying Setup

Once the environment is configured, verify your local setup by running `bin/test`. Be aware that the first compilation may take a significant amount of time as it builds all dependencies.

### Code Formatting and Linting

Source formatting in Diesel follows the Rust Style Guide and utilizes `rustfmt`. The project specifies the required toolchain in `rust-toolchain`. To ensure your code passes quality checks, you must install `rustfmt-preview` and `clippy-preview`.

Run `cargo clippy` to check for warnings. Pull requests must compile without warnings. To check for formatting differences without modifying files, use:
```bash
cargo fmt --all -- --check
```
This command succeeds silently if formatting matches the standard. If there are unexpected differences in untouched code, it may indicate the wrong `rustfmt` version is installed. To apply corrections automatically, run:
```bash
cargo fmt --all
```
Editor integration is also available for these tools, allowing for real-time feedback during development.

## Technical Abbreviations

Understanding common abbreviations is crucial for reading Diesel’s source code and documentation:
*   **ST**: SQL type, generally constrained by `NativeSqlType`.
*   **DB**: Database, generally constrained by `Backend`.
*   **QS**: Query source, often unconstrained but sometimes constrained by `QuerySource`.
*   **PK**: Primary key.
*   **Lhs/Rhs**: Left and right-hand sides, typically used in binary expressions.
*   **Conn**: Connection.

Prefer descriptive type names, such as `Lhs` and `Rhs` for binary expressions, over generic placeholders like `T` and `U`. This practice enhances code readability and maintainability.

## Docker Automation

For developers preferring containerized environments, the repository provides shell scripts to automate database setup. The following script initializes MySQL and PostgreSQL containers, creating the necessary test databases:

```bash
#!/usr/bin/env sh
set -e
docker run -d --name diesel.mysql -p 3306:3306 -e MYSQL_ALLOW_EMPTY_PASSWORD=true mysql
while
  sleep 1;
  ! echo 'CREATE DATABASE diesel_test; CREATE DATABASE diesel_unit_test;' | docker exec -i diesel.mysql mysql
do sleep 1; done

docker run -d --name diesel.postgres -p 5432:5432 postgres
while
  sleep 1;
  ! echo 'CREATE DATABASE diesel_test;' | docker exec -i diesel.postgres psql -U postgres
do :; done
```

Alternatively, users can leverage `docker-compose` for orchestration:
```bash
$ docker-compose up
```

By adhering to these guidelines, contributors ensure a smooth development experience and maintain the high standards expected in the Diesel project.
