# fzf Version History: 0.9.3 through 0.24.3

## Overview

This document records the functional changes and technical improvements introduced in fzf releases from version 0.9.3 through version 0.24.3. Each version entry describes new features, behavioral modifications, and relevant implementation details.

## Version 0.9.3

Version 0.9.3 introduces the `--sync` option and improves initialization behavior. The `--sync` option restores buffered parallel filtering, allowing users to control whether results are filtered in parallel or sequentially. The finder now starts promptly when `--select-1` and `--exit-0` conditions cannot be met, preventing unnecessary delays.

## Version 0.9.4

This release adds streaming reversal via the `tac` command. The implicit reverse order previously applied by `--no-sort` is removed. Results from filter and `--no-sort` operations now stream unless `tac` or `--sync` requires buffering. Streaming results are processed sequentially, while the `--sync` flag restores the buffered parallel filtering behavior.

## Version 0.9.5

Version 0.9.5 introduces optional ANSI interpretation and stripping capabilities without full truecolor support at this version. Startup performance is improved by reducing pointer copying on initialization. A panic occurring with `--no-sort` and empty filters is fixed.

## Version 0.9.6

The `--expect` option is introduced in this release, allowing users to specify keys that trigger exit with special behavior. The accepting key is printed before results, enabling integration with editors like Vim for opening selected choices. An ANSI erase-line sequence is now properly ignored.

## Version 0.9.7

This version adds the `--toggle-sort` action and fixes the handling of expected output and comma bindings.

## Version 0.9.8

Version 0.9.8 fixes Unicode case handling and RuneError issues.

## Version 0.9.9

The `--tiebreak` option is added for result ranking control. The `--no-hscroll` option is introduced, and `--toggle-sort` now provides indication of sort status.

## Version 0.9.10

Memory usage is reduced through optimized memoization. Light color variants are added to the color palette.

## Version 0.9.11

The `--inline-info` option is introduced for compact information display. Case mutation handling is fixed, and per-term smart case behavior is corrected. Double-click handling for scrolled items is improved.

## Version 0.9.12

The `--bind` option is added for key binding customization. Resize information and ANSI offset calculations are fixed.

## Version 0.9.13

Color customization becomes available through the `--color` option. Reader termination for inputs exceeding 64 KB is fixed.

## Version 0.10.0

This major release introduces multiple significant features. The `--select`, `--deselect`, and `--toggle-all` actions enable programmatic selection control. The `--ignore` option filters results. The execute feature supports delimiter-based argument extraction. History functionality is introduced with a default of 1,000 entries, along with history navigation keys. The `--cycle` option enables wrap-around navigation. Fixes include spinner, marker, and anchored query behavior. The colon form of execute requires no closing delimiter and must terminate the binding list.

## Version 0.10.1

Margins and sticky headers are added. The `--cancel` and `--delete-char-eof` actions are introduced. Colon and comma binding handling is fixed, as is multiline ANSI rendering.

## Version 0.10.2

Query and rune conversion processes are improved, and nth ranking is enhanced. ncurses initialization failures are handled gracefully. Filenames beginning with a dash are now handled correctly.

## Version 0.10.3

Delimiter processing is optimized by treating nonspecial patterns as literal and simplifying regex patterns.

## Version 0.10.4

ANSI codes are removed from `--with-nth` output.

## Version 0.10.5

The `--quote-prefix` option enables unquoting of quoted input. Backward end scans are supported.

## Version 0.10.6

The `--header-file` option is replaced with `--header`, which combines the functionality of header and header-lines options. Exit codes are standardized: 0 for successful selection, 1 for no match, 2 for error, and 130 for interruption. Linux builds now statically link ncurses.

## Version 0.10.7

Execute interrupts are serialized, and nth length is used for tiebreak calculations on trimmed items.

## Version 0.10.8

Setting colors after disabling them is fixed.

## Version 0.10.9

Extended search becomes the default mode. The `--extended-exact` option is replaced with the orthogonal `--exact` option. Nonprinting characters are suppressed from output. Double-click support is improved, and resize handling is enhanced.

## Version 0.11.0

OR searching and `--execute-multi` are introduced. Wide-character prompt positioning is fixed. The `--tiebreak` option accepts ordered distinct criteria with index as the last implicit criterion; the default order is length,index. The `begin` tiebreak criterion ignores leading whitespace. Toggle-in and toggle-out actions adapt to reversed layouts. Initial ongoing-input rendering delay decreases from up to 100 milliseconds to 20 milliseconds when tac is absent.

## Version 0.11.1

The `--tabstop` option is added to control tab character width.

## Version 0.11.2

The `--tiebreak` option now accepts ordered distinct criteria. The index criterion is last and implicit; the default is length,index. The `begin` criterion ignores leading whitespace. Toggle-in and toggle-out adapt to reversed layout. Initial ongoing-input rendering delay improves from up to 100 milliseconds to 20 milliseconds when tac is absent.

## Version 0.11.3

SIGTERM is handled gracefully. The selected shell is used for execute and default command execution. Completion generation and postprocessing APIs change.

## Version 0.11.4

The `--hscroll-off` option is introduced with a default value of 10, controlling horizontal scroll margin.

## Version 0.12.0

A new ranking algorithm is introduced via `--algo=v1|v2`, improving search result ordering.

## Version 0.12.1

The new ranking is applied universally, and exact-cache references are fixed. The build uses Go 1.12.

## Version 0.12.2

256-color detection is improved to work without checking TERM substrings. The `--print-query` option is added. Function keys F1–F10 and Alt+slash, Alt+space, and Alt+enter are supported. The `jump` and `jump-accept` actions are introduced.

## Version 0.13.0

Preview windows are introduced as a major feature. Single-quoted placeholders execute their contents. Bracketed-paste control characters are ignored.

## Version 0.13.1

Large ANSI output handling is fixed.

## Version 0.13.2

Clearing race conditions are fixed.

## Version 0.13.3

Duplicate preview lines are fixed.

## Version 0.13.4

Performance improvements are reported: 60% lower ASCII-string memory, 15–20% query improvement, and up to 45% faster nonregex nth delimiters. Hidden previews are fixed.

## Version 0.13.5

Up to twice the speed and half the memory are reported compared to previous versions.

## Version 0.15.0

Scoring is improved with `--algo=v1|v2` options. NUL input and output are supported via `--read0` and `--print0`.

## Version 0.15.1

Matches beyond column 2^15 are fixed, and very long-line rendering delays are eliminated.

## Version 0.15.2

Scrollable previews and preview actions are added. Intensity and VT100 handling are improved.

## Version 0.15.3

Additional ANSI styles are supported. Toggle-preview race conditions are fixed.

## Version 0.15.4

Field ranges and `{q}` placeholders are added. Unicode whitespace is supported. Preview scroll indicators are shown. Exact inverse matching becomes the default; inverse fuzzy matching remains available via the documented quote prefix.

## Version 0.15.5

Foreground color changes no longer force a black background. The `end` tiebreak criterion becomes relative. The `g:fzf_colors` variable in Vim wrap mode is honored.

## Version 0.15.6

Windows binaries are provided. Header clearing, control-character display, and WSL escape sequence handling are fixed, with up to 100 milliseconds waiting support.

## Version 0.15.7

Color-disabled and header-ANSI panic conditions are fixed.

## Version 0.15.8

VT100 and WSL handling are expanded. The `--no-bold` and `--bold` options are added. Alt digits and F11/F12 keys are supported.

## Version 0.15.9

Rendering regressions are fixed. A 50 millisecond escape delay is set and configurable via ESCDELAY. Overflowing preview indicators are always shown. ncurses6 and tcell extra color and italic features are supported.

## Version 0.16.0

The `--height` option is introduced, enabling flexible sizing on compatible terminals. Previews are truncated by default with optional wrapping. Latin accent normalization is applied by default with `--literal` to opt out. The `--filepath-word` option is added.

## Version 0.16.1

Height backgrounds are fixed. Half-page actions are added. The `-L` flag is added to find.

## Version 0.16.2

ncurses is removed as a dependency. FreeBSD, OpenBSD, and ARM binaries are provided. 24-bit color is supported. Chained actions with `+` are allowed. Zero-size hidden preview execution is permitted.

## Version 0.16.3

Trimmed tab rendering is fixed. The `+` multi-selection placeholder is added. Execute-silent operates without alternate-screen switching. The `--ctrl-space` binding is added.

## Version 0.16.4

The original horizontal border style is introduced as an option.

## Version 0.16.5

The `--toggle-preview-wrap` action is added. The build uses Go 1.8.

## Version 0.16.6

The `--no-clear` option is added to preserve screen output.

## Version 0.16.7

Ctrl+Alt letter combinations are supported. Ctrl+Z triggers SIGSTOP. The FZF_PREVIEW_WINDOW environment variable is introduced.

## Version 0.16.8

The `change` and `top` actions are added. nth tiebreak, prompt tab, and page-cycle overshoot issues are fixed. Git revision is included in `--version` output. Cygwin and Windows integration are improved.

## Version 0.16.9

About 20% general speed improvement is reported. ANSI processing shows up to fivefold improvement and memory usage is reduced by up to 50%. Bracketed-paste support is added. Command-error display and preview rendering are improved. Repeated `--no-clear` usage is optimized.

## Version 0.16.10

Preview ANSI handling is repaired and `--ansi` is improved.

## Version 0.16.11

Missed preview updates are fixed and performance is optimized.

## Version 0.17.0

Performance is optimized globally. Escaped literal spaces are matched correctly. The `--expect` option becomes additive.

## Version 0.17.0-2

Auxiliary scripts are modified: experimental Vim8/GVim terminal use, Fish shell handling, and fzf-tmux output and tput fixes.

## Version 0.17.1

Preview and Windows backgrounds are fixed. cmd.exe execution operates without extra parsing or escaping. The Vim8 terminal-window layout is added.

## Version 0.17.3

Preview dimensions are exported. Command error reporting is improved. Filesystem-loop duplicate behavior reverts to requiring find `-fstype`. Mouse buttons are distinguished with right-click toggle. The `--replace-query` and `--accept-non-empty` actions are added.

## Version 0.17.4

The `--layout=reverse-list` option is added with aliases for reverse and default layouts. Preview refresh without matches when placeholders are nonempty is supported. Shifted and Alt arrow keys are expanded. Fallback without `/dev/tty` is provided. Windows default-command changes are made. Bash and Zsh fixes are applied. The `--xdg` installation paths option is added.

## Version 0.17.5

Queries up to 300 characters wide are permitted, exceeding the screen width. The build uses Go 1.11.1.

## Version 0.18.0

Zero-based index placeholders `{n}` and `{+n}` are added. The gutter color option is introduced. ASCII borders are available via `--no-unicode`. The FZF_PREVIEW_LINES and FZF_PREVIEW_COLUMNS environment variables are added alongside LINES and COLUMNS. The build uses Go 1.12.1.

## Version 0.19.0

The `--phony` option enables selector-only use without input-driven filtering. The `reload` action replaces candidate lists. The `--multi` option accepts a selection cap. The `f` placeholder flag uses temporary files for large selections that might exceed ARG_MAX. The `deselect-all` action affects only matching items. The Bash completion setup helper is added. Default, inline, and hidden info styles are introduced. The `noborder` preview style is available. Trailing spaces in `--with-nth` are trimmed. Ctrl+backslash, Ctrl+bracket, Ctrl+caret, and Ctrl+slash bindings are added.

## Version 0.20.0

Preview foreground and background colors are configurable via `--color` with `preview-fg` and `preview-bg`. The `clear-query` and `clear-selection` actions are introduced. Composite bindings are supported through multiple `--bind` options using a leading `+` prefix. Reload flicker is removed. Parsing of `+` in execute and reload is fixed. Reload without matches and unfilled header-line clearing are corrected.

## Version 0.21.0

The `--height` option becomes available on Windows. The `--pointer` and `--marker` options enable customization of selection indicators. The `--keep-right` option keeps the right end of lines visible when too long. Border styling changes to display rounded corners; the previous horizontal style remains available via `--border=horizontal`. Unicode spinner improvements are made. Additional key and action bindings are provided. A PowerShell script for downloading Windows binaries is added. Vim plugin support for built-in floating windows is introduced via `g:fzf_layout` with window dimensions specified as `{ 'window': { 'width': 0.9, 'height': 0.6 } }`. Bash Ctrl+R completion begins with existing input and supports multiline commands. The fuzzy-completion API changes to accept multiple fzf arguments before `--` instead of a single string argument.

## Version 0.21.1

The Ctrl+R history is deduplicated to avoid repeated entries. tmux 3.2+ popup support is added. Windows traversal and keep-right ANSI handling are fixed. Zsh completion is fixed. The build uses Go 1.14.1.

## Version 0.22.0

The `backward-eof` action aborts when backspacing at an empty query prompt. The `refresh-preview` action reruns the preview command. Additional preview bindings enable dynamic preview manipulation. Initial preview scroll offsets control the starting position within previews. ANSI prompts are supported. Smart accented-character matching matches unaccented queries against both accented and unaccented text, while accented queries require accents. The Vim tmux layout is added. The build uses Go 1.14.9 after addressing performance regression #40727.

## Version 0.23.0

Preview offsets relative to window height are introduced via `--preview-window` with expressions like `+{2}-/2`. The `sharp` and `cycle` options for preview behavior are added. Padding reduction without borders is supported. Half-page preview actions enable screen-relative scrolling. Absolute Vim popup sizes are available through the `g:fzf_layout` window configuration. The `fzf#exec` function locates and downloads the binary. The build uses Go 1.15.2 and stops providing 32-bit binaries.

## Version 0.23.1

Preview-window options `nocycle`, `nohidden`, `nowrap`, and `default` are added. The build uses Go 1.14.9 to address performance regression #40727.

## Version 0.24.0

Preview output is rendered in real time as commands produce results. Regular, bold, dim, underline, italic, reverse, and blink color styles are introduced via `--color`. Vertical, top, bottom, left, and right borders are added to preview windows, with Vim border adaptation. The zero selected count displays in multi mode as `(0)`. Binary uploads to GitHub Releases begin.

## Version 0.24.1

The `--color=bw` and `--color=no` options are repaired.

## Version 0.24.2

Fixes and improvements are applied throughout the codebase.

## Version 0.24.3

The `--padding` option is introduced, allowing margin specification around the entire interface.

## Code Examples and Configuration

The `--margin` and `--padding` options control spacing:

```sh
fzf --margin 5% --padding 5% --border --preview 'cat {}' \
    --color bg:#222222,preview-bg:#333333
```

Preview windows render output in real time as commands complete:

```sh
fzf --preview 'sleep 1; for i in $(seq 100); do echo $i; sleep 0.01; done'
```

ANSI escape sequences for display clearing are supported in previews:

```sh
fzf --preview 'for i in $(seq 100000); do
  (( i % 200 == 0 )) && printf "\033[2J"
  echo "$i"
  sleep 0.01
done'
```

Style attributes combine and may depend on terminal support:

```sh
rg --line-number --no-heading --color=always "" |
  fzf --ansi --prompt "Rg: " \
      --color fg+:italic,hl:underline:-1,hl+:italic:underline:reverse:-1 \
      --color pointer:reverse,prompt:reverse,input:159 \
      --pointer '  '
```

Vim floating windows support absolute and relative sizing:

```vim
let g:fzf_layout = { 'window': { 'width': 0.9, 'height': 0.6 } }
let g:fzf_layout = { 'window': { 'width': 1.0, 'height': 0.5, 'border': 'horizontal' } }
let g:fzf_layout = { 'window': { 'width': 0.5, 'height': 1.0, 'border': 'vertical' } }
let g:fzf_layout = { 'window': { 'width': 1.0, 'height': 0.5, 'yoffset': 1.0, 'border': 'top' } }
let g:fzf_layout = { 'window': { 'width': 0.5, 'height': 1.0, 'xoffset': 1.0, 'border': 'left', 'highlight': 'Comment' } }
```

Multi-selection displays the selection cap and current count:

```sh
seq 100 | fzf
  # 100/100
seq 100 | fzf --multi
  # 100/100 (0)
seq 100 | fzf --multi 5
  # 100/100 (0/5)
```

Preview windows use delimiter-based field extraction and offsets:

```sh
git grep --line-number '' |
  fzf --delimiter : \
      --preview 'bat --style=numbers --color=always --highlight-line {2} {1}' \
      --preview-window +{2}-/2
```

The `backward-eof` binding aborts on empty query backspace:

```sh
fzf --bind backward-eof:abort
```

The `refresh-preview` binding reruns the preview command:

```sh
fzf --preview 'echo $RANDOM' --bind '?:refresh-preview'
```

Preview bindings work with or without default preview commands:

```sh
fzf --preview 'file {}' --bind '?:preview:cat {}'
fzf --bind '?:preview:cat {}'
fzf --bind '?:preview:cat {}' --preview-window hidden
```

Initial scroll offsets control preview positioning:

```sh
git grep --line-number '' |
  fzf --delimiter : --preview 'nl {1}' --preview-window +{2}-5
```

tmux popup layout is specified via `g:fzf_layout`:

```vim
let g:fzf_layout = { 'tmux': '-p90%,60%' }
```

The `--phony` option enables input-driven filtering without initial data:

```sh
: | fzf --bind 'change:reload:seq {q}' --phony
```

Composite bindings accumulate actions across multiple `--bind` options:

```sh
fzf --bind 'ctrl-a:up' --bind 'ctrl-a:+up'
fzf --multi --bind 'ctrl-l:select-all+execute:less {+f}' --bind 'ctrl-l:+deselect-all'
fzf --multi --bind 'ctrl-l:select-all+execute(less {+f})+deselect-all'
```

The `--phony` option enables ripgrep integration with query-driven reload:

```sh
RG_PREFIX="rg --column --line-number --no-heading --color=always --smart-case "
INITIAL_QUERY="foo"
FZF_DEFAULT_COMMAND="$RG_PREFIX '$INITIAL_QUERY' || true" \
  fzf --bind "change:reload:$RG_PREFIX {q} || true" \
      --ansi --phony --query "$INITIAL_QUERY"
```

Multi-selection with cap constraints behavior:

```sh
seq 100 | fzf --multi 3 --reverse --height 50%
seq 100000 | fzf --multi --bind ctrl-a:select-all \
                  --preview "awk '{sum+=\$1} END {print sum}' {+f}"
```

The `_fzf_setup_completion` helper configures completion for multiple commands:

```sh
_fzf_setup_completion path git kubectl
```

The `--expect` option specifies multiple keys that trigger exit:

```sh
fzf --expect=ctrl-v,ctrl-t,alt-s,f1,f2,~,@
```

History reversal and sorting:

```
history | fzf +s --tac
```
