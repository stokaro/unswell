# FZF Vim Integration API and Configuration

The fzf.vim plugin provides a robust integration between the fzf command-line utility and the Vim editor. This documentation outlines the installation requirements, core API functions, global configuration settings, layout management, and custom command creation.

## Installation and Setup

To enable fzf integration, the plugin must be installed and its directory added to Vim’s runtime path. The specific location depends on the package manager used.

For users of **vim-plug**, the plugin can be specified in the `.vimrc` file. If fzf is installed via Homebrew, the path is `/usr/local/opt/fzf`. If installed via git directly, it is typically `~/.fzf`.

```vim
" If installed using Homebrew
Plug '/usr/local/opt/fzf'

" If installed using git
Plug '~/.fzf'
```

Alternatively, users can fetch the newest version of the plugin from GitHub:

```vim
Plug 'junegunn/fzf'
```

To ensure the fzf binary remains up-to-date, an optional update hook can be configured. This hook automatically updates the binary when the plugin is updated:

```vim
Plug 'junegunn/fzf', { 'do': { -> fzf#install() } }
```

The plugin requires an fzf executable to be available on the system PATH. If fzf is not found, the plugin may request permission to download it. Additionally, setting `g:fzf_history_dir` enables per-command history storage.

## Core API

The primary interface for launching fzf within Vim consists of two main functions: `fzf#run` and `fzf#wrap`.

### fzf#run(spec)

The `fzf#run` function launches the fzf finder using a specification table (`spec`). This table defines the source of input, how selections are handled, and optional layout parameters.

*   **Source**: The `source` key can be a string containing a shell command (e.g., `'find .'`) or a Vim list. If omitted, fzf defaults to listing files in the current directory using `find` or the command specified in `FZF_DEFAULT_COMMAND`.
*   **Sink**: The `sink` key determines how selected items are processed. It can be a string representing a Vim command (e.g., `'e'` for edit, `'tabedit'` for tab split) or a function reference. Each selection is passed individually to the sink. Alternatively, `sink*` (note the asterisk) accepts a function reference that processes all output lines at once as a list.
*   **Options**: The `options` key accepts either a string or a list of arguments. Using a list is recommended to avoid shell escaping issues. For example:
    ```vim
    call fzf#run({'options': ['--reverse', '--prompt', 'C:\Program Files\']})
    ```
*   **Directory**: The `dir` key sets the working directory for the fzf process.
*   **Layout**: Keys such as `up`, `down`, `left`, and `right` define the window position and size. The `window` key can specify a Vim command to open the window or a dictionary for popup settings.

Example usage:
```vim
" Look for files under current directory
call fzf#run({'sink': 'e'})

" Look for git files in a split window
call fzf#run({'source': 'git ls-files', 'sink': 'e', 'left': '40%'})
```

### fzf#wrap([name], [spec], [fullscreen])

`fzf#wrap` returns a specification table extended with global preferences defined in `g:fzf_*` variables. This includes layout, colors, history settings, and opening actions. The arguments are optional:
*   `name`: If provided and `g:fzf_history_dir` is configured, this name is used to key the history.
*   `fullscreen`: Defaults to `0`. Accepts `0` or `1`.

Wrapped specs inherit global settings. However, `g:fzf_action` applies only when no custom `sink` or `sink*` is defined, as arbitrary entries require custom handling.

Example:
```vim
call fzf#run(fzf#wrap({'source': 'ls'}))
```

## Global Settings

Several global variables allow customization of fzf's behavior and appearance.

### g:fzf_action

This dictionary defines keybindings for opening files. It maps keys to actions such as `'split'`, `'vsplit'`, or `'tab split'`. It can also map keys to functions for custom processing.

```vim
let g:fzf_action = {
  \ 'ctrl-t': 'tab split',
  \ 'ctrl-x': 'split',
  \ 'ctrl-v': 'vsplit' }
```

Custom functions can be used to process selected lines:
```vim
function! s:build_quickfix_list(lines)
  call setqflist(map(copy(a:lines), '{ "filename": v:val }'))
  copen
  cc
endfunction

let g:fzf_action = {
  \ 'ctrl-q': function('s:build_quickfix_list'),
  \ 'ctrl-t': 'tab split',
  \ 'ctrl-x': 'split',
  \ 'ctrl-v': 'vsplit' }
```

### g:fzf_layout

This variable controls the window placement. It supports various layout styles:
*   **Popup**: Defined by a dictionary with `width` and `height`. Width is a fraction (0-1) or integer (>=8). Height is a fraction (0-1) or integer (>=4). Optional offsets are `xoffset` and `yoffset` (default 0.5). Border styles include `'rounded'`, `'sharp'`, `'horizontal'`, `'vertical'`, and individual sides.
*   **Directional**: Using `down`, `up`, `left`, or `right` with a percentage or pixel value (e.g., `'40%'`).
*   **Vim Command**: Using the `window` key with a command like `'enew'`, `'-tabnew'`, or `'30vnew'`.
*   **Tmux**: Using the `tmux` key with fzf-tmux options (requires tmux 3.2+).

```vim
" Default popup layout
let g:fzf_layout = { 'window': { 'width': 0.9, 'height': 0.6 } }

" Downward layout
let g:fzf_layout = { 'down': '40%' }

" Tmux layout
if exists('$TMUX')
  let g:fzf_layout = { 'tmux': '-p90%,60%' }
else
  let g:fzf_layout = { 'window': { 'width': 0.9, 'height': 0.6 } }
endif
```

### g:fzf_colors

This dictionary maps UI elements to Vim highlight groups. It translates to `--color` options. Elements include `fg`, `bg`, `hl`, `fg+`, `bg+`, `hl+`, `gutter`, `pointer`, `marker`, `border`, `header`, `info`, `spinner`, and `prompt`. Each value is a list containing a type (`fg`, `bg`, or `hl`) and one or more Vim highlight groups.

```vim
let g:fzf_colors =
\ { 'fg':      ['fg', 'Normal'],
  \ 'bg':      ['bg', 'Normal'],
  \ 'hl':      ['fg', 'Comment'],
  \ 'fg+':     ['fg', 'CursorLine', 'CursorColumn', 'Normal'],
  \ 'bg+':     ['bg', 'CursorLine', 'CursorColumn'],
  \ 'hl+':     ['fg', 'Statement'],
  \ 'info':    ['fg', 'PreProc'],
  \ 'border':  ['fg', 'Ignore'],
  \ 'prompt':  ['fg', 'Conditional'],
  \ 'pointer': ['fg', 'Exception'],
  \ 'marker':  ['fg', 'Keyword'],
  \ 'spinner': ['fg', 'Label'],
  \ 'header':  ['fg', 'Comment'] }
```

### g:fzf_history_dir

Setting this variable enables per-command history. History files are stored in the specified directory. When enabled, `Ctrl-N` and `Ctrl-P` are bound to history navigation instead of moving down/up.

```vim
let g:fzf_history_dir = '~/.local/share/fzf-history'
```

## Built-in Commands and Custom Commands

The plugin provides the `:FZF` command, a basic file selector. It accepts options and an optional path.

```vim
" Look for files under current directory
:FZF

" Look for files under your home directory
:FZF ~

" With fzf command-line options
:FZF --reverse --info=inline /tmp

" Bang version starts fzf in fullscreen mode
:FZF!
```

Users can create custom commands using `fzf#wrap`. The following example creates an `LS` command that supports a bang prefix for fullscreen mode, directory completion, and unique history naming.

```vim
" Basic command
command! LS call fzf#run(fzf#wrap({'source': 'ls'}))

" With bang for fullscreen
command! -bang LS call fzf#run(fzf#wrap({'source': 'ls'}, <bang>0))

" With directory argument and completion
command! -bang -complete=dir -nargs=* LS
    \ call fzf#run(fzf#wrap({'source': 'ls', 'dir': <q-args>}, <bang>0))

" With unique history name 'ls'
command! -bang -complete=dir -nargs=* LS
    \ call fzf#run(fzf#wrap('ls', {'source': 'ls', 'dir': <q-args>}, <bang>0))
```

## Layout and Terminal Buffer Behavior

On Neovim, GVim, and terminal Vim with non-default layouts, fzf uses a terminal buffer. The filetype for this buffer is `fzf`, allowing customization via `FileType` autocmds. For example, users can temporarily hide the status line for non-popup layouts:

```vim
if has('nvim') && !exists('g:fzf_layout')
  autocmd! FileType fzf
  autocmd  FileType fzf set laststatus=0 noshowmode noruler
    \| autocmd BufLeave <buffer> set laststatus=2 showmode ruler
endif
```

The `window` option in the spec supports both string commands and dictionary-based popup settings, offering flexibility for different editor environments.
