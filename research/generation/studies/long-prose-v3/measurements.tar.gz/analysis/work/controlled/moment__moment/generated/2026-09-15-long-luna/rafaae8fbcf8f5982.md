Changelog
=========

### 2.29.1 [See full changelog](https://gist.github.com/marwahaha/cc478ba01a1292ab4bd4e861d164d99b)

* Release Oct 6, 2020

Updated the deprecation message and fixed a bug in the Hindi locale.

### 2.29.0 [See full changelog](https://gist.github.com/marwahaha/b0111718641a6461800066549957ec14)

* Release Sept 22, 2020

Added new locales: es-mx and bn-bd.
Fixed minor bugs and improved locales.
Added more tests.
Moment is in maintenance mode. Read more:
https://momentjs.com/docs/#/-project-status/

### 2.28.0 [See full changelog](https://gist.github.com/marwahaha/028fd6c2b2470b2804857cfd63c0e94f)

* Release Sept 13, 2020

Fixed a bug where `.format()` modified the original instance and improved locale updates.

### 2.27.0 [See full changelog](https://gist.github.com/marwahaha/5100c9c2f42019067b1f6cefc333daa7)

* Release June 18, 2020

Added the Turkmen locale, improved other locales, and made minor TypeScript fixes.

### 2.26.0 [See full changelog](https://gist.github.com/marwahaha/0725c40740560854a849b096ea7b7590)

* Release May 19, 2020

Made TypeScript fixes and many locale improvements.

### 2.25.3

* Release May 4, 2020

Removed the `module` property from `package.json`. Webpack behaves differently for modules loaded through `module` and `jsnext:main`.

### 2.25.2

* Release May 4, 2020

This release includes an ES module bundle for Moment, separate from its source code under the `dist/` folder. This might resolve issues when locating the `./locale` subfolder for loading locales. It might also cause Webpack to bundle all locales automatically unless configured otherwise.

### 2.25.1

* Release May 1, 2020

This is a quick patch release that addresses issues reported after the release of 2.25.0.

* [2e268635](https://github.com/moment/moment/commit/2e268635) [misc] Reverted #5269 because of a Webpack warning
* [226799e1](https://github.com/moment/moment/commit/226799e1) [locale] fil: Fixed the metadata comment
* [a83a521](https://github.com/moment/moment/commit/a83a521) [bugfix] Fixed `typeof` usages
* [e324334](https://github.com/moment/moment/commit/e324334) [pkg] Added `ts3.1-typings` to the npm package
* [28cc23e](https://github.com/moment/moment/commit/28cc23e) [misc] Removed the deleted generated `en-SG` locale

### 2.25.0 [See full changelog](https://gist.github.com/ichernev/6148e64df2427e455b10ce6a18de1a65)

* Release May 1, 2020

* [#4611](https://github.com/moment/moment/issues/4611) [022dc038](https://github.com/moment/moment/commit/022dc038) [feature] Added support for strict string parsing; fixes [#2469](https://github.com/moment/moment/issues/2469)
* [#4599](https://github.com/moment/moment/issues/4599) [4b615b9d](https://github.com/moment/moment/commit/4b615b9d) [feature] Added support for eras in en and jp
* [#4296](https://github.com/moment/moment/issues/4296) [757d4ff8](https://github.com/moment/moment/commit/757d4ff8) [feature] Added support for custom relative thresholds in `duration.humanize`

* 18 bug fixes
* 36 locale fixes
* 5 new locales: oc-lnc, zh-mo, en-in, gom-deva, and fil

### 2.24.0 [See full changelog](https://gist.github.com/marwahaha/12366fe45bee328f33acf125d4cd540e)

* Release Jan 21, 2019

* [#4338](https://github.com/moment/moment/pull/4338) [bugfix] Fixed `startOf`/`endOf` DST issues while improving performance
* [#4553](https://github.com/moment/moment/pull/4553) [feature] Added the `localeSort` parameter to Locale weekday methods
* [#4887](https://github.com/moment/moment/pull/4887) [bugfix] Made `Duration#as` work with quarters
* Added 3 new locales: it-ch, ga, and en-SG
* Made many locale improvements

### 2.23.0 [See full changelog](https://gist.github.com/marwahaha/eadb7ac11b761290399a576f8b2419a5)

* Release Dec 12, 2018

* [#4863](https://github.com/moment/moment/pull/4863) [new locale] Added the Kurdish language (`ku`)
* [#4417](https://github.com/moment/moment/pull/4417) [bugfix] Made `isBetween` return false for invalid dates
* [#4700](https://github.com/moment/moment/pull/4700) [bugfix] Fixed [#4698](https://github.com/moment/moment/pull/4698): Used ISO week year for `HTML5_FMT.WEEK`
* [#4563](https://github.com/moment/moment/pull/4563) [feature] Fixed [#4518](https://github.com/moment/moment/pull/4518): Added support for adding and subtracting ISO weeks
* Made other locale and build-process changes and fixed typos

### 2.22.2 [See full changelog](https://gist.github.com/marwahaha/4d992c13c2dbc0f59d4d8acae1dc6d3a)

* Release May 31, 2018

* [#4564](https://github.com/moment/moment/pull/4564) [bugfix] Avoided using `trim()`
* [#4453](https://github.com/moment/moment/pull/4453) [bugfix] Treated periods as periods, rather than as regex wildcards, during strict weekday parsing
* Made minor locale improvements for pa-in, be, and az

### 2.22.1 [See full changelog](https://gist.github.com/marwahaha/ff2cd13d0eda08afb7a237b10aae558c)

* Release Apr 14, 2018

* [#4495](https://github.com/moment/moment/pull/4495) [bugfix] Added `HTML5_FMT` to `moment.d.ts`
* Made minor locale improvements
* Upgraded QUnit and added Coveralls reporting

### 2.22.0 [See full changelog](https://gist.github.com/marwahaha/ae895025dac3f0641fa9ec2e36d282bb)

* Release Mar 30, 2018

* [#4423](https://github.com/moment/moment/pull/4423) [new locale] Added the Mongolian locale (`mn`)
* Made various locale improvements
* Made minor miscellaneous changes

### 2.21.0 [See full changelog](https://gist.github.com/marwahaha/80d19ef882b71df1948df7865efdd40e)

* Release Mar 2, 2018

* [#4391](https://github.com/moment/moment/pull/4391) [bugfix] Fixed [#4390](https://github.com/moment/moment/pull/4390): Used the offset correctly in `toISOString`
* [#4310](https://github.com/moment/moment/pull/4310) [bugfix] Fixed [#3883](https://github.com/moment/moment/pull/3883): Lazily loaded `parentLocale` in `defineLocale` and fell back to the global locale when missing
* [#4085](https://github.com/moment/moment/pull/4085) [misc] Printed a console warning when setting nonexistent locales
* [#4371](https://github.com/moment/moment/pull/4371) [misc] Fixed deprecated Rollup options
* Added new locales: ug-cn, en-il, and tg
* Made various locale improvements

### 2.20.1 [See changelog](https://gist.github.com/marwahaha/d72c1cb22076373be889b16272cbd187)

* Release Dec 18, 2017

* [#4359](https://github.com/moment/moment/pull/4359) [locale] Fixed the Arabic month locale again
* [#4357](https://github.com/moment/moment/pull/4357) [misc] Added the optional `keepOffset` parameter to `toISOString`

### 2.20.0 [See full changelog](https://gist.github.com/marwahaha/e0d4135fbf8bb75fa85c4aa2bddc5031)

* Release Dec 16, 2017

* [#4312](https://github.com/moment/moment/pull/4312) [bugfix] Fixed [#4251](https://github.com/moment/moment/issues/4251): Avoided RFC 2822 in the `utc()` test
* [#4240](https://github.com/moment/moment/pull/4240) [bugfix] Fixed incorrect strict parsing with full-width parentheses
* [#4341](https://github.com/moment/moment/pull/4341) [feature] Prevented `toISOString` from converting to UTC; see [#1751](https://github.com/moment/moment/pull/1751)
* [#4154](https://github.com/moment/moment/pull/4154) [feature] Added format constants for output to HTML5 input formats; see [#3928](https://github.com/moment/moment/pull/3928)
* [#4143](https://github.com/moment/moment/pull/4143) [new locale] Added Maltese (`mt`)
* [#4183](https://github.com/moment/moment/pull/4183) [locale] Added internationalization for relative seconds
* Made various other locale improvements

### 2.19.4 [See changelog](https://gist.github.com/marwahaha/d3b7b0ddf4bdae512244f16e8cc59efb)

* Release Dec 10, 2017

* [#4332](https://github.com/moment/moment/pull/4332) [bugfix] Fixed weekday verification for UTC and offset days; fixes [#4227](https://github.com/moment/moment/issues/4227)
* [#4336](https://github.com/moment/moment/pull/4336) [bugfix] Fixed [#4334](https://github.com/moment/moment/pull/4334): Removed an unused function-call argument
* [#4246](https://github.com/moment/moment/pull/4246) [misc] Added the `ss` relative-time key to the TypeScript definition

### 2.19.3 [See changelog](https://gist.github.com/marwahaha/3654006bc0c2e522451c08d12c0bfabf)

* Release Nov 29, 2017

* [#4326](https://github.com/moment/moment/pull/4326) [bugfix] Fixed a ReDoS vulnerability; see [#4163](https://github.com/moment/moment/issues/4163)
* [#4289](https://github.com/moment/moment/pull/4289) [misc] Fixed spelling and formatting for “U.S.” in es-us

### 2.19.2 [See changelog (it's the same >:D)](https://gist.github.com/ichernev/76b1a3f33d3a8ff9665ce434a45221d0)

* Release Nov 11, 2017

* [#4255](https://github.com/moment/moment/pull/4255) [bugfix] Fixed the year setter for random days in a leap year; fixes [#4238](https://github.com/moment/moment/issues/4238)
* [#4242](https://github.com/moment/moment/pull/4242) [bugfix] Made `updateLocale` load the parent; fixes [#3626](https://github.com/moment/moment/issues/3626)

### 2.19.1

* Release Oct 11, 2017

Made React Native and Webpack work together.
* #4225 #4226 #4232

### 2.19.0 [See full changelog](https://gist.github.com/ichernev/5f3f4eb02761b4f765a0cccf02cec603)

* Release Oct 10, 2017

## Fix React Native 0.49+ crash

* [#4213](https://github.com/moment/moment/pull/4213) [critical] Renamed the dynamic `require` to avoid a React Native crash
* [#4214](https://github.com/moment/moment/pull/4214) [fixup] Moved the `require` rename inside `try/catch`; fixes [#4213](https://github.com/moment/moment/issues/4213)

## Features

* [#3735](https://github.com/moment/moment/pull/3735) [feature] Ignored `NaN` values in setters
* [#4106](https://github.com/moment/moment/pull/4106) [fixup] Dropped the `isNumeric` utility function; fixes [#3735](https://github.com/moment/moment/issues/3735)
* [#4080](https://github.com/moment/moment/pull/4080) [feature] Implemented a clone method for durations; fixes [#4078](https://github.com/moment/moment/issues/4078)
* [#4215](https://github.com/moment/moment/pull/4215) [misc] Added `duration.clone()` to TypeScript; for [#4080](https://github.com/moment/moment/issues/4080)

## Packaging

* [#4003](https://github.com/moment/moment/pull/4003) [pkg] bower: Removed tests from the package
* [#3904](https://github.com/moment/moment/pull/3904) [pkg] Changed `jsnext:main` to `module` in `package.json`
* [#4060](https://github.com/moment/moment/pull/4060) [pkg] Accounted for the new Rollup interface

Also included bug fixes, new locales, and locale fixes.

### 2.18.1

* Release Mar 22, 2017

* [#3853](https://github.com/moment/moment/pull/3853) [misc] Fixed invalid whitespace that prevented `moment.js` from being parsed

### 2.18.0 [See full changelog](https://gist.github.com/ichernev/78920c5a1e419fb28c6e4546d1b7235c)

* Release Mar 18, 2017

## Features

* [#3708](https://github.com/moment/moment/pull/3708) [feature] Added RFC 2822 parsing
* [#3611](https://github.com/moment/moment/pull/3611) [feature] Added validity to durations
* [#3738](https://github.com/moment/moment/pull/3738) [feature] Enabled relative time for multiple seconds; requested in [#2558](https://github.com/moment/moment/issues/2558)
* [#3766](https://github.com/moment/moment/pull/3766) [feature] Added support for parsing the `k` and `kk` format tokens

## Bugfixes

* [#3643](https://github.com/moment/moment/pull/3643) [bugfix] Fixed [#3520](https://github.com/moment/moment/issues/3520): `parseZone` incorrectly handled minutes under 16
* [#3710](https://github.com/moment/moment/pull/3710) [bugfix] Fixed [#3632](https://github.com/moment/moment/issues/3632): `toISOString` returned `null` for an invalid date
* [#3787](https://github.com/moment/moment/pull/3787) [bugfix] Fixed [#3717](https://github.com/moment/moment/issues/3717): Ensured that the day of year was nonzero
* [#3780](https://github.com/moment/moment/pull/3780) [bugfix] Fixed [#3765](https://github.com/moment/moment/issues/3765): Ensured that year 0 was formatted with `YYYY`
* [#3806](https://github.com/moment/moment/pull/3806) [bugfix] Fixed [#3805](https://github.com/moment/moment/issues/3805): Fixed locale month getters for standalone and format cases

Added 7 new locales, many locale improvements, and miscellaneous changes.

### 2.17.1 [Also available here](https://gist.github.com/ichernev/f38280b2b29c4932914a6d3a4e50bfb2)

* Release Dec 03, 2016

* [#3638](https://github.com/moment/moment/pull/3638) [misc] Made the TypeScript definitions work with 1.x
* [#3628](https://github.com/moment/moment/pull/3628) [misc] Added a “sign CLA” link to `CONTRIBUTING.md`
* [#3640](https://github.com/moment/moment/pull/3640) [misc] Fixed locale issues

### 2.17.0 [Also available here](https://gist.github.com/ichernev/ed58f76fb95205eeac653d719972b90c)

* Release Nov 22, 2016

* [#3435](https://github.com/moment/moment/pull/3435) [new locale] Added the Yoruba (`yo`) locale for Nigeria
* [#3595](https://github.com/moment/moment/pull/3595) [bugfix] Fixed an accidental reference to the global `value` variable
* [#3506](https://github.com/moment/moment/pull/3506) [bugfix] Prevented invalid moments from returning valid dates from method calls
* [#3563](https://github.com/moment/moment/pull/3563) [locale] ca: Changed future relative time
* [#3504](https://github.com/moment/moment/pull/3504) [tests] Fixed [#3463](https://github.com/moment/moment/issues/3463): `parseZone` did not handle `Z` correctly (tests only)
* [#3591](https://github.com/moment/moment/pull/3591) [misc] TypeScript: Updated TypeScript to 2.0.8 and added `strictNullChecks=true`
* [#3597](https://github.com/moment/moment/pull/3597) [misc] Fixed capitalization in the NuGet specification

### 2.16.0 [See full changelog](https://gist.github.com/ichernev/17bffc1005a032cb1a8ac4c1558b4994)

* Release Nov 9, 2016

## Features

* [#3530](https://github.com/moment/moment/pull/3530) [feature] Checked whether input was a date before checking whether the format was an array
* [#3515](https://github.com/moment/moment/pull/3515) [feature] Fixed [#2300](https://github.com/moment/moment/issues/2300): Defaulted to the current week

## Bugfixes

* [#3546](https://github.com/moment/moment/pull/3546) [bugfix] Implemented lazy loading of child locales with missing parents
* [#3523](https://github.com/moment/moment/pull/3523) [bugfix] Made `parseZone` handle UTC
* [#3502](https://github.com/moment/moment/pull/3502) [bugfix] Fixed [#3500](https://github.com/moment/moment/issues/3500): ISO 8601 parsing now matches the full string, not only its beginning
* [#3581](https://github.com/moment/moment/pull/3581) [bugfix] Fixed `parseZone`, redid [#3504](https://github.com/moment/moment/issues/3504), and fixed [#3463](https://github.com/moment/moment/issues/3463)

## New Locales

* [#3416](https://github.com/moment/moment/pull/3416) [new locale] Added nl-be, the Dutch (Belgium) locale
* [#3393](https://github.com/moment/moment/pull/3393) [new locale] Added ar-dz, the Arabic (Algeria) locale
* [#3342](https://github.com/moment/moment/pull/3342) [new locale] Added tet, the Tetun Dili (East Timor) locale

Also included locale, build, and TypeScript improvements.

### 2.15.2

* Release Oct 23, 2016
* [#3525](https://github.com/moment/moment/pull/3525) Sped up month standalone and format regular expressions **(IMPORTANT)**
* [#3466](https://github.com/moment/moment/pull/3466) Fixed a Javanese typo

### 2.15.1

* Release Sept 20, 2016
* [#3438](https://github.com/moment/moment/pull/3438) Fixed locale autoloading and reverted [#3344](https://github.com/moment/moment/pull/3344)

### 2.15.0 [See full changelog](https://gist.github.com/ichernev/10e1c5bf647545c72ca30e9628a09ed3)

- Release Sept 12, 2016

## New Locales

* [#3255](https://github.com/moment/moment/pull/3255) [new locale] Added mi, the Maori language
* [#3267](https://github.com/moment/moment/pull/3267) [new locale] Added ar-ly, the Arabic (Libya) locale
* [#3333](https://github.com/moment/moment/pull/3333) [new locale] Added zh-hk, the Chinese (Hong Kong) locale

## Bugfixes

* [#3276](https://github.com/moment/moment/pull/3276) [bugfix] duration: parser: Added support for millisecond durations in .NET syntax
* [#3312](https://github.com/moment/moment/pull/3312) [bugfix] locales: Enabled locale-data getters without Moment; fixes [#3284](https://github.com/moment/moment/issues/3284)
* [#3381](https://github.com/moment/moment/pull/3381) [bugfix] parsing: Fixed `parseZone` without a timezone in the string; fixes [#3083](https://github.com/moment/moment/issues/3083)
* [#3383](https://github.com/moment/moment/pull/3383) [bugfix] toJSON: Fixed `isValid` so that `toJSON` works after a moment is frozen
* [#3427](https://github.com/moment/moment/pull/3427) [bugfix] ie8: Fixed an IE8 regression introduced in 2.14.x

## Packaging

* [#3299](https://github.com/moment/moment/pull/3299) [pkg] npm: Removed `.npmignore` from the npm package
* [#3273](https://github.com/moment/moment/pull/3273) [pkg] jspm: Included `moment.d.ts` in the package
* [#3344](https://github.com/moment/moment/pull/3344) [pkg] exports: Used `module.require` for Node.js

Also included locale and TypeScript improvements.

### 2.14.1

- Release July 20, 2016

* [#3280](https://github.com/moment/moment/pull/3280) Fixed the TypeScript definitions.

### 2.14.0 [See full changelog](https://gist.github.com/ichernev/812e79ac36a7829a22598fe964bfc18a)

- Release July 20, 2016

## New Features

* [#3233](https://github.com/moment/moment/pull/3233) Introduced `month.isFormat` for format and standalone discovery
* [#2848](https://github.com/moment/moment/pull/2848) Allowed users to get and set the rounding method used when calculating relative time
* [#3112](https://github.com/moment/moment/pull/3112) Optimized `configFromStringAndFormat`
* [#3147](https://github.com/moment/moment/pull/3147) Called the calendar format function with the Moment context
* [#3160](https://github.com/moment/moment/pull/3160) Deprecated `isDSTShifted`
* [#3175](https://github.com/moment/moment/pull/3175) Made the Moment calendar extensible with ad hoc options
* [#3191](https://github.com/moment/moment/pull/3191) Made `toDate` return a copy of the internal date object
* [#3192](https://github.com/moment/moment/pull/3192) Added support for Rollup imports
* [#3238](https://github.com/moment/moment/pull/3238) Treated empty objects and empty arrays passed during creation as now
* [#3082](https://github.com/moment/moment/pull/3082) Used a relative AMD Moment dependency

## Bugfixes

* [#3241](https://github.com/moment/moment/pull/3241) Escaped all 24 mixed pieces, rather than only the first 12, in `computeMonthsParse`
* [#3008](https://github.com/moment/moment/pull/3008) Ordered object setter operations by unit size
* [#3177](https://github.com/moment/moment/pull/3177) Fixed [#2704](https://github.com/moment/moment/pull/2704): Made `isoWeekday(String)` consistent with `isoWeekday(Number)`
* [#3230](https://github.com/moment/moment/pull/3230) Fixed passing a date with a format string so that the format string is ignored
* [#3232](https://github.com/moment/moment/pull/3232) Fixed negative zero in certain diff cases
* [#3235](https://github.com/moment/moment/pull/3235) Used proper locale inheritance for the base locale; fixes [#3137](https://github.com/moment/moment/issues/3137)

Also included the es-do locale and locale bug fixes.

### 2.13.0 [See full changelog](https://gist.github.com/ichernev/0132fcf5b61f7fc140b0bb0090480d49)

- Release April 18, 2016

## Enhancements

* [#2982](https://github.com/moment/moment/pull/2982) Added `date` as an alias for `day` in `startOf()` and `endOf()`
* [#2955](https://github.com/moment/moment/pull/2955) Added parsing of negative duration components in ISO 8601
* [#2991](https://github.com/moment/moment/pull/2991) Added support for both open and closed intervals in `isBetween`
* [#3105](https://github.com/moment/moment/pull/3105) Added the `localeSorted` argument to weekday listers
* [#3102](https://github.com/moment/moment/pull/3102) Added the `k` and `kk` formatting tokens

## Bugfixes

* [#3109](https://github.com/moment/moment/pull/3109) Fixed [#1756](https://github.com/moment/moment/issues/1756): Resolved a server-side thread-safety issue
* [#3078](https://github.com/moment/moment/pull/3078) Fixed parsing for months and weekdays with unusual characters
* [#3098](https://github.com/moment/moment/pull/3098) Used the `Z` suffix in UTC mode; see [#3020](https://github.com/moment/moment/issues/3020)
* [#2995](https://github.com/moment/moment/pull/2995) Fixed floating-point rounding errors in durations
* [#3059](https://github.com/moment/moment/pull/3059) Fixed a bug where `diff` returned negative zero in month-related differences
* [#3045](https://github.com/moment/moment/pull/3045) Prevented arbitrary input from being interpreted as the `a` token
* [#2877](https://github.com/moment/moment/pull/2877) Used explicit `.valueOf()` calls instead of coercion
* [#3036](https://github.com/moment/moment/pull/3036) Made the year setter preserve the time when DST changes

Also included 3 new locales and locale fixes.

### 2.12.0 [See full changelog](https://gist.github.com/ichernev/6e5bfdf8d6522fc4ac73)

- Release March 7, 2016

## Enhancements

* [#2932](https://github.com/moment/moment/pull/2932) Added a way to list loaded locales
* [#2818](https://github.com/moment/moment/pull/2818) Parsed ISO 8601 durations containing both day and week values
* [#2774](https://github.com/moment/moment/pull/2774) Implemented locale inheritance and locale updates

## Bugfixes

* [#2970](https://github.com/moment/moment/pull/2970) Changed add and subtract to handle decimal values by rounding
* [#2887](https://github.com/moment/moment/pull/2887) Fixed `toJSON` casting of an invalid moment
* [#2897](https://github.com/moment/moment/pull/2897) Parsed string arguments for `month()` correctly; closes [#2884](https://github.com/moment/moment/issues/2884)
* [#2946](https://github.com/moment/moment/pull/2946) Fixed usage suggestions for `min` and `max`

## New Locales

* [#2917](https://github.com/moment/moment/pull/2917) Added the Punjabi (Gurmukhi, India) locale format conversion

And more changes.

### 2.11.2 (Fixes ReDoS attack vector)

- Release February 7, 2016

* [#2939](https://github.com/moment/moment/pull/2939) Used a full-string match to speed up the ASP.NET regex match

### 2.11.1 [See full changelog](https://gist.github.com/ichernev/8ec3ee25b749b4cff3c2)

- Release January 9, 2016

## Bugfixes

* [#2881](https://github.com/moment/moment/pull/2881) Reverted “Merge pull request #2746 from mbad0la:develop” (`Sep` -> `Sept`)
* [#2868](https://github.com/moment/moment/pull/2868) Added format and parse token `Y` so it works correctly
* [#2865](https://github.com/moment/moment/pull/2865) Used `typeof` checks for undefined global variables
* [#2858](https://github.com/moment/moment/pull/2858) Fixed a Date mocking regression introduced in 2.11.0
* [#2864](https://github.com/moment/moment/pull/2864) Included the changelog in the npm release
* [#2830](https://github.com/moment/moment/pull/2830) Added `grunt-cli` as a dependency
* [#2869](https://github.com/moment/moment/pull/2869) Fixed month parsing for some locales

### 2.11.0 [See full changelog](https://gist.github.com/ichernev/6594bc29719dde6b2f66)

- Release January 4, 2016

* [#2624](https://github.com/moment/moment/pull/2624) Added proper handling of invalid moments
* [#2634](https://github.com/moment/moment/pull/2634) Fixed strict month parsing in cs, ru, and sk
* [#2735](https://github.com/moment/moment/pull/2735) Reset the locale to `en` after defining all locales in `min/locales.js`
* [#2702](https://github.com/moment/moment/pull/2702) Reworked weeks
* [#2746](https://github.com/moment/moment/pull/2746) Changed the September abbreviation to “Sept” in locale-specific English files and the default locale file
* [#2646](https://github.com/moment/moment/pull/2646) Fixed [#2645](https://github.com/moment/moment/issues/2645): Fixed invalid dates before 1970
* [#2641](https://github.com/moment/moment/pull/2641) Implemented basic format and comma as the millisecond separator in ISO 8601
* [#2665](https://github.com/moment/moment/pull/2665) Implemented stricter weekday parsing
* [#2700](https://github.com/moment/moment/pull/2700) Added `[Hh]mm` and `[Hh]mmss` formatting tokens, allowing values such as `123` to be parsed with `hmm`
* [#2565](https://github.com/moment/moment/pull/2565) [#2835](https://github.com/moment/moment/pull/2835) Exposed the arguments used to create a moment with `creationData`; fixes [#2443](https://github.com/moment/moment/pull/2443)
* [#2648](https://github.com/moment/moment/pull/2648) Fixed [#2640](https://github.com/moment/moment/pull/2640): Added support for the `instanceof` operator
* [#2709](https://github.com/moment/moment/pull/2709) Added `isSameOrAfter` and `isSameOrBefore` comparison methods
* [#2721](https://github.com/moment/moment/pull/2721) Fixed moment creation from objects with string values
* [#2740](https://github.com/moment/moment/pull/2740) Enabled the `d hh:mm:ss.sss` duration format
* [#2766](https://github.com/moment/moment/pull/2766) [#2833](https://github.com/moment/moment/pull/2833) Added support for an alternate clock source

### 2.10.6

- Release July 28, 2015

[#2515](https://github.com/moment/moment/pull/2515) Fixed a regression introduced in `2.10.5` related to `moment.ISO_8601` parsing.

### 2.10.5 [See full changelog](https://gist.github.com/ichernev/6ec13ac7efc396da44b2)

- Release July 26, 2015

Important changes:

* [#2357](https://github.com/moment/moment/pull/2357) Improved unit bubbling for ISO dates. This fixes day-to-year conversions around the end of the year, approximately 365 days. As a side effect, 365 days is 11 months and 30 days, and 366 days is one year.
* [#2438](https://github.com/moment/moment/pull/2438) Fixed inconsistent `moment.min` and `moment.max` results. Returned an invalid result if any input was invalid.
* [#2494](https://github.com/moment/moment/pull/2494) Fixed two-digit year parsing with the `YYYY` format. This provides the benefits of `YY` to `YYYY`.
* [#2368](https://github.com/moment/moment/pull/2368) Used a faster way to copy dates, improving performance throughout the library.

### 2.10.3 [See full changelog](https://gist.github.com/ichernev/f264b9bed5b00f8b1b7f)

- Release May 13, 2015

* Added `moment.fn.to` and `moment.fn.toNow`, similar to `from` and `fromNow`
* Added new locales: Sinhalese (`si`), Montenegrin (`me`), and Javanese (`ja`)
* Made performance improvements

### 2.10.2

- Release April 9, 2015

* Fixed `moment-with-locales` in browser environments after the Esperanto change

### 2.10.1

* Re-added `moment.duration.fn`

### 2.10.0

Ported the code to ES6 modules.

### 2.9.0 [See full changelog](https://gist.github.com/ichernev/0c9a9b49951111a27ce7)

- Release January 8, 2015

Languages:

* [2104](https://github.com/moment/moment/issues/2104) Added the Frisian (`fy`) language file with a unit test
* [2097](https://github.com/moment/moment/issues/2097) Added the ar-tn locale

Deprecations:

* [2074](https://github.com/moment/moment/issues/2074) Implemented `moment.fn.utcOffset` and deprecated `moment.fn.zone`

Features:

* [2088](https://github.com/moment/moment/issues/2088) Added `moment.fn.isBetween`
* [2054](https://github.com/moment/moment/issues/2054) Called `updateOffset` when creating a moment, as required for the default timezone in Moment Timezone
* [1893](https://github.com/moment/moment/issues/1893) Added `moment.isDate`
* [1825](https://github.com/moment/moment/issues/1825) Implemented `toJSON` for Duration
* [1809](https://github.com/moment/moment/issues/1809) Allowed `moment.set()` to accept a hash of units
* [2128](https://github.com/moment/moment/issues/2128) Added `firstDayOfWeek` and `firstDayOfYear` locale getters
* [2131](https://github.com/moment/moment/issues/2131) Added quarter diff support

Also included bug fixes and language improvements. See the [full changelog](https://gist.github.com/ichernev/0c9a9b49951111a27ce7).

### 2.8.4 [See full changelog](https://gist.github.com/ichernev/a4fcb0a46d74e4b9b996)

- Release November 19, 2014

Features:

* [#2000](https://github.com/moment/moment/issues/2000) Added the localized `LTS` format, including seconds
* [#1960](https://github.com/moment/moment/issues/1960) Added format token `x` for the Unix offset in milliseconds; see [#1938](https://github.com/moment/moment/issues/1938)
* [#1965](https://github.com/moment/moment/issues/1965) Added support for `24:00:00.000` to mean the next day at midnight
* [#2002](https://github.com/moment/moment/issues/2002) Accepted the `date` key when creating a moment from an object
* [#2009](https://github.com/moment/moment/issues/2009) Used the native `toISOString` when possible

Also included bug fixes and language improvements. See the [full changelog](https://gist.github.com/ichernev/a4fcb0a46d74e4b9b996).

### 2.8.3

- Release September 5, 2014

Bug fixes:

* [#1801](https://github.com/moment/moment/issues/1801) Fixed Arabic pluralization
* [#1833](https://github.com/moment/moment/issues/1833) Improved SPM integration
* [#1871](https://github.com/moment/moment/issues/1871) Fixed a timezone bug caused by Firefox 24
* [#1882](https://github.com/moment/moment/issues/1882) Used `hh:mm` in Czech
* [#1883](https://github.com/moment/moment/issues/1883) Fixed a 2.8.0 regression in duration conversions
* [#1890](https://github.com/moment/moment/issues/1890) Made Travis builds faster
* [#1892](https://github.com/moment/moment/issues/1892) Made `isBefore`, `isAfter`, and `isSame` faster
* [#1848](https://github.com/moment/moment/issues/1848) Fixed flaky month differences
* [#1895](https://github.com/moment/moment/issues/1895) Fixed a 2.8.0 regression in `moment.utc` with a format array
* [#1896](https://github.com/moment/moment/issues/1896) Supported setting the locale of an invalid instance as a no-op
* [#1897](https://github.com/moment/moment/issues/1897) Supported `moment([str])` in addition to `moment([int])`

### 2.8.2

- Release August 22, 2014

Minor bug fixes:

* [#1874](https://github.com/moment/moment/issues/1874) Used `Object.prototype.hasOwnProperty` instead of `obj.hasOwnProperty` for an IE8 bug
* [#1873](https://github.com/moment/moment/issues/1873) Added `duration#toString()`
* [#1859](https://github.com/moment/moment/issues/1859) Improved month and weekday names in Norwegian
* [#1812](https://github.com/moment/moment/issues/1812) Improved meridiem parsing for Greek
* [#1804](https://github.com/moment/moment/issues/1804) Changed Spanish `del` to `de`
* [#1800](https://github.com/moment/moment/issues/1800) Improved Korean `LT`

### 2.8.1

- Release August 1, 2014

* [#1813](https://github.com/moment/moment/issues/1813) Fixed the incompatibility of `moment().lang([key])`

### 2.8.0 [See changelog](https://gist.github.com/ichernev/ac3899324a5fa6c8c9b4)

- Release July 31, 2014

Incompatible changes:

* [#1761](https://github.com/moment/moment/issues/1761): Moments created without a language no longer follow the global language when it changes. Only newly created moments use the global language by default. If this affects you, wait and comment on [#1797](https://github.com/moment/moment/issues/1797) for a proper reimplementation.
* [#1642](https://github.com/moment/moment/issues/1642): According to `humanize`, 45 days is no longer “a month.” The cutoffs for months and years have changed. Code should not depend on a particular `humanize` result.
* [#1784](https://github.com/moment/moment/issues/1784): If you store human-readable English date-time strings in an unusual way, a format change could break your code.

Deprecations (old behavior will be removed in 3.0):

* [#1761](https://github.com/moment/moment/issues/1761): Renamed `lang` to `locale` and `langData` to `localeData`. Added `defineLocale`, which should be used to create new locales.
* [#1763](https://github.com/moment/moment/issues/1763): Deprecated `add(unit, value)` and `subtract(unit, value)`. Use `add(value, unit)` and `subtract(value, unit)` instead.
* [#1759](https://github.com/moment/moment/issues/1759): Renamed `duration.toIsoString` to `duration.toISOString`. The JavaScript standard library and Moment’s `toISOString` use that convention.

New locales:

* [#1789](https://github.com/moment/moment/issues/1789): Tibetan (`bo`)
* [#1786](https://github.com/moment/moment/issues/1786): Afrikaans (`af`)
* [#1778](https://github.com/moment/moment/issues/1778): Burmese (`my`)
* [#1727](https://github.com/moment/moment/issues/1727): Belarusian (`be`)

Also included bug fixes, locale fixes, performance improvements, and features.

### 2.7.0 [See changelog](https://gist.github.com/ichernev/b0a3d456d5a84c9901d7)

- Release June 12, 2014

New languages:

* [#1678](https://github.com/moment/moment/issues/1678) Bengali (`bn`)
* [#1628](https://github.com/moment/moment/issues/1628) Azerbaijani (`az`)
* [#1633](https://github.com/moment/moment/issues/1633) Arabic, Saudi Arabia (`ar-sa`)
* [#1648](https://github.com/moment/moment/issues/1648) Austrian German (`de-at`)

Features:

* [#1663](https://github.com/moment/moment/issues/1663) Added configurable relative-time thresholds
* [#1554](https://github.com/moment/moment/issues/1554) Added support for an anchor time in `moment.calendar`
* [#1693](https://github.com/moment/moment/issues/1693) Added support for `moment.ISO_8601` as a parsing format
* [#1637](https://github.com/moment/moment/issues/1637) Added `moment.min` and `moment.max` and deprecated the instance `min` and `max` methods
* [#1704](https://github.com/moment/moment/issues/1704) Added support for string values in `add` and `subtract`
* [#1647](https://github.com/moment/moment/issues/1647) Added SPM support

Also included bug fixes.

### 2.6.0 [See changelog](https://gist.github.com/ichernev/10544682)

- Release April 12, 2014

Languages:

* [#1529](https://github.com/moment/moment/issues/1529) Serbian Cyrillic (`sr-cyr`)
* [#1544](https://github.com/moment/moment/issues/1544), [#1546](https://github.com/moment/moment/issues/1546) Khmer, Cambodia (`km`)

Features:

* [#1419](https://github.com/moment/moment/issues/1419), [#1468](https://github.com/moment/moment/issues/1468), [#1467](https://github.com/moment/moment/issues/1467), [#1546](https://github.com/moment/moment/issues/1546) Improved handling of timezone-aware moments around DST
* [#1462](https://github.com/moment/moment/issues/1462) Added `weeksInYear` and `isoWeeksInYear`
* [#1475](https://github.com/moment/moment/issues/1475) Added ordinal parsing
* [#1499](https://github.com/moment/moment/issues/1499) Added Composer support
* [#1577](https://github.com/moment/moment/issues/1577), [#1604](https://github.com/moment/moment/issues/1604) Moved Date parsing to `moment.createFromInputFallback` so it can be deprecated and controlled later
* [#1545](https://github.com/moment/moment/issues/1545) Extracted two-digit year parsing into `moment.parseTwoDigitYear`, allowing it to be overridden
* [#1590](https://github.com/moment/moment/issues/1590) (see [#1574](https://github.com/moment/moment/issues/1574)) Set the AMD global before module definition to improve support for non-AMD module dependencies in an AMD environment
* [#1589](https://github.com/moment/moment/issues/1589) Removed the global in the Node.js environment
* [#1586](https://github.com/moment/moment/issues/1586) Added support for quarter setting and parsing

Fixed 18 bugs.

### 2.5.1

- Release January 22, 2014

Languages:

* [#1392](https://github.com/moment/moment/issues/1392) Added Armenian (`hy-am`)

Bug fixes:

* [#1429](https://github.com/moment/moment/issues/1429) Fixed [#1423](https://github.com/moment/moment/issues/1423), a Chrome 32 bug involving JavaScript object creation
* [#1421](https://github.com/moment/moment/issues/1421) Removed HTML entities from Welsh
* [#1418](https://github.com/moment/moment/issues/1418) Fixed [#1401](https://github.com/moment/moment/issues/1401): Improved nonpadded tokens in strict matching
* [#1417](https://github.com/moment/moment/issues/1417) Fixed [#1404](https://github.com/moment/moment/issues/1404): Handled a broken Moment object created by property cloning
* [#1398](https://github.com/moment/moment/issues/1398) Fixed [#1397](https://github.com/moment/moment/issues/1397): Fixed Arabic-like week-number parsing
* [#1396](https://github.com/moment/moment/issues/1396) Added `leftZeroFill(4)` to the `GGGG` and `gggg` formats
* [#1373](https://github.com/moment/moment/issues/1373) Used lowercase month and day names in Catalan

Testing:

* [#1374](https://github.com/moment/moment/issues/1374) Ran tests across multiple browser and operating-system combinations through Sauce Labs and Travis

### 2.5.0 [See changelog](https://gist.github.com/ichernev/8104451)

- Release Dec 24, 2013

New languages:

* Luxemburish (`lb`) [1247](https://github.com/moment/moment/issues/1247)
* Serbian (`rs`) [1319](https://github.com/moment/moment/issues/1319)
* Tamil (`ta`) [1324](https://github.com/moment/moment/issues/1324)
* Macedonian (`mk`) [1337](https://github.com/moment/moment/issues/1337)

Features:

* [1311](https://github.com/moment/moment/issues/1311) Added the quarter getter and format token `Q`
* [1303](https://github.com/moment/moment/issues/1303) Made strict parsing respect the number of digits for each token; fixes [1196](https://github.com/moment/moment/issues/1196)
* 0d30bb7 Added JSPM support
* [1347](https://github.com/moment/moment/issues/1347) Improved timezone parsing
* [1362](https://github.com/moment/moment/issues/1362) Added meridiem parsing for Korean

Fixed 22 bugs.

### 2.4.0

- Release Oct 27, 2013

* **Deprecated** globally exported `moment`; it will be removed in the next major release
* Added new languages:
  * Faroese (`fo`) [#1206](https://github.com/moment/moment/issues/1206)
  * Tagalog/Filipino (`tl-ph`) [#1197](https://github.com/moment/moment/issues/1197)
  * Welsh (`cy`) [#1215](https://github.com/moment/moment/issues/1215)
* Fixed bugs:
  * Properly handled `Z` at the end of the ISO regular expression [#1187](https://github.com/moment/moment/issues/1187)
  * Improved Chinese meridian time handling [#1076](https://github.com/moment/moment/issues/1076)
  * Fixed language tests [#1177](https://github.com/moment/moment/issues/1177)
  * Removed failing tests that should not have existed [#1185](https://github.com/moment/moment/issues/1185), [#1183](https://github.com/moment/moment/issues/1183)
  * Handled Russian noun cases in unusual situations [#1195](https://github.com/moment/moment/issues/1195)

### 2.3.1

- Release Oct 9, 2013

Removed a trailing comma [1169] and fixed a bug in the `months` and `weekdays` getters [#1171](https://github.com/moment/moment/issues/1171).

### 2.3.0 [See changelog](https://gist.github.com/ichernev/6864354)

- Release Oct 7, 2013

Changed `isValid` and added strict parsing.
Added week-token parsing.

### 2.2.1

- Release Sep 12, 2013

Fixed a bug in the string prototype test.
Updated the authors and contributors.

### 2.2.0 [See changelog](https://gist.github.com/ichernev/00f837a9baf46a3565e4)

- Release Sep 11, 2013

Added Bower support.

Language files now use UMD.

Creating a moment now defaults to the current date, month, and year.

Added a bundle containing Moment and all language files.

### 2.1.0 [See changelog](https://gist.github.com/timrwood/b8c2d90d528eddb53ab5)

- Release Jul 8, 2013

Added improved week support.

Added the ability to set an offset with `moment#zone`.

Added the ability to set a month or weekday from a string.

Added `moment#min` and `moment#max`.

### 2.0.0 [See changelog](https://gist.github.com/timrwood/e72f2eef320ed9e37c51)

- Release Feb 9, 2013

Added short-form localized tokens.

Added the ability to define the language in which a string should be parsed.

Added support for reversed `add` and `subtract` arguments.

Added support for `endOf('week')` and `startOf('week')`.

Fixed the logic for `moment#diff(Moment, 'months')` and `moment#diff(Moment, 'years')`.

`moment#diff` now floors instead of rounds.

Normalized `moment#toString`.

Added `isSame`, `isAfter`, and `isBefore` methods.

Added improved week support.

Added `moment#toJSON`.

Bug fixes:

* Fixed parsing of dates in the first century
* Fixed parsing of `10Sep2001`
* Fixed unusual behavior when parsing with `moment.utc()`

Changed the language ordinal method to return the number plus the ordinal instead of only the ordinal.

Changed the two-digit year parsing cutoff to match `strptime`.

Removed `moment#sod` and `moment#eod` in favor of `moment#startOf` and `moment#endOf`.

Removed `moment.humanizeDuration()` in favor of `moment.duration().humanize()`.

Removed language data objects from the top-level namespace.

A `Date` passed to `moment()` is now duplicated instead of referenced.

### 1.7.2 [See discussion](https://github.com/timrwood/moment/issues/456)

- Release Oct 2, 2012

Bug fixes.

### 1.7.1 [See discussion](https://github.com/timrwood/moment/issues/384)

- Release Oct 1, 2012

Bug fixes.

### 1.7.0 [See discussion](https://github.com/timrwood/moment/issues/288)

- Release Jul 26, 2012

Added `moment.fn.endOf()` and `moment.fn.startOf()`.

Added validation through `moment.fn.isValid()`.

Made the formatting method three times faster:
http://jsperf.com/momentjs-cached-format-functions

Added support for month and weekday callbacks in `moment.fn.format()`.

Added instance-specific languages.

Added two-letter weekday abbreviations with the `dd` formatting token.

Made various language updates and bug fixes.

### 1.6.0 [See discussion](https://github.com/timrwood/moment/pull/268)

- Release Apr 26, 2012

Added durations.

Reworked the parser to support parsing nonseparated strings such as `YYYYMMDD` and `YYYY-MM-DD`.

Added support for millisecond parsing and formatting tokens: `S`, `SS`, and `SSS`.

Added a getter for `moment.lang()`.

Made various bug fixes.

Several items were deprecated in the 1.6.0 release:

1. The `z` and `zz` format tokens, which represent timezone abbreviations such as EST, CST, and MST, are no longer supported. Inconsistent browser support prevents these values from being produced reliably. See [this issue](https://github.com/timrwood/moment/issues/162) for background.

2. The `moment.fn.native` method is deprecated in favor of `moment.fn.toDate`. Google Closure Compiler can report errors when `native` is used, even for valid instances.

3. The method for customizing AM/PM strings is changing. This affects only custom language files. For more information, see [this issue](https://github.com/timrwood/moment/pull/222).

### 1.5.0 [See milestone](https://github.com/timrwood/moment/issues?milestone=10&page=1&state=closed)

- Release Mar 20, 2012

Added UTC mode.

Added automatic ISO 8601 parsing.

Made various bug fixes.

### 1.4.0 [See milestone](https://github.com/timrwood/moment/issues?milestone=8&state=closed)

- Release Feb 4, 2012

Added `moment.fn.toDate` as a replacement for `moment.fn.native`.

Added `moment.fn.sod` and `moment.fn.eod` to get the start and end of a day.

Made various bug fixes.

### 1.3.0 [See milestone](https://github.com/timrwood/moment/issues?milestone=7&state=closed)

- Release Jan 5, 2012

Added support for parsing month names in the current language.

Added escape blocks for parsing tokens.

Added `moment.fn.calendar` to format strings such as “Today 2:30 PM,” “Tomorrow 1:25 AM,” and “Last Sunday 4:30 AM.”

Added `moment.fn.day` as a setter.

Made various bug fixes.

### 1.2.0 [See milestone](https://github.com/timrwood/moment/issues?milestone=4&state=closed)

- Release Dec 7, 2011

Added timezones to the parser and formatter.

Added `moment.fn.isDST`.

Added `moment.fn.zone` to get the timezone offset in minutes.

### 1.1.2 [See milestone](https://github.com/timrwood/moment/issues?milestone=6&state=closed)

- Release Nov 18, 2011

Made various bug fixes.

### 1.1.1 [See milestone](https://github.com/timrwood/moment/issues?milestone=5&state=closed)

- Release Nov 12, 2011

Added time-specific differences, including months, days, and hours.

### 1.1.0

- Release Oct 28, 2011

Added localized masks to `moment.fn.format`: `L`, `LL`, `LLL`, and `LLLL`; see [issue 29](https://github.com/timrwood/moment/pull/29).

Fixed [issue 31](https://github.com/timrwood/moment/pull/31).

### 1.0.1

- Release Oct 18, 2011

Added `moment.version` to get the current version.

Removed `window !== undefined` when checking whether a module exists to support Browserify; see [issue 25](https://github.com/timrwood/moment/pull/25).

### 1.0.0

- Release

Added convenience methods for getting and setting date parts.

Improved support for `moment.add()`.

Improved language support in Node.js.

Renamed the library from underscore.date to Moment.js.

### 0.6.1

- Release Oct 12, 2011

Added Portuguese, Italian, and French language support.

### 0.6.0

- Release Sep 21, 2011

Added `_date.lang()` support.

Added support for passing multiple formats when parsing a date:
`_date("07-10-1986", ["MM-DD-YYYY", "YYYY-MM-DD"]);`

Made parsing from a string and a single format 25% faster.

### 0.5.2

- Release Jul 11, 2011

Fixed [issue 8](https://github.com/timrwood/underscore.date/pull/8) and [issue 9](https://github.com/timrwood/underscore.date/pull/9).

### 0.5.1

- Release Jun 17, 2011

Fixed [issue 5](https://github.com/timrwood/underscore.date/pull/5).

### 0.5.0

- Release Jun 13, 2011

Removed the redundant `_date.date()` in favor of `_date()`.

Removed `_date.now()`, which duplicated `_date()` with no parameters.

Removed `_date.isLeapYear(yearNumber)`. Use `_date([yearNumber]).isLeapYear()` instead.

Exposed customization options through the `_date.relativeTime`, `_date.weekdays`, `_date.weekdaysShort`, `_date.months`, `_date.monthsShort`, and `_date.ordinal` variables instead of the `_date.customize()` function.

### 0.4.1

- Release May 9, 2011

Added date input formats for input strings.

### 0.4.0

- Release May 9, 2011

Added underscore.date to npm.

Removed dependencies on Underscore.

### 0.3.2

- Release Apr 9, 2011

Added `z` and `zz` to `_.date().format()`.

Removed redundant code to reduce the file size.

### 0.3.1

- Release Mar 25, 2011

Cleaned up the namespace.

Moved all date manipulation and display functions to the `_.date()` object.

### 0.3.0

- Release Mar 25, 2011

Adopted the Underscore approach of not modifying native object prototypes.

Added chaining.

### 0.2.1

- Release

Changed date names to the more standardized format `dddd, MMMM Do YYYY, h:mm:ss a`.

Added `Date.prototype` functions: `add`, `subtract`, `isdst`, and `isleapyear`.

### 0.2.0

- Release

Changed function names to be more concise.

Changed the date format from PHP date format to a custom format.

### 0.1.0

- Release

Initial release.
