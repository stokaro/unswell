# Containerd Operational Configuration

Containerd is a high-performance container runtime that requires careful configuration of its daemon, service integration, storage layout, and plugins. This documentation covers the primary configuration mechanisms and their operational implications.

## Configuration File and Daemon Startup

Most containerd settings reside in `/etc/containerd/config.toml`. The daemon accepts command-line flags to override the default configuration file path and to set core runtime parameters. The `--config` or `-c` flag changes the configuration file path at daemon startup. Additional CLI flags control logging level, gRPC address, and root directory.

Supported logging levels are debug, info, warn, error, fatal, and panic. These levels control verbosity and filtering of daemon output. The `--log-level` or `-l` flag sets this at startup. The `--address` or `-a` flag specifies the address for containerd's gRPC server. The `--root` flag sets the containerd root directory, overriding the configuration file setting.

## Systemd Service Integration

Containerd runs as a systemd service, and proper configuration ensures correct container lifecycle management and resource accounting. Two critical settings are required for production deployments.

`Delegate=yes` permits containerd and its runtimes to manage container control groups independently. Without delegation, systemd can move processes into its own cgroups, disrupting resource accounting and isolation. This setting is essential for accurate container resource management.

`KillMode=process` limits shutdown to the containerd daemon process itself, allowing container shims and containers to survive daemon upgrades and restarts. The default whole-cgroup termination would terminate all processes in the daemon's cgroup, killing running containers. This mode is required for graceful upgrade scenarios.

A typical systemd service file loads the overlay kernel module before starting the daemon and orders the service after `network.target`. This ensures network availability and filesystem readiness when the daemon starts.

Alternatively, containerd can be started with `systemd-run`, which accepts `-p Delegate=yes` and `-p KillMode=process` flags to apply the same settings without a persistent unit file. This approach suits temporary or testing scenarios.

The `oom_score` setting controls Out-Of-Memory (OOM) killer priority. A value of `-999` instructs the kernel to select containers under memory pressure before the daemon itself, preventing the daemon from becoming unkillable. This balances daemon stability with container resource limits.

## Storage Directories

Containerd uses two separate directory hierarchies for different data types, each with distinct persistence requirements.

The `root` directory stores persistent plugin data, including content blobs, snapshots, image and container metadata, and other plugin-specific state that must survive daemon restarts and system reboots. This directory must be backed by persistent storage. Default path is `/var/lib/containerd`. All persistent functionality originates from plugins that write to this location.

The `state` directory stores ephemeral runtime data, including gRPC and debug sockets, process identifiers, mount points, and container runtime state. This data must not survive system reboot and is typically placed on a temporary filesystem. Default path is `/run/containerd`. Both directories are namespaced by plugin, allowing isolated storage within each directory structure.

Storage directories are implementation details. External applications must not modify them directly. Observing or reading these directories during plugin operation has caused EBUSY errors and stale file handle errors during cleanup. Access should occur only through containerd's documented APIs.

## gRPC and Debug Sockets

The gRPC socket is the primary interface for external clients to communicate with the daemon. The debug socket provides diagnostic and introspection capabilities. Both sockets are created in the state directory.

The `grpc` configuration section specifies the gRPC server address, defaulting to `/run/containerd/containerd.sock`. The `uid` and `gid` fields control socket ownership, both defaulting to zero for root. Socket permissions are typically restrictive to limit daemon access to authorized clients.

The `debug` configuration section specifies the debug socket address, defaulting to `/run/containerd/debug.sock`. The `level` field sets debug verbosity; the default is "info". Debug sockets use the same ownership and permission model as the gRPC socket.

## Metrics

Containerd exposes metrics in Prometheus format for monitoring daemon and container performance. The `metrics` configuration section specifies a TCP address where metrics are published. Example configuration uses `127.0.0.1:1234`. Prometheus support in current snapshots requires a TCP metrics endpoint rather than Unix socket.

## Plugin Configuration

Plugins provide containerd's core functionality for snapshots, runtimes, content services, and other subsystems. Plugin-specific settings use `[plugins.<name>]` sections in the configuration file. CLI flags do not control plugin configuration; operators must consult each plugin's documentation for available options and defaults.

## Linux Runtime Configuration

The Linux runtime plugin requires specific settings for shim and runtime binary selection. The `shim` field specifies the shim binary name or path. The `runtime` field specifies the runtime binary; `runc` is a common choice. The `no_shim` flag disables shim usage, saving memory but removing live restore support for containers. The `shim_debug` flag includes shim logs in the daemon's standard output, aiding troubleshooting.

## Content Sharing Policy

The Bolt metadata plugin manages content blob sharing between namespaces. The `content_sharing_policy` field in `[plugins.bolt]` selects the sharing mode. The `shared` policy (default) allows namespaces to reuse blobs by opening writers with expected digests, reducing bandwidth but permitting blob access from digest knowledge alone. The `isolated` policy requires all content submission before namespace entry, demonstrating explicit access. Both modes share backing storage; policy selection affects security boundaries and efficiency trade-offs.
