# etcd Documentation

## Introduction

etcd is a distributed key-value store designed for storing critical system data across a cluster. It is implemented in Go and utilizes the Raft consensus algorithm to ensure a highly available replicated log. This architecture provides distributed reliability and ensures data consistency across multiple nodes. The system exposes a gRPC API for client communication and supports automatic TLS with optional client-certificate authentication for secure interactions.

Historical benchmarks reported by the source indicate a performance capacity of 10,000 writes per second. This figure represents a specific measurement from the source documentation and should not be treated as a universal performance guarantee for all environments. etcd is widely used in production environments, including integration with Kubernetes, locksmith, vulcand, and Doorman. Its reliability is supported by extensive functional testing. The primary command-line client for interacting with etcd is etcdctl.

## Installation and Versions

Prebuilt releases are available for macOS, Linux, Windows, and Docker, providing convenient deployment options for various operating systems. For users preferring to build from source, the latest master branch requires Go version 1.12 or later in this snapshot.

It is important to note that the master branch may be unstable or broken during development phases. For stable binaries suitable for production or reliable testing, official releases are recommended. Features and bug fixes initially land on the master branch. Subsequently, these changes are ported to release branches according to the project’s branch-management guidance. Additional installation and operations guides are linked at play.etcd.io and within the project’s Documentation section.

## Single-Node Startup

To run a single-member cluster, users can utilize the downloaded etcd binary. The binary can be moved to a location on the system PATH and executed simply by running the `etcd` command. Alternatively, after a source build, the binary can be executed directly from the build directory using `./bin/etcd`.

For the prebuilt test binary, the execution path is `/tmp/etcd-download-test/etcd`. To make this accessible globally, one may move the binary to `/usr/local/bin/` and then run `etcd`.

Client communication with the etcd server occurs on port 2379, while peer-to-peer communication between cluster members uses port 2380.

## Basic Operations

Once the single-node cluster is running, interactions can be performed using the etcdctl client. The following commands demonstrate basic key-value operations:

```bash
etcdctl put mykey "this is awesome"
etcdctl get mykey
```

These commands illustrate writing a value to a key and subsequently retrieving it, without making additional claims about application performance or behavior.

## Local Cluster and Proxy Setup

For local multi-node testing, the project provides a Procfile example managed by goreman. Running `goreman start` launches a local cluster consisting of three members named infra1, infra2, and infra3, along with an etcd grpc-proxy. All members and the proxy accept key-value reads and writes, facilitating comprehensive local testing of cluster behaviors.

## API and Further Configuration

The etcd API provides robust capabilities for distributed data storage. Follow-on documentation covers the full API specification, multi-machine cluster configurations, command-line flags, environment variables, and configuration options. Additional topics include integrations, TLS security setup, and tuning parameters for optimal performance.

## Contribution and Community

The project welcomes contributions, bug reports, and issue triaging. Guides for contribution, bug reporting, issue triage, and pull request management are available as separate linked documents. Security issues should be discussed with MAINTAINERS first; they may be reported publicly only when appropriate.

The etcd project is licensed under the Apache 2.0 license. Emeritus maintainers associated with the project include Fanmin Shi and Anthony Romano.

## Historical Community Information

Historical community announcements indicate that development activities resumed on January 10, 2019. Meetings were scheduled every four weeks on Thursdays at 11:00 AM US Pacific time. Agendas were placed in a shared document a day before meetings, and suggestions were welcome. The following Zoom and dial-in information was provided for these historical meetings:

```
One tap mobile
+14086380986,,916003437# US (San Jose)
+16465588665,,916003437# US (New York)

Dial by location
        +1 408 638 0986 US (San Jose)
        +1 646 558 8665 US (New York)

Meeting ID: 916 003 437
```

## Contact Channels

Community engagement and technical discussions occur through several channels. The primary mailing list is etcd-dev. Historically, the freenode etcd IRC channel was used for real-time communication. GitHub milestones and roadmaps track project progress, and issues are managed via GitHub. These channels remain the primary points of contact for developers and users.
