# Libevent Build Systems, Installation, and Community

## Overview

Libevent provides two build systems for compilation and installation: Autoconf, which is the mature and fully supported build environment in this snapshot, and CMake, which represents a new and experimental workflow. The choice of build system depends on your platform and preferences, with Autoconf being the established choice for Unix-like systems and CMake providing enhanced Windows support alongside Unix capabilities.

## Autoconf Build System

The Autoconf build system is the established approach for compiling Libevent on Unix-like platforms. The basic workflow consists of three primary steps: configuration, compilation, and optional testing, followed by installation.

To build from a release or stable source, execute the following sequence:

```
$ ./configure
$ make
$ make verify   # (optional)
$ sudo make install
```

For users working with git checkouts directly from the repository, an additional preliminary step is required. Before running the configure script, you must first generate it by executing the autogen.sh script to create the configure script and supporting build infrastructure necessary for the build process.

The `make verify` command runs the regression test suite, which is optional but strongly recommended. Running these tests ensures that Libevent functions correctly on your system. Before reporting any problems or issues, it is strongly advised that regression tests be run to verify the integrity of the build.

Installation via `make install` typically requires root or administrator privileges on the target system. The command installs compiled libraries and headers to system directories as determined by the configuration prefix.

## Autoconf Configuration Options

The configure script accepts numerous options to customize the build. Key options include:

The `--prefix` option specifies the root directory for all installed files, allowing for installation in non-standard locations. The `--disable-shared` option restricts the build to static-only libraries, producing only .a files rather than shared objects.

Compiler behavior can be tuned with `--enable-gcc-warnings`, which enables extra compiler checking when using GCC to identify potential code quality issues.

Feature control options include `--disable-malloc-replacement`, which prevents applications from replacing the memory management functions provided by Libevent. The `--disable-openssl` option removes support for OpenSSL encryption, reducing dependencies. The `--disable-thread-support` option builds Libevent without multithreaded environment support.

For debugging purposes, the CFLAGS environment variable can be used to enable low-level tracing. Setting `CFLAGS=-DUSE_DEBUG` before running configure activates verbose debugging output that provides detailed traces of internal operations useful for diagnosing issues.

## CMake Build System

CMake is a cross-platform build system that provides particular advantages for Windows development while also supporting Unix platforms. The CMake workflow is described as new and experimental in this snapshot.

### Windows CMake Workflow

On Windows systems, the process begins with installing CMake if not already present. Create a build directory within the Libevent source tree and configure the project by specifying a Visual Studio generator:

```
$ mkdir build && cd build
$ cmake -G "Visual Studio 10" ..   # Or whatever generator you prefer; use cmake --help for a list
$ start libevent.sln
```

The generated Visual Studio solution can then be opened and built within the IDE. Alternatively, NMake Makefiles provides a command-line build interface for Windows environments.

### Unix CMake Workflow

On Unix systems, the process is streamlined with simpler defaults:

```
$ mkdir build && cd build
$ cmake ..     # Default to Unix Makefiles
$ make
$ make verify  # (optional)
```

This configuration defaults to Unix Makefiles. The optional `make verify` command runs regression tests to validate the build.

### CMake Workflow Features

A significant advantage of CMake is support for out-of-source builds, allowing multiple configurations to be built from a single source tree without conflicts. Each configuration exists in its own build directory.

The CMake GUI tool provides interactive selection of source and output directories when preferred over command-line configuration. To list available CMake settings and their current values, use `cmake -LAH <sourcedir_path>`.

## CMake Configuration Variables

CMake provides numerous configuration options expressed as variables with documented defaults:

`EVENT__LIBRARY_TYPE` controls whether to build shared or static libraries, defaulting to SHARED for MSVC and BOTH otherwise. `EVENT_INSTALL_CMAKE_DIR` specifies the installation directory for CMake configuration files, defaulting to lib/cmake/libevent.

`EVENT__COVERAGE` enables gcov coverage reporting, disabled by default and working only with GCC or Clang when CMAKE_BUILD_TYPE equals Debug. `EVENT__DISABLE_BENCHMARK` prevents building benchmark executables. `EVENT__DISABLE_DEBUG_MODE` disables debug mode support. `EVENT__DISABLE_MM_REPLACEMENT` prevents replacing memory management functions. `EVENT__DISABLE_OPENSSL` removes OpenSSL encryption support. `EVENT__DISABLE_REGRESS` disables regression tests. `EVENT__DISABLE_SAMPLES` prevents building sample files. `EVENT__DISABLE_TESTS` prevents compiling test programs. `EVENT__DISABLE_THREAD_SUPPORT` disables thread support. `EVENT__ENABLE_VERBOSE_DEBUG` enables verbose debugging output.

`EVENT__FORCE_KQUEUE_CHECK`, used when cross-compiling, forces verification of kqueue functionality with pipes. This requires manual testing of the generated test program on the target platform to verify correct operation.

## Community Resources

Official releases are available through libevent.org. Nick Mathewson provides a work-in-progress Libevent book documenting library usage and internals. The source code, issue tracker, and pull request system are hosted on GitHub at https://github.com/libevent/libevent.git.

Community discussion occurs on the libevent-users mailing list, with archives maintained at archives.seul.org/libevent/users. Git patches and bug reports can be submitted to the mailing list for review and integration.

## Acknowledgments

The Libevent project has benefited from contributions by numerous individuals who have provided suggestions, ideas, code, and bug fixes. The project maintains an extensive acknowledgments list crediting all contributors. If you believe your name has been omitted from the acknowledgments, please contact the project maintainers for inclusion.
