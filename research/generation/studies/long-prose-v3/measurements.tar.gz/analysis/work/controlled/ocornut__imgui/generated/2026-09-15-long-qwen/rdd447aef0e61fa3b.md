# Dear ImGui: Architecture, Integration, and Development Overview

Dear ImGui is a self-contained, renderer-independent C++ graphical user interface (GUI) library designed for creating tools, visualizations, and debuggers. It is characterized by its lack of external dependencies, making it an ideal choice for integration into existing projects without complex build requirements. The library produces vertex buffers and command lists, which are then rendered within the application’s 3D pipeline. Its primary intended users are programmers building creation, visualization, and debugging tools for game engines, real-time 3D applications, fullscreen environments, embedded systems, and console applications. It is important to note that Dear ImGui does not include some higher-level or end-user UI features found in traditional desktop UI toolkits; instead, it focuses on providing the fundamental primitives necessary for custom tool development.

## Core Architecture and Immediate Mode Paradigm

The fundamental design of Dear ImGui is based on the immediate-mode GUI paradigm. Unlike retained-mode interfaces, where the application state is managed by the UI framework, immediate-mode UI minimizes duplicated, synchronized, and retained application state. This approach supports dynamic interfaces that can change rapidly based on program logic. In this model, GUI calls can occur throughout the program loop, including within algorithms or rendering code, because the library does not directly alter graphics state during the immediate execution of UI commands.

It is a common misconception that immediate-mode implies an immediate GPU call for every single widget. In reality, Dear ImGui batches a small draw-call list and buffers these commands. This allows the rendering to happen later or remotely, optimizing performance by reducing the number of state changes and draw calls submitted to the graphics card. This batching mechanism ensures that while the interface is highly responsive and dynamic, it remains efficient for real-time applications.

Common use cases for Dear ImGui include temporary hot-reloaded controls, algorithm traces, data inspection, logs, profilers, debuggers, and editors. The library’s simplicity allows developers to inspect internal states and modify parameters in real-time, facilitating rapid iteration and debugging.

## Integration and Backend System

Integrating Dear ImGui into an existing project is straightforward. Developers need to compile the root `.cpp` files, specifically `imgui.cpp`, `imgui_demo.cpp`, and `imgui_draw.cpp`, directly into their project. No special build system is required for this core integration. However, to function, the library requires a backend that feeds mouse, keyboard, and gamepad inputs, as well as platform-specific settings, and handles the actual rendering of the vertices.

Integration typically involves uploading one texture atlas and supplying textured-triangle rendering capabilities. Official examples are provided for various backends, but custom backends are entirely possible for unique platforms or requirements. The official renderers supported include DirectX 9, 10, 11, and 12; legacy OpenGL; modern OpenGL3/ES/ES2; Vulkan; and Metal. Supported platforms include GLFW, SDL2, Win32, GLUT, and OSX. Additionally, frameworks such as Emscripten, Allegro5, and Marmalade are supported.

Combining existing platform and renderer backends is recommended to ensure stability and compatibility. For developers using other languages or frameworks, a list of third-party bindings is available. Notably, `cimgui` provides C bindings that are auto-generated. These bindings expose JSON and Lua data, which can be used by other binding generators to create interfaces for various programming languages.

## API Usage and Examples

The API of Dear ImGui is designed to be simple and intuitive. Developers can create windows, menus, buttons, and input fields with minimal code. Below is a simple example demonstrating basic text output, buttons, input fields, and sliders:

```cpp
ImGui::Text("Hello, world %d", 123);
if (ImGui::Button("Save"))
    MySaveFunction();
ImGui::InputText("string", buf, IM_ARRAYSIZE(buf));
ImGui::SliderFloat("float", &f, 0.0f, 1.0f);
```

For more complex interfaces, such as windows with menu bars and child scrolling regions, the API allows for nested structures. The following example creates a window called "My First Tool" with a menu bar, color editing, data plotting, and a scrolling text list:

```cpp
// Create a window called "My First Tool", with a menu bar.
ImGui::Begin("My First Tool", &my_tool_active, ImGuiWindowFlags_MenuBar);
if (ImGui::BeginMenuBar())
{
    if (ImGui::BeginMenu("File"))
    {
        if (ImGui::MenuItem("Open..", "Ctrl+O")) { /* Do stuff */ }
        if (ImGui::MenuItem("Save", "Ctrl+S"))   { /* Do stuff */ }
        if (ImGui::MenuItem("Close", "Ctrl+W"))  { my_tool_active = false; }
        ImGui::EndMenu();
    }
    ImGui::EndMenuBar();
}

// Edit a color (stored as ~4 floats)
ImGui::ColorEdit4("Color", my_color);

// Plot some values
const float my_values[] = { 0.2f, 0.1f, 1.0f, 0.5f, 0.9f, 2.2f };
ImGui::PlotLines("Frame Times", my_values, IM_ARRAYSIZE(my_values));

// Display contents in a scrolling region
ImGui::TextColored(ImVec4(1,1,0,1), "Important Stuff");
ImGui::BeginChild("Scrolling");
for (int n = 0; n < 50; n++)
    ImGui::Text("%04d: Some text", n);
ImGui::EndChild();
ImGui::End();
```

## Demo and Visual Features

The `ImGui::ShowDemoWindow` function provides a comprehensive demonstration of the features implemented in `imgui_demo.cpp`. This demo window serves as both a testing ground for new features and a reference for API usage. Example builds are tested on Windows, macOS, and Linux. The supplied Windows download, version 1.78 WIP dated September 18, 2020, is provided for immediate testing. Please note that these demo binaries are not DPI-aware. Applications integrating Dear ImGui should reload fonts at appropriate scales and call `style.ScaleAllSizes` to ensure proper rendering on high-DPI displays. Guidance on handling DPI is available in the Frequently Asked Questions (FAQ).

## Development Plans and Upcoming Changes

The development roadmap for 2020 focuses on several key areas aimed at enhancing the library's capabilities for complex UI layouts and input handling. Plans include the implementation of docking and multiple viewports/OS windows, which are being developed on the docking branch. This feature set aims to allow users to arrange multiple windows in a tabbed or docked interface, similar to modern IDEs.

Additionally, support for gamepad and keyboard controls is being expanded to improve usability in console and embedded environments. A new Tables API, developed on the tables branch, is planned to replace the older Columns API, offering more robust and flexible table layouts. Other development goals include automated library and application testing, as well as improved styles, fonts, and HiDPI examples. These plans are subject to feedback from the community, and developers are encouraged to provide input on the docking and tables branches.

## Documentation and Resources

Comprehensive documentation is available to assist users at all levels. Resources include release notes, demos, the FAQ, a wiki, paradigm articles, binding lists, galleries, user quotes, and software listings. Beginners encountering setup, input, or font problems are encouraged to use the Discord community for real-time assistance. For bug reports, feature requests, and technical feedback, GitHub issues should be used with the provided template.

The master branch is generally recommended as it is stable and receives regular updates. Advanced users who wish to test upcoming features may use the regularly synchronized docking branch. For those requiring private support, paying businesses can obtain dedicated assistance by contacting the maintainers directly.

## Support, Community, and Sponsorship

Dear ImGui relies on a vibrant community and corporate sponsorship for its continued development. Help is primarily provided through community answers, GitHub issues, and maintainable pull requests (PRs). Maintainers take ongoing responsibility for accepted code, ensuring quality and stability.

Businesses interested in supporting the project can do so through support and maintenance contracts by contacting `contact@dearimgui.com`. Individuals can also contribute through donations. The sponsor roster records corporate support, and ongoing development from November 2014 through December 2019 was financially supported by users on Patreon and through individual donations.

Platinum and chocolate sponsors include major industry players such as Blizzard, Google, Nvidia, and Ubisoft. Other significant supporters include Activision, Arkane Studios, Dotemu, Framefield, Hexagon, Kylotonn, Media Molecule, Mesh Consultants, Mobigame, Nadeo, Next Level Games, RAD Game Tools, Supercell, Remedy Entertainment, and Unit 2 Games.

Free open-source services are also utilized to maintain code quality and reliability. PVS-Studio provides static analysis, GitHub Actions handles continuous integration, and OpenCppCoverage offers code coverage analysis.

## Credits and Licensing

Dear ImGui was developed by Omar Cornut, with contributions from various developers. The library was initially supported by Media Molecule and was used in the game *Tearaway* on the PlayStation Vita. Cornut was inspired by Atman Binstock’s implementation at Q-Games, which he later rewrote at Media Molecule. Recurring contributors in 2020 include Rokas Kupstys and Ben Carter. Some automation and regression work remains unpublished. Credits are also extended to Casey Muratori and early feedback/testing contributors listed in the source code.

The library is released under the MIT License. Embedded fonts include `ProggyClean.ttf` by Tristan Grimmer, also under the MIT license. The third-party headers `stb_textedit.h`, `stb_truetype.h`, and `stb_rect_pack.h` are by Sean Barrett and are identified as public domain.

## Third-Party Bindings and Frameworks

Dear ImGui supports a wide array of languages and frameworks through third-party bindings. Languages include C, C#, C++, and bindings for Beef, ChaiScript, Crystal, D, Go, Haskell, Haxe/hxcpp, Java, JavaScript, Julia, Kotlin, Lua, Odin, Pascal, PureBasic, Python, Ruby, Rust, and Swift.

Frameworks and engines supported include AGS/Adventure Game Studio, Amethyst, bsf, Cinder, Cocos2d-x, Diligent Engine, Flexium, GML/Game Maker Studio2, Godot, GTK3+OpenGL3, Irrlicht Engine, LÖVE+LUA, Magnum, NanoRT, nCine, Nim Game Lib, Ogre, openFrameworks, OSG/OpenSceneGraph, Orx, Photoshop, px_render, Qt/QtDirect3D, SFML, Sokol, Unity, Unreal Engine 4, vtk, Win32 GDI, and WxWidgets.

For detailed information on bindings, users are directed to the [Bindings](https://github.com/ocornut/imgui/wiki/Bindings) page on the wiki. The wiki also hosts a list of software using Dear ImGui, user quotes, and additional resources.
