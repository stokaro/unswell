# Lazy pulling stargz/eStargz base images (Experimental)

This document describes how to configure BuildKit to lazily pull [stargz](https://github.com/google/crfs/blob/master/README.md#introducing-stargz)- and [eStargz](https://github.com/containerd/stargz-snapshotter/blob/master/docs/stargz-estargz.md)-formatted images from registries.

By default, BuildKit does not pull images until they are strictly needed. For example, during a build, BuildKit does not pull the base image until it runs commands on it (such as a `RUN` Dockerfile instruction) or exports stages as tarballs.

Additionally, when an image is formatted as stargz/eStargz, BuildKit can skip pulling that image even when it is needed (for example, for `RUN` and `COPY` instructions). Instead, it *mounts* the image from the registry on the node and *lazily* fetches the necessary files—or chunks of large files—from the image on demand. This can reduce build time. This document describes the configuration and usage of this feature.

For more details about the stargz/eStargz image format, see the [Stargz and eStargz image formats](#stargz-and-estargz-image-formats) section.

## Known limitations

- For the OCI worker, `~/.docker/config.json`-based authentication cannot be used for stargz/eStargz-based lazy pulling.
- For the containerd worker, the stargz snapshotter (`containerd-stargz-grpc`) must be run and configured separately.
- Rootless execution is currently unsupported.

## Enabling lazy pulling of stargz/eStargz images

BuildKit supports two ways to enable lazy pulling of stargz/eStargz images.

### Using built-in support (recommended)

The OCI worker has built-in support for stargz/eStargz. Enable this feature by running `buildkitd` with the `--oci-worker-snapshotter=stargz` option.

```
buildkitd --oci-worker-snapshotter=stargz
```

This is the easiest way to use lazy pulling with BuildKit. Currently, this configuration is unsupported for the containerd worker.

#### Example of building an image with lazy pull

Once `buildkitd` starts with the configuration above, stargz/eStargz images can be lazily pulled. For example, the following Go program can be built with BuildKit.

```golang
package main

import "fmt"

func main() {
	fmt.Println("Hello, world!")
}
```

The following Dockerfile uses an eStargz-formatted base image.

```Dockerfile
# Uses an eStargz-formatted golang image as the base image. It is not pulled here.
FROM ghcr.io/stargz-containers/golang:1.15.3-buster-esgz AS dev

# Copies the source code from the context. The base image is mounted and pulled lazily.
COPY ./hello.go /hello.go

# Runs the Go compiler on that base image. The base image is mounted and pulled lazily.
RUN go build -o /hello /hello.go

FROM scratch

# Harvests the resulting binary.
COPY --from=dev /hello /
```

The image can then be built without pulling `ghcr.io/stargz-containers/golang:1.15.3-buster-esgz`. Instead, the image is mounted from the registry on the node, and the necessary content (such as the `go` command binary and libraries) is fetched partially from the registry on demand.

```
$ buildctl build --frontend dockerfile.v0 \
                 --local context=/tmp/hello \
                 --local dockerfile=/tmp/hello \
                 --output type=local,dest=./
$ ./hello
Hello, world!
```

When a stage is exported (for example, to a registry), the base image for that stage—including a stargz/eStargz image—must be pulled so it can be copied to the destination. However, if the destination is a registry and the target repository already contains some blobs from that image, or if [cross-repository blob mount](https://docs.docker.com/registry/spec/api/#cross-repository-blob-mount) can be used, BuildKit keeps those blobs lazy.

Registry configuration in `/etc/buildkit/buildkitd.toml` also applies to lazy pulling. However, `~/.docker/config.json`-based authorization is currently unsupported. Integration work is in progress.

### Using a proxy (standalone) snapshotter

Another way to enable stargz-based lazy pulling is to install the [Stargz Snapshotter (`containerd-stargz-grpc`)](https://github.com/containerd/stargz-snapshotter). BuildKit's registry configuration does not propagate to the stargz snapshotter, so it must be configured separately when using private or mirror repositories.

This configuration is for users of the containerd worker and for users who want to try versions of the stargz snapshotter other than the one built into the OCI worker.

#### With the OCI worker

Run `containerd-stargz-grpc` as a separate process. Then run `buildkitd` with `--oci-worker-proxy-snapshotter-path=/run/containerd-stargz-grpc/containerd-stargz-grpc.sock` so it recognizes the snapshotter through the socket.

```
containerd-stargz-grpc
buildkitd --oci-worker-snapshotter=stargz \
          --oci-worker-proxy-snapshotter-path=/run/containerd-stargz-grpc/containerd-stargz-grpc.sock
```

#### With the containerd worker

Configure containerd's `config.toml` (by default, `/etc/containerd/config.toml`) so it recognizes the stargz snapshotter as a [proxy snapshotter](https://github.com/containerd/containerd/blob/master/PLUGINS.md#proxy-plugins).

```toml
[proxy_plugins]
  [proxy_plugins.stargz]
    type = "snapshot"
    address = "/run/containerd-stargz-grpc/containerd-stargz-grpc.sock"
```

Then start `containerd-stargz-grpc` and `containerd`, and run `buildkitd` with `--containerd-worker-snapshotter=stargz` to tell containerd to use the stargz snapshotter.

```
containerd-stargz-grpc
containerd
buildkitd --containerd-worker-snapshotter=stargz --oci-worker=false --containerd-worker=true
```

#### Registry-related configuration for the standalone stargz snapshotter

When using the standalone stargz snapshotter, configure its registry settings separately. Create a TOML file containing the registry configuration for the stargz snapshotter (for example, `/etc/containerd-stargz-grpc/config.toml`). The configuration format [**differs** from BuildKit](https://github.com/containerd/stargz-snapshotter/blob/master/cmd/containerd-stargz-grpc/config.go). For more information, see the [repository documentation](https://github.com/containerd/stargz-snapshotter/blob/master/docs/overview.md#registry-related-configuration).

```toml
[[resolver.host."exampleregistry.io".mirrors]]
host = "examplemirror.io"
```

Pass this file to the stargz snapshotter with the `--config` option.

```
containerd-stargz-grpc --config=/etc/containerd-stargz-grpc/config.toml
```

## Stargz and eStargz image formats

[Stargz](https://github.com/google/crfs/blob/master/README.md#introducing-stargz) and [eStargz](https://github.com/containerd/stargz-snapshotter/blob/master/docs/stargz-estargz.md) are OCI/Docker-compatible image formats that can be lazily pulled from standard registries, such as Docker Hub and GitHub Container Registry. Because they are backward-compatible with OCI/Docker images, they can run on standard runtimes, such as Docker and containerd.

Stargz was proposed by the [Google CRFS project](https://github.com/google/crfs). eStargz is an extended version of stargz developed by the [Stargz Snapshotter](https://github.com/containerd/stargz-snapshotter). It provides [additional features](https://github.com/containerd/stargz-snapshotter/blob/master/docs/stargz-estargz.md#estargz-archive-format), including chunk verification and prefetching to avoid the overhead of on-demand fetching. For more information about lazy pulling with stargz/eStargz images, see the documentation in these repositories.

### Getting stargz/eStargz-formatted images

Pre-converted stargz/eStargz images are available in the [`ghcr.io/stargz-containers` repository](https://github.com/containerd/stargz-snapshotter/blob/master/docs/pre-converted-images.md), mainly for testing.

You can also create stargz/eStargz images by converting an OCI/Docker image with one of the following tools:

- [`ctr-remote`](https://github.com/containerd/stargz-snapshotter#creating-stargz-images-and-further-optimization), developed as part of the stargz snapshotter project.
- [`stargzify`](https://github.com/google/crfs/tree/master/stargz/stargzify), developed as part of the CRFS project. Creating eStargz images is unsupported.

For more information about these tools, see the documentation in their respective repositories.
