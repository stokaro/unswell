# Contributing to Svelte

Svelte is a new way to build web applications. It's a compiler that takes your declarative components and converts them into efficient JavaScript that surgically updates the DOM.

The [Open Source Guides](https://opensource.guide/) website has a collection of resources for individuals, communities, and companies. These resources help people who want to learn how to run and contribute to open source projects. Contributors and newcomers to open source will find the following guides especially useful:

* [How to Contribute to Open Source](https://opensource.guide/how-to-contribute/)
* [Building Welcoming Communities](https://opensource.guide/building-community/)

## Get involved

There are many ways to contribute to Svelte, and many do not require writing code. Here are some ideas to get started:

- Use Svelte and complete the [Getting Started](https://svelte.dev/blog/the-easiest-way-to-get-started) guide. If you encounter issues, [open a bug report](#reporting-new-issues).
- Review [open issues](https://github.com/sveltejs/svelte/issues). Provide workarounds, request clarification, suggest labels, and help [triage issues](#triaging-issues-and-pull-requests).
- [Open a pull request](#your-first-pull-request) to fix an issue you find.
- Review the [tutorials](https://svelte.dev/tutorial/basics). Click "Edit this chapter" at the bottom left of any tutorial page to suggest improvements.
- Look at [features requested](https://github.com/sveltejs/svelte/labels/enhancement) by the community and consider opening a pull request.

Need help planning your contribution? Contact us on Discord at [svelte.dev/chat](https://svelte.dev/chat).

### Triaging issues and pull requests

Help triage issues and pull requests without writing code:

- Request additional information if an issue lacks necessary details to solve it.
- Suggest [labels](https://github.com/sveltejs/svelte/labels) to categorize issues.
- Flag stale or closed issues.
- Ask for test plans and review code.

## Bugs

Report bugs on [GitHub issues](https://github.com/sveltejs/svelte/issues). Check whether someone has already reported the issue before submitting a [bug report](#reporting-new-issues).

For questions about using Svelte, contact us on Discord at [svelte.dev/chat](https://svelte.dev/chat).

To request a feature, [create a feature request issue](https://github.com/sveltejs/svelte/issues/new?template=feature_request.md).

## Reporting new issues

When [opening a new issue](https://github.com/sveltejs/svelte/issues/new/choose), fill out the issue template completely. **This is important.** Incomplete reports may not be processed promptly. Feel free to open a new issue once you have gathered all required information.

- **One issue, one bug:** Report a single bug per issue.
- **Provide reproduction steps:** List all steps necessary to reproduce the issue so others can follow them with minimal effort. Use the [REPL](https://svelte.dev/repl) if possible.

## RFCs

For large new features or significant changes, [create an RFC](https://github.com/sveltejs/rfcs) to discuss the proposal first.

## Installation

1. Ensure you have [npm](https://www.npmjs.com/get-npm) installed.
1. After cloning the repository, run `npm install` in the root directory.
1. Start a development server with `npm run dev`.

## Pull requests

### Your first pull request

Submitting code to the project is appreciated. We will review your contribution. Learn from this free video series:

[**How to Contribute to an Open Source Project on GitHub**](https://egghead.io/courses/how-to-contribute-to-an-open-source-project-on-github)

### Proposing a change

File an issue with the [feature template](https://github.com/sveltejs/svelte/issues/new?template=feature_request.md) to request a new feature or enhancement before submitting code.

For bug fixes, file an issue describing what you are fixing, even if you plan to submit a pull request directly. This helps track the issue if we do not accept the specific fix.

### Sending a pull request

Keep pull requests small and focused on a single change. Split large requests into multiple PRs.

When submitting a pull request:

1. Fork [the repository](https://github.com/sveltejs/svelte) and create your branch from `master`.
1. Describe your **test plan** in the pull request description and verify your changes.
1. Ensure your code passes linting: `npm run lint`.
1. Ensure your tests pass: `npm run test`.

All pull requests must target the `master` branch.

#### Test plan

A good test plan includes the exact commands you ran and their output. Provide screenshots or videos if your changes affect the UI.

- Update documentation if you have changed APIs.

#### Writing tests

All tests are in the `/test` folder. Test samples are in `/test/xxx/samples`.

#### Running tests

1. Run tests with `npm run test`.
1. Use `-g` (or `--grep`) to run tests for a specific feature. For example: `npm run test -- -g transition`.

##### Running solo tests

1. Rename a test sample folder to end with `.solo` to run that test only. For example: `test/js/samples/action.solo`.
1. Rename a test suite folder to end with `.solo` to run only that suite. For example: `test/js.solo`.
1. Rename the folder back before committing, as solo tests will fail CI.

##### Updating `.expected` files

1. Test suites like `css`, `js`, and `server-side-rendering` assert that generated output matches the `.expected` file. For example, the `js` suite compares generated code to `expected.js`.
1. Update `.expected` files by running `npm run test --update`.

#### Breaking changes

Use this template in your pull request for breaking changes:

```md
### New breaking change here

- **Who does this affect**:
- **How to migrate**:
- **Why make this breaking change**:
- **Severity (number of people affected x effort)**:
```

### What happens next?

The core Svelte team monitors pull requests. Follow the guidelines above to make your request easy to review.

## Style guide

[Eslint](https://eslint.org) catches most styling issues. Check your code with `npm run lint`.

### Code conventions

- `snake_case` for internal variable names and methods.
- `camelCase` for public variable names and methods.

## License

Contributions are licensed under the [MIT license](https://github.com/sveltejs/svelte/blob/master/LICENSE).
