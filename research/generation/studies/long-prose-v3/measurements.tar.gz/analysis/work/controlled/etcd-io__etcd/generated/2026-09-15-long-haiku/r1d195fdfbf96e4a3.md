# Introduction to etcd

etcd is a distributed key-value store designed for critical system data. Implemented in Go, it uses Raft consensus to maintain a highly available replicated log. The system provides a gRPC API, automatic TLS with optional client-certificate authentication, and has been benchmarked at 10,000 writes per second. This architecture enables distributed reliability across deployments.

etcd is used in production environments including Kubernetes, locksmith, vulcand, and Doorman. These deployments depend on the reliability supported by extensive functional testing. The etcdctl command-line client provides direct access to the key-value store.

## Installation

etcd is available through multiple installation methods. Prebuilt releases are provided for macOS, Linux, Windows, and Docker. These releases represent stable binaries suitable for production use. The master branch may be unstable or broken during development; releases are recommended for stability.

To use a prebuilt release, download the binary for your platform and extract it to a convenient location. Installation guides, along with additional operations documentation, are linked at play.etcd.io and in the project's Documentation. Alternatively, you can build etcd from source. This approach requires Go 1.12 or later. Features and bug fixes first land on the master branch before being ported to release branches according to the project's branch-management guidance.

## Single-Node Cluster

Starting a single-member cluster is straightforward. If you have downloaded a prebuilt release, run the binary from its installation location:

```
/tmp/etcd-download-test/etcd
```

Alternatively, you can move the etcd binary onto your system PATH and run it directly:

```
mv /tmp/etcd-download-test/etcd /usr/local/bin/
etcd
```

If you built etcd from source, execute the binary from the build directory:

```
./bin/etcd
```

By default, client communication uses port 2379, while peer communication uses port 2380. Once the etcd server starts, you can interact with it using etcdctl. To write and read a key-value pair, use the following commands:

```
etcdctl put mykey "this is awesome"
etcdctl get mykey
```

This clearly demonstrates the core functionality of etcd as a key-value store accessible through the etcdctl interface.

## Local Multi-Member Cluster

To run a local cluster with multiple members, the project provides a Procfile example managed by goreman. goreman is a process manager that simplifies running multiple etcd instances on a single machine. Launch the local cluster using:

```
goreman start
```

This command starts three members named infra1, infra2, and infra3, along with an etcd grpc-proxy. All members and the proxy accept key-value reads and writes, allowing you to test distributed operations locally. This configuration is useful for development and testing scenarios.

## APIs and Interfaces

etcd exposes its functionality through a gRPC API. This API supports the core operations of reading and writing key-value pairs, as well as additional distributed features enabled by the Raft consensus mechanism. The automatic TLS configuration provides secure communication between clients and servers, with optional client-certificate authentication for enhanced security and reliability.

## Documentation and Resources

The project provides extensive follow-on documentation covering the full API specification, configuration for multi-machine clusters, command-line flags and environment variables, system integrations, TLS security configuration, and performance tuning. These resources support both development and production deployments. Additional guides address operations, monitoring, and best practices for running etcd in various environments.

## Contribution and Support Channels

Contribution guidelines are available through separate linked documents covering contributions, bug reporting, issue triage, and pull request management. Security issues should be handled carefully: they may be reported publicly only when appropriate. Otherwise, security concerns should be discussed with MAINTAINERS before public disclosure to ensure proper handling.

The etcd project maintains multiple contact channels for community engagement and support. The etcd-dev mailing list serves as a primary communication channel for discussions and announcements. A historical freenode IRC channel for etcd is available for community discussion and feedback. GitHub milestones and roadmap documentation provide visibility into planned work, while GitHub issues allow tracking of bugs and feature requests.

The project's community meeting schedule was resumed on January 10, 2019, with meetings held every four weeks on Thursday at 11:00 AM US Pacific Time. Meeting agendas are prepared in a shared document one day before each meeting, with community suggestions welcome. Zoom connection details and calendar information are provided for remote participation.

Emeritus maintainers Fanmin Shi and Anthony Romano are recognized for their historical contributions to the project. etcd is distributed under the Apache 2.0 license.
