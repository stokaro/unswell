## Dear ImGui: Using Fonts

Dear ImGui embeds `ProggyClean.ttf`, by Tristan Grimmer, in `imgui.cpp`. This 13-pixel, pixel-perfect font is used by default and requires no filesystem access. Because ProggyClean does not scale smoothly, load your own font when building an application that should look good at multiple resolutions.

You can also load external `.TTF` and `.OTF` files. The [`misc/fonts/`](https://github.com/ocornut/imgui/tree/master/misc/fonts) folder contains several suggested fonts.

For more information, read the [Fonts section of the FAQ](https://www.dearimgui.org/faq). Use the [Discord server](http://discord.dearimgui.org), rather than the GitHub issue tracker, for basic font-loading questions.

## Index

- [Readme First](#readme-first)
- [How should I handle DPI in my application?](#how-should-i-handle-dpi-in-my-application)
- [Font Loading Instructions](#font-loading-instructions)
- [Using Icons](#using-icons)
- [Using FreeType Rasterizer](#using-freetype-rasterizer)
- [Using Custom Glyph Ranges](#using-custom-glyph-ranges)
- [Using Custom Colorful Icons](#using-custom-colorful-icons)
- [Using Font Data Embedded In Source Code](#using-font-data-embedded-in-source-code)
- [About filenames](#about-filenames)
- [Credits/Licenses For Fonts Included In Repository](#creditslicenses-for-fonts-included-in-repository)
- [Font Links](#font-links)

---------------------------------------

## Readme First

All loaded font glyphs are rendered into one texture atlas. Calling `io.Fonts->GetTexDataAsAlpha8()`, `io.Fonts->GetTexDataAsRGBA32()`, or `io.Fonts->Build()` builds the atlas.

Use `ImGui::ShowStyleEditor()` and its **Fonts** section to inspect loaded fonts. You can also open it through `Demo->Tools->Style Editor->Fonts`.

Font-range data must remain available while calling `GetTexDataAsAlpha8()`, `GetTexDataAsRGBA32()`, or `Build()`.

Use C++11 `u8"..."` syntax for UTF-8 string literals:

```cpp
u8"hello"
u8"こんにちは"   // encoded as UTF-8
```

## How should I handle DPI in my application?

See the [DPI FAQ entry](https://github.com/ocornut/imgui/blob/master/docs/FAQ.md#q-how-should-i-handle-dpi-in-my-application).

## Font Loading Instructions

**Load the default font:**

```cpp
ImGuiIO& io = ImGui::GetIO();
io.Fonts->AddFontDefault();
```

**Load a `.TTF` or `.OTF` file:**

```cpp
ImGuiIO& io = ImGui::GetIO();
io.Fonts->AddFontFromFileTTF("font.ttf", size_pixels);
```

If you see `Could not load font file!`, the filename is probably incorrect. See [About filenames](#about-filenames).

**Load multiple fonts:**

```cpp
ImGuiIO& io = ImGui::GetIO();
ImFont* font1 = io.Fonts->AddFontFromFileTTF("font.ttf", size_pixels);
ImFont* font2 = io.Fonts->AddFontFromFileTTF("anotherfont.otf", size_pixels);

ImGui::Text("Hello"); // The first loaded font is the default.
ImGui::PushFont(font2);
ImGui::Text("Hello with another font");
ImGui::PopFont();
```

For advanced options, create an `ImFontConfig` and pass it to `AddFontFromFileTTF()`. The configuration is copied internally:

```cpp
ImFontConfig config;
config.OversampleH = 2;
config.OversampleV = 1;
config.GlyphExtraSpacing.x = 1.0f;
ImFont* font = io.Fonts->AddFontFromFileTTF("font.ttf", size_pixels, &config);
```

**Merge multiple fonts:**

```cpp
ImFont* font = io.Fonts->AddFontDefault();

static const ImWchar icons_ranges[] = { 0xf000, 0xf3ff, 0 };
ImFontConfig config;
config.MergeMode = true;

io.Fonts->AddFontFromFileTTF(
    "DroidSans.ttf", 18.0f, &config,
    io.Fonts->GetGlyphRangesJapanese());
io.Fonts->AddFontFromFileTTF(
    "fontawesome-webfont.ttf", 18.0f, &config, icons_ranges);
io.Fonts->Build();
```

The ranges array is not copied by `AddFont*()` and is used when the atlas is built, so keep it available until then.

To bake only specific ranges, pass a fourth argument:

```cpp
// Basic and Extended Latin
io.Fonts->AddFontFromFileTTF(
    "font.ttf", size_pixels, NULL, io.Fonts->GetGlyphRangesDefault());

// Default plus common Simplified Chinese characters
io.Fonts->AddFontFromFileTTF(
    "font.ttf", size_pixels, NULL,
    io.Fonts->GetGlyphRangesChineseSimplifiedCommon());

// Default plus Japanese kana and selected ideographs
io.Fonts->AddFontFromFileTTF(
    "font.ttf", size_pixels, NULL, io.Fonts->GetGlyphRangesJapanese());
```

See [Using Custom Glyph Ranges](#using-custom-glyph-ranges) for custom ranges.

Example Japanese font:

```cpp
ImGuiIO& io = ImGui::GetIO();
io.Fonts->AddFontFromFileTTF(
    "NotoSansCJKjp-Medium.otf", 20.0f, NULL,
    io.Fonts->GetGlyphRangesJapanese());

ImGui::Text(u8"こんにちは！テスト %d", 123);
if (ImGui::Button(u8"ロード"))
{
    // do stuff
}
ImGui::InputText("string", buf, IM_ARRAYSIZE(buf));
ImGui::SliderFloat("float", &f, 0.0f, 1.0f);
```

### Font Atlas too large?

A large number of glyphs or multiple fonts can make the texture too large for your graphics API. A failed texture upload commonly appears as white rectangles for every glyph. Texture-size limits also vary between graphics drivers and user hardware.

`GetGlyphRangesChineseSimplifiedCommon()` is especially large. If you use it, set `OversampleH` and `OversampleV` to `1` and use a small font size.

Possible solutions:

1. Build ranges from localization data with `ImFontGlyphRangesBuilder`.
2. Reduce oversampling:
   ```cpp
   font_config.OversampleH = font_config.OversampleV = 1;
   ```
3. Set `io.Fonts.TexDesiredWidth` to reduce texture height.
4. Set `io.Fonts.Flags |= ImFontAtlasFlags_NoPowerOfTwoHeight;`.
5. Read about oversampling [here](https://github.com/nothings/stb/blob/master/tests/oversample).

## Using Icons

Icon fonts such as [FontAwesome](http://fontawesome.io) and [OpenFontIcons](https://github.com/traverseda/OpenFontIcons) provide a practical way to display icons. A common approach is to merge the icon font into the main font so strings can contain icons without changing fonts.

Use the icon UTF-8 codepoint headers from [IconFontCppHeaders](https://github.com/juliettef/IconFontCppHeaders):

```cpp
#include "IconsFontAwesome.h"

ImGuiIO& io = ImGui::GetIO();
io.Fonts->AddFontDefault();

ImFontConfig config;
config.MergeMode = true;
config.GlyphMinAdvanceX = 13.0f;
static const ImWchar icon_ranges[] = { ICON_MIN_FA, ICON_MAX_FA, 0 };

io.Fonts->AddFontFromFileTTF(
    "fonts/fontawesome-webfont.ttf", 13.0f,
    &config, icon_ranges);
```

Use the generated constants in text:

```cpp
ImGui::Text("%s among %d items", ICON_FA_SEARCH, count);
ImGui::Button(ICON_FA_SEARCH " Search");
```

String literals concatenate at compile time, so `ICON_FA_SEARCH " Search"` forms one string.

## Using FreeType Rasterizer

Dear ImGui normally uses `imstb_truetype.h`, with optional oversampling. Small fonts may appear blurry or difficult to read. The [`misc/freetype/`](https://github.com/ocornut/imgui/tree/master/misc/freetype) folder provides a FreeType-based atlas builder. FreeType auto-hinting can improve small-font readability. See that folder for documentation. Correct sRGB blending also significantly affects font quality.

## Using Custom Glyph Ranges

`ImFontGlyphRangesBuilder` creates ranges from text:

```cpp
ImVector<ImWchar> ranges;
ImFontGlyphRangesBuilder builder;
builder.AddText("Hello world");
builder.AddChar(0x7262);
builder.AddRanges(io.Fonts->GetGlyphRangesJapanese());
builder.BuildRanges(&ranges);

io.Fonts->AddFontFromFileTTF(
    "myfontfile.ttf", size_in_pixels, NULL, ranges.Data);
io.Fonts->Build(); // Keep ranges alive until the atlas is built.
```

## Using Custom Colorful Icons

This is a beta API intended for users familiar with Dear ImGui and their rendering backend.

Register custom rectangles before building the atlas with `AddCustomRect()` or `AddCustomRectFontGlyph()`. After `Build()`, use `GetCustomRectByIndex()` to obtain each rectangle's position and size, then copy graphics data into it.

```cpp
ImFont* font = io.Fonts->AddFontDefault();
int rect_ids[2];
rect_ids[0] = io.Fonts->AddCustomRectFontGlyph(font, 'a', 13, 13, 14);
rect_ids[1] = io.Fonts->AddCustomRectFontGlyph(font, 'b', 13, 13, 14);

io.Fonts->Build();

unsigned char* tex_pixels = NULL;
int tex_width, tex_height;
io.Fonts->GetTexDataAsRGBA32(&tex_pixels, &tex_width, &tex_height);

for (int rect_n = 0; rect_n < IM_ARRAYSIZE(rect_ids); rect_n++)
{
    int rect_id = rect_ids[rect_n];
    if (const ImFontAtlas::CustomRect* rect =
            io.Fonts->GetCustomRectByIndex(rect_id))
    {
        for (int y = 0; y < rect->Height; y++)
        {
            ImU32* p = (ImU32*)tex_pixels +
                (rect->Y + y) * tex_width + rect->X;
            for (int x = rect->Width; x > 0; x--)
                *p++ = IM_COL32(255, 0, 0, 255);
        }
    }
}
```

This API may change to support multiple DPI scales across viewports and monitors.

## Using Font Data Embedded In Source Code

Compile [binary_to_compressed_c.cpp](https://github.com/ocornut/imgui/blob/master/misc/fonts/binary_to_compressed_c.cpp) to convert a font into a compressed C-style array. Its documentation explains how to use the tool. A precompiled Windows version may be available instead of demo binaries; see the [README](https://github.com/ocornut/imgui/blob/master/docs/README.md).

Base85 encoding can reduce source-code size, but the read-only arrays in the binary become about 20% larger.

```cpp
ImFont* font = io.Fonts->AddFontFromMemoryCompressedTTF(
    compressed_data, compressed_data_size, size_pixels, ...);
```

or:

```cpp
ImFont* font = io.Fonts->AddFontFromMemoryCompressedBase85TTF(
    compressed_data_base85, size_pixels, ...);
```

## About filenames

Many font-loading problems are caused by incorrect filenames or paths.

Your executable's working directory determines how relative paths are resolved. Configure it in your IDE or debugger. In Visual Studio, use `Properties > General > Debugging > Working Directory`.

```cpp
io.Fonts->AddFontFromFileTTF("MyFont.ttf", ...);
io.Fonts->AddFontFromFileTTF("../MyFont.ttf", ...);
```

In C and C++, escape backslashes in string literals:

```cpp
io.Fonts->AddFontFromFileTTF("MyFiles\MyFont.ttf", ...);   // Incorrect
io.Fonts->AddFontFromFileTTF("MyFiles\\MyFont.ttf", ...);  // Correct
```

A forward slash may also work as a Windows path separator.

## Credits/Licenses For Fonts Included In Repository

Fonts in `misc/fonts/` include:

```
Roboto-Medium.ttf
  Apache License 2.0
  by Christian Robertson
  https://fonts.google.com/specimen/Roboto

Cousine-Regular.ttf
  by Steve Matteson
  Copyright (c) 2010 Google Corporation
  SIL Open Font License, Version 1.1
  https://fonts.google.com/specimen/Cousine

DroidSans.ttf
  Copyright (c) Steve Matteson
  Apache License, Version 2.0
  https://www.fontsquirrel.com/fonts/droid-sans

ProggyClean.ttf
  Copyright (c) 2004, 2005 Tristan Grimmer
  MIT License
  Recommended: Size = 13.0, GlyphOffset.y = +1
  http://www.proggyfonts.net/

ProggyTiny.ttf
  Copyright (c) 2004, 2005 Tristan Grimmer
  MIT License
  Recommended: Size = 10.0, GlyphOffset.y = +1
  http://www.proggyfonts.net/

Karla-Regular.ttf
  Copyright (c) 2012 Jonathan Pinhorn
  SIL Open Font License, Version 1.1
```

## Font Links

**Icon fonts:** [IconFontCppHeaders](https://github.com/juliettef/IconFontCppHeaders), [FontAwesome](https://fortawesome.github.io/Font-Awesome), [OpenFontIcons](https://github.com/traverseda/OpenFontIcons), [Google Icon Fonts](https://design.google.com/icons/), [Kenney Icon Font](https://github.com/nicodinh/kenney-icon-font), and [IcoMoon](https://icomoon.io/app).

**Regular fonts:** [Google Noto Fonts](https://www.google.com/get/noto/), [Open Sans](https://fonts.google.com/specimen/Open+Sans), and Japanese [M+ fonts](http://mplus-fonts.sourceforge.jp/mplus-outline-fonts/index-en.html).

**Monospace fonts:** Pixel-perfect options include [Proggy Fonts](http://www.proggyfonts.net), [Sweet16](https://github.com/kmar/Sweet16Font), and Sweet16 Mono. Regular options include [Google Noto Mono](https://www.google.com/get/noto/), [Codeface](https://github.com/chrissimpkins/codeface), [Programmation fonts](http://s9w.github.io/font_compare/), [Inconsolata](http://www.levien.com/type/myfonts/inconsolata.html), [Source Code Pro](https://github.com/adobe-fonts/source-code-pro), and [programmer fonts](http://www.lowing.org/fonts/). Windows also provides Arial Unicode and other Unicode fonts, but verify their licensing.
