# bat: File Display, Integration, Installation, and Customization

`bat` is a command-line file viewer that combines syntax highlighting with features commonly needed when inspecting source code and other text files. It displays files with syntax highlighting, Git-index modification markers, optional nonprinting-character indicators, and automatic paging. It can also concatenate multiple files.

```bash
> bat README.md
```

Multiple files can be displayed in sequence:

```bash
> bat src/*.rs
```

When output is redirected, `bat` provides plain file contents and behaves like `cat` for that use case. This makes it suitable for both interactive viewing and shell pipelines.

```bash
bat > note.md  # quickly create a new file

bat header.md content.md footer.md > document.md
```

A hyphen represents standard input. It can therefore be combined with named files to control the order of concatenation:

```bash
bat f - g  # output 'f', then stdin, then 'g'.
```

`bat` also detects standard input in common shell situations. A shebang can be used to identify the input language. When detection is not sufficient, specify the language explicitly with `-l` or `--language`.

```bash
> curl -s https://sh.rustup.rs | bat
```

```bash
> yaml2json .travis.yml | json_pp | bat -l json
```

Use `-A` or `--show-all` to highlight nonprinting characters:

```bash
> bat -A /etc/hosts
```

Line numbers are one display option:

```bash
bat -n main.rs  # show line numbers (only)
```

## Integrations

`bat` can be inserted into existing command-line workflows. With `find`, use `-exec` to pass matching files to `bat`:

```bash
find … -exec bat {} +
```

With `fd`, use `--exec-batch` or its short form `-X`:

```bash
fd … -X bat
```

For ripgrep results, `batgrep` combines search output with file display:

```bash
batgrep needle src/
```

Log monitoring can be combined with `tail -f`. Disable paging for continuously growing output and provide the log syntax explicitly:

```bash
tail -f /var/log/pacman.log | bat --paging=never -l log
```

Historical file contents from Git can be passed through standard input. Because the filename is not available to determine syntax, set the language explicitly:

```bash
git show v0.6.0:src/main.rs | bat -l rs
```

Diff highlighting is unsupported. `delta` is referenced for that purpose.

The display gutters, headers, and other decorations are useful for interactive reading but may be undesirable when copying text. Use plain output or pipe the output to `xclip` when the copied content should not include gutters:

```bash
bat main.cpp | xclip
```

Manual pages can be colored by setting `MANPAGER`:

```bash
export MANPAGER="sh -c 'col -bx | bat -l man -p'"
man 2 select
```

If manual-page formatting is incorrect, `MANROFFOPT=-c` may fix it. `batman` wraps this manual-page use. Mandoc's `man` implementation is unsupported.

`prettybat` combines formatters such as `prettier`, `shfmt`, and `rustfmt` with `bat`.

## Installation

Package installation is available for a range of operating systems and package managers.

On Ubuntu 19.10 and later, install the package with:

```bash
apt install bat
```

Debian Sid also provides a package. Debian-family packages may install the executable as `batcat` because of a name clash. A symlink or alias can restore the `bat` command. For a symlink in the local user binary directory:

```bash
mkdir -p ~/.local/bin
ln -s /usr/bin/batcat ~/.local/bin/bat
```

Downloaded Debian archives can be installed with `dpkg`. Adapt the version number and architecture as needed:

```bash
sudo dpkg -i bat_0.16.0_amd64.deb  # adapt version number and architecture
```

On Alpine Linux:

```bash
apk add bat
```

On Arch Linux:

```bash
pacman -S bat
```

On Fedora Modular:

```bash
dnf install bat
```

On Gentoo:

```bash
emerge sys-apps/bat
```

On Void Linux:

```bash
xbps-install -S bat
```

On FreeBSD, install the package:

```bash
pkg install bat
```

The FreeBSD ports tree can also be used:

```bash
cd /usr/ports/textproc/bat
make install
```

For Nix:

```bash
nix-env -i bat
```

For openSUSE:

```bash
zypper install bat
```

Homebrew installation uses:

```bash
brew install bat
```

MacPorts installation uses:

```bash
port install bat
```

On Windows, Chocolatey provides the package:

```bash
choco install bat
```

Scoop provides another installation route:

```bash
scoop install bat
```

Windows requires the Visual C++ Redistributable.

Release archives include many architectures and MUSL static builds. These archives provide an alternative when a package manager does not provide a suitable package.

### Building from source

Source builds require Rust 1.40 or newer. The basic Cargo installation command is:

```bash
cargo install --locked bat
```

The project source can be cloned recursively to retrieve all submodules:

```bash
# Recursive clone to retrieve all submodules
git clone --recursive https://github.com/sharkdp/bat

# Build (debug version)
cd bat
cargo build --bins

# Run unit tests and integration tests
cargo test

# Install (release version)
cargo install --locked

# Build a bat binary with modified syntaxes and themes
bash assets/create.sh
cargo install --locked --force
```

Cargo builds generate man and completion files in the target build directory, but Cargo does not install those files automatically.

## Themes and color behavior

Use `--list-themes` to inspect the available themes:

```bash
bat --list-themes
```

Select a theme with `--theme`, or set `BAT_THEME` to make a selection persistent. Examples include `TwoDark`, `GitHub`, and `OneHalfLight`.

```bash
bat --list-themes | fzf --preview="bat --theme={} --color=always /path/to/file"
```

Dark backgrounds are the default assumption. `ansi-dark` and `ansi-light` use basic three-bit colors. `base16` uses four-bit colors following base16 styling. `base16-256` maps some bright colors into slots 16–21 for base16-shell. `base16-256` is not a generic choice for every 256-color terminal.

Restricted themes track changes to the terminal palette and blend with other terminal software. Use restricted themes when the terminal environment or palette requires that behavior.

`OneHalfDark` and `OneHalfLight` use brighter grid and line colors.

Truecolor terminals should expose either `COLORTERM=truecolor` or `COLORTERM=24bit`. If the terminal does not advertise truecolor this way, `bat` falls back to eight-bit colors.

## Output style

The `--style` option selects which output elements are displayed. For example, `numbers,changes` shows line numbers and Git changes without the grid or header:

```bash
--style="numbers,changes"
```

The style can be made persistent with `BAT_STYLE` or a configuration file. A configuration entry can include several command-line arguments:

```bash
# Set the theme to "TwoDark"
--theme="TwoDark"

# Show line numbers, Git modifications and file header (but no grid)
--style="numbers,changes,header"

# Use italic text on the terminal (not supported on all terminals)
--italic-text=always

# Use C++ syntax for .ino files
--map-syntax "*.ino:C++"

# Use ".gitignore"-style highlighting for ".ignore" files
--map-syntax ".ignore:Git Ignore"
```

The syntax highlighting system uses syntect, which reads Sublime `.sublime-syntax` files and themes.

## Custom syntaxes and themes

Custom language definitions and themes can be installed in the documented configuration directories. `bat --config-dir` identifies the configuration directory used by the installation.

Create a directory for custom syntax definitions, then place `.sublime-syntax` files there or in subdirectories:

```bash
mkdir -p "$(bat --config-dir)/syntaxes"
cd "$(bat --config-dir)/syntaxes"

# Put new '.sublime-syntax' language definition files
# in this folder (or its subdirectories), for example:
git clone https://github.com/tellnobody1/sublime-purescript-syntax
```

After adding definitions, build the binary cache:

```bash
bat cache --build
```

Verify the available languages with `--list-languages`. Verify themes with `--list-themes`.

Custom themes use the corresponding themes directory:

```bash
mkdir -p "$(bat --config-dir)/themes"
cd "$(bat --config-dir)/themes"

# Download a theme in '.tmTheme' format, for example:
git clone https://github.com/greggb/sublime-snazzy

# Update the binary cache
bat cache --build
```

To return to the defaults, clear the cache:

```bash
bat cache --clear
```

## Pager configuration

Pager selection gives precedence to `BAT_PAGER` over `PAGER`. If neither variable selects a pager, `less` is the fallback. The `--pager` option is another configuration route.

For example:

```bash
export BAT_PAGER="less -RF"
```

When `less` is used without explicit arguments, `bat` supplies `-R` so ANSI colors are displayed and `-F` so the pager quits when the output fits on one screen. For versions of `less` older than 530, `bat` also adds `-X` to work around a quit-if-one-screen issue. This workaround costs mouse-wheel support.

On older `less` versions, selecting only `-R` restores mouse-wheel use but disables the automatic quit for short output.

Disable paging with `--paging=never` or by setting `BAT_PAGER` to an empty value.

## Tabs and configuration files

Before paging, `bat` expands tabs to four spaces by default. Use `--tabs` to change the width. Use `--tabs=0` to pass tabs through to the pager.

Pager tab-stop settings cannot affect spaces that `bat` has already expanded. To let the pager receive literal tab characters, use `--tabs=0`.

`--config-file` prints the platform-dependent configuration path:

```bash
bat --config-file
```

Set `BAT_CONFIG_PATH` to select another configuration file:

```bash
export BAT_CONFIG_PATH="/path/to/bat.conf"
```

Generate a default configuration file with:

```bash
bat --generate-config-file
```

The configuration format is a list of command-line arguments. Comments begin with `#`.

On macOS, a shell alias can select a theme according to the operating system's dark or light appearance:

```bash
alias cat="bat --theme=\$(defaults read -globalDomain AppleInterfaceStyle &> /dev/null && echo default || echo GitHub)"
```

## Platform limits

Windows `more` is limited. Install `less` and place it on `PATH`, or configure a different pager. Chocolatey installs `less` automatically.

Windows 10 version 1511 and later support colors in Command Prompt and PowerShell. Newer Bash versions also support colors. Older Windows versions can use Cmder or ConEmu.

Git/MSYS `less` may misinterpret colors. If paging or color handling is unsuitable, disable paging with `--paging=never` or set `BAT_PAGER` to an empty value.

Native `bat` cannot interpret Cygwin `/cygdrive` paths. A wrapper can convert those paths before invoking the native executable:

```bash
bat() {
    local index
    local args=("$@")
    for index in $(seq 0 ${#args[@]}) ; do
        case "${args[index]}" in
        -*) continue;;
        *)  [ -e "${args[index]}" ] && args[index]="$(cygpath --windows "${args[index]}")";;
        esac
    done
    command bat "${args[@]}"
}
```

UTF-8 and UTF-16 are supported natively. Convert other encodings with `iconv`. If language detection fails after conversion, specify the syntax explicitly:

```bash
iconv -f ISO-8859-1 -t UTF-8 my-file.php | bat
```

## Project scope and metadata

The project aims to provide syntax highlighting, Git integration, a POSIX-compatible `cat` replacement, and a usable command-line interface. Alternatives are documented.

The maintainers are sharkdp and eth-p. The license choice is MIT or Apache 2.0. Copyright belongs to bat-developers, 2018–2020.
