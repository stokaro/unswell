# Prometheus

[![CircleCI](https://circleci.com/gh/prometheus/prometheus/tree/master.svg?style=shield)][circleci]
[![Docker Repository on Quay](https://quay.io/repository/prometheus/prometheus/status)][quay]
[![Docker Pulls](https://img.shields.io/docker/pulls/prom/prometheus.svg?maxAge=604800)][hub]
[![Go Report Card](https://goreportcard.com/badge/github.com/prometheus/prometheus)](https://goreportcard.com/report/github.com/prometheus/prometheus)
[![CII Best Practices](https://bestpractices.coreinfrastructure.org/projects/486/badge)](https://bestpractices.coreinfrastructure.org/projects/486)
[![fuzzit](https://app.fuzzit.dev/badge?org_id=prometheus&branch=master)](https://fuzzit.dev)
[![Gitpod ready-to-code](https://img.shields.io/badge/Gitpod-ready--to--code-blue?logo=gitpod)](https://gitpod.io/#https://github.com/prometheus/prometheus)

Visit [prometheus.io](https://prometheus.io) for complete documentation, examples, and guides.

Prometheus, a [Cloud Native Computing Foundation](https://cncf.io/) project, is a systems and service monitoring system. It collects metrics from configured targets at specified intervals, evaluates rule expressions, displays results, and can trigger alerts when conditions are observed.

Prometheus features:

- A **multidimensional** data model: time series are defined by a metric name and key/value dimensions
- PromQL, a **powerful and flexible query language**
- No dependency on distributed storage; **single-server nodes are autonomous**
- An HTTP **pull model** for collecting time series
- **Pushing time series** through an intermediary gateway for batch jobs
- Target discovery through **service discovery** or **static configuration**
- Multiple **graphing and dashboarding** modes
- Hierarchical and horizontal **federation**

## Architecture overview

![](https://cdn.jsdelivr.net/gh/prometheus/prometheus@c34257d069c630685da35bcef084632ffd5d6209/documentation/images/architecture.svg)

## Install

Prometheus can be installed in several ways.

### Precompiled binaries

Precompiled binaries for released versions are available in the [download section](https://prometheus.io/download/) on [prometheus.io](https://prometheus.io). The latest production release binary is recommended. See the [Installing](https://prometheus.io/docs/introduction/install/) documentation for details.

### Docker images

Images are available from [Quay.io](https://quay.io/repository/prometheus/prometheus) and [Docker Hub](https://hub.docker.com/r/prom/prometheus/).

    $ docker run --name prometheus -d -p 127.0.0.1:9090:9090 prom/prometheus

Prometheus is then available at http://localhost:9090/.

### Building from source

Building from source requires [Go 1.14 or later](https://golang.org/doc/install), [Node.js](https://nodejs.org/), and [Yarn](https://yarnpkg.com/).

You can install the `prometheus` and `promtool` binaries with:

    $ go get github.com/prometheus/prometheus/cmd/...
    $ prometheus --config.file=your_config.yml

When built with `go get`, Prometheus expects web assets in `web/ui/static` and `web/ui/templates`. Run it from the cloned repository root. The experimental React UI requires `make assets` or `make build`. An example configuration is [available here](https://github.com/prometheus/prometheus/blob/master/documentation/examples/prometheus.yml).

Alternatively, clone the repository and run `make build` to compile the web assets into the binaries:

    $ git clone https://github.com/prometheus/prometheus.git
    $ cd prometheus
    $ make build
    $ ./prometheus --config.file=your_config.yml

The Makefile includes `build`, `test`, `test-short`, `format`, `vet`, `docker`, and `assets` targets.

## React UI Development

See the React app's [README.md](https://github.com/prometheus/prometheus/blob/master/web/ui/react-app/README.md) for information about building and developing the experimental React-based UI.

## More information

- [Prometheus Core](https://godoc.org/github.com/prometheus/prometheus)
- [CircleCI configuration](.circleci/config.yml)
- [Community page](https://prometheus.io/community)

## Contributing

See [CONTRIBUTING.md](https://github.com/prometheus/prometheus/blob/master/CONTRIBUTING.md).

## License

Apache License 2.0; see [LICENSE](https://github.com/prometheus/prometheus/blob/master/LICENSE).
