# Prometheus

[![CircleCI](https://circleci.com/gh/prometheus/prometheus/tree/master.svg?style=shield)][circleci]
[![Docker Repository on Quay](https://quay.io/repository/prometheus/prometheus/status)][quay]
[![Docker Pulls](https://img.shields.io/docker/pulls/prom/prometheus.svg?maxAge=604800)][hub]
[![Go Report Card](https://goreportcard.com/badge/github.com/prometheus/prometheus)](https://goreportcard.com/report/github.com/prometheus/prometheus)
[![CII Best Practices](https://bestpractices.coreinfrastructure.org/projects/486/badge)](https://bestpractices.coreinfrastructure.org/projects/486)
[![fuzzit](https://app.fuzzit.dev/badge?org_id=prometheus&branch=master)](https://fuzzit.dev)
[![Gitpod ready-to-code](https://img.shields.io/badge/Gitpod-ready--to--code-blue?logo=gitpod)](https://gitpod.io/#https://github.com/prometheus/prometheus)

Visit [prometheus.io](https://prometheus.io) for full documentation, examples, and guides.

Prometheus, a [Cloud Native Computing Foundation](https://cncf.io/) project, is a systems and service monitoring platform. It collects metrics from configured targets at specified intervals, evaluates rule expressions, displays results, and triggers alerts when specified conditions occur.

The features that distinguish Prometheus from other monitoring systems are:

- A **multi-dimensional** data model (time series defined by metric name and key/value dimensions)
- PromQL, a **powerful and flexible query language** for leveraging this dimensionality
- No distributed storage dependency; **single server nodes are autonomous**
- An HTTP **pull model** for time series collection
- **Push capability** for time series via an intermediary gateway for batch jobs
- Target discovery via **service discovery** or **static configuration**
- Multiple modes of **graphing and dashboarding support**
- Support for hierarchical and horizontal **federation**

## Architecture overview

![](https://cdn.jsdelivr.net/gh/prometheus/prometheus@c34257d069c630685da35bcef084632ffd5d6209/documentation/images/architecture.svg)

## Install

### Precompiled binaries

Precompiled binaries for released versions are available in the [download section](https://prometheus.io/download/) on prometheus.io. Using the latest production release is the recommended installation method. See the [Installing](https://prometheus.io/docs/introduction/install/) chapter in the documentation for details.

### Docker images

Docker images are available on [Quay.io](https://quay.io/repository/prometheus/prometheus) and [Docker Hub](https://hub.docker.com/r/prom/prometheus/).

To run Prometheus in a container:

    $ docker run --name prometheus -d -p 127.0.0.1:9090:9090 prom/prometheus

Prometheus will be accessible at http://localhost:9090/.

### Building from source

Ensure you have a working Go environment with [version 1.14 or greater](https://golang.org/doc/install). You also need [Node.js](https://nodejs.org/) and [Yarn](https://yarnpkg.com/) installed to build the frontend assets.

Use the `go` tool to download and install the `prometheus` and `promtool` binaries:

    $ go get github.com/prometheus/prometheus/cmd/...
    $ prometheus --config.file=your_config.yml

When building with `go get`, Prometheus expects to read web assets from directories under `web/ui/static` and `web/ui/templates`. Run Prometheus from the cloned repository root. These directories do not include the experimental React UI unless built explicitly using `make assets` or `make build`.

Alternatively, clone the repository and build with `make build` to compile assets into the binary:

    $ mkdir -p $GOPATH/src/github.com/prometheus
    $ cd $GOPATH/src/github.com/prometheus
    $ git clone https://github.com/prometheus/prometheus.git
    $ cd prometheus
    $ make build
    $ ./prometheus --config.file=your_config.yml

The Makefile provides these targets:

- *build*: compile `prometheus` and `promtool` binaries with web assets
- *test*: run all tests
- *test-short*: run short tests
- *format*: format source code
- *vet*: check source code for common errors
- *docker*: build a Docker container from the current HEAD
- *assets*: build the experimental React UI

## React UI Development

For information on building, running, and developing the React-based UI, see the React app's [README.md](https://github.com/prometheus/prometheus/blob/master/web/ui/react-app/README.md).

## More information

- Source code is periodically indexed: [Prometheus Core](https://godoc.org/github.com/prometheus/prometheus)
- CircleCI configuration: [`.circleci/config.yml`](.circleci/config.yml)
- Community contact: see the [Community page](https://prometheus.io/community)

## Contributing

Refer to [CONTRIBUTING.md](https://github.com/prometheus/prometheus/blob/master/CONTRIBUTING.md).

## License

Apache License 2.0, see [LICENSE](https://github.com/prometheus/prometheus/blob/master/LICENSE).

[hub]: https://hub.docker.com/r/prom/prometheus/
[circleci]: https://circleci.com/gh/prometheus/prometheus
[quay]: https://quay.io/repository/prometheus/prometheus
