# etcd Documentation

etcd is a distributed key-value store designed for critical system data. Written in Go, etcd implements Raft consensus to maintain a highly available replicated log. The system provides a gRPC API, automatic TLS with optional client-certificate authentication, and achieves a reported 10,000 writes per second in benchmark measurements. These characteristics make etcd suitable for systems requiring distributed reliability and data consistency.

etcd powers production systems including Kubernetes, locksmith, vulcand, and Doorman. Functional testing supports the reliability of these deployments. The command-line client, etcdctl, provides direct access to etcd functionality.

## Installation

Prebuilt releases are available for macOS, Linux, Windows, and Docker. Prebuilt binaries offer the most straightforward installation path. For users building from source, Go 1.12 or later is required to build the latest master branch.

The master branch may be unstable or broken during development. Stable binaries are recommended for production use. Features and bug fixes first land on master, then are ported to release branches according to branch-management guidance. Installation and operations guides are linked at play.etcd.io and in the main Documentation section.

## Single-Member Cluster

To run a single-member cluster, start by obtaining the etcd binary. Three approaches are available:

Download a prebuilt release and run the binary directly from its installation location:
```
/tmp/etcd-download-test/etcd
```

Move the binary to a system path and run it:
```
mv /tmp/etcd-download-test/etcd /usr/local/bin/
etcd
```

Build from source and execute the binary from the bin directory:
```
./bin/etcd
```

Client communication uses port 2379 by default. Peer communication between cluster members uses port 2380.

Once etcd is running, use etcdctl to store and retrieve data. To write a key-value pair:
```
etcdctl put mykey "this is awesome"
```

To read the value back:
```
etcdctl get mykey
```

## Local Cluster Startup

For testing multiple cluster members locally, goreman manages the provided Procfile example. goreman simplifies launching and managing multiple processes on a single machine.

Start a local three-member cluster:
```
goreman start
```

This command launches three members named infra1, infra2, and infra3, along with an etcd gRPC proxy. All members and the proxy accept key-value reads and writes, allowing you to test distributed behavior on a single system.

## APIs and Further Documentation

etcd exposes its functionality through the gRPC API and etcdctl. The complete API documentation covers the full range of operations beyond basic key-value storage.

Follow-on documentation addresses multi-machine cluster setup, cluster flags and environment variables, configuration options, integrations with other systems, TLS security configuration, and performance tuning. These guides provide guidance for deploying etcd in production environments and optimizing its behavior for specific workloads.

## Community and Contribution

The etcd community resumed activities on January 10, 2019. Regular meetings occur every four weeks on Thursday at 11:00 AM US Pacific time. Agendas are prepared in a shared document one day before each meeting, and suggestions for topics are welcome.

Meeting participation is available through Zoom and calendar integration. One-tap mobile access is provided at +14086380986,,916003437# for US (San Jose) and +16465588665,,916003437# for US (New York). Location-based dialing uses +1 408 638 0986 for US (San Jose) and +1 646 558 8665 for US (New York), with meeting ID 916 003 437.

## Support and Contribution Channels

Several channels support etcd users and contributors:

- etcd-dev mailing list for discussions and questions
- The historical freenode etcd IRC channel for real-time communication
- GitHub milestones and roadmap for tracking planned work
- GitHub issues for reporting problems and requesting features

Contribution guides, bug-report procedures, issue-triage guidelines, and pull-request management documentation are available as separate linked resources.

Security issues should be reported publicly only when appropriate. Otherwise, discuss security concerns with MAINTAINERS first to ensure responsible disclosure.

The etcd project is licensed under Apache 2.0. Emeritus maintainers include Fanmin Shi and Anthony Romano.
