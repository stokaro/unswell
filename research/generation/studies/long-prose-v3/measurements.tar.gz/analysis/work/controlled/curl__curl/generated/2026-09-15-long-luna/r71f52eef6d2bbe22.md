# Building curl and libcurl with Visual C++

This procedure describes the historical Windows build process for curl and libcurl with Microsoft Visual C++.

## Requirements

Building requires Visual C++. Visual C++ 6 is the documented minimum, although newer versions are recommended. Visual C++ is also available through the Windows Platform SDK, so installing the full Visual Studio product is not required solely to build curl. The source links the Windows SDK archive for this purpose.

Optional dependencies are downloaded separately:

- zlib
- OpenSSL
- c-ares
- libSSH2

The suggested directory layout places the dependency files in a directory beside the curl source directory:

```text
somedirectory\
 |_curl-src
 | |_winbuild
 |
 |_deps
   |_ lib
   |_ include
   |_ bin
```

The dependency archives are available from:

```text
https://windows.php.net/downloads/php-sdk/deps/
```

Uncompress the archives into the `deps` directory. By default, the build searches for dependencies in `../deps`, relative to the source tree. Use `WITH_DEVEL` to specify another development-files directory.

A Git checkout requires preparation before building. From the source root, run `buildconf.bat`. A released source archive does not require this step.

## Developer command prompt

Build from a Visual Studio developer command prompt. Its default target is x86. To build for another machine type, call `Vcvarsall.bat` with the intended target. Some Visual Studio releases instead provide named prompts for a Visual Studio version, platform, or native or cross compilation. The available prompts vary by Visual Studio version. The original source links Microsoft’s instructions for configuring the command-line environment.

After configuring the environment, enter the Windows build directory:

```text
cd curl-src\winbuild
```

Run `nmake` with the desired library mode and options:

```text
nmake /f Makefile.vc mode=<static or dll> <options>
```

Build output is placed under the `builds` directory in the source root. Each output is stored in a subdirectory named for its configuration.

## Library and dependency options

The `mode` argument selects either a static or DLL build of libcurl. Dependency options select DLL or static versions of individual libraries:

```text
WITH_SSL=<dll/static>
WITH_NGHTTP2=<dll/static>
WITH_MBEDTLS=<dll/static>
WITH_CARES=<dll/static>
WITH_ZLIB=<dll/static>
WITH_SSH2=<dll/static>
```

These options enable OpenSSL, HTTP/2, mbedTLS, c-ares, zlib, and libSSH2 support, respectively.

Use `WITH_PREFIX=<dir>` to select the installation location. Use `WITH_DEVEL=<path>` for the common development-files directory. Individual dependency locations can instead be supplied with:

```text
CARES_PATH=<path>
MBEDTLS_PATH=<path>
NGHTTP2_PATH=<path>
SSH2_PATH=<path>
SSL_PATH=<path>
ZLIB_PATH=<path>
```

## Configuration defaults

The documented defaults are:

- `ENABLE_SSPI=yes`: enable SSPI support.
- `ENABLE_IPV6=yes`: enable IPv6.
- `ENABLE_IDN=yes`: enable the Windows IDN APIs. This requires Windows Vista or later.
- `ENABLE_OPENSSL_AUTO_LOAD_CONFIG=yes`: load OpenSSL configuration automatically.
- `ENABLE_UNICODE=no`: do not enable Unicode support by default.
- `MACHINE=x86`: target x86 by default.

Schannel, the native Windows SSL backend, defaults to enabled when SSPI is enabled and no other SSL library is selected. Control it explicitly with `ENABLE_SCHANNEL=<yes/no>`.

Use `GEN_PDB=<yes/no>` to generate Program Database debug symbols for a release build. Use `DEBUG=<yes/no>` to select a debug build.

## Microsoft C runtime

`mode=static` links a static libcurl, but it does not request the static Microsoft C runtime. The usual runtime is a DLL. Set `RTLIBCFG=static` to force the static runtime.

This option is rarely used and rarely tested. If `RTLIBCFG` is changed for a configuration that has already been built, remove that configuration’s directory under `builds` and rebuild from scratch.

Applications that link static libcurl on Windows must define `CURL_STATICLIB`. Without this definition, linking searches for dynamic import symbols.

## SSL backend considerations

The default native SSL backend is Schannel through Windows SSPI. On Windows XP or earlier, Schannel cannot connect to servers that reject those systems’ legacy handshakes or algorithms. Applications targeting those systems should select another SSL backend, such as OpenSSL.
