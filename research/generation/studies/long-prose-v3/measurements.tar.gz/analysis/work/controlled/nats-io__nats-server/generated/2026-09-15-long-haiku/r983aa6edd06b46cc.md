# Roadmap [DRAFT]

This is the roadmap for the NATS Server. The purpose of this document is to provide insight into major features planned for the near future. This is a living document that will change as goals and milestones are completed and new plans are made.

The project's release plan is maintained on [the wiki](https://github.com/nats-io/gnatsd/wiki).

A master project release plan for all NATS projects can be found [here](https://github.com/nats-io/roadmap/wiki).

### Planning and Tracking

An [Open-Source Planning Process](https://github.com/nats-io/gnatsd/wiki/Open-Source-Planning-Process) is used to define the roadmap.

The project is managed via GitHub [milestones](https://github.com/nats-io/gnatsd/milestones). [Project Pages](https://github.com/nats-io/gnatsd/wiki) define goals for each milestone and identify current progress.

Upcoming features and bugfixes are added to relevant milestones. One or more milestones are assigned to each release. Features or bugfixes not assigned to a milestone are currently unscheduled for implementation.

### Short Term

#### Hot configuration reload

Enable changes to a subset of configuration items on a running `gnatsd` instance without requiring a restart.

See [Issue #338](https://github.com/nats-io/gnatsd/issues/338)

#### Integrate Prometheus support

Work has been completed on exporting NATS monitoring data via Prometheus. This work will be shared in an upcoming release.

See [Issue #345](https://github.com/nats-io/gnatsd/issues/345)

### Further Out

#### Enable external authentication and authorization via extensible auth provider

Improve and extend the auth interfaces and configuration to support external auth endpoints.

See [Issue #434](https://github.com/nats-io/gnatsd/issues/434)

#### Namespace isolation by account/organization

Multi-tenancy is a popular requirement, and one frequently requested feature is the ability to isolate the subject namespace by tenant (such as an account or organization). For example, messages published to `FOO.BAR` by tenant A would not be visible to tenant B's subscribers on `FOO.BAR`, and vice versa. Support for this in an efficient and performant manner is planned.

See [Issue #347](https://github.com/nats-io/gnatsd/issues/347) and [Issue #348](https://github.com/nats-io/gnatsd/issues/348)

#### Rate limiting

Rate limiting is another multi-tenancy requirement: the ability to limit the rate at which publishers publish messages to `gnatsd`. An implementation exists in a branch for an internal project and will be made public soon.

See [Issue #346](https://github.com/nats-io/gnatsd/issues/346)

#### Make auto-unsubscribe atomic to the SUB protocol

Auto-unsubscribe currently requires two operations: `SUB foo 1` followed by `UNSUB foo 1 1` (unsubscribe after 1 message). For simplicity, efficiency, and usability, this will be made a single atomic protocol operation, with the limit optionally specified as part of the subscription, for example `SUB foo 1 1`.

See [Issue #344](https://github.com/nats-io/gnatsd/issues/344)

#### Rename `gnatsd` to `nats-server`

The original Ruby-based NATS server (now retired) was called `nats-server`. The Go version required a unique name, hence `gnatsd`. Recent efforts to normalize names across NATS projects will be continued. Renaming `gnatsd` to `nats-server` will align it more closely with other components in the NATS family.

See [Issue #226](https://github.com/nats-io/gnatsd/issues/226)

#### Client pruning/rebalancing

With cluster auto-discovery implemented for both clients and servers, NATS clusters can be dynamically expanded. Client connections should be optionally rebalanced across the expanded cluster.

See [Issue #343](https://github.com/nats-io/gnatsd/issues/343)
