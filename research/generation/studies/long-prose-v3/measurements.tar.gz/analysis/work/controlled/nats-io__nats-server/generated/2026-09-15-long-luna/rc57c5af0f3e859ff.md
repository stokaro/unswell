# NATS Server Roadmap

The NATS Server roadmap is a draft. It changes as milestones are completed and new plans are added. The server wiki tracks releases, while a separate NATS roadmap wiki coordinates projects across the NATS ecosystem.

The Open-Source Planning Process defines how the roadmap is developed. GitHub milestones track implementation work, and project wiki pages record the goals and progress for each milestone. A release can contain several milestones. Conversely, a feature or fix that is not associated with a milestone is considered unscheduled.

## Near-term plans

The near-term roadmap includes reloading a subset of `gnatsd` configuration without restarting the server instance. This work is tracked by GitHub issue #338.

The roadmap also includes release work for exporting monitoring data through Prometheus. This work is tracked by issue #345.

## Later plans

The planned authentication and authorization work will extend the related interfaces and configuration to support external providers. This work is tracked by issue #434.

Another later plan is to isolate subject namespaces by tenant, account, or organization. The work is tracked by issues #347 and #348. With namespace isolation, a publication from tenant A on `FOO.BAR` must remain invisible to subscribers from tenant B on `FOO.BAR`, and the reverse must also be true.

Publisher rate limiting, tracked by issue #346, exists on an internal-project branch and is proposed for public release.

Atomic auto-unsubscribe, tracked by issue #344, would combine the current `SUB foo 1` and `UNSUB foo 1 1` operations. The limit could optionally be encoded directly as `SUB foo 1 1`.

## Naming and cluster behavior

The retired Ruby server was named `nats-server`. The Go implementation used the name `gnatsd` to distinguish it from the Ruby server. Issue #226 proposes renaming the Go implementation back to `nats-server`, aligning its name with the other NATS components.

Client/server auto-discovery already permits dynamic cluster expansion. Issue #343 proposes optional connection pruning and rebalancing across a larger cluster. This proposal concerns how connections are managed after the cluster expands.

## Roadmap and release relationship

The roadmap describes planned project work, while the server wiki records the releases that deliver that work. Milestones provide the connection between these views: GitHub milestones identify the tracked implementation effort, and project wiki pages describe each milestone’s goals and progress. Because releases may include several milestones, release boundaries do not necessarily correspond to individual roadmap entries.

The roadmap should therefore be read as an evolving coordination document rather than a fixed release schedule. Completed milestones and new plans can change its contents. Items without an associated milestone remain unscheduled until they are assigned to tracked work.
