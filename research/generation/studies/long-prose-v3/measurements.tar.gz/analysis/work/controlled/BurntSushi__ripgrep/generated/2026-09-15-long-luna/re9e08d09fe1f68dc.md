# ripgrep Technical Documentation

## Scope

This document answers common questions about ripgrep search semantics, performance, configuration, Windows use, PowerShell integration, file replacement workflows, and project policy. It describes the default regular-expression engine, optional PCRE2 support, line and multiline search, encoding behavior, compiled-expression limits, compressed input, output ordering, terminal colors, shell completion, and related operational details.

Ripgrep is a search tool with behavior that differs from `grep` in several important ways. It can search recursively while honoring ignore files, search Unicode and UTF-16 data, and search large directories in parallel. It is not a complete behavior-compatible replacement for `grep`, is not POSIX conformant, and is less ubiquitous for portable scripts. GNU `grep`, possibly combined with filters, wrappers, or parallel `xargs`, may be sufficient for a particular use case. A missing required feature remains a reason to use another tool.

Ripgrep's Unicode behavior does not depend on locale settings.

## Documentation, builds, and releases

Configuration and encoding information is documented in `GUIDE.md`. Changes are documented in `CHANGELOG.md`. Volunteers publish on a best-effort basis without release dates. A serious regression can motivate a patch, but it does not create a promise about when that patch will be available.

When `asciidoctor` or `asciidoc` is installed, a build generates a man page from the argument parser. The generated file is placed under the target's build output. Binary releases include the man page. The command-line help remains an equivalent source for option details:

```text
rg --help
```

The shorter help form condenses each flag to one line:

```text
rg -h
```

Builds and releases also include shell completions.

The separately maintained Zsh completion file is:

```text
complete/_rg
```

Bash uses `rg.bash`. It can be placed under either:

```text
$XDG_CONFIG_HOME/bash_completion
```

or:

```text
/etc/bash_completion.d
```

Fish uses:

```text
~/.config/fish/completions/rg.fish
```

Zsh installs `_rg` in a directory listed in `fpath`.

PowerShell profiles dot-source `_rg.ps1`. If the executable or completion file is not available on `PATH`, the profile should use the full path to `_rg.ps1`.

A generated man page can be located in the build output with:

```text
$ find ./target -name rg.1 -print0 | xargs -0 ls -t | head -n1
./target/debug/build/ripgrep-79899d0edd4129ca/out/rg.1
```

## Search order and compressed input

Parallel search produces nondeterministic result order. The order can change between runs because files are searched concurrently. If consistent path ordering is required, use:

```text
--sort path
```

Sorting by path disables parallelism. Smaller repositories may see little slowdown from this change, but the option changes the search strategy because results must be ordered rather than emitted as workers find them.

The `-z` and `--search-zip` options search compressed input through installed decompressor processes. The supported compression formats are gzip, bzip2, xz, lzma, lz4, Brotli, and Zstandard. The option does not search archive formats such as `tar.gz`. Compression support therefore applies to compressed streams, not to arbitrary archive contents.

The `-U` and `--multiline` options allow results to span lines. Multiline search has substantial memory and performance consequences, described below.

## Regular-expression engines

### Default engine

The default regular-expression engine is automata-based. It uses finite-state machines and provides linear worst-case matching. This makes it suitable for fast searches over large inputs, but it does not implement every feature available in backtracking engines.

In particular, the default engine does not implement backreferences or look-around. A pattern that requires one of these features cannot be expressed using the default engine.

The default engine can inspect a pattern's syntax and determine whether it can cross a line boundary. This analysis lets ripgrep remove newline from classes such as backslash-s when line-only behavior requires that matches not span newlines. It also allows ripgrep to search buffers without scanning each line separately in cases where the pattern is known not to cross a newline.

An explicit unsupported newline literal produces an error:

```text
$ rg '\n'
the literal '"\n"' is not allowed in a regex
```

Default line-only search must prevent matches from spanning a newline. The default engine's syntax analysis supports this restriction while preserving efficient search strategies. Equivalent introspection is unavailable to ripgrep when using PCRE2, so PCRE2 mode forces line-by-line searching in that situation.

### PCRE2

Use `-P` or `--pcre2` to select the optional PCRE2 engine. PCRE2 is a backtracking engine with additional regular-expression features. It can express patterns requiring features that the default engine does not provide, including backreferences.

For example:

```text
$ rg -P '(\w{10})\1'
tests/misc.rs
483:    cmd.arg("--max-filesize").arg("44444444444444444444");
globset/src/glob.rs
1206:    matches!(match7, "a*a*a*a*a*a*a*a*a", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
```

PCRE2 is optional. Most project release binaries enable it, but package-manager builds may differ. If `-P` is unavailable, ask the package maintainer whether the package was built with PCRE2 support.

The same command on a build without PCRE2 reports:

```text
$ rg -P '(\w{10})\1'
PCRE2 is not available in this build of ripgrep
```

The default engine and PCRE2 have different search properties. The default engine is based on automata and has linear worst-case matching. PCRE2 is based on backtracking and provides additional syntax. Selecting PCRE2 can therefore affect both the set of accepted patterns and the search strategy.

## Pattern compilation limits

A regular expression can be short in source form and still compile into a large internal representation. For example, a Unicode-letter class repeated 1,000 times can reach the default compiled-expression size limit:

```text
$ rg '\pL{1000}'
Compiled regex exceeds size limit of 10485760 bytes.
```

The approximate compilation allowance can be raised with `--regex-size-limit`:

```text
$ rg '\pL{1000}' --regex-size-limit 1G
```

An allowance of `1G` does not allocate 1 GB automatically. It raises the permitted approximate size; memory is used only as required by compilation and the resulting search.

The `-f` or `--file` option reads one pattern per line. The patterns form a union: a line matches when it matches any pattern in the pattern file.

A large number of patterns can exhaust the fast engine's cache. When that happens, ripgrep can use a slower engine. The cache allowance can be raised with `--dfa-size-limit`, for example:

```text
--dfa-size-limit 1G
```

As with `--regex-size-limit`, this does not automatically allocate the full allowance. It raises the permitted cache size without requiring the complete amount of memory to be reserved in advance.

## Colors and configuration

The `--color` option chooses when ripgrep emits color:

- `never` disables color.
- `auto` is the default and emits color only for terminals.
- `always` emits color regardless of whether the output is a terminal.
- `ansi` emits ANSI color sequences.

The `--colors` option configures the appearance of paths, line numbers, columns, and matches. Its argument has this form:

```text
--colors '{type}:{attribute}:{value}'
```

The configurable types include `path`, `line`, `column`, and `match`. Attributes include foreground color, background color, and style. Style values include:

```text
bold
nobold
intense
nointense
underline
nounderline
```

Colors can be specified using one of eight color names, a decimal index from 0 through 255, a hexadecimal index from 0 through 255, or a comma-separated RGB triple.

For example, a match can be configured with a blue background, white foreground, and bold style:

```text
$ rg somepattern \
    --colors 'match:none' \
    --colors 'match:bg:0x33,0x66,0xFF' \
    --colors 'match:fg:white' \
    --colors 'match:style:bold'
```

The `match:none` setting resets the match element's styling. A later setting can then establish only the desired attributes:

```text
$ rg somepattern --colors 'match:fg:0x33,0x66,0xFF'
```

To clear the existing match styling before applying a foreground color, use:

```text
$ rg somepattern --colors 'match:none' --colors 'match:fg:0x33,0x66,0xFF'
```

This reset is useful when a default style, such as bold, interferes with terminal color behavior.

A Silver Searcher-like color scheme can be expressed as:

```text
rg --colors line:fg:yellow      \
   --colors line:style:bold     \
   --colors path:fg:green       \
   --colors path:style:bold     \
   --colors match:fg:black      \
   --colors match:bg:yellow     \
   --colors match:style:nobold  \
   foo
```

The same configuration can be stored in a file:

```text
$ cat $HOME/.config/ripgrep/rc
--colors=line:fg:yellow
--colors=line:style:bold
--colors=path:fg:green
--colors=path:style:bold
--colors=match:fg:black
--colors=match:bg:yellow
--colors=match:style:nobold
```

Activate that file with `RIPGREP_CONFIG_PATH`:

```text
$ RIPGREP_CONFIG_PATH=$HOME/.config/ripgrep/rc rg foo
```

The configuration file supplies command-line options. Its use is controlled by `RIPGREP_CONFIG_PATH`.

## Windows terminal colors

Windows terminals do not all provide the same color capabilities. Cygwin may support truecolor directly. Ordinary consoles from before Windows 10 have no known route for truecolor.

On Windows 10, clear the default match styling before applying truecolor VT100 escapes if bold styling interferes with truecolor output. The reset can be supplied with `--colors 'match:none'`, followed by the desired foreground or background color.

After interrupted output, the terminal may retain a changed color. In `cmd`, the `color` command can restore the color. A Unix reset escape can also restore it.

PowerShell can save and restore the original foreground color with this function:

```powershell
$OrigFgColor = $Host.UI.RawUI.ForegroundColor
function Reset-ForegroundColor {
	$Host.UI.RawUI.ForegroundColor = $OrigFgColor
}
Set-Alias -Name color -Value Reset-ForegroundColor
```

The history of Windows handling includes changes through PR187 and issue281.

## Encoding and PCRE2 Unicode behavior

PCRE2 Unicode mode requires valid UTF-8. The default engine can search arbitrary bytes, while refusing invalid sequences for patterns that require Unicode-only behavior.

Normally, ripgrep transcodes invalid UTF-8 to replacement characters before searching with PCRE2. It also disables redundant PCRE2 validation in that mode. This lets ripgrep perform the conversion itself and prevents PCRE2 from separately rejecting the converted stream.

The distinction is visible with invalid data:

```text
$ cat invalid-utf8
foobar

$ xxd invalid-utf8
00000000: 666f 6fff 6261 720a                      foo.bar.

$ rg foo invalid-utf8
1:foobar

$ rg -P foo invalid-utf8
1:foo�bar

$ rg -P foo invalid-utf8 --no-encoding
invalid-utf8: PCRE2: error matching: UTF-8 error: illegal byte (0xfe or 0xff)
```

Passing invalid data directly to PCRE2 can produce an error and stop that file's search. `--no-encoding` skips ripgrep's conversion and re-enables PCRE2 validation. It can be slower and can expose invalid-UTF-8 errors.

The conversion and validation path is one reason performance can differ between the default engine and PCRE2. Possible differences in UTF-8 validation include `encoding_rs` SIMD. This is an explanation considered by the author, not a proven universal limitation of PCRE2.

## Performance experiment

A performance experiment uses a large subtitle file and the pattern `^\w{42}$`. The pattern has one hit and no literal shortcut. The file can be obtained and checked with:

```text
$ curl -O 'https://burntsushi.net/stuff/subtitles2016-sample.gz'
$ gzip -d subtitles2016-sample
$ md5sum subtitles2016-sample
e3cb796a20bbc602fbfd6bb43bda45f5   subtitles2016-sample
```

The default engine search reports:

```text
$ time rg '^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.783s
user    0m1.731s
sys     0m0.051s
```

The corresponding PCRE2 search reports:

```text
$ time rg -P '^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m2.458s
user    0m2.419s
sys     0m0.038s
```

The commands find the same line. Their timings differ because the engines and search strategies differ.

The `--trace` option distinguishes fast and slow line search and shows decoding decisions. For the default engine:

```text
$ rg '^\w{42}$' subtitles2016-sample --trace
[... snip ...]
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:622: Some("subtitles2016-sample"): searching via memory map
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:712: slice reader: searching via slice-by-line strategy
TRACE|grep_searcher::searcher::core|grep-searcher/src/searcher/core.rs:61: searcher core: will use fast line searcher
[... snip ...]
```

For PCRE2:

```text
$ rg -P '^\w{42}$' subtitles2016-sample --trace
[... snip ...]
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:622: Some("subtitles2016-sample"): searching via memory map
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:705: slice reader: needs transcoding, using generic reader
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:685: generic reader: searching via roll buffer strategy
TRACE|grep_searcher::searcher::core|grep-searcher/src/searcher/core.rs:63: searcher core: will use slow line searcher
[... snip ...]
```

The default search uses a memory map, a slice-by-line strategy, and the fast line searcher. The PCRE2 search needs transcoding, uses a generic reader and roll-buffer strategy, and uses the slow line searcher.

Skipping ripgrep's encoding conversion does not necessarily make this example faster:

```text
$ time rg -P '^\w{42}$' subtitles2016-sample --no-encoding
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m3.074s
user    0m3.021s
sys     0m0.051s
```

The result remains the same, but the reported time is greater in this experiment.

## Multiline search and memory

Multiline search requires the whole file in memory because a match can be arbitrarily long. A memory map normally supplies the file contents. UTF-8 conversion, however, requires a heap copy.

The default engine can recognize a pattern that cannot cross lines and retain its fast incremental strategy even when `-U` is supplied. The presence of multiline mode does not by itself require every pattern to be treated as an arbitrary cross-line expression when syntax analysis establishes that the pattern cannot cross a newline.

With PCRE2, combining `-U` with `--no-pcre2-unicode` can avoid both line-by-line searching and decoding. This can allow memory mapping and JIT speed when Unicode semantics and cross-line restrictions are unnecessary.

Disabling Unicode can miss non-ASCII word characters. It should therefore be used only when the loss of Unicode semantics is acceptable.

The experiment with multiline mode reports:

```text
$ time rg -U '^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.803s
user    0m1.748s
sys     0m0.054s

$ time rg -P -U '^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m2.962s
user    0m2.246s
sys     0m0.713s
```

The default engine remains close to its earlier timing. PCRE2 with multiline mode is slower in this run.

The default engine can also disable Unicode for a pattern with the inline flag:

```text
$ time rg '(?-u)^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.714s
user    0m1.669s
sys     0m0.044s
```

The PCRE2 equivalent uses:

```text
$ time rg -P '^\w{42}$' subtitles2016-sample --no-pcre2-unicode
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.997s
user    0m1.958s
sys     0m0.037s
```

With both multiline mode and Unicode disabled:

```text
$ time rg -U '(?-u)^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.714s
user    0m1.655s
sys     0m0.058s

$ time rg -P -U '^\w{42}$' subtitles2016-sample --no-pcre2-unicode
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.121s
user    0m1.071s
sys     0m0.048s
```

These results show why a PCRE2 search can be made faster by avoiding Unicode decoding and line-by-line restrictions when those semantics are not needed. The source also acknowledges that other APIs or designs could perform differently. The timings are observations from the supplied experiment, not universal performance guarantees.

## Aliases and unexpected command behavior

Unexpected `rg` behavior may come from another executable or from a shell alias. One notable case is the Oh My Zsh Rails mapping, which maps `rg` to `rails generate`.

Inspect the command resolution with:

```text
which rg
```

Possible remedies include:

- Disable the plugin that defines the mapping.
- Invoke the command as `command rg`.
- Escape or quote the command invocation.
- Use the full path to the ripgrep executable.
- Remove the alias with `unalias rg`.
- Define a distinct alias for ripgrep.

The important distinction is whether the shell is invoking ripgrep at all. Checking command resolution should precede investigation of search semantics when the output or options appear unrelated to ripgrep.

## PowerShell wrappers and input

A PowerShell wrapper must propagate arguments and must pipe input only when input exists. Piping an empty input object makes ripgrep search empty standard input instead of searching the intended files.

The following wrapper counts the input, resets the input object, and conditionally pipes it:

```powershell
function grep {
    $count = @($input).Count
    $input.Reset()

    if ($count) {
        $input | rg.exe --hidden $args
    }
    else {
        rg.exe --hidden $args
    }
}
```

When input exists, it is piped to `rg.exe`. When it does not, `rg.exe` receives the arguments without an empty pipeline.

A PowerShell profile is run at startup. The profile path is exposed by the profile variable. Profile configuration can therefore contain the wrapper, aliases, completion setup, and encoding settings that should apply to each session.

## PowerShell output encoding

PowerShell's `OutputEncoding` controls the bytes that PowerShell pipes to native processes. The documented default is US-ASCII. Characters unsupported by that encoding become question marks when passed to a native process.

Set `OutputEncoding` to a .NET `UTF8Encoding`, or set the console output encoding to UTF-8. Place the setting in the PowerShell profile when it must persist across sessions.

The setting for bytes sent to native processes is separate from the setting used to display output. `Console.OutputEncoding` can separately be set to UTF-8 for display. Both paths may matter when PowerShell sends text to ripgrep and displays ripgrep's output.

## Replacing text

Ripgrep never edits files. It searches and reports. It can list paths containing matches, and another program can use those paths to modify the files.

To list matching paths:

```text
rg foo --files-with-matches
```

A simple GNU `sed` replacement can use `-i`:

```text
rg foo --files-with-matches | xargs sed -i 's/foo/bar/g'
```

BSD `sed` requires a backup-extension argument. An empty argument disables backups:

```text
rg foo --files-with-matches | xargs sed -i '' 's/foo/bar/g'
```

Paths containing whitespace require NUL-delimited output and NUL-aware `xargs`:

```text
rg foo --files-with-matches -0 | xargs -0 sed -i 's/foo/bar/g'
```

The search step still does not modify files. `sed` performs the modification after receiving the selected paths.

`fastmod` is another replacement tool. It shares some underlying libraries with ripgrep.

## Shell completion details

Completion files are included in builds and releases. Their installation locations differ by shell.

For Zsh, the separately maintained file is `complete/_rg`, and `_rg` must be installed in a directory contained in `fpath`. For Bash, `rg.bash` belongs under `$XDG_CONFIG_HOME/bash_completion` or `/etc/bash_completion.d`. For Fish, the file is `~/.config/fish/completions/rg.fish`.

For PowerShell, profiles dot-source `_rg.ps1`. If the file is not on `PATH`, use its full path. Since the profile runs at startup, this makes completion available in new sessions.

Completion files and the generated man page are release artifacts. The man page is generated only when `asciidoctor` or `asciidoc` is installed during the build; binary releases include it.

## Project naming and volunteer policy

The project name has a specific history. The initial name was `rep`, followed by `xrep`. `rustgrep` and `rgrep` were considered. `rip` was chosen to suggest fast searching while retaining an `r` associated with Rust.

The interpretation of RIP as a grep killer was noticed only after release. It was not the intended meaning.

The author declines donations to preserve a personally sustainable volunteer relationship with the project. Suggested alternatives are the Internet Archive, Rails Girls, or Wikipedia.

Volunteers publish on a best-effort basis without release dates. Serious regressions can motivate a patch, but no timing promise follows from that motivation. Users should therefore treat release timing as unspecified.

## License policy

Users may choose either the MIT license or the Unlicense.

The author favors the Unlicense because of its copyright-disclaimer goal, while offering the familiar MIT terms for adoption. The project requires all direct and transitive dependencies to remain permissively licensed.

GPL, LGPL, and MPL licenses are excluded. Creative Commons ShareAlike is also excluded, even when it is described as weak copyleft. License evaluation applies to direct dependencies and to the complete transitive dependency set.

## Choosing ripgrep or another tool

Ripgrep can replace some uses of `grep`, especially recursive code search with ignore files, Unicode or UTF-16 searching, and parallel searches over large directories.

It is not a complete behavior-compatible replacement. It is not POSIX conformant, and it is less ubiquitous in portable scripts. A script that depends on broad system availability may therefore require GNU `grep` or another tool.

GNU `grep` combined with filters, wrappers, or parallel `xargs` may be sufficient. Conversely, a missing feature remains a valid reason to use another search tool. Tool choice depends on the required behavior rather than on a general claim that one command replaces every other command.

Ripgrep's Unicode behavior does not depend on locale settings. The search result is therefore not controlled by the locale in the way locale-dependent tools may be.

## Practical decision points

Use the default engine when linear worst-case matching and automata-based search are appropriate. Remember that backreferences and look-around are unavailable there.

Use `-P` or `--pcre2` when additional PCRE2 syntax is required, and verify that the build includes PCRE2. Release binaries generally enable it, but package-manager builds may not.

Use `-U` or `--multiline` when results may span lines. Account for whole-file memory requirements and the possibility of a different search strategy.

Use `--no-pcre2-unicode` only when Unicode semantics are unnecessary. It can avoid decoding and permit faster memory-mapped or JIT paths, but it can miss non-ASCII word characters.

Use `--no-encoding` when ripgrep's conversion of invalid UTF-8 must be skipped. This re-enables PCRE2 validation and can expose errors or reduce performance.

Use `--regex-size-limit` for a compiled expression that exceeds the approximate size limit. Use `--dfa-size-limit` when many patterns exhaust the fast engine's cache. Neither option automatically allocates its full allowance.

Use `--sort path` when deterministic path ordering is more important than parallel search. Expect parallelism to be disabled.

Use `--search-zip` for supported compressed streams, but do not expect it to inspect archive formats such as `tar.gz`.

Use `--colors` and `RIPGREP_CONFIG_PATH` to make output styling repeatable. Reset an element with `type:none` before applying a new style when inherited styling causes problems.

Check `which rg` when a shell invokes an unexpected command. Check the PowerShell wrapper when empty input is unexpectedly searched. Check `OutputEncoding` when non-ASCII characters become question marks in a native-process pipeline.

Use NUL-delimited output with `-0` and `xargs -0` when matching paths can contain whitespace. Use `sed` or `fastmod` for edits because ripgrep itself never changes files.
