# Ripgrep: Comprehensive Technical Documentation and Usage Guide

## Introduction and Project Scope

Ripgrep (`rg`) is a high-performance command-line search tool designed for developers, system administrators, and power users who require rapid, recursive file searching capabilities. This document serves as the authoritative technical reference for understanding ripgrep’s search semantics, performance characteristics, configuration options, Windows-specific behaviors, and project policies. The material herein is derived directly from the project’s source code, official guides, and changelog entries. It is intended for software developers seeking to integrate, extend, or effectively utilize ripgrep within their workflows.

The primary purpose of this documentation is to answer common and advanced questions regarding ripgrep’s operation. It covers configuration and encoding mechanisms, shell completion setups, parallel search behaviors, regex engine differences, color output customization, Windows terminal nuances, performance tuning, Unicode handling, and project licensing. By adhering to the facts and code examples provided in the source material, this guide ensures that users can rely on accurate, verified information without speculative claims or external assumptions.

## Configuration and Encoding

Configuration and encoding details for ripgrep are primarily documented in the project’s `GUIDE.md` file. Updates, changes, and new features are recorded in `CHANGELOG.md`. It is important to note that ripgrep is maintained by volunteers on a best-effort basis. Consequently, there are no fixed release dates, and updates are published when volunteers are available. While serious regressions may motivate the creation of a patch, the project creates no timing promise for when such patches will be released or incorporated.

For users interested in building ripgrep from source, the build process generates documentation artifacts if specific tools are installed. Specifically, if `asciidoctor` or `asciidoc` is installed on the system, the build process will generate a man page from the argument parser. This generated man page is placed under the target’s build output directory. For example, the build process may produce a file located at:

```
./target/debug/build/ripgrep-79899d0edd4129ca/out/rg.1
```

This can be identified and verified using standard Unix utilities:

```bash
$ find ./target -name rg.1 -print0 | xargs -0 ls -t | head -n1
./target/debug/build/ripgrep-79899d0edd4129ca/out/rg.1
```

Binary releases of ripgrep include this man page, ensuring that users installing pre-built binaries have access to the documentation. Additionally, the command-line help options provide equivalent details. The `rg --help` flag displays full option details, while `rg -h` condenses each flag to a single line for quick reference.

## Shell Completions

Ripgrep includes shell completions for several popular shell environments in its builds and releases. These completions enhance the user experience by providing auto-completion for flags, options, and file paths. The setup varies depending on the shell being used.

### Zsh

For Zsh, the completion file is separately maintained. It is located in the file `complete/_rg`. To enable completions, users must ensure that this file is installed in their Zsh `fpath`. This typically involves copying the file to a directory listed in the `$fpath` variable or sourcing it directly in the `.zshrc` configuration file.

### Bash

Bash completions are provided in the file `rg.bash`. Users can install this file in one of two standard locations:
1. `$XDG_CONFIG_HOME/bash_completion/`
2. `/etc/bash_completion.d/`

Installing in `/etc/bash_completion.d/` requires root privileges and applies system-wide. Installing in the user’s configuration directory applies only to the current user.

### Fish

Fish shell users should place the completion file `rg.fish` in the directory `~/.config/fish/completions/`. This is the standard location for user-specific completions in Fish.

### PowerShell

PowerShell users can utilize the `_rg.ps1` script. To enable completions, users must dot-source this file in their PowerShell profile. If the script is not available on the system `PATH`, users must provide the full path to the file when dot-sourcing. The PowerShell profile path is exposed by the `$PROFILE` variable, and the script runs automatically at startup if added there.

## Search Semantics and Parallelism

### Parallel Search and Determinism

Ripgrep performs parallel searches by default, utilizing multiple threads to scan files concurrently. This parallelism significantly improves search speed on multi-core systems, especially in large repositories. However, parallel search produces nondeterministic result order. The order in which results appear may vary between runs because the time taken to process each file depends on system load, disk I/O speed, and thread scheduling.

If a consistent, deterministic result order is required, users can use the `--sort path` flag. This flag sorts the output by file path. However, enabling `--sort path` disables parallelism for the search. This is because sorting requires collecting all results before printing, which necessitates a single-threaded approach to ensure order. For smaller repositories, the slowdown caused by disabling parallelism may be negligible or unnoticeable.

### Multiline Search

The `-U` or `--multiline` flag allows ripgrep to return results that span multiple lines. By default, ripgrep searches line-by-line, meaning a match cannot span across a newline character. Enabling multiline mode changes this behavior.

Multiline search requires the whole file to be available in memory because a match can be arbitrarily long. Ripgrep normally uses a memory map to supply this data efficiently. However, if UTF-8 transcoding is required, ripgrep must make a heap copy of the data. This can impact performance and memory usage.

The default regex engine in ripgrep is optimized for performance. It can recognize patterns that cannot cross lines and will continue to use its fast incremental strategy even when `-U` is enabled. This optimization is not available when using the PCRE2 engine (`-P`).

### Searching Compressed Files

The `-z` or `--search-zip` flag enables ripgrep to search inside compressed files. It supports the following compression formats:
- gzip
- bzip2
- xz
- lzma
- lz4
- Brotli
- Zstd

When this flag is used, ripgrep spawns installed decompressor processes to handle the decompression. It is important to note that ripgrep does not search archive formats such as `tar.gz`. It only searches individual compressed files. For example, to search a gzip-compressed file, the file must be a `.gz` file, not a `.tar.gz` archive.

## Regex Engines

Ripgrep offers two regex engines: the default engine and PCRE2.

### Default Engine

The default regex engine is based on finite-state machines (FSMs). This approach provides linear worst-case matching time, making it highly predictable and resistant to catastrophic backtracking. However, the default engine does not implement backreferences or look-around assertions.

The default engine also exposes syntax analysis to remove newline characters from character classes such as `\s` (whitespace). This prevents matches from spanning newline characters in the default line-only search mode. If a user explicitly includes an unsupported newline literal in a regex, the default engine will return an error. This behavior enables ripgrep to search buffers without scanning each line separately, improving performance.

### PCRE2 Engine

The `-P` or `--pcre2` flag selects the optional PCRE2 engine. PCRE2 is a backtracking engine that supports additional regex features, including backreferences and look-around assertions. Most project release binaries enable PCRE2 support. However, package-manager builds may differ, and users may need to ask their package maintainer if PCRE2 is enabled in their specific build.

When using PCRE2, ripgrep does not have access to the same level of introspection as the default engine. This forces ripgrep to perform line-by-line search in default mode, even if the pattern does not span lines. This can result in slower performance compared to the default engine.

### Backreferences Example

Backreferences are a key feature of PCRE2. The following example demonstrates a backreference that matches a word character repeated ten times, followed by the same sequence:

```bash
$ rg -P '(\w{10})\1'
tests/misc.rs
483:    cmd.arg("--max-filesize").arg("44444444444444444444");
globset/src/glob.rs
1206:    matches!(match7, "a*a*a*a*a*a*a*a*a", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
```

If PCRE2 is not available in the build, the command will return an error:

```bash
$ rg -P '(\w{10})\1'
PCRE2 is not available in this build of ripgrep
```

### Regex Size Limits

Large compiled regexes can hit a size limit, even when the source pattern is short. For example, a Unicode-letter class repeated 1,000 times can exceed the default limit:

```bash
$ rg '\pL{1000}'
Compiled regex exceeds size limit of 10485760 bytes.
```

The `--regex-size-limit` flag raises the approximate compilation allowance. For example, setting it to 1G allows larger regexes:

```bash
$ rg '\pL{1000}' --regex-size-limit 1G
```

It is important to note that a 1 GB allowance does not allocate 1 GB of memory automatically. It only raises the limit for compilation.

### DFA Size Limit

When many patterns are specified using `-f` or `--file`, ripgrep may exhaust the fast engine’s cache and trigger a slower engine. The `--dfa-size-limit` flag raises the cache allowance for the deterministic finite automaton (DFA) engine. For example:

```bash
$ rg -f patterns.txt --dfa-size-limit 1G
```

Like `--regex-size-limit`, this does not automatically allocate the full amount of memory.

## Color Configuration

Ripgrep provides extensive color customization options to improve readability and integrate with various terminal themes.

### Color Choices

The `--color` flag chooses when colors appear in the output. The available options are:
- `never`: Never use colors.
- `auto` (default): Use colors only if the output is a terminal.
- `always`: Always use colors, even if output is redirected.
- `ansi`: Use ANSI escape sequences for colors.

### Color Configuration

The `--colors` flag configures the appearance of paths, lines, columns, and matches. It accepts arguments in the format `type:attribute:value`. The types are `path`, `line`, `column`, and `match`. The attributes include `fg` (foreground), `bg` (background), and `style`.

Style values include:
- `bold` / `nobold`
- `intense` / `nointense`
- `underline` / `nounderline`

Colors can be specified using:
- Eight named colors.
- Decimal or hex indices from 0–255.
- Comma-separated RGB triples.

The value `none` resets that element’s styling.

### Example Configurations

To set bold white text on a blue background for matches, you can use:

```bash
$ rg somepattern \
    --colors 'match:none' \
    --colors 'match:bg:0x33,0x66,0xFF' \
    --colors 'match:fg:white' \
    --colors 'match:style:bold'
```

Alternatively, you can specify the background color directly in hex:

```bash
$ rg somepattern --colors 'match:fg:0x33,0x66,0xFF'
```

To reset styling and then apply a new foreground color:

```bash
$ rg somepattern --colors 'match:none' --colors 'match:fg:0x33,0x66,0xFF'
```

A Silver Searcher-like scheme can be configured as follows:

```bash
rg --colors line:fg:yellow      \
   --colors line:style:bold     \
   --colors path:fg:green       \
   --colors path:style:bold     \
   --colors match:fg:black      \
   --colors match:bg:yellow     \
   --colors match:style:nobold  \
   foo
```

### Configuration File

Ripgrep can read configuration from a file. The `RIPGREP_CONFIG_PATH` environment variable activates a config file. The file should contain one option per line. For example, to create a config file at `~/.config/ripgrep/rc`:

```bash
$ cat $HOME/.config/ripgrep/rc
--colors=line:fg:yellow
--colors=line:style:bold
--colors=path:fg:green
--colors=path:style:bold
--colors=match:fg:black
--colors=match:bg:yellow
--colors=match:style:nobold
```

Then, run ripgrep with the config file:

```bash
$ RIPGREP_CONFIG_PATH=$HOME/.config/ripgrep/rc rg foo
```

## Windows-Specific Behaviors

Windows terminals present unique challenges for color output, particularly regarding truecolor support.

### Terminal Differences

Cygwin may support truecolor directly. However, ordinary pre-Windows-10 consoles have no known truecolor route. On Windows 10, truecolor is supported via VT100 escape sequences.

### Color Interference

On Windows 10, bold text can interfere with truecolor VT100 escapes. To resolve this, users should clear default match styling first. This ensures that the truecolor escape sequences are applied correctly.

### Resetting Colors

After interrupted output, cmd.exe may retain incorrect color settings. Users can restore colors using the `color` command in cmd or by sending a Unix reset escape sequence. In PowerShell, a function can be defined to reset the foreground color:

```powershell
$OrigFgColor = $Host.UI.RawUI.ForegroundColor
function Reset-ForegroundColor {
	$Host.UI.RawUI.ForegroundColor = $OrigFgColor
}
Set-Alias -Name color -Value Reset-ForegroundColor
```

Earlier handling of these issues changed through PR187 and issue281. Users should be aware of these historical changes if they encounter unexpected color behavior.

## Performance Tuning

Ripgrep is designed for speed, but performance can be affected by various factors.

### Performance Experiment

A performance experiment can be conducted using a large file and a regex that matches exactly 42 word characters at the start of a line. The regex `^\w{42}$` has one hit and no literal shortcut, making it a good candidate for testing.

First, download and decompress a sample file:

```bash
$ curl -O 'https://burntsushi.net/stuff/subtitles2016-sample.gz'
$ gzip -d subtitles2016-sample
$ md5sum subtitles2016-sample
e3cb796a20bbc602fbfd6bb43bda45f5   subtitles2016-sample
```

Then, time the search using the default engine:

```bash
$ time rg '^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.783s
user    0m1.731s
sys     0m0.051s
```

Compare this with the PCRE2 engine:

```bash
$ time rg -P '^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m2.458s
user    0m2.419s
sys     0m0.038s
```

The default engine is faster in this case due to its optimized incremental strategy.

### Trace Output

The `--trace` flag distinguishes between fast and slow line search and decoding. It provides detailed logging of the search process.

For the default engine:

```bash
$ rg '^\w{42}$' subtitles2016-sample --trace
[... snip ...]
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:622: Some("subtitles2016-sample"): searching via memory map
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:712: slice reader: searching via slice-by-line strategy
TRACE|grep_searcher::searcher::core|grep-searcher/src/searcher/core.rs:61: searcher core: will use fast line searcher
[... snip ...]
```

For the PCRE2 engine:

```bash
$ rg -P '^\w{42}$' subtitles2016-sample --trace
[... snip ...]
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:622: Some("subtitles2016-sample"): searching via memory map
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:705: slice reader: needs transcoding, using generic reader
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:685: generic reader: searching via roll buffer strategy
TRACE|grep_searcher::searcher::core|grep-searcher/src/searcher/core.rs:63: searcher core: will use slow line searcher
[... snip ...]
```

The trace output shows that the PCRE2 engine uses a "generic reader" and a "slow line searcher" due to the need for transcoding.

### UTF-8 Validation and SIMD

Possible differences in UTF-8 validation include the use of `encoding_rs` SIMD instructions. This is an explanation considered by the author but is not a proven universal PCRE2 limitation. Users should be aware that UTF-8 validation can impact performance, especially with large files.

### Multiline Performance

Multiline search performance depends on the engine and Unicode settings.

For the default engine with multiline:

```bash
$ time rg -U '^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.803s
user    0m1.748s
sys     0m0.054s
```

For PCRE2 with multiline:

```bash
$ time rg -P -U '^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m2.962s
user    0m2.246s
sys     0m0.713s
```

The PCRE2 engine is slower due to the lack of optimization for multiline search.

### Disabling Unicode

Disabling Unicode semantics can improve performance when Unicode semantics and cross-line restrictions are unnecessary. However, disabling Unicode can miss non-ASCII word characters.

For the default engine with Unicode disabled:

```bash
$ time rg '(?-u)^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.714s
user    0m1.669s
sys     0m0.044s
```

For PCRE2 with Unicode disabled:

```bash
$ time rg -P '^\w{42}$' subtitles2016-sample --no-pcre2-unicode
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.997s
user    0m1.958s
sys     0m0.037s
```

Combining `-U` and `--no-pcre2-unicode` can avoid both line-by-line searching and decoding, allowing memory mapping and JIT speed when Unicode semantics are not required.

For the default engine with multiline and Unicode disabled:

```bash
$ time rg -U '(?-u)^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.714s
user    0m1.655s
sys     0m0.058s
```

For PCRE2 with multiline and Unicode disabled:

```bash
$ time rg -P -U '^\w{42}$' subtitles2016-sample --no-pcre2-unicode
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.121s
user    0m1.071s
sys     0m0.048s
```

In this case, PCRE2 is faster than the default engine because it can use memory mapping and JIT without the overhead of Unicode validation.

### Disabling Encoding

Passing invalid data directly to PCRE2 would produce errors and stop the search for that file. Ripgrep normally transcodes invalid UTF-8 to replacement characters before PCRE2 search and disables redundant PCRE2 checks.

The `--no-encoding` flag skips ripgrep’s conversion but re-enables PCRE2 validation. This can be slower and can expose invalid-UTF-8 errors.

```bash
$ time rg -P '^\w{42}$' subtitles2016-sample --no-encoding
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m3.074s
user    0m3.021s
sys     0m0.051s
```

### Invalid UTF-8 Handling

Ripgrep handles invalid UTF-8 gracefully. It transcodes invalid sequences to replacement characters.

Create a file with invalid UTF-8:

```bash
$ cat invalid-utf8
foobar

$ xxd invalid-utf8
00000000: 666f 6fff 6261 720a                      foo.bar.
```

Search with the default engine:

```bash
$ rg foo invalid-utf8
1:foobar
```

Search with PCRE2 (transcoded):

```bash
$ rg -P foo invalid-utf8
1:foo�bar
```

Search with PCRE2 and `--no-encoding` (error):

```bash
$ rg -P foo invalid-utf8 --no-encoding
invalid-utf8: PCRE2: error matching: UTF-8 error: illegal byte (0xfe or 0xff)
```

## Unexpected Behavior and Aliases

Unexpected ripgrep behavior may come from another executable or alias. A notable example is Oh My Zsh, which maps `rg` to `rails generate`.

To inspect the command being executed, use `which rg`:

```bash
$ which rg
```

Options to resolve alias conflicts include:
1. Disabling the plugin in Oh My Zsh.
2. Using the full command `rg` or escaped/quoted invocation.
3. Using a full executable path.
4. Unaliasing `rg` with `unalias rg`.
5. Creating a distinct alias for ripgrep.

## PowerShell Integration

PowerShell wrappers must propagate arguments and only pipe input when input exists. Piping an empty input object makes ripgrep search empty stdin, which can lead to unexpected results.

The supplied wrapper shows this conditional behavior:

```powershell
function grep {
    $count = @($input).Count
    $input.Reset()

    if ($count) {
        $input | rg.exe --hidden $args
    }
    else {
        rg.exe --hidden $args
    }
}
```

The profile path is exposed by the `$PROFILE` variable, and the script runs at startup.

PowerShell’s `OutputEncoding` controls bytes piped to native processes. The documented default is US-ASCII, which turns unsupported characters into question marks. To preserve characters, set a .NET `UTF8Encoding` or the console output encoding. Place the setting in the profile for persistence.

Console output encoding can be set separately to UTF-8 for display:

```powershell
Console.OutputEncoding = [System.Text.Encoding]::UTF8
```

## File Modification Workflow

Ripgrep never edits files. It is a search tool, not a modification tool. However, it can list matching paths for use with other tools like `xargs` or `sed` to modify files.

To list matching paths:

```bash
rg foo --files-with-matches
```

To modify files using GNU sed:

```bash
rg foo --files-with-matches | xargs sed -i 's/foo/bar/g'
```

BSD sed requires a backup-extension argument. An empty string disables backups:

```bash
rg foo --files-with-matches | xargs sed -i '' 's/foo/bar/g'
```

Paths containing whitespace require NUL-delimited ripgrep output and `xargs -0`:

```bash
rg foo --files-with-matches -0 | xargs -0 sed -i 's/foo/bar/g'
```

Another replacement tool is `fastmod`, which shares some underlying libraries with ripgrep.

## Project Policy and Licensing

Users may choose between the MIT License and the Unlicense for their contributions or usage. The author favors the Unlicense’s copyright-disclaimer goal while offering familiar MIT terms for adoption.

All direct and transitive dependencies must remain permissively licensed. GPL, LGPL, MPL, and Creative Commons ShareAlike licenses are excluded, even when described as weak copyleft. This policy ensures that ripgrep remains free and open for commercial and personal use without legal encumbrances.

## Comparison with Other Tools

Ripgrep can replace some `grep` uses, especially for:
- Recursive code search with ignore files.
- Unicode and UTF-16 support.
- Parallel large-directory searches.

However, ripgrep is not a complete behavior-compatible replacement for `grep`. It is not POSIX conformant and is less ubiquitous for portable scripts. GNU `grep` with filters, wrappers, and parallel `xargs` may be sufficient for some users. Missing required features remain a reason to use another tool.

Ripgrep’s Unicode behavior does not depend on locale settings, which simplifies usage across different environments.

## Name History

The project has undergone several name changes:
1. `rep`
2. `xrep`
3. `rustgrep` / `rgrep` (considered)
4. `rip` (chosen to suggest fast searching while retaining an 'r' associated with Rust)
5. `rg` / `ripgrep`

The "RIP/grep-killer" interpretation was noticed only after release and was not the intended meaning. The name `rip` was chosen for its association with speed and Rust.

## Donations and Support

The author declines donations to preserve a personally sustainable volunteer relationship with the project. Instead, the author suggests supporting organizations such as:
- Internet Archive
- Rails Girls
- Wikipedia

This approach ensures that the project remains free and volunteer-driven, without the pressure of financial expectations.

## Conclusion

Ripgrep is a powerful, fast, and flexible search tool for developers. By understanding its search semantics, performance characteristics, configuration options, and platform-specific behaviors, users can leverage ripgrep effectively in their workflows. This documentation provides the necessary facts and code examples to support informed decision-making and efficient usage.
