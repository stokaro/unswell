# bat Version History and Technical Documentation

This document provides a comprehensive technical record of the software development lifecycle, feature evolution, and architectural changes for the command-line interface tool `bat` through version 0.16.0. The following sections detail the progression from the initial release to the current stable version, focusing on command-line interface modifications, library API adjustments, packaging updates, and syntax highlighting enhancements. The material is intended for software developers requiring precise historical data regarding dependency management, configuration structures, and behavioral changes across minor and major version increments.

## Initial Releases and Core Foundations (v0.1.0 – v0.3.0)

The development of `bat` began with version 0.1.0, which established the foundational capabilities of the tool. This initial release introduced the core concept of providing a syntax-highlighted cat(1) clone. The architecture was designed to support basic file viewing with an emphasis on readability and integration with standard Unix utilities.

Version 0.2.0 marked a significant step in extensibility by introducing custom syntax definitions and extended Markdown support. A critical fix in this release addressed child-directory Git markers, ensuring that version control status was accurately reflected even when files were located in subdirectories. This improvement was vital for developers using `bat` within complex project structures.

Subsequent patch releases, v0.2.1 and v0.2.2, focused on dependency optimization and language support. v0.2.1 added support for the Elixir programming language and switched the library's backend to libcurl, a decision that likely improved network request handling and portability. v0.2.2 removed the OpenSSL dependency, reducing the binary size and simplifying the build process for environments where OpenSSL was not readily available or desired. v0.2.3 provided MUSL static binaries, enhancing portability for Linux distributions that utilize the musl libc implementation, thereby ensuring broader compatibility across diverse Linux environments.

Version 0.3.0 represented a major architectural shift, introducing automatic less paging for standard input and redirected output. This change aligned `bat` more closely with user expectations for terminal-based file viewing, where large files should be paged automatically rather than dumped to the terminal screen. The release also introduced distinct color modes, allowing users to toggle between light and dark themes dynamically. Language lists and selection mechanisms were refined, providing a more robust way to query supported syntaxes. Output styles were formalized, and the configuration format was standardized to TOML. A significant internal change was the replacement of the `init-cache` command with `cache`, streamlining the cache management workflow. Furthermore, Git context detection was derived from the input path rather than the current working directory, and support for process substitution was added, enabling more flexible piping and command chaining in shell environments.

## Early Stability and Feature Expansion (v0.4.0 – v0.6.1)

Version 0.4.0 introduced several high-visibility features that defined the user experience for many subsequent releases. Wrapping capabilities were added, allowing long lines to be broken into multiple lines for better readability on standard terminal widths. This release also formalized the syntax and theme system, adding support for Julia, Dockerfile, VimL, CMake, INI, and Less syntaxes. Visual enhancements included support for bold, italic, and underline text styles, which are critical for distinguishing code elements in syntax highlighting. Support for 32-bit architectures was added, broadening the tool's applicability to older hardware and embedded systems. The `-u` and `-n` flags were introduced to control underlining and line numbering, respectively. Additionally, Windows 10 ANSI support was implemented, ensuring that color output was rendered correctly on modern Windows terminals.

A structural change in this version was the renaming of the custom syntax folder to `syntaxes`, providing a more intuitive directory structure for users adding custom highlighting rules. Markdown rendering was updated to use the Sublime Text default, ensuring consistency with one of the most popular code editors. File listings were sorted, and flags were allowed to override earlier copies, providing flexibility in configuration precedence. Fixes in this version addressed issues with tiny terminals, filename detection, invalid UTF-8 sequences, error handling, and Unicode support in less. The release also included improvements to nightly builds and added tests, logos, and documentation for alternatives and refactoring efforts.

Version 0.4.1 was a patch release that fixed tests when run outside of a Git checkout, ensuring that the test suite remained robust regardless of the execution environment.

Version 0.5.0 introduced line ranges, allowing users to view specific sections of a file without loading the entire content into memory. This feature was particularly useful for large log files or source codebases. Environment variables `BAT_THEME` and `PAGER`/`BAT_PAGER` were added, giving users finer control over theming and paging behavior. Support for Nix and AWK syntaxes was added, expanding the tool's utility for system administrators and DevOps engineers. The release also introduced independent additive syntax and theme sets, allowing users to combine custom definitions without overwriting defaults. Theme-based gutter colors were implemented, providing visual cues for line numbers and changes. Fixes covered escape stripping, isolated Git snapshot tests, and issues with Markdown and JavaScript highlighting. ARMv7 releases and Arch Linux packaging were added, and color conversion improvements were made to ensure accurate color representation across different terminals.

Version 0.6.0 added theme previews, accessible via the `-p` flag, allowing users to browse available themes interactively. Exact-byte redirected output was implemented, ensuring that when output is piped to a file or another program, the byte count is preserved accurately. Support for Elm, Kotlin, Puppet, TypeScript, and the Zenburn theme was added. Custom themes could now be added additively without requiring a `Default` symlink, simplifying the theme management process. Cache deduplication fixes were applied, improving performance and reducing storage usage. A first man page was generated, and development and troubleshooting documentation was added to assist users and contributors.

Version 0.6.1 fixed an issue where the `--list-languages` command failed when piped to `head`, ensuring that language lists could be queried programmatically. The release also honored color settings in list outputs, enabled Windows Git markers, and began automated Windows releases, improving the reliability and accessibility of the tool on Windows platforms.

## Refinement and Library Introduction (v0.7.0 – v0.9.0)

Version 0.7.0 introduced significant enhancements to tab handling and style configuration. The `--tabs` option and `BAT_TABS` environment variable were added, allowing users to customize tab width. The `BAT_STYLE` environment variable was introduced, providing a centralized way to configure output styles. The OneHalf theme was added, offering a popular modern color scheme. Syntax support was expanded to include CSV, JSX, TSX, Cabal, Dart, F#, PureScript, Swift, Crystal, and PowerShell. Conditional Git queries were implemented, optimizing performance by only querying Git status when necessary. Plain mode no longer wrapped lines, preserving the original structure of the input. Fixes addressed cache-named files, Windows and less detection, wrapnever decorations, and directory headers. Builds for aarch64 and armhf architectures were added, and the Scoop package manager was supported for Windows users.

Version 0.7.1 improved eight-bit color approximation, ensuring that colors were rendered more accurately on terminals with limited color palettes. A panic in Haskell highlighting was fixed, and plain wrapping issues were resolved. Support for Ansible was added, and instructions for Cygwin were included, improving compatibility with Windows development environments.

Version 0.8.0 introduced argument-list configuration, allowing users to store command-line arguments in configuration files. Linux support for `~/.config/bat/config` was added, following the XDG Base Directory Specification. The `--config-file` option was introduced, allowing users to specify a custom configuration file. `BAT_OPTS` precedence was defined, ensuring that environment variables took precedence over configuration file settings. Custom syntax mappings were supported, and pager arguments could be passed directly. Windows wildcard support was added, and first-line detection was implemented to improve syntax detection accuracy. UTF-16LE and UTF-16BE encodings were supported, expanding compatibility with legacy systems. Robot syntax was added for testing automation. Interactive binary files were detected and suppressed, preventing garbled output. JavaDoc and Haskell fixes were applied, and build-generated completions were introduced. Tests were expanded, and distribution support for Termux, Nix, and Docker was added. Exact configuration and mapping examples were documented to assist users.

Version 0.9.0 added the `--show-all` option, which displays non-printing characters, enhancing the tool's utility for debugging text files. The `pager` option was refined, and the `BAT_CONFIG_PATH` environment variable was added, providing flexibility in configuration storage. Repeated style and line-range options were supported, allowing for more complex queries. Terminal-width offsets were added, enabling users to adjust the effective width of the terminal for formatting purposes. Italics were made opt-in, addressing compatibility issues with terminals that did not support italic text. Tabs defaulted to four spaces, aligning with common coding standards. The Sublime Snazzy theme was added. Completions stopped shipping as separate files, being integrated into the build process instead. Recursion prevention for `PAGER=bat` was implemented, avoiding infinite loops. openSUSE support and Chinese documentation were added, and tab and integration tests were improved.

## Library API and High-Level Features (v0.10.0 – v0.11.0)

Version 10.0 introduced the `--highlight-line` feature, allowing users to emphasize specific lines in the output. On macOS, the configuration directory moved from `~/Library/Preferences/bat` to `~/.config/bat`, aligning with modern macOS standards. Users were required to copy their existing configuration to the new location. Completion generation was disabled in this version, likely due to stability or maintenance concerns. Improvements were made to less flags, missing-file error handling, and nonexistent-file pager behavior. The `--init` flag for cache was renamed to `--build`, and hidden config and cache-dir flags were relocated. Fixes covered trailing plain lines and repeated stdin EOF handling. New syntaxes included Twig, desktop, AsciiDoc, assembly, log, Protobuf, Terraform, Jsonnet, and Varlink. A Japanese README was added, expanding international support.

Version 11.0 added the ansi-light and ansi-dark themes, as well as base16 themes, providing more options for users with specific aesthetic preferences. Handwritten Fish shell completion was added, improving the user experience for Fish users. The double `-p` flag was introduced to disable paging after the plain style, offering a convenient way to suppress paging in specific contexts. Explicit less arguments were preserved, and warnings were added for binary interactive inputs. Empty-file headers were restored, and terminal-width zero was rejected to prevent errors. Cache-file ambiguity was resolved, and tests were added to the test suite. The project adopted Rust 2018 edition, modernizing the codebase. F# and Fish syntax updates were included, and Chocolatey support was added for Windows package management.

Version 12.0 let the `-A` flag display binary data, providing a way to inspect binary files without corruption. Man-pager use was added, allowing man pages to be viewed with `bat`. Line-range separators were introduced, improving the visual distinction between selected ranges. The `-L` flag was added. Fixes covered grid balance, cache-named files, absent cache directories, and negative terminal-width parsing. Fish completion entered DEB packages, and syntaxes for Org, requirements, .env, SSH, hosts, GraphQL, Verilog, SCSS, Sass, and strace were added. Gentoo, Alpine, and Fedora packaging was recorded, documenting the tool's availability across various Linux distributions.

Version 12.1 fixed a CreateFile2 failure on older Windows versions, ensuring compatibility with legacy Windows systems.

## Library Exposure and Breaking Changes (v0.13.0)

Version 13.0 was a landmark release as it first exposed `bat` as a library. This move acknowledged the growing demand for integrating `bat`'s syntax highlighting capabilities into other applications. However, the release noted missing documentation and likely API changes, warning library consumers to expect instability. A breaking change was introduced with the glob-based `--map-syntax` option, requiring users to update their mapping configurations. Other additions included highlight-line ranges, wide-Unicode wrapping, the `BAT_CACHE_PATH` environment variable, and combining styles. Fixes covered new-less no-init behavior, cache-command precedence, Scala `.sc` files, man names with underscores and dashes, empty lines, redirected wrapping, non-Unicode filenames, empty-file grids, and build-file shebangs.

The release also parameterized man and completion names, enabling LTO (Link-Time Optimization) with a reported roughly 10% speedup. Documentation for macOS themes, integrations, encodings, and Windows was improved. The default theme could be accepted, and syntax support for Jinja2, SaltStack, fstab, group, passwd, proc files, Nim, Vue, and CoffeeScript was added. Themes such as Dracula, Nord, and Solarized were included. Ubuntu/Debian and MacPorts packages were made available, and Fish completions used `vendor_completions.d`. A new maintainer, eth-p, joined the team, signaling a commitment to ongoing development.

## High-Level API and Configuration Overhaul (v0.14.0)

Version 14.0 added the `--file-name` and `--generate-config-file` options, enhancing the user experience for file identification and configuration setup. Performance improvements were made to C# and Makefile highlighting. Ruby heredocs and Rust syntax were repaired. A bug causing disappearing short Windows output was fixed, and issues with `highlight-line` when using `tabs=0` or `wrap=never` were resolved. Cache metadata in `metadata.yaml` now records version compatibility, rejecting incompatible assets to prevent errors. A new high-level library API was recommended, though it remained in beta. The low-level API was refactored for better maintainability. The default application feature included executable dependencies, but library consumers could disable this, with paging and Git support as separate optional features. Older syntect support was retained. Rego and Stylo syntaxes were added.

## Low-Level API Changes and Performance (v0.15.0)

Version 15.0 introduced the `--diff` and `--diff-context` flags, allowing users to show Git-change neighborhoods directly in the output. Interleaved file errors were fixed, ensuring consistent output when multiple files are processed. Custom-cache startup was reported to be roughly twice as fast, a significant performance improvement. Solarized themes were updated. Low-level Config and error-handler APIs changed, including a mutable writer argument, though the high-level API remained unaffected.

## Restoration and Fixes (v0.15.1 – v0.15.4)

Version 15.1 fixed issues with Markdown and base16 themes and added support for Fortran, email, and QML syntaxes. The ansi-dark and ansi-light themes were suggested for Windows SSH palette problems, addressing color rendering issues in remote sessions.

Version 15.2 fixed rails, symlink, and file-name syntax mapping. Header padding without grids was added, and invalid-syntax errors were handled more gracefully. The `vcs_modification_markers` feature was deprecated when used without Git. Syntect 4.2 and oniguruma were integrated, removing the bindgen and libclang build requirements, simplifying the compilation process.

Version 15.3 fixed relative paths and digit-leading SSH users, improving compatibility with complex authentication setups. Support for SML (Standard ML) was added.

Version 15.4 restored Solarized themes, which may have been inadvertently removed or broken in previous releases, and fixed Haskell highlighting, ensuring accurate syntax representation for this functional programming language.

## Current State and Advanced Features (v0.16.0)

Version 16.0 introduces several significant features and fixes. The `NO_COLOR` environment variable is now supported, allowing users to disable color output in accordance with the NO_COLOR standard. The `-P` flag was added to disable paging entirely, providing a straightforward way to output raw content. The `--force-colorization` (`-f`) flag was introduced, forcing color output even when piping to non-terminals.

Redirected nonprinting display was fixed, ensuring that special characters are handled correctly when output is redirected. Language-extension conflicts were resolved, preventing ambiguities in syntax detection. The Unicode character U+00B7 (Middle Dot) is now used for spaces in certain contexts, improving visual clarity. Zsh completion, help, and man guidance were added, enhancing the user experience for Zsh users.

Syntax highlighting updates include improvements to AsciiDoc, GLSL, Nginx, and Apache configuration files. Crypttab support was added via fstab, and XDG Git configuration highlighting was improved. Themes such as Gruvbox and base16-256 were added, expanding the available color schemes.

Library APIs were updated with the addition of `InputDescription` and direct `PrettyPrinter` Inputs. The `Input::theme_preview_file` function was removed, likely due to refactoring or deprecation of specific preview functionalities. The liquid build dependency was removed, further simplifying the build process and reducing dependencies.

## Technical Configuration and Usage Examples

The configuration of `bat` can be managed through command-line flags, environment variables, and configuration files. The following sections provide technical details on key configuration options and library usage.

### Library Integration

For developers integrating `bat` into their Rust projects, the library can be included via Cargo. To minimize dependencies, default features can be disabled.

```toml
[dependencies]
bat = { version = "0.14", default-features = false }
```

This configuration allows library consumers to opt out of executable dependencies, paging, and Git support, which can be enabled separately if needed.

### Syntax Mapping

The `--map-syntax` flag allows users to associate specific file patterns with syntax definitions. This is particularly useful for files without standard extensions or for overriding default mappings. The syntax is glob-based, requiring users to update mappings when upgrading from earlier versions.

```bash
--map-syntax <glob-pattern>:<syntax-name>
```

Examples of usage include mapping a `.config` file to JSON syntax or mapping specific build files to their respective languages.

```bash
bat --map-syntax .config:json ...
```

### Configuration File Options

Configuration files, typically located at `~/.config/bat/config` on Linux and macOS, support TOML syntax. Users can define default options such as tab width, theme, and syntax mappings.

```toml
--tabs=4
--theme="Sublime Snazzy"

# A line-comment
--map-syntax .ignore:.gitignore
--map-syntax PKGBUILD:bash
--map-syntax Podfile:ruby

# Flags and options can also be on a single line:
--wrap=never --paging=never
```

These options can be combined to create a tailored viewing experience. For instance, disabling wrapping and paging can be useful for scripting or when viewing files in a specific context.

### Environment Variables

Several environment variables influence the behavior of `bat`. `BAT_CONFIG_PATH` specifies the location of the configuration file. `BAT_THEME` sets the default theme. `BAT_CACHE_PATH` allows customization of the cache directory. `BAT_STYLE` controls the output style. `BAT_TABS` sets the tab width. `BAT_OPTS` can be used to pass additional options. `PAGER` and `BAT_PAGER` control the paging behavior. `NO_COLOR` disables color output.

### Command-Line Flags

Key command-line flags include:

- `--diff`: Show Git-change neighborhoods.
- `--diff-context`: Specify the context size for diff view.
- `--file-name`: Display the file name in the output.
- `--generate-config-file`: Generate a default configuration file.
- `--force-colorization` (`-f`): Force color output.
- `-P`: Disable paging.
- `-A`: Display binary data.
- `-L`: List syntaxes.
- `-p`: Show theme previews or disable paging after plain style.
- `-u`: Enable underlining.
- `-n`: Enable line numbering.
- `--tabs`: Set tab width.
- `--theme`: Set the theme.
- `--map-syntax`: Map file patterns to syntaxes.
- `--wrap`: Set wrapping mode (always, never, auto).
- `--paging`: Set paging mode (auto, always, never).

### Performance and Compatibility

Performance improvements have been made in several versions, including faster cache startup and LTO support. Compatibility has been enhanced through support for various architectures (ARMv7, aarch64, armhf), operating systems (Windows, macOS, Linux), and package managers (Scoop, Chocolatey, Nix, Arch, Ubuntu, Debian, MacPorts, Gentoo, Alpine, Fedora).

### Syntax Highlighting Support

`bat` supports a wide range of syntaxes, including programming languages (Rust, C, C++, Java, Python, JavaScript, TypeScript, Go, Ruby, PHP, Swift, Kotlin, Elm, Nim, Vue, CoffeeScript, Julia, Dockerfile, VimL, CMake, INI, Less, F#, PureScript, Crystal, PowerShell, Dart, Cabal, JSX, TSX, CSV, Haskell, Elm, Kotlin, Puppet, TypeScript, Twig, assembly, log, Protobuf, Terraform, Jsonnet, Varlink, Org, requirements, .env, SSH, hosts, GraphQL, Verilog, SCSS, Sass, strace, Jinja2, SaltStack, fstab, group, passwd, proc, Rego, Stylo, Ansible, Robot, SML, Fortran, email, QML, AsciiDoc, GLSL, Nginx, Apache, crypttab, XDG Git, Markdown, LaTeX, TOML, YAML, JSON, XML, HTML, CSS, SQL, Bash, Zsh, Fish, PowerShell, Windows Batch, Makefile, CMake, VimL, Lua, Perl, R, Octave, MATLAB, Scala, Clojure, Groovy, Elixir, Erlang, Haskell, OCaml, F#, Rust, Go, Swift, Kotlin, Elm, Nim, Vue, CoffeeScript, Julia, Dockerfile, VimL, CMake, INI, Less, F#, PureScript, Crystal, PowerShell, Dart, Cabal, JSX, TSX, CSV, Haskell, Elm, Kotlin, Puppet, TypeScript, Twig, assembly, log, Protobuf, Terraform, Jsonnet, Varlink, Org, requirements, .env, SSH, hosts, GraphQL, Verilog, SCSS, Sass, strace, Jinja2, SaltStack, fstab, group, passwd, proc, Rego, Stylo, Ansible, Robot, SML, Fortran, email, QML, AsciiDoc, GLSL, Nginx, Apache, crypttab, XDG Git, Markdown, LaTeX, TOML, YAML, JSON, XML, HTML, CSS, SQL, Bash, Zsh, Fish, PowerShell, Windows Batch, Makefile, CMake).

### Themes

A variety of themes are available, including Solarized, Dracula, Nord, Gruvbox, base16, ansi-dark, ansi-light, OneHalf, Sublime Snazzy, Zenburn, and others. Users can browse and preview themes using the `-p` flag.

### Conclusion

The evolution of `bat` from version 0.1.0 to 0.16.0 demonstrates a commitment to performance, usability, and extensibility. The introduction of library APIs, comprehensive syntax support, and robust configuration options make `bat` a valuable tool for software developers. By adhering to standards such as NO_COLOR and supporting a wide range of platforms and package managers, `bat` ensures broad accessibility and integration within modern development workflows.
