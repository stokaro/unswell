# Highlight.js 10 Breaking Changes by Installation Path

Highlight.js version 10.0 is a major release that collects breaking changes held out of minor releases. The project defines a breaking change as any modification that could break a user's integration, although many users may not notice a practical difference. The complete VERSION_10_BREAKING_CHANGES.md file supplements this summary and provides additional comprehensive details.

## Core Client Users

Users including Highlight.js via client-side CDN or distribution package builds must address three essential changes. First, rename the darkula stylesheet from darkula.css to darcula.css to match updated naming conventions. Second, switch minified JavaScript filenames from the .pack.js suffix to the standard .min.js suffix now used throughout the project. Third, account for ES2015 code that drops support for very old browsers such as Internet Explorer 11. Applications requiring legacy browser compatibility should plan accordingly for this change.

Regarding HTML class names and highlighting behavior, only nohighlight and no-highlight classes skip highlighting completely. Classes containing text or plain no longer serve this purpose and their behavior has changed significantly. Update any HTML templates or code that relied on these class names to prevent highlighting.

## Client Users with Extra CDN Grammars

Users loading extra CDN grammars must check for renamed grammar files. For example, nimrod.js became nim.js. Review the complete CDN grammar list to identify all renamed grammars affecting your supported languages.

Version 9 CDN JavaScript language files are incompatible with version 10 and cannot be combined. All grammar files must be updated to version 10 simultaneously to maintain consistency. The core client-side changes described above also apply completely to projects using supplementary CDN grammars.

## Node.js Users

Node.js users of the full public API library through require('./highlight.js') may need no integration change. Users registering only selected languages must review grammar renames and dependency changes, along with the client-side changes if the project targets browser environments.

For server-only integrations using the complete Node API without client-side components, grammar renames represent the primary concern. Verify that selected languages exist under their new names and confirm that language dependencies have been updated accordingly.

## Direct Raw GitHub Source Use

Direct raw GitHub source use on the client no longer works without an appropriate build pipeline such as rollup. The source implementation now uses ES6 modules and a new build system and is expected to become more modular during the version 10 series.

Choose instead a static CDN build, cdn-release assets from GitHub releases, or the distribution npm package named in the source. Source-level custom integrations are outside the stability promise for npm and CDN builds and the public API.

Source consumers should inspect the complete breaking-changes documentation and possibly review commit history to understand architectural evolution. Questions and problems should be directed to GitHub issues.

## Custom Server Integrations

Custom server integrations beyond the public Node API require thorough review of the complete breaking-change list. The scope of changes to the codebase may affect proprietary server-side implementations that depend on internal implementation details.
