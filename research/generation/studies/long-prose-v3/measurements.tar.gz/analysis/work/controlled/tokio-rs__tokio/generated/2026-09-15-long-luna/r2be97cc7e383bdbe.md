# Tokio

Tokio is an asynchronous runtime for Rust applications that require event-driven, nonblocking I/O. It combines a multithreaded, work-stealing task scheduler with a reactor backed by operating-system event queues, including epoll, kqueue, and IOCP. It also provides asynchronous TCP and UDP sockets.

Rust’s ownership model, type system, and concurrency support help ensure thread safety. Tokio handles backpressure and cancellation, while its design aims to maintain low overhead and a small footprint.

## TCP echo server

The following example creates a TCP echo server. It binds to `127.0.0.1:8080`, accepts connections, and spawns an asynchronous task for each socket. Each task reads data into a buffer and writes the received bytes back to the client.

```rust,no_run
use tokio::net::TcpListener;
use tokio::prelude::*;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let mut listener = TcpListener::bind("127.0.0.1:8080").await?;

    loop {
        let (mut socket, _) = listener.accept().await?;

        tokio::spawn(async move {
            let mut buf = [0; 1024];

            // In a loop, read data from the socket and write the data back.
            loop {
                let n = match socket.read(&mut buf).await {
                    // socket closed
                    Ok(n) if n == 0 => return,
                    Ok(n) => n,
                    Err(e) => {
                        eprintln!("failed to read from socket; err = {:?}", e);
                        return;
                    }
                };

                // Write the data back
                if let Err(e) = socket.write_all(&buf[0..n]).await {
                    eprintln!("failed to write to socket; err = {:?}", e);
                    return;
                }
            }
        });
    }
}
```

Additional examples and the `mini-redis` project demonstrate larger applications. Feature-flag documentation lists optional components available for use.

## Related crates

Tokio is part of a broader collection of Rust networking and asynchronous libraries:

- `hyper` implements HTTP/1.1 and HTTP/2.
- `tonic` implements gRPC over HTTP/2.
- `warp` is a composable web framework.
- `tower` provides reusable networking-client and server components.
- `tracing`, formerly `tokio-trace`, provides application tracing and asynchronous diagnostics.
- `rdbc` supports MySQL, PostgreSQL, and SQLite connectivity.
- `mio` abstracts operating-system I/O and underlies Tokio.
- `bytes` supplies byte buffers and related utilities.
- `loom` tests concurrent Rust code.

## Support, versions, and license

Guides and API documentation provide help, along with Discord and GitHub discussions. A contribution guide explains how to participate.

Tokio builds against the latest stable Rust and supports Rust 1.45 or newer. Earlier Rust versions have no build guarantee.

Tokio uses the MIT license. Contributions intentionally submitted to the project inherit that license without additional terms unless the contributor explicitly states otherwise.
