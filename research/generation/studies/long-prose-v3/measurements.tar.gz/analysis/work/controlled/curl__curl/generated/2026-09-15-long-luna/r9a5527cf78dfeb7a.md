How curl Became Like This
=========================

Toward the end of 1996, Daniel Stenberg was spending time writing an IRC bot
for an Amiga-related channel on EFnet. He then came up with the idea of making
currency-exchange calculations available to Internet Relay Chat (IRC) users.
All the necessary data was published on the Web; he just needed to automate its
retrieval.

1996
----

Daniel adopted an existing command-line open-source tool, httpget, which
Brazilian Rafael Sagula had written and recently released as version 0.1.
After a few minor adjustments, it did exactly what he needed.

1997
----

HttpGet 1.0 was released on April 8, 1997, with brand-new HTTP proxy support.

We soon found and fixed support for retrieving currencies over GOPHER. Once FTP
download support was added, the name of the project was changed, and urlget 2.0
was released in August 1997. The HTTP-only days had already passed.

1998
----

The project slowly grew larger. When upload capabilities were added and the
name once again became misleading, a second name change was made. On March 20,
1998, curl 4 was released. The version numbering from the previous names was
kept.

(Unrelated to this project, a company called Curl Corporation registered a US
trademark for the name "CURL" on May 18, 1998. That company had already
registered the curl.com domain in November of the previous year. All this was
revealed to us much later.)

SSL support was added, powered by the SSLeay library.

August: First announcement of curl on freshmeat.net.

October: With the curl 4.9 release and the introduction of cookie support,
curl was no longer released under the GPL license. We were then at 4,000 lines
of code, and we switched to the MPL license to restrict the effects of
"copyleft."

November: A configure script and reports of successful compilation on several
major operating systems. The never-quite-understood -F option was added, and
curl could now simulate quite a lot of a browser. TELNET support was added.

Curl 5 was released in December 1998 and introduced curl's first man page.
People started making Linux RPM packages from it.

1999
----

January: DICT support was added.

OpenSSL took over, and SSLeay was abandoned.

May: First Debian package.

August: LDAP:// and FILE:// support were added. The curl website received
1,300 visits weekly. The site moved to curl.haxx.nu.

September: curl 6.0 was released. 15,000 lines of code.

December 28: The project was added to SourceForge, and we started using its
services to manage the project.

2000
----

Spring: A major internal overhaul provided a suitable library interface. The
first non-beta release was named 7.1 and arrived in August. It offered the
easy interface and marked the beginning of other software and programs being
based on and powered by libcurl. Almost 20,000 lines of code.

June: The curl site moved to "curl.haxx.se."

August: The curl website received 4,000 visits weekly.

The PHP developers adopted libcurl that same month, when the first-ever
third-party libcurl binding appeared. CURL has been a supported module in PHP
since the release of PHP 4.0.2. Others soon followed. More than 16 different
bindings existed at the time of this writing.

September: Kerberos 4 support was added.

November: Work began on a test suite for curl. It was later rewritten from
scratch. The libcurl major SONAME number was set to 1.

2001
----

January: Daniel released curl 7.5.2 under a new license: MIT (or MPL). The MIT
license is extremely liberal and can be combined with the GPL in other
projects. This finally ended the "complaints" from people involved in GPLed
projects who had previously been prohibited from using libcurl while it was
released under the MPL only. This was because the MPL is deemed "GPL
incompatible."

March 22: curl began supporting HTTP 1.1 with the release of 7.7. This also
introduced libcurl's ability to use persistent connections. 24,000 lines of
code. The libcurl major SONAME number was bumped to 2 because of this
overhaul. The first experimental ftps:// support was added.

August: curl was bundled in Mac OS X 10.1. It was increasingly becoming a
standard utility in Linux distributions and a regular part of the BSD ports
collections. The curl website received 8,000 visits weekly. Curl Corporation
contacted Daniel to discuss "the name issue." After Daniel's reply, they never
got back in touch.

September: libcurl 7.9 introduced the cookie jar and curl_formadd(). During
the forthcoming 7.9.x releases, we slowly introduced the multi interface
without much fanfare.

2002
----

June: The curl website received 13,000 visits weekly. curl and libcurl totaled
35,000 lines of code. Successful compilation was reported on more than 40
combinations of CPUs and operating systems.

Estimating the number of users of the curl tool or libcurl library is nearly
impossible. About 5,000 packages downloaded each week from the main site gives
a hint, but the packages are mirrored extensively, bundled with numerous OS
distributions, and otherwise retrieved as part of other software.

October 1: With the release of curl 7.10, it was released under the MIT license
only.

Starting with 7.10, curl verified SSL server certificates by default.

2003
----

January: Work began on the distributed curl tests, the autobuilds.

February: The curl site averaged 20,000 visits weekly. At any given moment,
an average of three people were browsing the website.

Multiple new authentication schemes were supported: Digest (May), NTLM
(June), and Negotiate (June).

November: curl 7.10.8 was released. 45,000 lines of code. Approximately
55,000 unique visitors to the website. Five official web mirrors.

December: Full-fledged SSL for FTP was supported.

2004
----

January: curl 7.11.0 introduced large-file support.

June: curl 7.12.0 introduced IDN support. Ten official web mirrors.

This release bumped the major SONAME to 3 because of the removal of the
curl_formparse() function.

August: curl and libcurl 7.12.1

    Public curl release number:                82
    Releases counted from the very beginning: 109
    Available command-line options:            96
    Available curl_easy_setopt() options:     120
    Number of public functions in libcurl:     36
    Number of public website mirrors:         12
    Number of known libcurl bindings:          26

2005
----

April: GnuTLS could now optionally be used for the secure layer when curl was
built.

April: The multi_socket() API was added.

September: TFTP support was added.

The curl website had more than 100,000 unique visitors. There were 25 mirrors.

December: Security vulnerability: libcurl URL buffer overflow.

2006
----

January: We dropped support for Gopher. We found bugs in the implementation
that had been introduced years earlier. Since nobody had found them in all
that time, we removed Gopher instead of fixing it.

March: Security vulnerability: libcurl TFTP packet buffer overflow.

September: The major SONAME number for libcurl was bumped to 4 because of the
removal of third-party FTP transfer support.

November: SCP and SFTP support were added.

2007
----

February: Support was added for the Mozilla NSS library to handle SSL/TLS.

July: Security vulnerability: libcurl GnuTLS insufficient certificate
verification.

2008
----

November:

    Command-line options:         128
    curl_easy_setopt() options:   158
    Public functions in libcurl:   58
    Known libcurl bindings:        37
    Contributors:                 683

145,000 unique visitors. More than 100 GB downloaded.

2009
----

March: Security vulnerability: libcurl arbitrary file access.

April: CMake support was added.

August: Security vulnerability: libcurl embedded zero in certificate name.

December: Support was added for IMAP, POP3, and SMTP.

2010
----

January: Support was added for RTSP.

February: Security vulnerability: libcurl data callback excessive length.

March: The project switched to Git, hosted by GitHub, instead of CVS for
source-code control.

May: Support was added for RTMP.

Support was added for PolarSSL to handle SSL/TLS.

August:

    Public curl releases:         117
    Command-line options:         138
    curl_easy_setopt() options:   180
    Public functions in libcurl:   58
    Known libcurl bindings:        39
    Contributors:                 808

Gopher support was added—re-added, actually; see January 2006.

2011
----

February: Support was added for the axTLS backend.

April: The cyassl backend was added; it was later renamed WolfSSL.

2012
----

July: Support was added for Schannel, the native Windows TLS backend, and
Darwin SSL, the native Mac OS X and iOS TLS backend.

Metalink support was added.

October: SSH-agent support was added.

2013
----

February: The internals were cleaned up to always use the "multi"
non-blocking approach internally, exposing the blocking API only through a
wrapper.

September: The first small steps toward supporting HTTP/2 with nghttp2 were
taken.

October: Kerberos 4 support was removed.

December: Happy Eyeballs support was added.

2014
----

March: The first release with real HTTP/2 support.

September: The website had 245,000 unique visitors and served 236 GB of data.

SMB and SMBS support was added.

2015
----

June: Support for multiplexing with HTTP/2 was added.

August: Support for HTTP/2 server push was added.

December: The Public Suffix List was added.

2016
----

January: The curl tool defaulted to HTTP/2 for HTTPS URLs.

December: curl 7.52.0 introduced support for HTTPS proxies.

The first TLS 1.3 support was added.

2017
----

July: OSS-Fuzz started fuzzing libcurl.

September: Multi-SSL support was added.

The website served 3,100 GB per month.

    Public curl releases:         169
    Command-line options:         211
    curl_easy_setopt() options:   249
    Public functions in libcurl:  74
    Contributors:                 1609

October: SSLKEYLOGFILE support and a new MIME API were added.

October: Daniel received the Polhem Prize for his work on curl.

November: Brotli support was added.

2018
----

January: A new SSH backend powered by libssh was added.

March: Starting with the 1803 release of Windows 10, curl was shipped bundled
with Microsoft's operating system.

July: curl began showing headers in bold type.

October: DNS-over-HTTPS (DoH) and the URL API were added.

MesaLink became a supported TLS backend.

libcurl began using HTTP/2, including multiplexing, by default on HTTPS URLs.

curl and libcurl were installed in an estimated 5 *billion* instances
worldwide.

October 31: curl and libcurl 7.62.0

    Public curl releases:         177
    Command-line options:         219
    curl_easy_setopt() options:   261
    Public functions in libcurl:  80
    Contributors:                 1808

December: axTLS support was removed.

2019
----

March: Experimental alt-svc support was added.

August: The first HTTP/3 requests were made with curl.

September: 7.66.0 was released, and the tool offered parallel downloads.

2020
----

curl and libcurl were installed in an estimated 10 *billion* instances
worldwide.

January: BearSSL support was added.

March: PolarSSL support was removed, and wolfSSH support was added.

April: Experimental MQTT support was added.

August: zstd support was added.

November: The website moved to www.curl.se. The website served 10 TB of data
monthly.
