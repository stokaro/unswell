# Operational Configuration

Containerd’s operational settings are primarily stored in `/etc/containerd/config.toml`. The daemon can use a different configuration path at startup with `--config` or `-c`. Its command-line options also include logging level, the gRPC server address, and the root directory.

The available logging levels are `debug`, `info`, `warn`, `error`, `fatal`, and `panic`. The command-line interface identifies the configuration file with a default of `/etc/containerd/config.toml`:

```text
--config value, -c value     path to the configuration file (default: "/etc/containerd/config.toml")
--log-level value, -l value  set the logging level [debug, info, warn, error, fatal, panic]
--address value, -a value    address for containerd's GRPC server
--root value                 containerd root directory
```

Most operational and plugin-specific settings belong in the configuration file rather than in daemon flags. Plugin settings are typed and use sections named `[plugins.<name>]`. Operators must consult the documentation for the relevant plugin when configuring these sections. Snapshotters, runtimes, content services, and other containerd functions are registered as plugins.

## Running containerd with systemd

A systemd service should delegate cgroup management to containerd and its runtimes:

```systemd
[Unit]
Description=containerd container runtime
Documentation=https://containerd.io
After=network.target

[Service]
ExecStartPre=-/sbin/modprobe overlay
ExecStart=/usr/local/bin/containerd
Delegate=yes
KillMode=process

[Install]
WantedBy=multi-user.target
```

`Delegate=yes` allows containerd and its runtimes to manage the cgroups associated with containers. Without delegation, systemd may move processes into its own cgroups, disrupting resource accounting.

`KillMode=process` limits service shutdown to the containerd daemon. This allows shims and containers to survive an upgrade. The default whole-cgroup termination behavior would also kill those processes. The example loads the `overlay` module before starting `/usr/local/bin/containerd` and orders the service after `network.target`.

A systemd-run invocation can provide the same service properties directly:

```text
sudo systemd-run -p Delegate=yes -p KillMode=process /usr/local/bin/containerd
```

The sample configuration also sets `oom_score` to `-999`:

```toml
oom_score = -999
```

This means containers should be selected before the containerd daemon under memory pressure. The daemon is prioritized, but it is not made unkillable.

## Persistent and ephemeral storage

Containerd separates persistent plugin storage from ephemeral runtime state:

```toml
# persistent data location
root = "/var/lib/containerd"
# runtime state information
state = "/run/containerd"
```

The `root` directory stores content, snapshots, image and container metadata, and other persistent plugin data. The `state` directory stores sockets, process IDs, mount points, and runtime state that must not survive a reboot. Both directories are namespaced by plugin. Containerd’s core persistent functionality comes from its plugins.

A persistent storage layout can include content, metadata, runtime, and snapshotter plugin directories:

```text
/var/lib/containerd/
├── io.containerd.content.v1.content
│   ├── blobs
│   └── ingest
├── io.containerd.metadata.v1.bolt
│   └── meta.db
├── io.containerd.runtime.v1.linux
│   ├── default
│   └── example
├── io.containerd.snapshotter.v1.btrfs
└── io.containerd.snapshotter.v1.overlayfs
    ├── metadata.db
    └── snapshots
```

Ephemeral state can contain daemon sockets and runtime-specific process data:

```text
/run/containerd
├── containerd.sock
├── debug.sock
├── io.containerd.runtime.v1.linux
│   └── default
│       └── redis
│           ├── config.json
│           ├── init.pid
│           ├── log.json
│           └── rootfs
└── runc
    └── default
        └── redis
            └── state.json
```

These storage directories are implementation details. External applications must not modify them. Even watching or reading them has caused `EBUSY` errors and stale file handles during cleanup.

## Sockets, logging, metrics, and runtime settings

The sample gRPC configuration uses `/run/containerd/containerd.sock`. The debug socket is `/run/containerd/debug.sock`. Both sockets use UID and GID zero:

```toml
[grpc]
  address = "/run/containerd/containerd.sock"
  uid = 0
  gid = 0

[debug]
  address = "/run/containerd/debug.sock"
  uid = 0
  gid = 0
  level = "info"
```

Daemon and container metrics use Prometheus format. In this configuration, Prometheus support requires a TCP metrics endpoint:

```toml
[metrics]
  address = "127.0.0.1:1234"
```

Linux runtime settings are configured through the plugin section:

```toml
[plugins.linux]
	shim = ""
	runtime = "runc"
	no_shim = false
	shim_debug = true
```

The `shim` and `runtime` values supply binary names or paths. The example selects `runc`, keeps shims enabled, and enables shim debugging. Setting `no_shim = true` saves memory when starting containers, but live restore is not supported. With `shim_debug = true`, shim logs are included in the containerd daemon’s log output.

## Bolt content sharing

The Bolt metadata plugin defaults to shared content. After a blob exists in any namespace, another namespace can reuse it by opening a writer with its expected digest. Shared content reduces bandwidth, but knowledge of a digest alone permits blob access.

The alternative `isolated` policy requires all content to be submitted before it enters the namespace, demonstrating access. The two policies still share the same backing storage. Select the isolated policy with:

```toml
[plugins.bolt]
	content_sharing_policy = "isolated"
```
