# Highlight.js 10 Breaking Changes by Integration Path

Highlight.js 10.0 is a major release that collects changes held out of earlier minor releases. The project defines a breaking change as any change that could break a user’s integration, even when many users do not notice a difference. This summary covers the main installation and integration paths. The complete `VERSION_10_BREAKING_CHANGES.md` file provides the full list and supplements this overview.

## Core client users

If your client integration uses the core Highlight.js files, make these changes:

- Rename `darkula.css` to `darcula.css`.
- Change references to minified JavaScript files from the `.pack.js` naming convention to `.min.js`.
- Account for the use of ES2015 code. Very old browsers, including IE11, are no longer supported by this code.

To disable highlighting completely, use only the `nohighlight` or `no-highlight` classes. Classes that contain `text` or `plain` no longer disable highlighting and should not be used for this purpose.

## Client users loading additional CDN grammars

Client integrations that load extra language grammars from a CDN must review grammar filenames for renames. For example, `nimrod.js` is now `nim.js`.

Version 9 CDN JavaScript language files are incompatible with version 10. Do not combine those files with a version-10 core installation. The core-client changes also apply to integrations that load additional CDN grammars, so review stylesheet names, minified filenames, browser requirements, and highlighting-disable classes in those integrations as well.

## Node users

Node users of the full public API library through `require('./highlight.js')` may not need to change their integration.

If your Node integration registers only selected languages, review grammar renames and dependency changes. The client-side changes also apply where relevant. Custom server integrations require review of the complete breaking-change list because this summary does not cover all custom integration behavior.

## Direct raw GitHub source use

Using direct raw GitHub source files on the client no longer works without an appropriate build pipeline, such as Rollup. Instead, choose a static CDN build, the `cdn-release` assets, or the distribution npm package named in the source.

Source-level custom integrations are outside the stability promise provided for npm and CDN builds and the public API. If your integration consumes the implementation source directly, treat it as a custom integration and inspect the complete version-10 changes before upgrading.

## Source implementation changes

The source implementation now uses ES6 modules and a new build system. It is also expected to become more modular during the version-10 series. Consumers of the source should inspect the breaking changes and may also need to review the project’s commit history to understand impacts on their integration.

When the documented changes do not answer a question or a problem appears during migration, use GitHub issues for questions and problem reports. Review the complete `VERSION_10_BREAKING_CHANGES.md` file before finalizing an upgrade, especially for selected-language Node integrations, custom server integrations, and source-level integrations.
