# bat Documentation and Release History Through v0.16.0

## Overview

This document records bat’s command-line interface, syntax support, library API, packaging, configuration, performance, and compatibility changes through version 0.16.0. It describes the progression from the initial release through the additions, fixes, and changes in each documented version.

bat began with version 0.1.0. Version 0.2.0 added custom syntax support and extended Markdown support, and fixed Git markers for files in child directories. Version 0.2.1 added Elixir support and changed the libcurl backend. Version 0.2.2 removed OpenSSL. Version 0.2.3 provided statically linked MUSL binaries.

Version 0.3.0 introduced automatic less integration, standard input support, redirected output, color modes, language listing and language selection, output styles, and TOML support. The `cache` command replaced `init-cache`. Git context was derived from the input path, and process substitution worked.

Version 0.4.0 added wrapping, styles, themes, Julia, Dockerfile, VimL, CMake, INI, and Less syntax support. It added bold, italic, and underline styles, 32-bit support, `-u`, `-n`, and ANSI support on Windows 10. The custom syntax directory was renamed to `syntaxes`. Markdown began using the Sublime default. Syntax listings were sorted, and flags could override earlier copies.

Version 0.4.0 also fixed issues involving tiny terminals, filename detection, invalid UTF-8, errors, Unicode handling in less, and nightly builds. Tests, the logo, alternatives, and refactoring were added. Version 0.4.1 fixed tests that ran outside a Git checkout.

## Version 0.5.0

Version 0.5.0 added line ranges, `BAT_THEME`, `PAGER`, and `BAT_PAGER`. It added Nix and AWK syntax support, independent additive syntax and theme sets, and theme-based gutter colors.

The release fixed escape stripping, isolated Git snapshot tests, and Markdown and JavaScript behavior. ARMv7 releases and Arch packaging were added. Color conversion was improved.

The independent additive syntax and theme sets allowed custom additions without replacing the existing sets. Theme-based gutter colors made the gutter color part of the selected theme.

## Version 0.6.0 and v0.6.1

Version 0.6.0 added theme previews and the `-p` option. Redirected output preserved exact bytes. Elm, Kotlin, Puppet, and TypeScript syntax were added, along with the Zenburn theme.

Custom themes became additive and no longer required a `Default` symlink. Cache deduplication was fixed. The first man page was added, together with development and troubleshooting documentation.

Version 0.6.1 fixed `list-languages` when its output was piped to `head`. Color settings were honored in language lists. Windows Git markers were enabled, and automated Windows releases began.

## Version 0.7.0 and v0.7.1

Version 0.7.0 added tab configuration and `BAT_TABS`, the `BAT_STYLE` environment variable, and the OneHalf theme. It added CSV, JSX, TSX, Cabal, Dart, F#, PureScript, Swift, Crystal, and PowerShell syntax support.

Git queries became conditional. Plain mode no longer wrapped output. The release fixed cache-named files, Windows and less detection, decorations when `wrapnever` was selected, and directory headers.

Builds for `aarch64` and `armhf` were added, as was Scoop distribution.

Version 0.7.1 improved eight-bit color approximation. It fixed a Haskell panic and plain-mode wrapping. Ansible and Cygwin instructions were added.

## Version 0.8.0

Version 0.8.0 introduced argument-list configuration, the Linux `~/.config/bat/config` location, `--config-file`, `BAT_OPTS` precedence, custom syntax mappings, pager arguments, Windows wildcards, first-line language detection, UTF-16LE and UTF-16BE support, and Robot syntax.

An argument-list configuration can contain options in the same form used on the command line. For example:

```bash
--tabs=4
--theme="Sublime Snazzy"

# A line-comment
--map-syntax .ignore:.gitignore
--map-syntax PKGBUILD:bash
--map-syntax Podfile:ruby

# Flags and options can also be on a single line:
--wrap=never --paging=never
```

Custom syntax mappings use a glob pattern and syntax name:

```bash
--map-syntax <glob-pattern>:<syntax-name>
```

A mapping can associate a filename pattern with a syntax. For example:

``` bash
bat --map-syntax .config:json ...
```

The `BAT_OPTS` environment variable participates in option precedence. The release added support for pager arguments, Windows wildcards, first-line detection, UTF-16LE and UTF-16BE input, and Robot files.

Interactive binary files were detected and suppressed. JavaDoc and Haskell highlighting were fixed. Build-generated completions and additional tests were added. Distribution through Termux, Nix, and Docker followed this release.

## Version 0.9.0

Version 0.9.0 added show-all, pager support, `BAT_CONFIG_PATH`, repeated style options, repeated line-range options, and terminal-width offsets. Italics became opt-in, and tabs defaulted to four spaces. The Sublime Snazzy theme was added.

Completions stopped shipping. bat prevented recursion when `PAGER=bat`. openSUSE and Chinese documentation were added. Tab handling and integration tests were improved.

## Version 0.10.0

Version 0.10.0 added `highlight-line`. On macOS, configuration moved from `~/Library/Preferences/bat` to `~/.config/bat`; users must copy their configuration to the new location.

Completion generation was disabled. less flags were improved. Missing-file errors and pager behavior for nonexistent files were improved. The cache command `--init` was renamed to `--build`, and hidden configuration and cache-directory flags were relocated.

The release fixed trailing plain lines and repeated end-of-file behavior for standard input. New syntaxes included Twig, desktop files, AsciiDoc, assembly, log files, Protobuf, Terraform, Jsonnet, and Varlink. A Japanese README was added.

## Version 0.11.0

Version 0.11.0 added the `ansi-light`, `ansi-dark`, and `base16` themes. It added handwritten Fish completion and allowed double `-p` to disable paging after plain style had been selected.

Explicit less arguments were preserved. Interactive binary inputs generated a warning. Headers for empty files were restored. A terminal width of zero was rejected. Cache-file ambiguity was fixed, and additional tests were added.

The project adopted Rust 2018. F# and Fish syntax were updated. Chocolatey packaging was added.

## Version 0.12.0 and v0.12.1

Version 0.12.0 allowed `-A` to display binary data. It added man-pager use, separators between line ranges, and `-L`.

The release fixed grid balancing, files named like cache entries, absent cache directories, and parsing of negative terminal-width values. Fish completion entered DEB packages.

New syntaxes included Org, requirements files, `.env`, SSH configuration, hosts files, GraphQL, Verilog, SCSS, Sass, and strace. Gentoo, Alpine, and Fedora packaging was recorded.

Version 0.12.1 fixed `CreateFile2` failures on older Windows versions.

## Version 0.13.0

Version 0.13.0 first exposed bat as a library. The initial library documentation was incomplete, and API changes were likely. A new library API was therefore introduced with that limitation in mind.

The glob-based `--map-syntax` option was a breaking change. Existing mappings had to be updated to use the new form:

```bash
--map-syntax <glob-pattern>:<syntax-name>
```

The release added highlight-line ranges, wide-Unicode wrapping, `BAT_CACHE_PATH`, and combining styles. It fixed behavior for new-less and no-init operation, cache-command precedence, Scala `.sc` files, man names containing underscores or dashes, empty lines, redirected wrapping, non-Unicode filenames, empty-file grids, and build-file shebangs.

Man-page and completion names became parameterized. Link-time optimization was enabled, with a reported speedup of roughly ten percent. Documentation was added for macOS themes, integrations, encodings, and Windows. The default theme became an accepted value.

Jinja2, SaltStack, fstab, group, passwd, proc files, Nim, Vue, and CoffeeScript syntax were added. The Dracula, Nord, and Solarized themes were added.

Ubuntu and Debian packages became available. MacPorts packaging was recorded. Fish completions used `vendor_completions.d`. eth-p joined maintenance.

## Version 0.14.0

Version 0.14.0 added `--file-name` and `--generate-config-file`. It repaired performance for C# and Makefile highlighting, Ruby heredocs, Rust syntax, disappearing short output on Windows, and `highlight-line` when tabs were zero or wrapping was disabled.

Cache `metadata.yaml` began recording version compatibility. Incompatible cache assets were rejected.

A new high-level library API was recommended, although it was still beta. The low-level library API was refactored. The default application feature included executable dependencies. Library consumers could disable that feature. Paging and Git were separate optional features, and older syntect support was available.

Rego and Stylo syntax were added.

Library consumers can disable the default application feature with a dependency declaration such as:

```toml
[dependencies]
bat = { version = "0.14", default-features = false }
```

This separates application defaults from library use. Paging and Git remain separately optional features.

## Version 0.15.0

Version 0.15.0 added `--diff` and its short form `-d`, together with `--diff-context`. These options show neighborhoods around Git changes.

The release fixed interleaved file errors. Startup with a custom cache was reported to be roughly twice as fast. Solarized themes were updated.

Low-level configuration and error-handler APIs changed. One change involved a mutable writer argument. The high-level API was unaffected.

## Version 0.15.1

Version 0.15.1 fixed Markdown and base16 behavior. It added Fortran, email, and QML syntax support.

The `ansi-dark` and `ansi-light` themes were suggested for Windows SSH palette problems.

## Version 0.15.2

Version 0.15.2 fixed syntax mapping for Rails files, symbolic links, and file names. It added header padding without grids and errors for invalid syntax.

`vcs_modification_markers` was deprecated when Git was unavailable.

The Syntect 4.2 and onig combination removed the bindgen and libclang build requirement.

## Version 0.15.3

Version 0.15.3 fixed relative paths and SSH users whose names began with digits. Standard ML syntax was added.

## Version 0.15.4

Version 0.15.4 restored the Solarized themes and fixed Haskell highlighting.

## Version 0.16.0

Version 0.16.0 adds `NO_COLOR`, `-P` for no paging, and `--force-colorization`, with `-f` as its short form.

The release fixes display of redirected nonprinting content and conflicts between language extensions. Spaces are represented with U+00B7. Zsh completion, help, and man-page guidance were added.

Syntax support was updated for AsciiDoc, GLSL, Nginx and Apache configuration files, crypttab through fstab, and XDG Git configuration. The Gruvbox and base16-256 themes were added.

The library API adds `InputDescription` and direct `PrettyPrinter` inputs. `Input::theme_preview_file` was removed. The `liquid` build dependency was removed.

## Command-Line and Environment Configuration

Across these releases, bat’s configuration expanded from individual command-line options to environment variables, configuration files, syntax mappings, themes, and pager settings.

`BAT_THEME` selects a theme. `BAT_STYLE` selects output styles. `BAT_TABS` controls tab handling. `BAT_CONFIG_PATH` identifies configuration. `BAT_CACHE_PATH` identifies the cache location. `BAT_OPTS` supplies options, and its precedence is documented with argument-list configuration.

`PAGER` and `BAT_PAGER` configure paging. bat prevents recursion when `PAGER=bat`. Pager arguments can be configured, explicit less arguments are preserved, and paging can be disabled with the documented paging options. Version 0.16.0 adds `-P` for no paging. Version 0.11.0 supports double `-p` to disable paging after plain style. The configuration examples include:

```bash
--wrap=never --paging=never
```

Version 0.10.0 moved cache initialization from `--init` to `--build`. Version 0.14.0 added `--generate-config-file`. Version 0.8.0 added `--config-file`, and version 0.10.0 relocated hidden configuration and cache-directory flags.

On macOS, the configuration path changed from `~/Library/Preferences/bat` to `~/.config/bat`. Existing users must copy their configuration. Linux configuration uses `~/.config/bat/config`.

## Syntax Mapping and Detection

Custom syntax support began in version 0.2.0 and was expanded through configuration-file and command-line mappings. Version 0.8.0 introduced custom syntax mappings based on patterns. Version 0.13.0 made the glob-based form breaking, requiring mappings to be updated.

The mapping syntax is:

```bash
--map-syntax <glob-pattern>:<syntax-name>
```

Examples include:

```bash
--map-syntax .ignore:.gitignore
--map-syntax PKGBUILD:bash
--map-syntax Podfile:ruby
```

A direct command-line mapping can be used as follows:

``` bash
bat --map-syntax .config:json ...
```

Syntax detection also uses file names, extensions, and first-line detection. Version 0.15.3 fixed relative paths. Version 0.16.0 fixed conflicts between language extensions. Version 0.10.0 added many syntax definitions, and later releases continued adding and updating language and configuration formats.

## Output, Wrapping, and Color

bat supports automatic paging, redirected output, plain output, themes, styles, wrapping, line ranges, highlighted lines, and multiple color modes.

Version 0.3.0 introduced color modes and redirected output. Version 0.6.0 made redirected output preserve exact bytes. Version 0.7.0 disabled wrapping in plain mode. Version 0.13.0 added wide-Unicode wrapping and fixed redirected wrapping. Version 0.16.0 fixes redirected display of nonprinting content and uses U+00B7 for spaces.

Tabs default to four spaces from version 0.9.0. Tab configuration was added earlier through `BAT_TABS`. Version 0.14.0 fixed `highlight-line` with tabs set to zero and wrapping disabled.

Line ranges were added in version 0.5.0 and can be repeated. Version 0.12.0 added separators between line ranges. Version 0.13.0 added highlight-line ranges. Version 0.10.0 introduced `highlight-line`.

Themes include OneHalf, Zenburn, Sublime Snazzy, Dracula, Nord, Solarized, Gruvbox, base16, and base16-256. Version 0.15.4 restored Solarized themes. Version 0.15.1 suggested ansi-dark and ansi-light for Windows SSH palette problems. Version 0.11.0 added ansi-light, ansi-dark, and base16. Version 0.16.0 added Gruvbox and base16-256.

Version 0.4.0 added bold, italic, and underline. Italics became opt-in in version 0.9.0. Version 0.5.0 added theme-based gutter colors. Version 0.13.0 added combining styles.

## Library API

bat first became available as a library in version 0.13.0. The release acknowledged missing documentation and likely API changes. Version 0.14.0 introduced a recommended high-level API, still beta, and refactored the low-level API. The high-level API remained unaffected by the low-level changes in version 0.15.0.

Version 0.14.0 separated application defaults from library use. The default application feature includes executable dependencies. Library consumers can disable default features:

```toml
[dependencies]
bat = { version = "0.14", default-features = false }
```

Paging and Git are separate optional features. Older syntect support is also available.

Version 0.16.0 adds `InputDescription` and allows direct `PrettyPrinter` inputs. It removes `Input::theme_preview_file`. The `liquid` build dependency is removed.

## Cache and Compatibility

The `cache` command replaced `init-cache` in version 0.3.0. Version 0.10.0 renamed cache `--init` to `--build`. Cache-command precedence was fixed in version 0.13.0.

Cache-named files, cache-file ambiguity, absent cache directories, and cache deduplication were fixed in various releases. Version 0.14.0 added compatibility metadata to `metadata.yaml`. Cache assets whose versions are incompatible are rejected.

Version 0.15.0 reported roughly twice-fast startup for a custom cache. These changes preserve cache correctness while improving startup and handling of cache paths and assets.

## Packaging and Distribution

MUSL static binaries were added in version 0.2.3. Version 0.4.0 added 32-bit support and nightly builds. Version 0.6.1 began automated Windows releases. Version 0.7.0 added `aarch64` and `armhf` builds and Scoop. Version 0.9.0 added openSUSE documentation. Version 0.12.0 recorded Gentoo, Alpine, and Fedora packaging.

Ubuntu and Debian packages and MacPorts packaging were recorded in version 0.13.0. Fish completions used `vendor_completions.d`. Version 0.8.0 added Termux, Nix, and Docker distribution. Version 0.5.0 added ARMv7 releases and Arch packaging. Version 0.11.0 added Chocolatey.

Completion behavior changed over time. Version 0.8.0 added build-generated completions. Version 0.9.0 stopped shipping completions. Version 0.10.0 disabled completion generation. Version 0.11.0 added handwritten Fish completion. Version 0.13.0 parameterized man and completion names and used Fish’s `vendor_completions.d`. Version 0.16.0 added Zsh completion, help, and man guidance.

## Build and Maintenance Changes

Version 0.11.0 adopted Rust 2018. Version 0.13.0 enabled link-time optimization and reported a roughly ten percent speedup. Version 0.14.0 removed the application’s executable dependencies from library use through feature control. Version 0.15.2 removed the bindgen and libclang build requirement through Syntect 4.2 and onig. Version 0.16.0 removed the `liquid` build dependency.

The project added tests throughout the release history, including tests for cache behavior, integration behavior, color settings, isolated Git snapshots, Windows behavior, wrapping, and file handling. Performance repairs included C#, Makefile, and custom-cache startup behavior.

The result through version 0.16.0 is a command-line application with configurable syntax detection, themes, styles, wrapping, paging, Git-aware output, cache management, and broad packaging support, together with a library API whose high-level interface is recommended while remaining subject to the documented beta status and ongoing API changes.
