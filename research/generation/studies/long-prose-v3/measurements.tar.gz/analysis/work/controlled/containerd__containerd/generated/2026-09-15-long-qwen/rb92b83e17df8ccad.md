# Operational Configuration of the containerd Daemon

The containerd daemon is a high-performance container runtime that manages the lifecycle of containers, images, and storage. Its operational behavior is primarily controlled through configuration files, command-line flags, and integration with system initialization services. This documentation outlines the configuration of the daemon, systemd integration, storage architecture, and plugin settings.

## Daemon Configuration and CLI Flags

Most containerd settings reside in the configuration file located at `/etc/containerd/config.toml`. The path to this configuration file can be altered at daemon startup using the `--config` or `-c` flag. In addition to the configuration file, the daemon accepts various CLI flags to adjust runtime behavior. The help output for containerd lists several global options, including `--log-level` (or `-l`) to set the logging verbosity. Supported logging levels are `debug`, `info`, `warn`, `error`, `fatal`, and `panic`. Other global options include `--address` (or `-a`) to specify the gRPC server address and `--root` to define the root directory for persistent data.

The daemon version provided in the reference material is `v1.0.0-alpha3-36-ge9b86af`. The command-line interface supports commands such as `config` for configuration information and `help` for usage details.

## Systemd Service Integration

Integrating containerd with systemd requires specific service configurations to ensure proper resource management and process isolation. The provided systemd unit file demonstrates these requirements. The service description is set to "containerd container runtime" with documentation linked to the official website. The service is ordered to start after `network.target` to ensure network availability.

A critical setting in the `[Service]` section is `Delegate=yes`. This directive allows containerd and its associated runtimes to manage container cgroups directly. Without delegation, systemd might move processes into its own cgroups, which can disrupt resource accounting and control. Additionally, the `ExecStartPre` command loads the `overlay` kernel module before the daemon starts, ensuring the overlay storage driver is available.

The `KillMode=process` setting is essential for maintaining stability during updates or shutdowns. This configuration limits the shutdown signal to the containerd daemon process only. This allows shims and running containers to survive the daemon restart, facilitating live restore capabilities. Without this setting, the default `whole-cgroup` termination mode would kill all processes in the cgroup, including the containers themselves.

For environments not using a static unit file, `systemd-run` provides an alternative method to start the daemon with these parameters. The command `sudo systemd-run -p Delegate=yes -p KillMode=process /usr/local/bin/containerd` achieves the same result dynamically. Furthermore, the configuration sets the OOM score to `-999` via the `oom_score` option. This ensures that under memory pressure, the system selects containers for termination before the containerd daemon, but does not make the daemon unkillable.

## Storage Architecture

Containerd utilizes two primary directories for data storage, both of which are namespaced by plugin. The `root` directory is designated for persistent plugin storage. It holds content, snapshots, image and container metadata, and other plugin-specific data. The default path is `/var/lib/containerd`. The `state` directory is reserved for ephemeral storage, including sockets, process IDs, mount points, and runtime state. This data must not survive a reboot. The default path is `/run/containerd`.

The directory structure reflects the plugin-based architecture. Under `root`, directories such as `io.containerd.content.v1.content`, `io.containerd.metadata.v1.bolt`, and snapshotter directories like `io.containerd.snapshotter.v1.overlayfs` exist. Under `state`, sockets such as `containerd.sock` and `debug.sock` are located, along with runtime state directories for specific containers.

These storage directories are implementation details. External applications must not modify them. Even reading or watching these directories can cause `EBUSY` errors and stale file handles during cleanup operations. Operators should interact with containerd exclusively through its API or CLI.

## gRPC, Debug, and Metrics Configuration

The daemon exposes interfaces via Unix sockets and TCP endpoints. The gRPC configuration specifies the address for the containerd server, defaulting to `/run/containerd/containerd.sock`. The socket UID and GID are set to zero. Similarly, the debug socket is configured at `/run/containerd/debug.sock`, also with UID and GID zero. The debug level is set to `info`.

For monitoring, the daemon supports Prometheus metrics. The configuration requires a TCP metrics endpoint. The example sets the metrics address to `127.0.0.1:1234`. This TCP endpoint is required for Prometheus support in this snapshot.

## Plugin Configuration

Plugin-specific settings are defined in the configuration file using the `[plugins.<name>]` syntax. These settings cannot be controlled via CLI flags. Operators must consult individual plugin documentation for detailed options.

The Linux runtime plugin example configures the shim and runtime binaries. The `runtime` is set to `runc`. The `no_shim` option is set to `false` by default. Enabling `no_shim` saves memory by avoiding the shim process, but it removes live restore support. The `shim_debug` option is set to `true` to include shim logs in the daemon's output.

The Bolt metadata plugin manages content sharing between namespaces. By default, it uses a `shared` content sharing policy. In shared mode, once a blob exists in any namespace, other namespaces can reuse it by opening a writer with the expected digest. This reduces bandwidth usage but allows blob access based on digest knowledge alone. To enforce isolation, the `content_sharing_policy` can be set to `isolated`. In isolated mode, all content must be submitted before it enters a namespace, demonstrating strict access control. Both modes share the same backing storage. The configuration snippet `[plugins.bolt] content_sharing_policy = "isolated"` demonstrates how to select the isolated policy.
