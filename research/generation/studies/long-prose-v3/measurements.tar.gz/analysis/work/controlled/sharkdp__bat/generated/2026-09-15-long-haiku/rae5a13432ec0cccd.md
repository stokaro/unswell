# unreleased

## Features

## Bugfixes

## Other

## Syntaxes

## New themes

## `bat` as a library

## Packaging

# v0.16.0

## Features

- Added support for the `NO_COLOR` environment variable, see #1021 and #1031 (@eth-p)
- Added `-P` short flag to disable paging, see #1075 and #1082 (@LordFlashmeow)
- Added `--force-colorization`/`-f` flag to force color and decoration output, see #1141 (@alexanderkarlis)

## Bugfixes

- Fixed display of non-printable characters for redirected output, see #1061 (@gsomix)
- Handle file extension conflicts in `--list-languages`, see #1076 and #1135 (@Kienyew)

## Other

- Switched to "·" (U+00B7) Middle Dot from "•" (U+2022) Bullet for non-printing spaces, see #1056 and #1100 (@LordFlashmeow)
- Added zsh shell completion script, see #1136 (@Kienyew)
- Improved `--help` text (@sharkdp)
- Added custom languages and themes sections to manpage (@eth-p)

## Syntaxes

- Updated AsciiDoc syntax, see #1034 (@rxt1077)
- GLSL (@caioalonso)
- Added Nginx and Apache configuration file syntax, see #1137 (@kjmph, @niklasmohrin)
- Apply `fstab` syntax highlighting to `crypttab` files, see #1073 (@sharkdp)
- Added syntax highlighting support for files in `$XDG_CONFIG_HOME/git/`, see #1191 (@ahmedelgabri)

## New themes

- Gruvbox, see #1069 (@kyleondy)
- base16-256 for [base16-shell](https://github.com/chriskempson/base16-shell) users, see #1111 (@mk12)

## `bat` as a library

- Added APIs for providing `Input` descriptions via `InputDescription` (@eth-p)
- Added function to directly pass `Input`s to `PrettyPrinter` (@eth-p)
- **Breaking:** `Input::theme_preview_file` is no longer available (@eth-p)

## Packaging

- Removed build dependency on `liquid` (@sharkdp)

# v0.15.4

## Bugfixes

- Added missing Solarized themes, see #1027
- Fixed highlighting bug in Haskell source files, see #1026

# v0.15.3

## Bugfixes

- Fixed inability to run `bat` with relative paths, see #1022
- Fixed incorrect highlighting of users starting with digits in SSH configuration, see #984

## New syntaxes

- SML, see #1005 (@kopecs)

## Other

- Some syntaxes and themes have been updated to the latest version

# v0.15.2

## Bugfixes

- Fixed syntax detection for files called 'rails', see #1008
- Fixed potential errors with syntax detection for symlinked files, see #1001
- Fixed `--map-syntax` not working with names provided through `--file-name` (@eth-p)

## Other

- Added padding above headers when not using a grid, see #968 and #981 (@pt2121)
- bat now prints an error if an invalid syntax is specified via `-l` or `--map-syntax`, see #1004 (@eth-p)

## `bat` as a library

- `PrettyPrinter::vcs_modification_markers` has been marked deprecated when building without the `git` feature, see #997 and #1020 (@eth-p, @sharkdp)

## Packaging

- Compilation problems with `onig_sys` on various platforms have been resolved by upgrading to `syntect 4.2`, which includes a new `onig` version that allows building `onig_sys` without the `bindgen` dependency. This removes the need for `libclang(-dev)` to be installed to compile `bat`. Package maintainers may want to remove `clang` as a build dependency. See #650 for more details.

# v0.15.1

## Bugfixes

- Fixed highlighting of Markdown files, see #963 and #977
- Fixed `base16` theme (broken since v0.14), see #972, #934, and #979 (@mk12)
  Users experiencing #865 ("no color for bat in ssh from a Windows client") can now use the `ansi-dark` and `ansi-light` themes.

## New syntaxes

- Fortran, see #957
- Email (@mariozaizar)
- QML, see #962 (@pylipp)

# v0.15.0

## Features

- Added new `--diff`/`-d` option to show only lines surrounding Git changes (added, removed, or modified lines). Context amount is controlled with `--diff-context=N`. See #23 and #940

## Bugfixes

- Fixed error message printed in the middle of output for another file, see #946
- Performance improvements for custom caches (via `bat cache --build`): bat startup time is now approximately twice as fast (@lzutao)

## Themes

- Updated Solarized dark and light themes, see #941

## `bat` as a library

- Several changes to the low-level API: the `Config` struct has changed and the error handler requires a new `&mut dyn Write` argument. The high-level API is not affected.

# v0.14.0

## Features

- Added new `--file-name <name>…` option to overwrite displayed filename(s) in the header. This is useful when piping input into `bat`. See #654 and #892 (@neuronull)
- Added new `--generate-config-file` option to create an initial configuration file at the appropriate location. See #870 (@jmick414)

## Bugfixes

- Fixed performance problems with C# source code, see #677 (@keith-hall)
- Fixed performance problems with Makefiles, see #750 (@keith-hall)
- Fixed highlighting bug when displaying Ruby files with unindented heredocs, see #914 (@keith-hall)
- Fixed highlighting problem with Rust source code, see #924 (@keith-hall)
- Fixed issue where short files not requiring paging were displayed then lost on Windows, see #887
- Fixed `--highlight-line` not working correctly in combination with `--tabs=0` and `--wrap=never`, see #937

## Other

- When saving or reading user-provided syntaxes or themes, `bat` now maintains a `metadata.yaml` file containing information about the `bat` version used to create the cached files. When loading cached files, an error is printed if they were created with an incompatible version. See #882
- Updated `liquid` dependency to 0.20, see #880 (@ignatenkobrain)

## `bat` as a library

- Added a completely new high-level API that is much more convenient to use. See the `examples` folder for updated code. The older low-level API remains available (everything not in the root `bat` module) but has been refactored substantially. Using the new high-level API is recommended when possible, as it is much easier to maintain stability. This should still be considered a beta release of `bat` as a library. For more details and screenshots of example programs, see #936
- Removed numerous binary-only dependencies, see #895 and #899 (@dtolnay)

  This introduces `features = ["application"]` which is enabled by default and includes everything required by the `bat` application. When depending on bat as a library, downstream `Cargo.toml` should disable this feature to remove unnecessary heavy dependencies:
  ``` toml
  [dependencies]
  bat = { version = "0.14", default-features = false }
  ```
  Other optional functionality has also been put behind features: `paging` and `git` support.
- Added support for using the library with older syntect versions, see #896 and #898 (@dtolnay)

## New syntaxes

- Rego, see #872 (@patrick-east)
- Stylo, see #917

# v0.13.0

## `bat` as a library

Beginning with this release, `bat` can be used as a library (#423).

This was a significant effort and I want to thank all contributors: @DrSensor, @mitsuhiko, @mre, @eth-p!

- Initial attempt in #469 (@mitsuhiko)
- Second attempt with complete restructuring of the `bat` crate, see #679 (@DrSensor)
- Updates to example code, public API, error handling, and further refactoring: #693, #873, #875 (@sharkdp)

This is the very first release of the library, and changes are likely. Much is still missing, including comprehensive documentation.

You can start using it now. See example programs in [`examples/`](https://github.com/sharkdp/bat/tree/master/examples).

API documentation is available at: https://docs.rs/bat/

## Features

- (**Breaking change**) Glob-based syntax mapping, see #877 and #592. Users with existing `--map-syntax` settings in their configuration files (accessed via `bat --config-file`) must update them.

  The option now works as follows:
  ```bash
  --map-syntax <glob-pattern>:<syntax-name>
  ```

  For more information, see the `--help` text, the man page, or the README.

  This feature enables proper highlighting for files such as:
  * `/etc/profile`
  * `~/.ssh/config`

- `--highlight-line` now accepts line ranges, see #809 (@lkalir)
- Added full wrapping support for output containing wide Unicode characters, see #811, #787, and #815 (@Kogia-sima)
- Many updates to existing syntaxes via #644 (@benwaffle, @keith-hall)
- `BAT_CACHE_PATH` can be used to place cached `bat` assets in a non-standard location, see #829 (@neuronull)
- Added support for combining multiple styles simultaneously, see #857 (@aslpavel)

## Bugfixes

- Fixed passing of '--no-init' on newer less versions, see #749 and #786 (@sharkdp)
- Fixed 'bat cache' taking precedence over existing files, see #666 (@sharkdp)
- Fixed `.sc` files not being recognized as Scala files, see #443 (@benwaffle)
- Added support for underscores and dashes in page names, see #670 (@LunarLambda)
- Fixed empty lines being modified, see #601 (@mbarbar)
- Fixed wrapping not working when piping, see #758 (@fusillicode, @allevo, @gildo)
- Added support for non-Unicode filenames, see #225 (@sharkdp)
- Fixed incomplete grid produced by empty files without header, see #798 (@eth-p)
- Fixed files named `build` not respecting shebang lines, see #685 (@sharkdp)

## Other

- Added parameterizable names for man page and shell completion files, see #659, #673, #656 (@eth-p)
- Enabled LTO, making `bat` approximately 10% faster, see #719 (@bolinfest, @sharkdp)
- Added suggestions for configuring `bat` for macOS dark mode in README (@jerguslejko)
- Extended ["Integration with other tools"](https://github.com/sharkdp/bat#integration-with-other-tools) section (@eth-p)
- Updated instructions on using `bat` as a `man`-pager, see #652 and #667 (@sharkdp)
- Added section on file encodings, see #688 and #568 (@sharkdp)
- Updated sort order of command-line options in `--help` text and manpage, see #653 and #700 (@hrlmartins)
- Updated man page syntax, see #718 (@sharkdp)
- Japanese documentation updates, see #863 (@k-ta-yamada, @sorairolake, @wt-l00)
- Added "default" as a valid theme option, see #757 (@fvictorio)
- Updated Windows installation instructions, see #852 (@sorenbug)
- Updated man page, see #573 (@sharkdp)

## New syntaxes

- Jinja2, see #648 (@Martin819)
- SaltStack SLS, see #658 (@Martin819)
- `/etc/fstab`, see #696 (@flopp and @eth-p)
- `/etc/group` and `/etc/passwd`, see #698 (@argentite)
- `/proc/cpuinfo` and `/proc/meminfo`, see #593 (@sharkdp)
- Nim, see #542 (@sharkdp)
- Vue, see #826 (@chaaaaarlotte)
- CoffeeScript, see #833 (@sharkdp)

## New themes

- Dracula, see #687 (@clarfon)
- Nord, see #760 (@crabique)
- Solarized light and dark, see #768 (@hakamadare)

## Packaging

- `bat` is now in the official Ubuntu and Debian repositories, see #323 and #705 (@MarcoFalke)
- `bat` can now be installed via MacPorts, see #675 (@bn3t)
- Fish completions are now installed into 'vendor_completions.d', see #651 (@sharkdp)

## Thanks

I want to thank all contributors and everyone who provided feedback. Special thanks go to @eth-p for joining as a maintainer. Your work managing issues, improving deployment, adding PR and issue templates (#837), and implementing features and fixes is greatly appreciated.

# v0.12.1

## Bugfixes

- Fixed panic occurring on older Windows versions (*"The procedure entry point `CreateFile2` could not be located"*), see #643 (@rivy)

# v0.12.0

## Features

- Binary file content can now be viewed with `bat -A`, see #623 and #640 (@pjsier and @sharkdp)
- `bat` can now be used as a man pager. See the README and #523 for more details
- Added new style component to separate multiple `--line-range` arguments, see #570 (@eth-p)
- Added `-L` as an alias for `--list-languages`

## Bugfixes

- Fixed unbalanced output when using '--style=grid,numbers' without 'header', see #571 (@eth-p)
- Fixed issues with filenames starting with "cache", see #584
- Fixed inability to build cache with new theme without creating cache directory first, see #576 (@frm)
- Fixed incorrect parsing of `--terminal-width -10`, see #611

## Other

- Added fish completions to DEB package, see #554

## New syntaxes

- Emacs Org mode, see #36 (@bricewge)
- `requirements.txt`
- DotENV `.env`
- SSH configuration syntax (`-l ssh_config`), see #582 (@issmirnov)
- `/etc/hosts`, see #583 (@issmirnov)
- GraphQL, see #625 (@dandavison)
- Verilog, see #616
- SCSS and Sass, see #637
- `strace` syntax, see #599

## Packaging

- `bat` is now in the official Gentoo repositories, see #588 (@toku-sa-n)
- `bat` is now in the official Alpine Linux repositories, see #586 (@5paceToast)
- `bat` is in the official Fedora repositories, see #610 (@ignatenkobrain)

# v0.11.0

## Features

- Three new special color themes are available: `ansi-light`, `ansi-dark`, and `base16`. These are useful for users who frequently switch between dark and light terminal themes or want colors matching their terminal configuration. See #543 and #490 (@mk12, implementation idea by @trishume)
- Hand-written autocompletion script for Fish shell, see #524 and #555 (@ev-dev and @eth-p)
- The `-p`/`--plain` option can now be used twice (typically `-pp`). The first `-p` switches `--style` to "plain". The second `-p` disables the pager. See #560 and #552 (@eth-p)

## Bugfixes

- Fixed `--pager` not correctly passing arguments to `less`, see #509
- Binary files are now indicated by a warning in interactive mode, see #530, #466, and #550 (@maxfilov)
- Fixed empty files no longer being printed with a single header line, see #504 and #566 (@reidwagner and @sharkdp)
- Fixed disallowance of `--terminal-width=0`, see #559 (@eth-p)
- Fixed accidental printing of files named `cache`, see #557

## Other

- Added new integration tests, see #500 and #502 (@reidwagner and @sharkdp)
- Added new ["Integration with other tools"](https://github.com/sharkdp/bat#integration-with-other-tools) section in README
- Migrated to Rust 2018 (@expobrain)

## New syntaxes

- Updated F# syntax, see #531 (@stroborobo)
- Fish shell, see #548 (@sanga)

## Packaging

- `bat` is now available on Chocolatey, see #541 (@rasmuskriest)

# v0.10.0

## Features

- Added new `--highlight-line <N>` option, see #453, #346, and #175 (@tskinn and @sharkdp)

## Changes

- **Changed the default configuration directory on macOS** to `~/.config/bat`, see #442 (@lavifb). Users on macOS must copy their configuration directory from the previous location (`~/Library/Preferences/bat`) to the new location (`~/.config/bat`)
- Completely disabled the generation of shell completion files, see #372
- Fixed arguments to `less` when `PAGER` environment variable contains commands like `less -F` (missing the `-R` option), see #430 (@majecty)
- Added reporting of missing file names in error messages, see #444 (@ufuji1984)
- Fixed pager starting for non-existent files, see #387
- Renamed `bat cache --init` to `bat cache --build`, see #498
- Moved `--config-dir` and `--cache-dir` options from `bat cache` to `bat` and hid them from help text

## Bugfixes

- Fixed blank line at end of output when using `--style=plain`, see #379
- Fixed requirement to send EOF twice on stdin when no other input is sent, see #477 (@reidwagner)

## New syntaxes

- Twig (@ahmedelgabri)
- `.desktop` files (@jleclanche)
- AsciiDoc (@markusthoemmes)
- Assembly (x86_64 and ARM)
- Log files (@caos21)
- Protobuf and ProtobufText (@caos21)
- Terraform (@caos21)
- Jsonnet (@hfm)
- Varlink (@haraldh)

## Other

- Added Japanese version of README (@sh-tech and @object1037)
- Code improvements (@barskern)

# v0.9.0

## Features

- Added new `-A`/`--show-all` option to show and highlight non-printable characters (similar to GNU `cat` option):

  See #395 and #381 for more details.

- Added `--pager` option to configure the pager from the configuration file, see #362 (@majecty)

- Added `BAT_CONFIG_PATH` environment variable to set a non-default path for `bat`'s configuration file, see #375 (@deg4uss3r)

- Enabled multiple occurrences of `--style` to allow configuration of styles from the configuration file, see #367 (@sindreij)

- Enabled multiple `--line-range` arguments, see #23

- The `--terminal-width` option now accepts offsets, see #376

## Changes

- Italics are now disabled by default (see #389 for details). They can be re-enabled by adding `--italic-text=always` to your configuration file

- The default tab width is now 4

- Added new "Sublime Snazzy" theme

- Shell completions are currently not shipped. See #372 for details

## Bugfixes

- Fixed endless recursion when `PAGER="bat"`, see #383 (@rodorgas)

## Other

- `bat` is now available on openSUSE, see #405 (@dmarcoux)

- Added section about the new configuration file in README (@deg4uss3r)

- Chinese translation of README (@chinanf-boy)

- Rewrote tests for `--tabs` (@choznerol)

- Improved integration test speed, see #394

# v0.8.0

## Features

- Added support for a configuration file with the following format:

  ```bash
  --tabs=4
  --theme="Sublime Snazzy"

  # A line comment
  --map-syntax .ignore:.gitignore
  --map-syntax PKGBUILD:bash
  --map-syntax Podfile:ruby

  # Flags and options can also be on a single line
  --wrap=never --paging=never
  ```

  Access the configuration file path via `bat --config-file`. On Linux, it is stored in `~/.config/bat/config`.

- Added support for the `BAT_OPTS` environment variable using the same format as specified above (in a single line). This takes precedence over the configuration file. See also #310.

- Added support for custom syntax mappings via the `-m`/`--map-syntax` option.

  This allows users to map certain file extensions or file names to existing syntaxes:

  ``` bash
  bat --map-syntax .config:json ...
  ```

  The option can be used multiple times. Make these mappings permanent by using bat's configuration file. See #169

- Added support for pager command-line arguments in `PAGER` and `BAT_PAGER`, see #352 (@Foxboron)

- Added support for wildcards in Windows CMD, see #309 (@zxey)

- Added first-line syntax detection for all input types, see #205

- Added encoding support for UTF-16LE and UTF-16BE, see #285

- Added syntax support for Robot framework (@sanga)

## Changes

- Binary files are now detected and not displayed when output goes to an interactive terminal, see #205

## Bugfixes

- Fixed JavaDoc comments breaking syntax highlighting in .java files, see #81

- Fixed bat panicking on Haskell source code, see #314

## Other

- Improved `-h` and `--help` texts

- Updated documentation on configuring `bat`'s pager

- Updated documentation for light backgrounds, see #328 (@russtaylor)

- Generate shell completions during build, see #115 (@davideGiovannini)

- Added new integration tests

- `bat` is now available via [Termux](https://termux.com/), see #341 (@fornwall)

- `bat` is now available via [nix](https://nixos.org/nix), see #344 (@mgttlinger)

- `bat` is now available via [Docker](https://hub.docker.com/r/danlynn/bat/), see #331 (@danlynn)

# v0.7.1

## Features

- Added `ansi_colours` package for better true-color approximation on 8-bit color terminals, see #319 and #202 (@mina86)

## Bugfixes

- Fixed bat panicking on Haskell source code, see #314
- Fixed wrapping being disabled when using `--style=plain`/`-p`, see #289

## Other

- Added Ansible install instructions (@aeimer)
- Added section about Cygwin to README (@eth-p)

# v0.7.0

## Features

- Tabs are now optionally expanded to spaces. This is controlled with the new `--tabs` command-line option or the `BAT_TABS` environment variable. This feature also addresses #166 and #184. See #302 for more information (@eth-p)

- Added support for the `BAT_STYLE` environment variable, see #208 (@ms2300)

- Added `OneHalf` theme for terminals with light-gray backgrounds, see #256

- Added new syntaxes for CSV, JSX in JavaScript and TypeScript, Cabal, Dart, F#, PureScript, Swift, Crystal, and PowerShell (thanks to @tobenna and @mimadrid)

## Changes

- Query `git diff` only when necessary, see #303 (@ShikChen)

- Disabled wrapping when using `--plain`, see #289 (@eth-p)

## Bugfixes

- Fixed inability to read files named `cache`, see #275 (@BK1603)

- Fixed numerous bugs on Windows, see #252 and #264

- Fixed reliable `less` detection across platforms, see #271 and #290 (@Aankhen)

- Fixed improper formatting of last decoration line with `--wrap never`, see #299 (@Rogach)

- Fixed file header display for directories, see #292

## Other

- Added new `aarch64` build target, see #258 (@rachitchokshi)

- Added Debian packages for `armhf`, see #280 (@rachitchokshi)

- Added README section about "`bat` on Windows" (@Aankhen)

- Added Windows installation via scoop (@meltinglava)

# v0.6.1

## Bugfixes

- Fixed panic when running `bat --list-languages | head`, see #232 (@mchlrhw)
- Fixed `--color` settings not being respected for `--list-themes` and `--list-languages`, see #233
- Fixed git modifications not working on Windows

## Other

- Auto-generated Windows releases are now available, starting with this version (@anykao)

# v0.6.0

## Features

- The `--list-themes` option now shows a preview for each highlighting theme (@ms2300)
- Added `-p`/`--plain` as an alias for `--style=plain`, see #212 (@ms2300)
- Major refactorings enabling progress on #150. In non-interactive mode, `bat` now copies input bytes 1:1
- Added syntax highlighting for: Elm, Kotlin, Puppet, and TypeScript, see #215, #216, #217, #218
- Added new "zenburn" syntax highlighting theme (@colindean)

## Changes

- New themes in `$BAT_CONFIG_DIR/themes` are now loaded in addition to default themes (they may also override), see #172
- The `Default.tmTheme` symlink is no longer necessary

## Bugfixes

- Fixed duplicated syntaxes when using `bat cache --init`, see #206

## Other

- Expanded and cleaned up `--help` text
- Added initial version of a man page, see #52
- Added new README sections: *Development* and *Troubleshooting*, see #220

# v0.5.0

## Features

- Added `--line-range n:m` option to print a range of lines, see #159 (@tskinn)
- The syntax highlighting theme can now be controlled by the `BAT_THEME` environment variable, see #177 (@mandx)
- The `PAGER` and `BAT_PAGER` environment variables can be used to control the pager used by `bat`, see #158
- Added syntax highlighting for Nix, see #180
- Added syntax highlighting for AWK (Gert Hulselmans)

## Changes

- Customization of syntax sets and theme sets is now separated. Syntax definitions are now loaded in addition to the ones stored in the `bat` binary by default. See [Adding new syntaxes](https://github.com/sharkdp/bat#adding-new-syntaxes--language-definitions) and [Adding new themes](https://github.com/sharkdp/bat#adding-new-themes) sections in README. See #172
- The color for the filename is now the default foreground color. Colors for the grid and line numbers are now determined from the syntax highlighting theme, which now works for light backgrounds, see #178

## Bugfixes

- Fixed escape sequences being partially stripped, see #182 (@eth-p)
- Added separate git repository for snapshot testing, see #165 and #161
- Fixed Markdown breaking on JavaScript, see #183

## Other

- Added binary builds for armv7, see #196
- `bat` is now in the official [Arch package repositories](https://www.archlinux.org/packages/community/x86_64/bat/)
- Optimized RGB to 8-bit conversion (@mina86)

# v0.4.1

(This is a small bugfix release; see v0.4.0 for all features and changes)

## Bugfixes

- Fixed problem with `cargo test` when `bat` is not checked out in a Git repository, see #161

# v0.4.0

## Features

- Added line-wrapping support, see #54 and #102 (@eth-p)
- Updated `--style` parameter with new options, see #74 (@pitkley)
- Added `--theme` and `--list-themes` options, see #89 (@rleungx)
- Added syntax highlighting for: Julia (@iamed2), Dockerfiles, VimL, CMake, INI, and Less
- Added several popular Sublime Text highlighting themes, see #133
- Added support for bold, italic, and underline font styles, see #96
- Added 32-bit system support, see #84
- Added `-u` and `-n` options, see #134
- Added ANSI color support on Windows 10

## Changes

- Renamed the customization folder for user syntaxes from `syntax` to `syntaxes` (see README)
- Changed default Markdown syntax to the Sublime Text syntax, see #157
- Sorted language listing (@rleungx)
- Command-line arguments like `--theme` or `--color` can now override themselves
- Improved `--help` text

## Bugfixes

- Fixed crash for very small terminal sizes, see #117 (@eth-p)
- Fixed syntax detection for `.bashrc`, `CMakeLists.txt`, etc., see #100
- Fixed proper handling of lines with invalid UTF-8, see #7 (@BrainMaestro)
- Improved error handling, see #17 (@rleungx and @sharkdp)
- Fixed proper handling of UTF-8 characters in `less`, see #98 (@ghuls)
- Fixed build on nightly, see #148 (@tathanhdinh)

## Other

- Added [Comparison with alternative projects](https://github.com/sharkdp/bat/blob/master/doc/alternatives.md)
- Added new "bat" logo in README, see #119 (@jraulhernandezi)
- Added output test cases (@BrainMaestro)
- Extensive refactoring work (@BrainMaestro)

# v0.3.0

## Features

- Added automatic paging by integrating with `less`, see #29 (@BrainMaestro)
- Added support for reading from standard input, see #2
- Added support for writing to non-interactive terminals (pipes, files, etc.). New `--color=auto/always/never` option, see #26 (@BrainMaestro)
- Added `--list-languages` option to print all available syntaxes, see #69 (@connorkuehl)
- Added option to specify the syntax via `-l`/`--language`, see #19 (@BrainMaestro)
- Added option to control output style (`--style`), see #5 (@nakulcg)
- Added syntax highlighting support for TOML files, see #37

## Changes

- Removed the `init-cache` sub-command. Cache can now be controlled via `bat cache`. See `bat cache -h` for all available commands

## Bugfixes

- Fixed git repository detection using file path instead of current directory, see #22 (@nakulcg)
- Added support for process substitution with bat (`bat <(echo a) <(echo b)`), see #80

## Thanks

Special thanks to all contributors and everyone who provided feedback. Particular gratitude goes to @BrainMaestro for significant contributions with new features, bug reports, and code reviews!

# v0.2.3

- Added a new statically linked version of bat (`..-musl-..`)

# v0.2.2

- Removed openssl dependency completely, see #30

# v0.2.1

- Added Elixir syntax, see #25
- Changed to use libcurl-openssl instead of libcurl-gnutls, see #30

# v0.2.0

- Added support for custom syntaxes and "Markdown extended" theme
- Fixed git modifications not being shown from child folders

# v0.1.0

Initial release
