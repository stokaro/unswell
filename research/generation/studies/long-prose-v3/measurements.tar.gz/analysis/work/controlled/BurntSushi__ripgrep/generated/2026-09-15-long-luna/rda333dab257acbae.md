# ripgrep Documentation

## Purpose and scope

This documentation answers common questions about ripgrep search semantics, performance, configuration, Windows use, and project policy. It describes how ripgrep searches text, how its regular-expression engines differ, how encoding and newline behavior affect searches, and how to diagnose differences between expected and observed behavior.

It also documents configuration and generated documentation, shell completions, color control, compressed-input searching, multiline searches, compiled-pattern limits, PowerShell integration, file replacement workflows, licensing, naming history, and the circumstances in which ripgrep is or is not an appropriate replacement for grep.

Configuration and encoding information is documented in `GUIDE.md`. Changes are documented in `CHANGELOG.md`. Volunteers publish on a best-effort basis without release dates. Serious regressions can motivate a patch, but they create no timing promise.

## Generated documentation and releases

When `asciidoctor` or `asciidoc` is installed, the build generates a man page from the argument parser. The generated file is placed under the build output in `target`. Binary releases include this man page.

The man page can be located by looking for the most recently modified `rg.1` file:

```text
$ find ./target -name rg.1 -print0 | xargs -0 ls -t | head -n1
./target/debug/build/ripgrep-79899d0edd4129ca/out/rg.1
```

The command-line help provides equivalent option details. Use `rg --help` for the full option descriptions. Use `rg -h` when a condensed presentation is preferred; it reduces each flag to one line.

Builds and releases also include shell completions. The completion files are distributed according to the conventions of their shells:

- Zsh uses a separately maintained file named `complete/_rg`.
- Bash uses `rg.bash`, placed under `XDG_CONFIG_HOME/bash_completion` or `/etc/bash_completion.d`.
- Fish uses `~/.config/fish/completions/rg.fish`.
- Zsh installs `_rg` in `fpath`.
- PowerShell profiles dot-source `_rg.ps1`. If the executable or script is unavailable on `PATH`, the profile uses its full path.

## Search ordering and parallelism

Parallel search produces nondeterministic result order. The order in which files or results are processed can vary, so output from one invocation need not appear in the same order as output from another invocation.

Use `--sort path` when consistent path ordering is required. Sorting by path disables parallelism. Smaller repositories may see little slowdown from this change, but the option trades parallel search for ordered output.

This distinction matters when output is consumed by another program or compared as text. If stable ordering is not required, retaining parallelism can preserve the performance benefit of searching multiple files concurrently. If stable ordering is required, specify the path sort explicitly.

## Compressed input

The `-z` or `--search-zip` option searches compressed input through installed decompressor processes. Supported compression formats include:

- gzip
- bzip2
- xz
- lzma
- lz4
- Brotli
- Zstd

The decompressor processes must be installed for the corresponding format. The option applies to these compressed streams; it does not search archive formats such as `tar.gz`. In particular, `tar.gz` is an archive format rather than merely a compressed text stream for this purpose.

## Multiline searching

Use `-U` or `--multiline` to allow results spanning lines. Without multiline mode, the ordinary line-oriented behavior prevents a match from spanning a newline.

Multiline searching has a memory consequence: ripgrep needs the whole file in memory because a match can be arbitrarily long. A memory map normally supplies the file contents. UTF-8 conversion, however, requires a heap copy.

The default regular-expression engine can recognize when a pattern cannot cross lines. Even with `-U`, it can preserve its fast incremental strategy for a pattern that is known not to cross line boundaries. This means that enabling multiline mode does not necessarily force every pattern into the same search strategy.

PCRE2 has different behavior in this area. Combining `-U` with `--no-pcre2-unicode` can avoid both line-by-line searching and decoding. This can allow memory mapping and JIT speed when Unicode semantics and cross-line restrictions are unnecessary. Disabling Unicode can miss non-ASCII word characters, so this option changes the meaning of patterns that depend on Unicode character classifications.

Other APIs or designs could perform differently. The behavior described here is the behavior of the implementation and search modes covered by these options.

## The default regular-expression engine

The default regular-expression engine uses finite-state machines. Its matching behavior has linear worst-case complexity. The engine is automata-based and does not implement every feature associated with backtracking regular-expression engines.

In particular, the default engine does not implement:

- backreferences
- look-around

For patterns requiring these features, use the optional PCRE2 engine with `-P` or `--pcre2`.

The default engine can search arbitrary bytes while refusing invalid sequences when a pattern requires Unicode-only behavior. Its handling of Unicode and invalid UTF-8 therefore differs from PCRE2's handling.

### PCRE2

Use `-P` or `--pcre2` to select PCRE2. PCRE2 is a backtracking engine with additional regular-expression features. The default engine is automata-based, while PCRE2 provides the feature set associated with backtracking matching.

Most project release binaries enable PCRE2. Package-manager builds may differ. If `-P` is unavailable in a package-manager build, ask the package maintainer whether that build was compiled with PCRE2 support.

For example, a backreference pattern can be searched with PCRE2:

```text
$ rg -P '(\w{10})\1'
tests/misc.rs
483:    cmd.arg("--max-filesize").arg("44444444444444444444");
globset/src/glob.rs
1206:    matches!(match7, "a*a*a*a*a*a*a*a*a", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
```

If PCRE2 is not available, the same command reports:

```text
$ rg -P '(\w{10})\1'
PCRE2 is not available in this build of ripgrep
```

### Newlines and line-only search

Default line-only search must prevent matches from spanning a newline. The default engine exposes syntax analysis that allows ripgrep to remove newline from classes such as backslash-s. An explicit unsupported newline literal produces an error:

```text
$ rg '\n'
the literal '"\n"' is not allowed in a regex
```

This analysis enables ripgrep to search buffers without scanning each line separately. The engine can determine relevant newline behavior from the pattern and retain an efficient buffer-search strategy.

Equivalent PCRE2 introspection is unavailable to ripgrep. In that mode, ripgrep is forced to search line by line when line-only behavior is required. This difference contributes to performance differences between otherwise similar default-engine and PCRE2 commands.

## Pattern compilation limits

Large compiled regular expressions can hit a size limit even when their source text is short. A Unicode-letter class repeated 1,000 times is an example:

```text
$ rg '\pL{1000}'
Compiled regex exceeds size limit of 10485760 bytes.
```

The source pattern is compact, but the compiled representation can be large. Use `--regex-size-limit` to raise the approximate compilation allowance:

```text
$ rg '\pL{1000}' --regex-size-limit 1G
```

An allowance of `1G` does not allocate 1 GB automatically. It raises the approximate limit available for compilation; memory is not reserved in full merely because the limit was specified.

The same principle applies to the fast engine's cache. `-f` or `--file` reads one pattern per line and matches their union. Supplying many patterns can exhaust the fast engine's cache and trigger a slower engine. Use `--dfa-size-limit 1G` to raise that cache allowance.

A larger DFA allowance also does not automatically allocate the entire amount. It changes the limit available to the cache rather than forcing a full allocation.

## Pattern files and unions

The `-f` or `--file` option reads one pattern per line. The resulting search matches the union of those patterns. Each line contributes a pattern, and a subject matches when it matches at least one of the patterns.

This is useful when patterns are supplied externally, but a large number of patterns can affect the fast engine's cache. If the cache limit is exhausted, ripgrep may use a slower engine. Raising the allowance with `--dfa-size-limit` can provide additional cache capacity without automatically allocating the complete stated limit.

## Colors and terminal output

The `--color` option controls when colors appear:

- `never` disables colors.
- `auto` is the default and uses colors only for terminals.
- `always` enables colors.
- `ansi` emits ANSI color codes.

The `--colors` option configures individual output elements. Its syntax is:

```text
--colors '{type}:{attribute}:{value}'
```

The configurable elements include path, line, column, and match. Attributes include foreground color, background color, and style.

Style values include:

- `bold`
- `nobold`
- `intense`
- `nointense`
- `underline`
- `nounderline`

Colors can be specified using eight color names, decimal or hexadecimal indices from 0 through 255, or comma-separated RGB triples.

The `type:none` form resets that element's styling. For example, to clear the current match styling before assigning new foreground, background, and style values:

```text
$ rg somepattern \
    --colors 'match:none' \
    --colors 'match:bg:0x33,0x66,0xFF' \
    --colors 'match:fg:white' \
    --colors 'match:style:bold'
```

An RGB foreground color can be specified directly:

```text
$ rg somepattern --colors 'match:fg:0x33,0x66,0xFF'
```

The `none` setting can be combined with a new foreground setting:

```text
$ rg somepattern --colors 'match:none' --colors 'match:fg:0x33,0x66,0xFF'
```

A Silver Searcher-like color scheme can be expressed as follows:

```text
rg --colors line:fg:yellow      \
   --colors line:style:bold     \
   --colors path:fg:green       \
   --colors path:style:bold     \
   --colors match:fg:black      \
   --colors match:bg:yellow     \
   --colors match:style:nobold  \
   foo
```

Color settings can be placed in a configuration file. The following file contains the same settings:

```text
$ cat $HOME/.config/ripgrep/rc
--colors=line:fg:yellow
--colors=line:style:bold
--colors=path:fg:green
--colors=path:style:bold
--colors=match:fg:black
--colors=match:bg:yellow
--colors=match:style:nobold
```

Set `RIPGREP_CONFIG_PATH` to activate the file:

```text
$ RIPGREP_CONFIG_PATH=$HOME/.config/ripgrep/rc rg foo
```

## Windows terminal color behavior

Windows terminals differ in their support for color and truecolor. Cygwin may support truecolor directly. Ordinary consoles from before Windows 10 have no known route for truecolor.

On Windows 10, clear the default match styling first when bold interferes with truecolor VT100 escapes. The reset is important because an existing bold setting can affect the appearance of a subsequently selected truecolor value.

Interrupted output can leave the terminal in a changed color state. In `cmd`, the `color` command can restore the color. A Unix reset escape also restores the color.

In PowerShell, a supplied function can restore the original foreground color:

```powershell
$OrigFgColor = $Host.UI.RawUI.ForegroundColor
function Reset-ForegroundColor {
	$Host.UI.RawUI.ForegroundColor = $OrigFgColor
}
Set-Alias -Name color -Value Reset-ForegroundColor
```

The function records the original foreground color, restores it when called, and assigns the name `color` as an alias for the reset function.

Earlier handling changed through PR187 and issue281. These references are part of the history of Windows color handling.

## Performance model

The default engine and PCRE2 use different matching approaches. The default engine uses finite-state machines and automata-based matching. PCRE2 is a backtracking engine with additional regular-expression features. The two modes can therefore use different search strategies, especially when Unicode handling, newline restrictions, or pattern features prevent the same optimizations.

A performance comparison should use a pattern and input that expose these differences. The supplied experiment uses a large file and the pattern `^\w{42}$`. It has one hit and no literal shortcut.

First, the compressed sample is obtained and checked:

```text
$ curl -O 'https://burntsushi.net/stuff/subtitles2016-sample.gz'
$ gzip -d subtitles2016-sample
$ md5sum subtitles2016-sample
e3cb796a20bbc602fbfd6bb43bda45f5   subtitles2016-sample
```

The default engine finds the one matching line:

```text
$ time rg '^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.783s
user    0m1.731s
sys     0m0.051s
```

The PCRE2 version finds the same line but has different timing:

```text
$ time rg -P '^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m2.458s
user    0m2.419s
sys     0m0.038s
```

The command uses a large file, one hit, and a pattern with no literal shortcut. The result is therefore not explained by immediately locating a literal substring.

Use `--trace` to distinguish fast and slow line search and to inspect decoding behavior. The default-engine trace includes:

```text
$ rg '^\w{42}$' subtitles2016-sample --trace
[... snip ...]
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:622: Some("subtitles2016-sample"): searching via memory map
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:712: slice reader: searching via slice-by-line strategy
TRACE|grep_searcher::searcher::core|grep_searcher/src/searcher/core.rs:61: searcher core: will use fast line searcher
[... snip ...]
```

The PCRE2 trace includes:

```text
$ rg -P '^\w{42}$' subtitles2016-sample --trace
[... snip ...]
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:622: Some("subtitles2016-sample"): searching via memory map
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:705: slice reader: needs transcoding, using generic reader
TRACE|grep_searcher::searcher|grep-searcher/src/searcher/mod.rs:685: generic reader: searching via roll buffer strategy
TRACE|grep_searcher::searcher::core|grep-searcher/src/searcher/core.rs:63: searcher core: will use slow line searcher
[... snip ...]
```

The traces show different paths. The default engine uses a slice-by-line strategy and a fast line searcher. The PCRE2 path needs transcoding, uses a generic reader and roll buffer strategy, and uses the slow line searcher.

Possible differences in UTF-8 validation include `encoding_rs` SIMD. This is an explanation considered by the author, not a proven universal PCRE2 limitation. The experiment should therefore be read as an observation about the shown commands and implementation paths, not as a universal statement that PCRE2 always has one fixed performance relationship to the default engine.

## Encoding and PCRE2 Unicode mode

PCRE2 Unicode mode requires valid UTF-8. The default engine can search arbitrary bytes while refusing invalid sequences for Unicode-only patterns.

Ripgrep normally transcodes invalid UTF-8 to replacement characters before PCRE2 search and disables redundant PCRE2 checks. This allows PCRE2 to receive converted input rather than rejecting the original invalid byte sequence immediately.

For example, consider a file containing invalid UTF-8:

```text
$ cat invalid-utf8
foobar

$ xxd invalid-utf8
00000000: 666f 6fff 6261 720a                      foo.bar.
```

The default engine searches it as follows:

```text
$ rg foo invalid-utf8
1:foobar
```

PCRE2 normally receives the transcoded input, in which the invalid bytes appear as replacement characters:

```text
$ rg -P foo invalid-utf8
1:foo�bar
```

With `--no-encoding`, ripgrep skips its conversion and re-enables PCRE2 validation:

```text
$ rg -P foo invalid-utf8 --no-encoding
invalid-utf8: PCRE2: error matching: UTF-8 error: illegal byte (0xfe or 0xff)
```

Passing invalid data directly to PCRE2 produces an error and stops that file's search. `--no-encoding` can be slower because PCRE2 validation is enabled, and it can expose invalid-UTF-8 errors that ripgrep's normal conversion would otherwise handle.

The performance comparison with `--no-encoding` is:

```text
$ time rg -P '^\w{42}$' subtitles2016-sample --no-encoding
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m3.074s
user    0m3.021s
sys     0m0.051s
```

This command still finds the same line, but its timing differs from both the default-engine command and the ordinary PCRE2 command.

## Unicode and multiline performance

Multiline search needs the whole file in memory because a match can be arbitrarily long. A memory map normally supplies the data, but UTF-8 conversion requires a heap copy.

The following comparison uses `-U`:

```text
$ time rg -U '^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.803s
user    0m1.748s
sys     0m0.054s

$ time rg -P -U '^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m2.962s
user     0m2.246s
sys     0m0.713s
```

The default engine can recognize that the pattern cannot cross lines and can retain its fast incremental strategy even though multiline mode is enabled. PCRE2 does not have the equivalent introspection available to ripgrep, so the PCRE2 path is different.

When Unicode semantics are unnecessary, disabling Unicode can avoid decoding-related work. The inline default-engine form is:

```text
$ time rg '(?-u)^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.714s
user    0m1.669s
sys     0m0.044s
```

The corresponding PCRE2 option is:

```text
$ time rg -P '^\w{42}$' subtitles2016-sample --no-pcre2-unicode
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.997s
user    0m1.958s
sys     0m0.037s
```

Combining multiline mode and disabled Unicode gives:

```text
$ time rg -U '(?-u)^\w{42}$' subtitles2016-sample
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.714s
user    0m1.655s
sys     0m0.058s

$ time rg -P -U '^\w{42}$' subtitles2016-sample --no-pcre2-unicode
21225780:EverymajordevelopmentinthehistoryofAmerica

real    0m1.121s
user    0m1.071s
sys     0m0.048s
```

With PCRE2, combining `-U` and `--no-pcre2-unicode` can avoid both line-by-line searching and decoding, allowing mapping and JIT speed. This is appropriate only when the changed Unicode semantics are acceptable. Disabling Unicode can miss non-ASCII word characters.

The experiment does not establish that every input or pattern will show the same timing. Other APIs or designs could perform differently.

## Diagnosing unexpected command behavior

Unexpected ripgrep behavior may come from another executable or from an alias. One notable case is an Oh My Zsh Rails mapping that maps `rg` to `rails generate`.

Use `which rg` to inspect what command the shell resolves for `rg`. If it does not resolve to the intended ripgrep executable, possible remedies include:

- disable the plugin providing the mapping;
- invoke `rg` as `command rg`;
- use an escaped or quoted invocation;
- invoke the executable by its full path;
- run `unalias rg`;
- define a distinct alias for ripgrep.

These approaches address shell resolution rather than search semantics. Confirming which executable is being invoked is the first step when the observed behavior does not match ripgrep's options or output.

## PowerShell wrappers

A PowerShell wrapper must propagate arguments to ripgrep. It must also distinguish between input that exists and input that does not exist.

Piping an empty input object to ripgrep makes ripgrep search empty standard input. A wrapper that always pipes `$input` can therefore cause ripgrep to search an empty stream instead of searching files or the current path.

The supplied wrapper uses conditional behavior:

```powershell
function grep {
    $count = @($input).Count
    $input.Reset()

    if ($count) {
        $input | rg.exe --hidden $args
    }
    else {
        rg.exe --hidden $args
    }
}
```

The wrapper counts the input, resets it, and pipes it only when the count is nonzero. If input exists, it invokes `rg.exe --hidden $args` with that input. If no input exists, it invokes ripgrep without piping an empty input object.

The PowerShell profile path is exposed by the profile variable. A script placed in the profile runs at startup, making the wrapper and related settings available in new sessions.

## PowerShell encoding

PowerShell's `OutputEncoding` controls the bytes piped to native processes. The documented default is US-ASCII. Characters unsupported by that encoding become question marks when sent to a native process.

Set a .NET `UTF8Encoding` or set the console output encoding to UTF-8. Place the setting in the PowerShell profile when it should persist across sessions.

`Console.OutputEncoding` can be set separately to UTF-8 for display. The encoding used for bytes piped to native processes and the encoding used for console display are separate settings, so configure the one relevant to the observed behavior, or configure both when both pipelines are involved.

## Replacing text

Ripgrep never edits files. It searches and reports; it does not modify the contents of matching files.

It can list matching paths for use with tools such as `xargs` and `sed`. The `--files-with-matches` option reports paths containing matches:

```text
rg foo --files-with-matches
```

Those paths can be passed to GNU `sed` for a substitution:

```text
rg foo --files-with-matches | xargs sed -i 's/foo/bar/g'
```

BSD `sed` requires a backup-extension argument. An empty string disables backups:

```text
rg foo --files-with-matches | xargs sed -i '' 's/foo/bar/g'
```

Paths containing whitespace require NUL-delimited ripgrep output and `xargs -0`:

```text
rg foo --files-with-matches -0 | xargs -0 sed -i 's/foo/bar/g'
```

The NUL-delimited form keeps path boundaries unambiguous when paths contain whitespace. The replacement is performed by `sed`, not by ripgrep.

`fastmod` is another replacement tool that shares some underlying libraries.

## Choosing ripgrep instead of grep

Ripgrep can replace some uses of grep. It is particularly relevant for recursive code search involving ignore files, Unicode or UTF-16, and parallel searches across large directories.

It is not a complete behavior-compatible replacement for grep. Ripgrep is not POSIX conformant and is less ubiquitous for portable scripts. A script that must rely on a widely available POSIX-conforming command may therefore require another tool.

GNU grep with filters, wrappers, or parallel `xargs` may be sufficient for a given task. Missing required features remain a reason to use another tool. The choice depends on the requirements of the search and the environment in which the command must run.

Ripgrep's Unicode behavior does not depend on locale settings. This is distinct from tools whose character behavior is affected by the process locale.

## Licensing and project policy

Users may choose either the MIT license or the Unlicense.

The author favors the Unlicense's copyright-disclaimer goal while offering familiar MIT terms for adoption. The two choices reflect different preferences about the form of permissive licensing.

All direct and transitive dependencies must remain permissively licensed. GPL, LGPL, MPL, and Creative Commons ShareAlike are excluded, even when they are described as weak copyleft.

This policy applies to dependencies throughout the dependency graph, not only to direct dependencies. A dependency's permissive description does not override the stated exclusions.

## Project naming history

The project name went through earlier candidates. The first name was `rep`, followed by `xrep`. `rustgrep` and `rgrep` were considered.

`rip` was chosen to suggest fast searching while retaining an `r` associated with Rust. The RIP or “grep-killer” interpretation was noticed only after release and was not the intended meaning.

The name history therefore reflects the intended association with fast searching and Rust rather than the later interpretation.

## Donations and volunteer sustainability

The author declines donations to preserve a personally sustainable volunteer relationship with the project.

Instead of donating to the project, suggested recipients include:

- Internet Archive
- Rails Girls
- Wikipedia

Project work is published on a best-effort basis without release dates. Serious regressions can motivate a patch, but a regression does not create a promise about when a patch or release will appear. This policy preserves the distinction between responding to serious problems and committing to a schedule.

## Practical option summary

The following options address the main behaviors covered here:

- `rg --help` displays full option details.
- `rg -h` displays condensed one-line flag descriptions.
- `--sort path` provides consistent path ordering and disables parallelism.
- `-z` or `--search-zip` searches supported compressed streams through installed decompressor processes.
- `-U` or `--multiline` allows matches spanning lines.
- `-P` or `--pcre2` selects the optional PCRE2 engine.
- `--regex-size-limit` raises the approximate compiled-regex size allowance.
- `--dfa-size-limit` raises the fast engine's cache allowance.
- `-f` or `--file` reads one pattern per line and matches their union.
- `--color` controls when colors appear.
- `--colors` configures path, line, column, or match styling.
- `RIPGREP_CONFIG_PATH` activates a configuration file.
- `--no-encoding` skips ripgrep's conversion and re-enables PCRE2 validation.
- `--no-pcre2-unicode` disables PCRE2 Unicode mode.
- `--files-with-matches` lists paths containing matches.
- `-0` produces NUL-delimited output for use with `xargs -0`.

## Configuration, documentation, and completion checklist

When documenting or configuring a ripgrep installation, use the following distinctions:

1. Read configuration and encoding documentation in `GUIDE.md`.
2. Review changes in `CHANGELOG.md`.
3. Use `rg --help` for complete option details.
4. Use `rg -h` for condensed option descriptions.
5. Check the build output under `target` for the generated `rg.1` man page.
6. Confirm that the binary release includes the man page.
7. Install the completion file appropriate to the shell.
8. For Zsh, ensure `_rg` is available in `fpath`.
9. For Bash, place `rg.bash` under `XDG_CONFIG_HOME/bash_completion` or `/etc/bash_completion.d`.
10. For Fish, use `~/.config/fish/completions/rg.fish`.
11. For PowerShell, dot-source `_rg.ps1` from the profile and use its full path when it is not on `PATH`.

## Troubleshooting checklist

When results differ from expectations, check the search mode and command resolution:

1. Run `which rg` to verify that the intended executable is being called.
2. Check for an alias, especially an Oh My Zsh Rails mapping of `rg` to `rails generate`.
3. Use `command rg`, an escaped or quoted invocation, a full executable path, `unalias rg`, or a distinct alias as appropriate.
4. Determine whether `-P` selected PCRE2.
5. Check whether the build has PCRE2 support.
6. If using a package-manager build, ask the package maintainer about PCRE2 availability.
7. Check whether `-U` or `--multiline` is allowing cross-line results.
8. Check whether Unicode mode is enabled.
9. Consider invalid UTF-8 and whether `--no-encoding` was used.
10. Use `--trace` to distinguish memory mapping, transcoding, line strategy, and fast or slow search.
11. If compilation fails, raise `--regex-size-limit`.
12. If many patterns exhaust the fast engine cache, raise `--dfa-size-limit`.
13. If output order must be stable, use `--sort path`, recognizing that it disables parallelism.
14. If colors look wrong, inspect `--color` and `--colors` settings.
15. On Windows 10, clear default match styling when bold interferes with truecolor escapes.
16. After interrupted output, restore terminal color with `color`, a reset escape, or the supplied PowerShell function.
17. In PowerShell, check `OutputEncoding` when piped characters become question marks.
18. Check the profile when wrappers or encoding settings do not persist across sessions.

## Worked behavior references

A backreference search demonstrates the boundary between the default engine and PCRE2:

```text
$ rg -P '(\w{10})\1'
tests/misc.rs
483:    cmd.arg("--max-filesize").arg("44444444444444444444");
globset/src/glob.rs
1206:    matches!(match7, "a*a*a*a*a*a*a*a*a", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
```

If the build lacks PCRE2, the feature is unavailable:

```text
$ rg -P '(\w{10})\1'
PCRE2 is not available in this build of ripgrep
```

A compiled-pattern limit can be raised explicitly:

```text
$ rg '\pL{1000}'
Compiled regex exceeds size limit of 10485760 bytes.
```

```text
$ rg '\pL{1000}' --regex-size-limit 1G
```

Color configuration can reset and then assign match styling:

```text
$ rg somepattern \
    --colors 'match:none' \
    --colors 'match:bg:0x33,0x66,0xFF' \
    --colors 'match:fg:white' \
    --colors 'match:style:bold'
```

A configuration file can activate a Silver Searcher-like scheme:

```text
$ cat $HOME/.config/ripgrep/rc
--colors=line:fg:yellow
--colors=line:style:bold
--colors=path:fg:green
--colors=path:style:bold
--colors=match:fg:black
--colors=match:bg:yellow
--colors=match:style:nobold
$ RIPGREP_CONFIG_PATH=$HOME/.config/ripgrep/rc rg foo
```

Invalid UTF-8 behaves differently with normal PCRE2 conversion and with direct validation:

```text
$ rg foo invalid-utf8
1:foobar

$ rg -P foo invalid-utf8
1:foo�bar

$ rg -P foo invalid-utf8 --no-encoding
invalid-utf8: PCRE2: error matching: UTF-8 error: illegal byte (0xfe or 0xff)
```

A wrapper must avoid piping an empty input object:

```powershell
function grep {
    $count = @($input).Count
    $input.Reset()

    if ($count) {
        $input | rg.exe --hidden $args
    }
    else {
        rg.exe --hidden $args
    }
}
```

File modification is performed by a separate tool:

```text
rg foo --files-with-matches | xargs sed -i 's/foo/bar/g'
```

For BSD `sed`:

```text
rg foo --files-with-matches | xargs sed -i '' 's/foo/bar/g'
```

For paths containing whitespace:

```text
rg foo --files-with-matches -0 | xargs -0 sed -i 's/foo/bar/g'
```

These examples preserve the central boundary: ripgrep identifies matching content or paths, while another command performs any requested modification.
