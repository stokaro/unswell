# Building curl and libcurl with Visual C++

## Requirements and Dependencies

Building curl and libcurl requires Microsoft Visual C++. Visual C++ 6 is the documented minimum version, though newer versions are recommended. Visual C++ is available through the Windows Platform SDK, and the full Visual Studio product installation is not required solely for building curl. The source documentation links to the Windows SDK archive for alternative installation methods.

curl and libcurl have optional dependencies: zlib, OpenSSL, c-ares, and libSSH2. These dependencies must be downloaded separately. The recommended directory structure uses a sibling `deps` directory alongside the curl source, containing `lib`, `include`, and `bin` subdirectories. The WITH_DEVEL option specifies an alternative dependency location, defaulting to ../deps. Dependency archives are available from windows.php.net and should be uncompressed into the deps folder.

When building from a Git checkout, run buildconf.bat from the source root first. Released source archives do not require this preparation step.

## Build Environment Setup

Build curl within a Visual Studio developer command prompt. The default target architecture is x86. To build for a different architecture, call Vcvarsall.bat with the intended machine type. Some Visual Studio releases provide named prompts for specific version, platform, and native-or-cross configurations; availability varies by Visual Studio version. Refer to Microsoft's command-line environment instructions for your specific installation.

## Build Process

Navigate to curl-src/winbuild and run the build command:

```
nmake /f Makefile.vc mode=<static or dll> <options>
```

The mode parameter specifies whether libcurl is built as a static library or DLL. Build outputs are placed under the source-root builds directory in a configuration-named subdirectory.

## Configuration Options

The `VC` option specifies the Visual C++ version, supporting values 6, 7, 8, 9, 10, 11, 12, 14, and 15.

Dependency support is controlled through WITH_ options. WITH_SSL, WITH_NGHTTP2, WITH_MBEDTLS, WITH_CARES, WITH_ZLIB, and WITH_SSH2 each select whether the dependency is included and whether it is linked as a DLL or static library. WITH_PREFIX specifies the installation location.

Custom paths for individual dependencies use CARES_PATH, MBEDTLS_PATH, NGHTTP2_PATH, SSH2_PATH, SSL_PATH, and ZLIB_PATH.

Feature enablement options include ENABLE_SSPI, which defaults to yes. ENABLE_IPV6 defaults to yes. ENABLE_IDN enables Windows IDN APIs and defaults to yes on Windows Vista or later. ENABLE_SCHANNEL enables native Windows SSL support and defaults to yes if SSPI is enabled and no other SSL library is selected. ENABLE_OPENSSL_AUTO_LOAD_CONFIG enables automatic loading of OpenSSL configuration and defaults to yes. ENABLE_UNICODE enables Unicode support and defaults to no.

Build options include GEN_PDB to generate Program Database files with debug symbols for release builds, and DEBUG to enable debug builds. MACHINE selects the target architecture as x86 or x64, with x86 as default.

## Static Linking Considerations

When mode=static is specified, libcurl is linked as a static library. However, this does not request the static Microsoft C runtime; the default is the DLL version. The RTLIBCFG option can force static CRT linking with RTLIBCFG=static. This option is rarely used and rarely tested. If changing RTLIBCFG for an already-built configuration, remove that configuration's build directory and rebuild completely from scratch.

Applications that link static libcurl on Windows must define the CURL_STATICLIB preprocessor symbol. Without this definition, the linker searches for dynamic import symbols, resulting in linking errors.

## SSL Backend Considerations

The default native SSL backend is Schannel, accessed through Windows SSPI. On Windows XP or earlier, Schannel cannot connect to servers that reject those systems' legacy handshakes or algorithms. Applications targeting Windows XP or earlier should select an alternative SSL backend, such as OpenSSL, to maintain compatibility.
