# fzf Vim Integration API, Global Settings, Layouts, and Custom Commands

## Installation

fzf can be integrated into Vim by adding its directory to Vim's runtimepath, with the installation location depending on your package manager. When using vim-plug, you have two options: you can use your locally installed package or fetch the newest plugin from GitHub. The plugin requires an fzf executable on PATH; if absent, it will ask permission to download one. An optional fzf#install update hook can be configured to keep the binary current.

If installed using Homebrew, add the following to your Vim configuration:

```vim
set rtp+=/usr/local/opt/fzf
```

For installations using git:

```vim
set rtp+=~/.fzf
```

With vim-plug, you can reference the installed package or fetch it from GitHub:

```vim
Plug '/usr/local/opt/fzf'
Plug '~/.fzf'
Plug 'junegunn/fzf'
```

To keep fzf current automatically, include the install hook:

```vim
Plug 'junegunn/fzf', { 'do': { -> fzf#install() } }
```

## Core API Functions

The primary API consists of two main functions: fzf#run(spec) and fzf#wrap().

**fzf#run(spec)** launches the finder with the provided specification dictionary. This function accepts all customization options for controlling fzf's behavior within Vim.

**fzf#wrap([name], [spec], [fullscreen])** returns a spec extended with global preferences. All arguments are optional. The name parameter keys history only when g:fzf_history_dir is configured; fullscreen defaults to 0 and accepts 0 or 1. Wrapped specs inherit layout, colors, history, and opening actions from global settings.

## Basic Commands

The :FZF [options] [path] command provides a basic file selector built on these APIs. It operates on the current directory by default:

```vim
:FZF                          " Look for files under current directory
:FZF ~                        " Look for files under your home directory
:FZF --reverse --info=inline /tmp  " With fzf command-line options
:FZF!                         " Bang version starts fzf in fullscreen mode
```

FZF_DEFAULT_COMMAND and FZF_DEFAULT_OPTS environment variables apply in Vim as well. Selection behavior is controlled by key mappings: Enter opens selections in the current window, Ctrl-T opens in tabs, Ctrl-X opens in horizontal splits, and Ctrl-V opens in vertical splits.

## Global Settings

Four primary global variables control fzf's behavior across all commands.

**g:fzf_action** changes file-opening key bindings. The default configuration is:

```vim
let g:fzf_action = {
  \ 'ctrl-t': 'tab split',
  \ 'ctrl-x': 'split',
  \ 'ctrl-v': 'vsplit' }
```

An action can be a reference to a function that processes selected lines. For example:

```vim
function! s:build_quickfix_list(lines)
  call setqflist(map(copy(a:lines), '{ "filename": v:val }'))
  copen
  cc
endfunction

let g:fzf_action = {
  \ 'ctrl-q': function('s:build_quickfix_list'),
  \ 'ctrl-t': 'tab split',
  \ 'ctrl-x': 'split',
  \ 'ctrl-v': 'vsplit' }
```

Note that g:fzf_action applies only when using the default sink; arbitrary entries with custom sink or sink* handlers need their own handling.

**g:fzf_layout** controls window placement and supports multiple layout styles. A popup window layout:

```vim
let g:fzf_layout = { 'window': { 'width': 0.9, 'height': 0.6 } }
```

Direction-based layouts using up, down, left, or right:

```vim
let g:fzf_layout = { 'down': '40%' }
```

Window layouts using Vim commands:

```vim
let g:fzf_layout = { 'window': 'enew' }
let g:fzf_layout = { 'window': '-tabnew' }
let g:fzf_layout = { 'window': '10new' }
```

**g:fzf_colors** customizes fzf colors to match your color scheme. The dictionary maps elements to pairs consisting of a component name and ordered Vim highlight groups, falling back when a group lacks a color:

```vim
let g:fzf_colors =
\ { 'fg':      ['fg', 'Normal'],
  \ 'bg':      ['bg', 'Normal'],
  \ 'hl':      ['fg', 'Comment'],
  \ 'fg+':     ['fg', 'CursorLine', 'CursorColumn', 'Normal'],
  \ 'bg+':     ['bg', 'CursorLine', 'CursorColumn'],
  \ 'hl+':     ['fg', 'Statement'],
  \ 'info':    ['fg', 'PreProc'],
  \ 'border':  ['fg', 'Ignore'],
  \ 'prompt':  ['fg', 'Conditional'],
  \ 'pointer': ['fg', 'Exception'],
  \ 'marker':  ['fg', 'Keyword'],
  \ 'spinner': ['fg', 'Label'],
  \ 'header':  ['fg', 'Comment'] }
```

The color table identifies available elements: `fg` / `bg` / `hl` (item foreground / background / highlight), `fg+` / `bg+` / `hl+` (current item variants), `gutter` (background of the gutter on the left), `pointer` (pointer to current line), `marker` (multi-select marker), `border` (border around the window), `header` (header line), `info` (info line with match counters), `spinner` (streaming input indicator), and `prompt` (prompt before query).

**g:fzf_history_dir** enables per-command history. When set, history files are stored in the specified directory, and Ctrl-N and Ctrl-P are bound to next-history and previous-history instead of down and up:

```vim
let g:fzf_history_dir = '~/.local/share/fzf-history'
```

## Run Specification Options

The run spec dictionary supports multiple configuration options. The **source** option provides input to fzf, either as a shell command string or a Vim list. If absent, find or FZF_DEFAULT_COMMAND supplies current-directory paths. The **sink** option specifies a Vim command to handle the selected item, or a callback function reference to process each selected item. The **sink*** variant accepts a function reference that takes the list of output lines at once.

The **options** parameter accepts fzf options as a string or list; lists avoid shell escaping issues:

```vim
call fzf#run({'options': '--reverse --prompt "C:\\Program Files\\"'})
call fzf#run({'options': ['--reverse', '--prompt', 'C:\Program Files\']})
```

The **dir** parameter sets the working directory. Layout parameters **up**, **down**, **left**, **right** accept number or string values specifying window position and size. The **tmux** parameter supplies fzf-tmux options. The **window** parameter accepts either a Vim command string or a popup dictionary for defining window behavior.

## Popup Window Settings

Popup windows require specific dimension parameters. Width can be a fraction from 0 to 1 or an integer at least 8; height can be a fraction from 0 to 1 or an integer at least 4. The xoffset and yoffset parameters default to 0.5. Border defaults to rounded; supported alternatives include sharp, horizontal, vertical, individual sides (top, bottom, left, right), and none:

```vim
let g:fzf_layout = { 'window': { 'width': 0.9, 'height': 0.6 } }
```

Optional popup settings include highlight (highlight group for border, default 'Comment') and border style specification.

## Using fzf#wrap for Custom Commands

The fzf#wrap function simplifies creating custom fzf commands by automatically applying global settings. Basic usage:

```vim
command! LS call fzf#run(fzf#wrap({'source': 'ls'}))
```

Adding bang support for fullscreen mode:

```vim
command! -bang LS call fzf#run(fzf#wrap({'source': 'ls'}, <bang>0))
```

With directory completion and arguments:

```vim
command! -bang -complete=dir -nargs=* LS
    \ call fzf#run(fzf#wrap({'source': 'ls', 'dir': <q-args>}, <bang>0))
```

Adding a command name for query history:

```vim
command! -bang -complete=dir -nargs=* LS
    \ call fzf#run(fzf#wrap('ls', {'source': 'ls', 'dir': <q-args>}, <bang>0))
```

When the first argument of fzf#wrap is a string, the query history for that command is stored under that name in g:fzf_history_dir.

## Terminal Buffer and Rendering

fzf uses a terminal buffer on Neovim, GVim, and terminal Vim with a nondefault layout. The terminal buffer's filetype is fzf, allowing FileType autocmd customization. For nonpopup layouts, a typical customization temporarily hides the status line:

```vim
if has('nvim') && !exists('g:fzf_layout')
  autocmd! FileType fzf
  autocmd  FileType fzf set laststatus=0 noshowmode noruler
    \| autocmd BufLeave <buffer> set laststatus=2 showmode ruler
endif
```

Popup examples cover editor windows and tmux popups, the latter requiring tmux 3.2 or later:

```vim
if exists('$TMUX')
  let g:fzf_layout = { 'tmux': '-p90%,60%' }
else
  let g:fzf_layout = { 'window': { 'width': 0.9, 'height': 0.6 } }
endif
```
