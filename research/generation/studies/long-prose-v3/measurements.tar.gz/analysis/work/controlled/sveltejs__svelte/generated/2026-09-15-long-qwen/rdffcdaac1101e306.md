# Contributing to Svelte

Svelte is a modern paradigm for building web applications. It operates as a compiler, transforming your declarative components into highly efficient JavaScript code that surgically updates the DOM.

The [Open Source Guides](https://opensource.guide/) website provides a comprehensive collection of resources tailored for individuals, communities, and companies. These resources assist anyone interested in learning how to run and contribute to open source projects. Both seasoned contributors and newcomers to open source will find the following guides particularly useful:

* [How to Contribute to Open Source](https://opensource.guide/how-to-contribute/)
* [Building Welcoming Communities](https://opensource.guide/building-community/)

## Get involved

There are numerous ways to contribute to Svelte, many of which do not require writing code. Here are several ideas to help you get started:

- Begin by using Svelte. Work through the [Getting Started](https://svelte.dev/blog/the-easiest-way-to-get-started) guide. If everything does not function as expected, we are constantly seeking improvements. Please share your feedback by [opening an issue](#reporting-new-issues).
- Review the [open issues](https://github.com/sveltejs/svelte/issues). You can provide workarounds, request clarification, or suggest appropriate labels. Additionally, you can help [triage issues](#triaging-issues-and-pull-requests).
- If you identify an issue you wish to resolve, [open a pull request](#your-first-pull-request).
- Read through our [tutorials](https://svelte.dev/tutorial/basics). If you encounter confusing content or see opportunities for improvement, you can make edits by clicking "Edit this chapter" located at the bottom left of the tutorial page.
- Review the [features requested](https://github.com/sveltejs/svelte/labels/enhancement) by the community and consider opening a pull request if you find a feature you would like to implement.

Contributions are highly welcome. If you feel you need assistance planning your contribution, please ping us on Discord at [svelte.dev/chat](https://svelte.dev/chat) and inform us that you are seeking help.

### Triaging issues and pull requests

One excellent way to contribute to the project without writing any code is to assist in triaging issues and pull requests as they arrive.

- Request additional information if you believe an issue lacks the necessary details to be resolved.
- Suggest [labels](https://github.com/sveltejs/svelte/labels) that can help categorize issues effectively.
- Flag issues that are stale or should be closed.
- Request test plans and review code.

## Bugs

We use [GitHub issues](https://github.com/sveltejs/svelte/issues) to track public bugs. If you wish to report a problem, please look around to see if someone has already opened an issue regarding it. If you are certain this is a new, unreported bug, you can submit a [bug report](#reporting-new-issues).

If you have questions about using Svelte, contact us on Discord at [svelte.dev/chat](https://svelte.dev/chat), and we will do our best to answer your questions.

If you see anything you would like to be implemented, create a [feature request issue](https://github.com/sveltejs/svelte/issues/new?template=feature_request.md).

## Reporting new issues

When [opening a new issue](https://github.com/sveltejs/svelte/issues/new/choose), always ensure you fill out the issue template. **This step is very important!** Failing to do so may result in your issue not being managed in a timely fashion. Do not take this personally if it happens, and feel free to open a new issue once you have gathered all the information required by the template.

- **One issue, one bug:** Please report a single bug per issue.
- **Provide reproduction steps:** List all the steps necessary to reproduce the issue. The person reading your bug report should be able to follow these steps to reproduce your issue with minimal effort. If possible, use the [REPL](https://svelte.dev/repl) to create your reproduction.

## RFCs

If you would like to propose an implementation for a large new feature or change, please [create an RFC](https://github.com/sveltejs/rfcs) to discuss it upfront.

## Installation

1. Ensure you have [npm](https://www.npmjs.com/get-npm) installed.
1. After cloning the repository, run `npm install` in the root of the repository.
1. To start a development server, run `npm run dev`.

## Pull requests

### Your first pull request

So you have decided to contribute code back to upstream by opening a pull request. You have invested a significant amount of time, and we appreciate it. We will do our best to work with you and get the PR reviewed.

Working on your first Pull Request? You can learn how from this free video series:

[**How to Contribute to an Open Source Project on GitHub**](https://egghead.io/courses/how-to-contribute-to-an-open-source-project-on-github)

### Proposing a change

If you would like to request a new feature or enhancement but are not yet thinking about opening a pull request, you can also file an issue with the [feature template](https://github.com/sveltejs/svelte/issues/new?template=feature_request.md).

If you are only fixing a bug, it is fine to submit a pull request right away, but we still recommend that you file an issue detailing what you are fixing. This is helpful in case we do not accept that specific fix but want to keep track of the issue.

### Sending a pull request

Small pull requests are much easier to review and more likely to get merged. Ensure the PR does only one thing; otherwise, please split it.

Please ensure the following is done when submitting a pull request:

1. Fork [the repository](https://github.com/sveltejs/svelte) and create your branch from `master`.
1. Describe your **test plan** in your pull request description. Ensure you test your changes.
1. Ensure your code lints (`npm run lint`).
1. Ensure your tests pass (`npm run test`).

All pull requests should be opened against the `master` branch.

#### Test plan

A good test plan includes the exact commands you ran and their output, and provides screenshots or videos if the pull request changes UI.

- If you have changed APIs, update the documentation.

#### Writing tests

All tests are located in the `/test` folder.

Test samples are kept in the `/test/xxx/samples` folder.

#### Running tests

1. To run tests, run `npm run test`.
1. To run tests for a specific feature, you can use the `-g` (aka `--grep`) option. For example, to only run tests involving transitions, run `npm run test -- -g transition`.

##### Running solo test

1. To run only one test, rename the test sample folder to end with `.solo`. For example, to run the `test/js/samples/action` only, rename it to `test/js/samples/action.solo`.
1. To run only one test suite, rename the test suite folder to end with `.solo`. For example, to run the `test/js` test suite only, rename it to `test/js.solo`.
1. Remember to rename the test folder back. The CI will fail if there is a solo test.

##### Updating `.expected` files

1. Test suites like `css`, `js`, `server-side-rendering` assert that the generated output must match the content in the `.expected` file. For example, in the `js` test suites, the generated JS code is compared against the content in `expected.js`.
1. To update the content of the `.expected` file, run the test with the `--update` flag. (`npm run test --update`)

#### Breaking changes

When adding a new breaking change, follow this template in your pull request:

```md
### New breaking change here

- **Who does this affect**:
- **How to migrate**:
- **Why make this breaking change**:
- **Severity (number of people affected x effort)**:
```

### What happens next?

The core Svelte team will be monitoring for pull requests. Please help us by making your pull request easy to review by following the guidelines above.

## Style guide

[Eslint](https://eslint.org) will catch most styling issues that may exist in your code. You can check the status of your code styling by simply running `npm run lint`.

### Code conventions

- `snake_case` for internal variable names and methods.
- `camelCase` for public variable names and methods.

## License

By contributing to Svelte, you agree that your contributions will be licensed under its [MIT license](https://github.com/sveltejs/svelte/blob/master/LICENSE).
