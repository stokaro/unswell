<p align="center">
  <img src="doc/logo-header.svg" alt="bat - a cat clone with wings"><br>
  <a href="https://github.com/sharkdp/bat/actions?query=workflow%3ACICD"><img src="https://github.com/sharkdp/bat/workflows/CICD/badge.svg" alt="Build Status"></a>
  <img src="https://img.shields.io/crates/l/bat.svg" alt="license">
  <a href="https://crates.io/crates/bat"><img src="https://img.shields.io/crates/v/bat.svg?colorB=319e8c" alt="Version info"></a><br>
  A <i>cat(1)</i> clone with syntax highlighting and Git integration.
</p>

<p align="center">
  <a href="#syntax-highlighting">Key Features</a> •
  <a href="#how-to-use">How To Use</a> •
  <a href="#installation">Installation</a> •
  <a href="#customization">Customization</a> •
  <a href="#project-goals-and-alternatives">Project goals, alternatives</a><br>
  [<a href="https://github.com/chinanf-boy/bat-zh">中文</a>] [<a href="doc/README-ja.md">日本語</a>] [<a href="doc/README-ko.md">한국어</a>] [<a href="doc/README-ru.md">Русский</a>]
</p>

### Syntax highlighting

`bat` supports syntax highlighting for many programming and markup languages:

![Syntax highlighting example](https://imgur.com/rGsdnDe.png)

### Git integration

`bat` communicates with `git` to show modifications relative to the index in the left sidebar:

![Git integration example](https://i.imgur.com/2lSW4RE.png)

### Show non-printable characters

Use the `-A`/`--show-all` option to show and highlight non-printable characters:

![Non-printable character example](https://i.imgur.com/WndGp9H.png)

### Automatic paging

`bat` can pipe its output to a pager, such as `less`, when the output is too large for one screen.

### File concatenation

`bat` can also concatenate files. When it detects a non-interactive terminal, such as when output is piped to another process or file, it acts as a drop-in replacement for `cat` and prints plain file contents.

## How to use

Display one file:

```bash
> bat README.md
```

Display multiple files:

```bash
> bat src/*.rs
```

Read from standard input and determine the syntax automatically. Highlighting works only when the syntax can be determined from the first line, usually through a shebang such as `#!/bin/sh`:

```bash
> curl -s https://sh.rustup.rs | bat
```

Read from standard input and specify the language:

```bash
> yaml2json .travis.yml | json_pp | bat -l json
```

Show and highlight non-printable characters:

```bash
> bat -A /etc/hosts
```

Use `bat` as a `cat` replacement:

```bash
bat > note.md  # quickly create a new file

bat header.md content.md footer.md > document.md

bat -n main.rs  # show line numbers only

bat f - g  # output 'f', then stdin, then 'g'
```

### Integration with other tools

#### `find` or `fd`

Use `find`'s `-exec` option to preview all search results with `bat`:

```bash
find … -exec bat {} +
```

With [`fd`](https://github.com/sharkdp/fd), use `-X`/`--exec-batch`:

```bash
fd … -X bat
```

#### `ripgrep`

With [`batgrep`](https://github.com/eth-p/bat-extras/blob/master/doc/batgrep.md), `bat` can print [`ripgrep`](https://github.com/BurntSushi/ripgrep) search results:

```bash
batgrep needle src/
```

#### `tail -f`

Combine `bat` with `tail -f` to monitor a file continuously with syntax highlighting:

```bash
tail -f /var/log/pacman.log | bat --paging=never -l log
```

Paging must be disabled for this to work. The syntax is specified explicitly with `-l log` because it cannot be detected automatically in this case.

#### `git`

Combine `bat` with `git show` to view an older file version with syntax highlighting:

```bash
git show v0.6.0:src/main.rs | bat -l rs
```

Syntax highlighting within diffs is not currently supported. For this use case, see [`delta`](https://github.com/dandavison/delta).

#### `xclip`

Line numbers and Git modification markers can make file contents difficult to copy. Use `-p`/`--plain`, or pipe the output to `xclip`:

```bash
bat main.cpp | xclip
```

`bat` detects redirected output and prints plain file contents.

#### `man`

Use `bat` as a colorizing `man` pager by setting `MANPAGER`:

```bash
export MANPAGER="sh -c 'col -bx | bat -l man -p'"
man 2 select
```

If formatting problems occur, you may also need to set `MANROFFOPT="-c"`.

To bundle this configuration in a command, use [`batman`](https://github.com/eth-p/bat-extras/blob/master/doc/batman.md).

The [Manpage syntax](assets/syntaxes/02_Extra/Manpage.sublime-syntax) is developed in this repository and still needs work. This configuration does not work with Mandocs' `man` implementation; see [issue 1145](https://github.com/sharkdp/bat/issues/1145).

#### `prettier` / `shfmt` / `rustfmt`

[`prettybat`](https://github.com/eth-p/bat-extras/blob/master/doc/prettybat.md) formats code and prints it with `bat`.

## Installation

[![Packaging status](https://repology.org/badge/vertical-allrepos/bat.svg)](https://repology.org/project/bat/versions)

### On Ubuntu (using `apt`)

*... and other Debian-based Linux distributions.*

`bat` is available for Ubuntu as of Eoan 19.10. On Debian, it is currently available only on the unstable “Sid” branch.

If your installation is new enough, run:

```bash
apt install bat
```

The executable may be installed as `batcat` instead of `bat` because of a [name clash with another package](https://github.com/sharkdp/bat/issues/982). Create a `bat` symlink or alias if needed:

```bash
mkdir -p ~/.local/bin
ln -s /usr/bin/batcat ~/.local/bin/bat
```

### On Ubuntu (using recent `.deb` packages)

If the package is not available for your installation, or you want the newest release, download the latest `.deb` package from the [release page](https://github.com/sharkdp/bat/releases):

```bash
sudo dpkg -i bat_0.16.0_amd64.deb  # adapt the version and architecture
```

### On Alpine Linux

Install the [`bat` package](https://pkgs.alpinelinux.org/packages?name=bat) from the official sources:

```bash
apk add bat
```

### On Arch Linux

Install the [`bat` package](https://www.archlinux.org/packages/community/x86_64/bat/):

```bash
pacman -S bat
```

### On Fedora

Install the [`bat` package](https://koji.fedoraproject.org/koji/packageinfo?packageID=27506) from the official [Fedora Modular](https://docs.fedoraproject.org/en-US/modularity/using-modules/) repository:

```bash
dnf install bat
```

### On Gentoo Linux

```bash
emerge sys-apps/bat
```

### On Void Linux

```bash
xbps-install -S bat
```

### On FreeBSD

Install a precompiled [`bat` package](https://www.freshports.org/textproc/bat):

```bash
pkg install bat
```

Alternatively, build it from the FreeBSD ports:

```bash
cd /usr/ports/textproc/bat
make install
```

### Via nix

```bash
nix-env -i bat
```

### On openSUSE

```bash
zypper install bat
```

### On macOS

Install `bat` with [Homebrew](http://braumeister.org/formula/bat):

```bash
brew install bat
```

Or use [MacPorts](https://ports.macports.org/port/bat/summary):

```bash
port install bat
```

### On Windows

After installing `bat`, see [Using `bat` on Windows](#using-bat-on-windows).

#### Prerequisites

Install the [Visual C++ Redistributable](https://support.microsoft.com/en-us/help/2977003/the-latest-supported-vc-downloads) package.

#### With Chocolatey

```bash
choco install bat
```

#### With Scoop

```bash
scoop install bat
```

#### From prebuilt binaries

Download prebuilt binaries from the [release page](https://github.com/sharkdp/bat/releases). You must also install the Visual C++ Redistributable.

### From binaries

The [release page](https://github.com/sharkdp/bat/releases) provides prebuilt versions for many architectures. Statically linked binaries have `musl` in the archive name.

### From source

Building `bat` requires Rust 1.40 or later:

```bash
cargo install --locked bat
```

Additional files, such as the man page and shell-completion files, cannot be installed this way. Cargo generates them in the cargo target folder under `build`.

## Customization

### Highlighting theme

List available themes:

```bash
bat --list-themes
```

Select the `TwoDark` theme with `--theme=TwoDark`, or set:

```bash
export BAT_THEME="TwoDark"
```

You can also use `bat`'s [configuration file](https://github.com/sharkdp/bat#configuration-file). To preview themes on a file, install [`fzf`](https://github.com/junegunn/fzf) and run:

```bash
bat --list-themes | fzf --preview="bat --theme={} --color=always /path/to/file"
```

`bat` defaults to a dark-background appearance. On a light background, `GitHub` or `OneHalfLight` may work better. You can add a custom theme as described below.

### 8-bit themes

Four themes always use [8-bit colors](https://en.wikipedia.org/wiki/ANSI_escape_code#Colors), even when truecolor is available:

- `ansi-dark` uses 3-bit colors and suits dark backgrounds.
- `ansi-light` uses the same colors for light backgrounds.
- `base16` uses 4-bit colors, including bright variants, according to the [base16 styling guidelines](https://github.com/chriskempson/base16/blob/master/styling.md).
- `base16-256` is designed for [base16-shell](https://github.com/chriskempson/base16-shell) and replaces selected bright colors with 8-bit colors 16 through 21. Do not use it only because your terminal supports 256 colors.

These themes harmonize with other terminal software using 3-bit or 4-bit colors. Their output also updates when you change the terminal theme.

### Output style

Use `--style` to control the output appearance. For example, `--style=numbers,changes` shows line numbers and Git changes without the grid or file header. Set `BAT_STYLE` or use the [configuration file](https://github.com/sharkdp/bat#configuration-file) to make the setting permanent.

### Adding syntax definitions

`bat` uses [`syntect`](https://github.com/trishume/syntect/), which reads Sublime Text `.sublime-syntax` files and themes.

Create a syntax directory:

```bash
mkdir -p "$(bat --config-dir)/syntaxes"
cd "$(bat --config-dir)/syntaxes"

# Add '.sublime-syntax' files here or in subdirectories
git clone https://github.com/tellnobody1/sublime-purescript-syntax
```

Build the binary cache:

```bash
bat cache --build
```

Check the available languages:

```bash
bat --list-languages
```

Restore the default settings with:

```bash
bat cache --clear
```

### Adding themes

Create a themes directory and add a `.tmTheme` theme:

```bash
mkdir -p "$(bat --config-dir)/themes"
cd "$(bat --config-dir)/themes"

git clone https://github.com/greggb/sublime-snazzy
bat cache --build
```

List available themes with `bat --list-themes`.

### Using a different pager

`bat` uses the pager in `PAGER`, or `less` if `PAGER` is unset. Set `BAT_PAGER` to override `PAGER`:

```bash
export BAT_PAGER="less -RF"
```

You can also configure the pager with the `--pager` option in the [configuration file](https://github.com/sharkdp/bat#configuration-file).

When using `less` without options, `bat` adds `-R`/`--RAW-CONTROL-CHARS`, `-F`/`--quit-if-one-screen`, and `-X`/`--no-init`. `-X` is used only with `less` versions older than 530.

`-R` enables ANSI color interpretation. `-F` exits when output fits on one screen. `-X` fixes an old `less` bug involving `--quit-if-one-screen`, but disables mouse-wheel support.

To enable mouse-wheel scrolling in older `less` versions, pass only `-R`; this disables the quit-if-one-screen behavior. `less` 530 and newer should work without this adjustment.

### Indentation

`bat` expands tabs to four spaces. Set `--tabs` to change the displayed width.

Pager tab stops do not apply because the pager receives expanded spaces. This avoids sidebar-related indentation problems. Use `--tabs=0` to pass tabs to the pager instead.

### Dark mode

On macOS, use different themes for dark and light mode:

```bash
alias cat="bat --theme=\$(defaults read -globalDomain AppleInterfaceStyle &> /dev/null && echo default || echo GitHub)"
```

## Configuration file

Find the default configuration-file path with:

```bash
bat --config-file
```

Set a different path with:

```bash
export BAT_CONFIG_PATH="/path/to/bat.conf"
```

Generate a default file with:

```bash
bat --generate-config-file
```

### Format

The configuration file is a list of command-line arguments. Use `bat --help` for available options and values. Add comments by starting a line with `#`.

```bash
# Set the theme to "TwoDark"
--theme="TwoDark"

# Show line numbers, Git changes, and the file header, but no grid
--style="numbers,changes,header"

# Use italic text when supported
--italic-text=always

# Use C++ syntax for .ino files
--map-syntax "*.ino:C++"

# Use Git Ignore syntax for .ignore files
--map-syntax ".ignore:Git Ignore"
```

## Using `bat` on Windows

`bat` generally works out of the box on Windows, but some features require additional configuration.

### Prerequisites

Install the [Visual C++ Redistributable](https://support.microsoft.com/en-us/help/2977003/the-latest-supported-visual-c-downloads) package.

### Paging

Windows includes only the limited `more` pager. Download a Windows binary for `less` from [its homepage](http://www.greenwoodsoftware.com/less/download.html) or [Chocolatey](https://chocolatey.org/packages/Less). Put it in a directory on `PATH`, or define it through the environment-variable configuration. The Chocolatey `bat` package installs `less` automatically.

### Colors

Windows 10 supports colors in `conhost.exe`, Command Prompt, and PowerShell since [version 1511](https://en.wikipedia.org/wiki/Windows_10_version_history#Version_1511_(November_Update)), as do newer bash versions. On earlier Windows versions, use [Cmder](http://cmder.net/), which includes [ConEmu](https://conemu.github.io/).

The Git and MSYS versions of `less` do not interpret colors correctly on Windows. If no other pager is installed, disable paging with `--paging=never` or set `BAT_PAGER` to an empty string.

### Cygwin

`bat` does not natively support Cygwin's Unix-style `/cygdrive/*` paths. Passing an absolute Cygwin path produces:

```text
The system cannot find the path specified. (os error 3)
```

Add this wrapper to `.bash_profile`:

```bash
bat() {
    local index
    local args=("$@")
    for index in $(seq 0 ${#args[@]}); do
        case "${args[index]}" in
        -*) continue;;
        *) [ -e "${args[index]}" ] && args[index]="$(cygpath --windows "${args[index]}")";;
        esac
    done
    command bat "${args[@]}"
}
```

## Troubleshooting

### Terminals and colors

`bat` supports terminals with and without truecolor. Most syntax themes are not optimized for 8-bit color, so a terminal with 24-bit truecolor support, such as `terminator`, `konsole`, or `iTerm2`, is recommended. Otherwise, use an 8-bit theme. See [this article](https://gist.github.com/XVilka/8346728) for details.

A truecolor terminal must set `COLORTERM` to `truecolor` or `24bit`. Otherwise, `bat` falls back to 8-bit colors.

### Line numbers and grid are barely visible

Try another theme. `bat --list-themes` lists the available themes. `OneHalfDark` and `OneHalfLight` have brighter grid and line colors.

### File encodings

`bat` supports UTF-8 and UTF-16 natively. Other encodings may need conversion to UTF-8 because they generally cannot be detected automatically:

```bash
iconv -f ISO-8859-1 -t UTF-8 my-file.php | bat
```

Use `-l`/`--language` if `bat` cannot detect the syntax.

## Development

```bash
# Clone all submodules
git clone --recursive https://github.com/sharkdp/bat

# Build the debug version
cd bat
cargo build --bins

# Run unit and integration tests
cargo test

# Install the release version
cargo install --locked

# Build with modified syntaxes and themes
bash assets/create.sh
cargo install --locked --force
```

## Maintainers

- [sharkdp](https://github.com/sharkdp)
- [eth-p](https://github.com/eth-p)

## Project goals and alternatives

`bat` aims to:

- Provide advanced, attractive syntax highlighting
- Integrate with Git to show file modifications
- Serve as a drop-in replacement for POSIX `cat`
- Provide a user-friendly command-line interface

Many similar programs are available. See [the alternatives document](doc/alternatives.md) for a comparison.

## License

Copyright (c) 2018-2020 [bat-developers](https://github.com/sharkdp/bat).

`bat` is available under either the MIT License or the Apache License 2.0, at your option.

See [LICENSE-APACHE](LICENSE-APACHE) and [LICENSE-MIT](LICENSE-MIT) for details.
