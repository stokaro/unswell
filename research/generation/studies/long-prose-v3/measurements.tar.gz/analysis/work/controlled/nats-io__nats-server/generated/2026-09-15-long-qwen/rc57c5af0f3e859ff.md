# NATS Server Roadmap and Release Milestones

This documentation outlines the draft NATS Server roadmap, detailing how milestones coordinate with release cycles and defining current and future development priorities. The roadmap is a dynamic document that evolves as milestones are completed and new plans are established. While the server wiki tracks official releases, a separate NATS roadmap wiki serves as the central hub for coordinating projects. The Open-Source Planning Process defines the strategic direction of the roadmap. Work is tracked via GitHub milestones, while project wiki pages record specific milestone goals and progress updates. A single release may encompass several milestones. Any feature or fix not associated with a specific milestone is considered unscheduled and is not part of the immediate release plan.

## Near-Term Development Plans

Current development efforts focus on configuration management and monitoring capabilities. A key near-term objective is the ability to reload a subset of gnatsd configuration without requiring a server restart. This feature aims to improve operational efficiency by allowing dynamic updates to running instances. This work is tracked under issue #338.

Simultaneously, release work is underway to export monitoring data through Prometheus. This integration will enhance observability for operators managing NATS deployments. This initiative is tracked under issue #345. These tasks represent the immediate priorities for the upcoming release cycle, ensuring that configuration management and monitoring standards are modernized and streamlined.

## Future Strategic Initiatives

Longer-term plans focus on security, isolation, and client-server efficiency. The roadmap proposes extending authentication and authorization interfaces to support external providers. This enhancement will allow NATS to integrate with broader identity management systems, increasing flexibility for enterprise deployments. This work is tracked under issue #434.

A critical architectural goal is the isolation of subject namespaces by tenant, account, or organization. This feature, tracked by issues #347 and #348, ensures strict data separation. Under this model, a publication made by tenant A on the subject FOO.BAR must remain completely invisible to subscribers belonging to tenant B on the same subject FOO.BAR, and vice versa. This isolation is essential for multi-tenant environments where data privacy and segregation are paramount.

## Proposed Features and Naming Conventions

Several proposed features aim to improve client-server interactions. Publisher rate limiting, tracked by issue #346, currently exists on an internal-project branch and is proposed for public release. This feature allows servers to control the rate at which publishers can send messages, preventing resource exhaustion.

Atomic auto-unsubscribe, tracked by issue #344, proposes a new subscription mechanism. This feature would combine the current SUB foo 1 and UNSUB foo 1 1 operations into a single atomic action. The limit would be optionally encoded directly in the subscription command as SUB foo 1 1, simplifying client logic for one-time or limited subscriptions.

Regarding nomenclature, the retired Ruby server was named nats-server, while the Go implementation used gnatsd to distinguish it from the original. Issue #226 proposes renaming the Go implementation back to nats-server. This change aligns naming conventions across all NATS components, reducing confusion for developers. Additionally, while client and server auto-discovery already permits dynamic cluster expansion, issue #343 proposes optional connection pruning and rebalancing. This feature would optimize client connections across larger clusters, ensuring balanced load distribution and improved performance in dynamic environments.
