# Runtime v2

Runtime v2 introduces a first-class shim API for runtime authors to integrate with containerd. The shim API is minimal and scoped to the execution lifecycle of a container.

## Binary Naming

Users specify the runtime they want to use when creating a container. The runtime can also be changed through a container update.

```bash
> ctr run --runtime io.containerd.runc.v1
```

When a user specifies the runtime name `io.containerd.runc.v1`, they specify the runtime's name and version. containerd translates this into a binary name for the shim:

`io.containerd.runc.v1` -> `containerd-shim-runc-v1`

containerd keeps the `containerd-shim-*` prefix so users can run `ps aux | grep containerd-shim` to see the running shims on their system.

## Shim Authoring

This section is for runtime authors who want to build a shim. It explains how the API works and discusses considerations when building a shim.

### Commands

Container information is provided to a shim in two ways: through the OCI runtime bundle and through the `Create` RPC request.

#### `start`

Each shim MUST implement a `start` subcommand. This command launches new shims. The `start` command MUST accept the following flags:

* `-namespace`: the namespace for the container
* `-address`: the address of containerd's main socket
* `-publish-binary`: the binary path used to publish events back to containerd
* `-id`: the ID of the container

For the `start` command, as well as for all binary calls to the shim, the container bundle is set as the `cwd`.

The `start` command MUST return an address for a shim to which containerd can issue API requests for container operations.

The `start` command can either start a new shim or return the address of an existing shim, depending on the shim's logic.

#### `delete`

Each shim MUST implement a `delete` subcommand. This command allows containerd to delete any container resources created, mounted, or run by a shim when containerd can no longer communicate with it over RPC. This can happen if a shim is terminated with `SIGKILL` while a container is running.

These resources must be cleaned up when containerd loses its connection to a shim. This command is also used when containerd boots and reconnects to shims. If a bundle remains on disk but containerd cannot connect to its shim, the `delete` command is invoked.

The `delete` command MUST accept the following flags:

* `-namespace`: the namespace for the container
* `-address`: the address of containerd's main socket
* `-publish-binary`: the binary path used to publish events back to containerd
* `-id`: the ID of the container
* `-bundle`: the path to the bundle to delete. On non-Windows platforms, this matches the `cwd`.

The `delete` command executes in the container bundle as its `cwd`, except on Windows.

### Host-Level Shim Configuration

containerd does not provide host-level configuration for shims through the API. If a shim needs user-provided configuration containing host-level information shared across all instances, the shim can use a shim-specific configuration file.

### Container-Level Shim Configuration

The create request contains a generic `*protobuf.Any` field that allows a user to specify container-level configuration for the shim.

```proto
message CreateTaskRequest {
	string id = 1;
	...
	google.protobuf.Any options = 10;
}
```

A shim author can create a custom protobuf message for configuration, which clients can import and provide when needed.

### I/O

The client provides container I/O to the shim through FIFOs on Linux, named pipes on Windows, or log files on disk. The paths to these files are provided in the `Create` RPC for the initial creation and in the `Exec` RPC for additional processes.

```proto
message CreateTaskRequest {
	string id = 1;
	bool terminal = 4;
	string stdin = 5;
	string stdout = 6;
	string stderr = 7;
}
```

```proto
message ExecProcessRequest {
	string id = 1;
	string exec_id = 2;
	bool terminal = 3;
	string stdin = 4;
	string stdout = 5;
	string stderr = 6;
}
```

Containers launched with an interactive terminal have the `terminal` field set to `true`. Data is still copied through the files (FIFOs or pipes) in the same way as for non-interactive containers.

### Root Filesystems

The container root filesystem is provided in the `Create` RPC. Shims are responsible for managing the filesystem mount throughout the container's lifecycle.

```proto
message CreateTaskRequest {
	string id = 1;
	string bundle = 2;
	repeated containerd.types.Mount rootfs = 3;
	...
}
```

The mount protobuf message is:

```proto
message Mount {
	// Type defines the nature of the mount.
	string type = 1;
	// Source specifies the name of the mount. Depending on the mount type, this
	// may be a volume name, a host path, or may be ignored.
	string source = 2;
	// Target path in the container.
	string target = 3;
	// Options specifies zero or more fstab-style mount options.
	repeated string options = 4;
}
```

Shims are responsible for mounting the filesystem into the `rootfs/` directory of the bundle. They are also responsible for unmounting the filesystem. During a `delete` binary call, the shim MUST ensure that the filesystem is unmounted. Filesystems are provided by containerd snapshotters.

### Events

Runtime v2 supports an asynchronous event model. For an upstream caller, such as Docker, to receive these events in the correct order, a Runtime v2 shim MUST implement the following events with `Compliance=MUST`. This avoids race conditions between the shim and shim client. For example, a call to `Start` could signal a `TaskExitEventTopic` before returning the results from the `Start` call. With these guarantees, a Runtime v2 shim must publish the asynchronous event `TaskStartEventTopic` before it can publish `TaskExitEventTopic`.

#### Tasks

| Topic | Compliance | Description |
| ----- | ---------- | ----------- |
| `runtime.TaskCreateEventTopic`       | MUST | When a task is successfully created |
| `runtime.TaskStartEventTopic`        | MUST (follow `TaskCreateEventTopic`) | When a task is successfully started |
| `runtime.TaskExitEventTopic`         | MUST (follow `TaskStartEventTopic`) | When a task exits, expected or unexpected |
| `runtime.TaskDeleteEventTopic`       | MUST (follow `TaskExitEventTopic` or `TaskCreateEventTopic` if never started) | When a task is removed from a shim |
| `runtime.TaskPausedEventTopic`       | SHOULD | When a task is successfully paused |
| `runtime.TaskResumedEventTopic`      | SHOULD (follow `TaskPausedEventTopic`) | When a task is successfully resumed |
| `runtime.TaskCheckpointedEventTopic` | SHOULD | When a task is checkpointed |
| `runtime.TaskOOMEventTopic`          | SHOULD | If the shim collects out-of-memory events |

#### Execs

| Topic | Compliance | Description |
| ----- | ---------- | ----------- |
| `runtime.TaskExecAddedEventTopic`   | MUST (follow `TaskCreateEventTopic`) | When an exec is successfully added |
| `runtime.TaskExecStartedEventTopic` | MUST (follow `TaskExecAddedEventTopic`) | When an exec is successfully started |
| `runtime.TaskExitEventTopic`        | MUST (follow `TaskExecStartedEventTopic`) | When an exec other than the init exec exits, expected or unexpected |
| `runtime.TaskDeleteEventTopic`      | SHOULD (follow `TaskExitEventTopic` or `TaskExecAddedEventTopic` if never started) | When an exec is removed from a shim |

#### Logging

Shims may support pluggable logging through STDIO URIs. The currently supported logging schemes are:

* `fifo` - Linux
* `binary` - Linux and Windows
* `file` - Linux and Windows
* `npipe` - Windows

Binary logging can forward a container's STDIO to an external binary for consumption. A sample logging driver that forwards the container's STDOUT and STDERR to `journald` is:

```go
package main

import (
	"bufio"
	"context"
	"fmt"
	"io"
	"sync"

	"github.com/containerd/containerd/runtime/v2/logging"
	"github.com/coreos/go-systemd/journal"
)

func main() {
	logging.Run(log)
}

func log(ctx context.Context, config *logging.Config, ready func() error) error {
	// Construct log metadata for the container.
	vars := map[string]string{
		"SYSLOG_IDENTIFIER": fmt.Sprintf("%s:%s", config.Namespace, config.ID),
	}
	var wg sync.WaitGroup
	wg.Add(2)
	// Forward both stdout and stderr to the journal.
	go copy(&wg, config.Stdout, journal.PriInfo, vars)
	go copy(&wg, config.Stderr, journal.PriErr, vars)

	// Signal that the driver is ready for the container to start.
	if err := ready(); err != nil {
		return err
	}
	wg.Wait()
	return nil
}

func copy(wg *sync.WaitGroup, r io.Reader, pri journal.Priority, vars map[string]string) {
	defer wg.Done()
	s := bufio.NewScanner(r)
	for s.Scan() {
		journal.Send(s.Text(), pri, vars)
	}
}
```

### Other

#### Unsupported RPCs

If a shim does not or cannot implement an RPC call, it MUST return a `github.com/containerd/containerd/errdefs.ErrNotImplemented` error.

#### Debugging and Shim Logs

A FIFO on Unix or a named pipe on Windows is provided to the shim. It is located inside the shim's `cwd` and named `log`.

Shims can use the existing `github.com/containerd/containerd/log` package to write debug messages. These messages are automatically output in the containerd daemon's logs with the correct fields and runtime set.

#### ttrpc

[ttrpc](https://github.com/containerd/ttrpc) is currently the only supported protocol for shims. It works with standard protobufs and gRPC services and generates clients. The only difference between gRPC and ttrpc is the wire protocol.

ttrpc removes the HTTP stack to save memory and reduce binary size, keeping shims small. Using ttrpc in a shim is recommended, but gRPC support is also in development.
