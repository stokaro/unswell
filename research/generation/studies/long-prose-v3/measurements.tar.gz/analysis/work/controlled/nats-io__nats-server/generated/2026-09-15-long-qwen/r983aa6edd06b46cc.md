# Roadmap [DRAFT]

This document outlines the roadmap for the NATS Server. Its purpose is to provide insight into major features planned for implementation in the near future. This is a living document that evolves as goals are met and new plans are established.

The project’s release plan is maintained on [the wiki](https://github.com/nats-io/gnatsd/wiki).

A master project release plan covering all NATS projects is available [here](https://github.com/nats-io/roadmap/wiki).

### Planning and Tracking

An [Open-Source Planning Process](https://github.com/nats-io/gnatsd/wiki/Open-Source-Planning-Process) defines the Roadmap.

This project is managed via GitHub [milestones](https://github.com/nats-io/gnatsd/milestones). [Project Pages](https://github.com/nats-io/gnatsd/wiki) define the goals for each Milestone and identify current progress.

Upcoming features and bug fixes are added to the relevant milestone. One or more Milestones are assigned to a release. If a feature or bug fix is not part of a milestone, it is currently unscheduled for implementation.

### Short Term

#### "Hot" configuration reload

We will enable changes to a subset of configuration items on a running `gnatsd` without requiring the instance to restart.

See [Issue #338](https://github.com/nats-io/gnatsd/issues/338)

#### Integrate Prometheus support

We have done work recently on exporting NATS monitoring data via Prometheus. We plan to share this work in an upcoming release.

See [Issue #345](https://github.com/nats-io/gnatsd/issues/345)

### Further Out

#### Enable external authentication and authorization via extensible auth provider

We will improve and extend the auth interfaces and configuration to support external auth endpoints.

See [Issue #434](https://github.com/nats-io/gnatsd/issues/434)

#### Namespace isolation by account/organization

Multi-tenancy is a popular discussion topic. One requirement we often hear is the ability to isolate or encapsulate the subject namespace by "tenant" (e.g., an account or organization). For example, messages published on `FOO.BAR` by tenant A would not be visible to tenant B's subscribers on `FOO.BAR`, and vice versa. We aim to support this efficiently and performantly.

See [Issue #347](https://github.com/nats-io/gnatsd/issues/347) and [Issue #348](https://github.com/nats-io/gnatsd/issues/348)

#### Rate limiting

Another multi-tenancy concern is the ability to limit the rate at which publishers can publish messages to `gnatsd`. We have implemented this in a branch for an internal project but intend to make it public soon.

See [Issue #346](https://github.com/nats-io/gnatsd/issues/346)

#### Make auto-unsubscribe atomic to the SUB protocol

Currently, auto-unsubscribe is two operations: `SUB foo 1` followed by `UNSUB foo 1 1` (unsubscribe after 1 message). For simplicity, efficiency, and usability, we want to make this an atomic protocol operation. This allows specifying the limit as part of the subscription, e.g., `SUB foo 1 1`.

See [Issue #344](https://github.com/nats-io/gnatsd/issues/344)

#### Rename `gnatsd` to `nats-server`

The original Ruby-based NATS server (now retired) was called `nats-server`. The newer Go version needed a unique name, hence `gnatsd`. We have recently normalized names across all NATS projects to make them more predictable. Renaming `gnatsd` to `nats-server` would align it more closely with the rest of the components in the NATS family.

See [Issue #226](https://github.com/nats-io/gnatsd/issues/226)

#### Client pruning/rebalancing

Cluster auto-discovery is now implemented for both clients and servers, allowing NATS clusters to be dynamically expanded on demand. When this happens, it is useful to optionally rebalance client connections across the new, larger cluster.

See [Issue #343](https://github.com/nats-io/gnatsd/issues/343)
