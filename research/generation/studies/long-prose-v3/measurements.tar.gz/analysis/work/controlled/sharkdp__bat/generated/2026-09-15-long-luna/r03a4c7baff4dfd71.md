# bat Documentation

## Overview

`bat` displays files with syntax highlighting, Git integration, optional display of nonprinting characters, and automatic paging. It can also concatenate multiple files. Its purpose is to provide syntax highlighting, Git integration, a POSIX-compatible `cat` replacement, and a usable command-line interface.

A basic invocation displays a file:

```bash
> bat README.md
```

Multiple files can be displayed in sequence:

```bash
> bat src/*.rs
```

When output is redirected, `bat` provides plain file contents and behaves like `cat`:

```bash
bat > note.md  # quickly create a new file

bat header.md content.md footer.md > document.md
```

Standard input can be mixed with named files. Use `-` as the standard-input marker:

```bash
bat f - g  # output 'f', then stdin, then 'g'.
```

Piped input is supported directly:

```bash
> curl -s https://sh.rustup.rs | bat
```

If input does not provide enough information for automatic syntax detection, set the language explicitly with `-l` or `--language`:

```bash
> yaml2json .travis.yml | json_pp | bat -l json
```

Use `-A` or `--show-all` to highlight nonprinting characters:

```bash
> bat -A /etc/hosts
```

## File display and output elements

The display can include syntax highlighting, line numbers, file headers, a grid, and Git-index modification markers. Git changes are shown as part of the normal display when the input is a file in a Git working tree.

The `--style` option selects which output elements are enabled. For example, the following style shows line numbers and Git changes without the grid or file header:

```text
--style="numbers,changes"
```

A style that includes line numbers, Git changes, and a file header, but omits the grid, is:

```text
--style="numbers,changes,header"
```

Line numbers alone can be requested with `-n`:

```bash
bat -n main.rs  # show line numbers (only)
```

The style can be made persistent with the `BAT_STYLE` environment variable or with a configuration file.

`bat` expands tabs to four spaces before sending output to the pager. Use `--tabs` to change the expansion width. Use `--tabs=0` to pass tabs through to the pager without expanding them. Pager tab-stop settings cannot affect spaces that `bat` has already inserted.

When copying displayed text, gutters such as line numbers, headers, and other display elements may be unwanted. Plain output or piping to `xclip` avoids copying gutters:

```bash
bat main.cpp | xclip
```

## Integrations

### `find`

Use `find -exec` to display files selected by `find`:

```bash
find … -exec bat {} +
```

### `fd`

`fd` can execute `bat` for its results in a batch:

```bash
fd … -X bat
```

### `batgrep`

`batgrep` combines `ripgrep` results with `bat` display:

```bash
batgrep needle src/
```

### Following logs

For a growing log, disable paging and specify log syntax explicitly:

```bash
tail -f /var/log/pacman.log | bat --paging=never -l log
```

### Historical Git contents

Pipe a file from a Git revision to `bat` and specify the syntax:

```bash
git show v0.6.0:src/main.rs | bat -l rs
```

### Diff output

Diff highlighting is unsupported. `delta` is referenced for this use.

### Manual pages

`MANPAGER` can be configured to color manual pages. The following command converts the manual-page output and sends it to `bat` with manual-page syntax:

```bash
export MANPAGER="sh -c 'col -bx | bat -l man -p'"
man 2 select
```

`MANROFFOPT=-c` may fix formatting. `batman` wraps this use. Mandoc's `man` implementation is unsupported.

### Formatting tools

`prettybat` combines formatters such as `prettier`, `shfmt`, and `rustfmt` with `bat`.

## Paging

The pager is selected in this order:

1. `BAT_PAGER`
2. `PAGER`
3. `less` as the fallback

The `--pager` option is another configuration route. For example:

```bash
export BAT_PAGER="less -RF"
```

When `less` is used without explicit arguments, `bat` supplies `-R` so ANSI colors are interpreted and `-F` so output that fits on one screen quits automatically. For `less` versions older than 530, `bat` also adds `-X` to work around a quit-if-one-screen issue. This workaround costs mouse-wheel support.

On those older `less` versions, selecting only `-R` restores mouse-wheel use but disables automatic quitting for short output.

Disable paging with:

```text
--paging=never
```

Paging can also be disabled by setting `BAT_PAGER` to an empty value.

Windows `more` is limited. Install `less` and put it on `PATH`, or configure the pager directly. Chocolatey installs `less` automatically.

## Themes and colors

Use `--list-themes` to list available themes:

```bash
bat --list-themes | fzf --preview="bat --theme={} --color=always /path/to/file"
```

Select a theme with `--theme` or `BAT_THEME`. Examples include `TwoDark`, `GitHub`, and `OneHalfLight`:

```text
--theme="TwoDark"
```

Dark backgrounds are the default assumption. `OneHalfDark` and `OneHalfLight` use brighter grid and line colors.

The `ansi-dark` and `ansi-light` themes use basic three-bit colors. `base16` uses four-bit colors following base16 styling. `base16-256` maps some bright colors into slots 16–21 for `base16-shell`. `base16-256` is not a generic choice for every 256-color terminal.

Restricted themes track terminal palette changes and blend with other terminal software. Use restricted themes when the terminal environment requires them.

Truecolor terminals should expose either `COLORTERM=truecolor` or `COLORTERM=24bit`. Without that information, `bat` falls back to eight-bit colors.

## Custom syntax definitions and themes

`bat` uses `syntect` to read Sublime `.sublime-syntax` files and themes. Custom language definitions and themes are placed in the documented configuration directories. The configuration directory can be used to locate the `syntaxes` and `themes` directories.

To add a language definition:

```bash
mkdir -p "$(bat --config-dir)/syntaxes"
cd "$(bat --config-dir)/syntaxes"

# Put new '.sublime-syntax' language definition files
# in this folder (or its subdirectories), for example:
git clone https://github.com/tellnobody1/sublime-purescript-syntax
```

Build the binary cache after adding definitions:

```bash
bat cache --build
```

Verify the available languages and themes with:

```text
--list-languages
--list-themes
```

To add a theme:

```bash
mkdir -p "$(bat --config-dir)/themes"
cd "$(bat --config-dir)/themes"

# Download a theme in '.tmTheme' format, for example:
git clone https://github.com/greggb/sublime-snazzy

# Update the binary cache
bat cache --build
```

Clear the cache to return to the defaults:

```bash
bat cache --clear
```

Syntax mappings can be stored as configuration arguments. For example:

```text
# Use the theme "TwoDark"
--theme="TwoDark"

# Show line numbers, Git modifications and file header (but no grid)
--style="numbers,changes,header"

# Use italic text on the terminal (not supported on all terminals)
--italic-text=always

# Use C++ syntax for .ino files
--map-syntax "*.ino:C++"

# Use ".gitignore"-style highlighting for ".ignore" files
--map-syntax ".ignore:Git Ignore"
```

## Configuration files

Use `--config-file` to print the platform-dependent configuration path:

```text
bat --config-file
```

Set `BAT_CONFIG_PATH` to select another configuration file:

```bash
export BAT_CONFIG_PATH="/path/to/bat.conf"
```

Generate a default configuration file with:

```bash
bat --generate-config-file
```

The configuration format is a list of command-line arguments. Comments begin with `#`.

## Installation

Package instructions are available for the following systems and package managers.

On Ubuntu 19.10 and later, install the package with:

```bash
apt install bat
```

On Debian Sid, use the Debian package. Debian-family packages may name the executable `batcat` because of a name clash. A symlink or alias restores the `bat` command. For example:

```bash
mkdir -p ~/.local/bin
ln -s /usr/bin/batcat ~/.local/bin/bat
```

A downloaded Debian archive can be installed with `dpkg`:

```bash
sudo dpkg -i bat_0.16.0_amd64.deb  # adapt version number and architecture
```

On Alpine:

```bash
apk add bat
```

On Arch:

```bash
pacman -S bat
```

On Fedora Modular:

```bash
dnf install bat
```

On Gentoo:

```bash
emerge sys-apps/bat
```

On Void:

```bash
xbps-install -S bat
```

On FreeBSD, install the package:

```bash
pkg install bat
```

The FreeBSD port can be installed with:

```bash
cd /usr/ports/textproc/bat
make install
```

On Nix:

```bash
nix-env -i bat
```

On openSUSE:

```bash
zypper install bat
```

On macOS with Homebrew:

```bash
brew install bat
```

With MacPorts:

```bash
port install bat
```

On Windows with Chocolatey:

```bash
choco install bat
```

With Scoop:

```bash
scoop install bat
```

Windows requires the Visual C++ Redistributable.

Release archives include many architectures and MUSL static builds.

## Building from source

Source builds require Rust 1.40 or later. The Cargo installation command is:

```bash
cargo install --locked bat
```

The development workflow can clone the repository recursively, build the debug binaries, run tests, install the release version, and rebuild after changing syntaxes or themes:

```bash
# Recursive clone to retrieve all submodules
git clone --recursive https://github.com/sharkdp/bat

# Build (debug version)
cd bat
cargo build --bins

# Run unit tests and integration tests
cargo test

# Install (release version)
cargo install --locked

# Build a bat binary with modified syntaxes and themes
bash assets/create.sh
cargo install --locked --force
```

Cargo builds generate man and completion files in the target build directory. They do not install those files automatically.

## Windows and shell limits

Windows 10 version 1511 and later supports colors in Command Prompt and PowerShell. Newer Bash versions also support colors. Older Windows versions can use Cmder or ConEmu.

Git/MSYS `less` may misinterpret colors. Windows users should install another `less`, place it on `PATH`, or configure the pager.

Native `bat` cannot interpret Cygwin `/cygdrive` paths. The following wrapper converts paths before calling the native command:

```bash
bat() {
    local index
    local args=("$@")
    for index in $(seq 0 ${#args[@]}) ; do
        case "${args[index]}" in
        -*) continue;;
        *)  [ -e "${args[index]}" ] && args[index]="$(cygpath --windows "${args[index]}")";;
        esac
    done
    command bat "${args[@]}"
}
```

## Character encodings

UTF-8 and UTF-16 are supported natively. Convert other encodings with `iconv`:

```bash
iconv -f ISO-8859-1 -t UTF-8 my-file.php | bat
```

Specify syntax explicitly if automatic detection fails.

## Project information

The maintainers are `sharkdp` and `eth-p`. The project aims to provide syntax highlighting, Git integration, a POSIX-`cat` replacement, and a usable command-line interface. Alternatives are documented.

The license choice is MIT or Apache 2.0. Copyright belongs to `bat-developers 2018–2020`.
