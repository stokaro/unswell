Diesel CLI
==========

Diesel CLI is a tool for managing your database schema. Migrations are
bidirectional changes to your database that are applied sequentially.

Installation
------------

By default, Diesel CLI requires [`libpq`][postgres], [`sqlite`][sqlite], and
[`mysql`][mysql]. After installing these dependencies, run
`cargo install diesel_cli`.

To install the CLI without unnecessary dependencies, omit them from the
following command:

```sh
cargo install diesel_cli --no-default-features --features "postgres sqlite mysql"
```

[postgres]: https://www.postgresql.org/download/
[sqlite]: http://www.sqlitetutorial.net/download-install-sqlite/
[mysql]: https://dev.mysql.com/doc/refman/5.7/en/installing.html

If you are using a system without an easy way to install SQLite, such as
Windows, you can use a bundled version instead:

```shell
cargo install diesel_cli --no-default-features --features "sqlite-bundled"
```

Getting Started
---------------

```sh
cargo install diesel_cli
diesel setup --database-url='postgres://localhost/my_db'
diesel migration generate create_users_table
```

The `setup` command generates a `migrations/` directory, and the
`migration generate` command generates two SQL files:
`migrations/{current_timestamp}_create_users_table/up.sql` and
`migrations/{current_timestamp}_create_users_table/down.sql`. Edit these files
to specify how to update your schema and undo that change.

```sql
-- up.sql
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    name VARCHAR NOT NULL,
    favorite_color VARCHAR
);
```

```sql
-- down.sql
DROP TABLE USERS;
```

Run your new migration with `diesel migration run`. The `DATABASE_URL`
environment variable must be set to run this command. You can set it in
several ways:

* Set it manually as an environment variable.
* Set it as an environment variable using [rust-dotenv][rust-dotenv].
* Pass it directly with the `--database-url` flag.

As an alternative to running migrations with the CLI, call
[`diesel::migrations::run_pending_migrations`][pending-migrations] from
`build.rs`.

Diesel automatically tracks which migrations have already run, ensuring that
they are never run twice.

Commands
--------

## `diesel setup`

Searches for a `migrations/` directory. If it cannot find one, it creates one
in the same directory as the first `Cargo.toml` it finds. It then tries to
connect to the provided `DATABASE_URL` and creates the database if it cannot
connect. Finally, it creates Diesel's internal table for tracking migrations
and runs existing migrations if the table did not previously exist.

## `diesel database`

#### `database setup`

Connects to the provided `DATABASE_URL` and creates the database if it cannot
connect. It then creates Diesel's internal migrations tracking table if
necessary and runs pending migrations if it created the table.

#### `database reset`

Drops the database specified in `DATABASE_URL` if possible, then runs
`diesel database setup`.

## `diesel migration`

#### `migration generate`

Takes the migration name as an argument and creates a migration directory in
the format `migrations/{current_timestamp}_{migration_name}`. It also
generates `up.sql` and `down.sql` files for running the migration up and down.

#### `migration run`

Runs all pending migrations, as determined by Diesel's internal schema table.

#### `migration revert`

Runs the `down.sql` file for the most recent migration.

#### `migration redo`

Runs the `down.sql` file, then the `up.sql` file, for the most recent migration.

## `diesel print-schema`

Prints table definitions for the database schema.

[pending-migrations]: https://docs.rs/diesel_migrations/*/diesel_migrations/fn.run_pending_migrations.html
[rust-dotenv]: https://github.com/slapresta/rust-dotenv#examples

Bash completion
---------------

Diesel can generate a Bash completion script for itself:

#### Linux

```sh
$ diesel bash-completion > /etc/bash_completion.d/diesel
```

#### OS X (Homebrew)

```sh
$ brew install bash-completion  # you may already have this installed
$ diesel bash-completion > $(brew --prefix)/etc/bash_completion.d/diesel
```
