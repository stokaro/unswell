"""Deliver frozen long-prose requests; never execute generated text or tools."""
import argparse
import concurrent.futures
import datetime
import hashlib
import json
import os
import pathlib
import signal
import subprocess
import threading
import time
import urllib.error
import urllib.request

SYSTEM = "Return only the requested text. Do not use tools."
MODELS = {"luna": "gpt-5.6-luna", "haiku": "claude-haiku-4-5-20251001", "qwen": "HivenetQuant/Qwen3.6-35B-A3B"}
LIMIT = 2_000_000
lock = threading.Lock()
tokens = 0
started = time.monotonic()
reserved = 0
stops = {name: threading.Event() for name in MODELS}


def save(path, value):
    data = json.dumps(value, ensure_ascii=False, indent=2) + "\n"
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(data)
    temporary.replace(path)


def command(family, empty, system, text_path):
    if family == "luna":
        return ["codex", "exec", "--ignore-user-config", "--ephemeral", "--sandbox", "read-only", "--skip-git-repo-check",
                "-C", str(empty), "-m", MODELS[family], "-c", "model_reasoning_effort=low", "-c", 'web_search="disabled"',
                "-c", 'model_instructions_file="' + str(system) + '"', "-c", "project_doc_max_bytes=0",
                "-c", "features.shell_tool=false", "-c", "features.multi_agent=false", "-c", "features.multi_agent_v2=false",
                "-c", "agents.enabled=false", "-c", "features.skip_host_skill_discovery=true", "--json", "-o", str(text_path), "-"]
    return ["claude", "-p", "--model", MODELS[family], "--effort", "low", "--tools", "", "--disable-slash-commands",
            "--strict-mcp-config", "--setting-sources", "", "--settings", '{"disableAllHooks":true}',
            "--no-session-persistence", "--permission-mode", "dontAsk", "--permission-prompts", "none",
            "--system-prompt", SYSTEM, "--output-format", "json"]


def cli(family, message, directory, study):
    out, err, final = directory / "stdout", directory / "stderr", directory / "final.txt"
    cmd = command(family, study / "empty", study / "system.txt", final)
    save(directory / "invocation.json", {"argv": cmd, "cwd": str(study / "empty")})
    with out.open("wb") as stdout, err.open("wb") as stderr:
        proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=stdout, stderr=stderr,
                                cwd=study / "empty", start_new_session=True)
        try:
            proc.communicate(message.encode(), timeout=1200)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGTERM)
            proc.wait(timeout=30)
            return {"status": "error", "note": "transport timeout", "transport_error": True}
    raw = out.read_text(errors="replace")
    if family == "haiku":
        data = json.loads(raw)
        usage = data.get("usage", {})
        models = list(data.get("modelUsage", {}))
        failed = data.get("is_error", False) or proc.returncode != 0
        return {"text": data.get("result", ""), "status": "error" if failed else "complete",
                "tokens": sum(item.get("outputTokens", 0) for item in data.get("modelUsage", {}).values()) or usage.get("output_tokens", 0), "remote_request_id": data.get("session_id", "unavailable"),
                "served_models": models, "model_basis": "Claude result modelUsage", "note": data.get("subtype", ""),
                "halt": failed, "transport_error": False}
    events = [json.loads(line) for line in raw.splitlines() if line.startswith("{")]
    completed = [e for e in events if e.get("type") == "turn.completed"]
    calls = [e for e in events if e.get("item", {}).get("type") not in [None, "agent_message", "reasoning", "error"]]
    text = final.read_text() if final.exists() else ""
    errors = [e for e in events if e.get("type") in ["error", "turn.failed"]]
    # A tool event is contamination. The sandbox still restricts execution;
    # it is never accepted as an ordinary response.
    good = proc.returncode == 0 and bool(completed) and not calls and bool(text)
    error_text = json.dumps(errors) + err.read_text(errors="replace")
    halt = any(s in error_text.lower() for s in ["usage limit", "rate limit", "quota", "authenticate", "unauthorized", "session expired"])
    usage = completed[-1].get("usage", {}) if completed else {}
    return {"text": text, "status": "complete" if good else "error", "tokens": usage.get("output_tokens", 0),
            "remote_request_id": next((e["thread_id"] for e in events if e.get("type") == "thread.started"), "unavailable"),
            "served_models": [], "model_basis": "CLI model selection; reply does not expose independent served-model identity",
            "note": "" if good else "CLI failure or tool event; see retained stdout/stderr", "halt": halt,
            "transport_error": not good and not calls and not halt}


def router(message, directory, key):
    body = {"model": MODELS["qwen"], "messages": [{"role": "system", "content": SYSTEM}, {"role": "user", "content": message}],
            "temperature": 0.7, "top_p": 0.9, "max_tokens": 16384, "chat_template_kwargs": {"enable_thinking": False}, "stream": False}
    save(directory / "request.json", body)
    request = urllib.request.Request("https://gpt-router.tenants.hivecompute.ai/v1/chat/completions", data=json.dumps(body).encode(),
                                     headers={"Authorization": "Bearer " + key, "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(request, timeout=1200) as response:
            data = json.load(response)
    except urllib.error.HTTPError as error:
        # Do not persist headers or credential-bearing request objects.
        return {"status": "error", "note": "HTTP " + str(error.code), "transport_error": error.code >= 500,
                "halt": error.code in [401, 403, 429]}
    save(directory / "response.json", data)
    choice = data["choices"][0]
    message = choice["message"]
    status = "truncated" if choice["finish_reason"] == "length" else "complete"
    if message.get("refusal") or choice["finish_reason"] == "content_filter":
        status = "refused"
    if choice["finish_reason"] not in ["stop", "length", "content_filter"] or not message.get("content"):
        status = "error"
    return {"text": message.get("content") or "", "status": status, "tokens": data.get("usage", {}).get("completion_tokens", 0),
            "remote_request_id": data.get("id", "unavailable"), "served_models": [data.get("model")],
            "model_basis": "router response model field", "note": "finish_reason=" + str(choice["finish_reason"]),
            "halt": data.get("model") != MODELS["qwen"], "transport_error": False}


def deliver(study, family, request, harness, key):
    global tokens, reserved
    directory = study / "runs" / family / "raw" / request["id"]
    directory.mkdir(parents=True, exist_ok=True)
    result_path = directory / "result.json"
    if result_path.exists():
        return
    with lock:
        if tokens + reserved + 65536 > LIMIT or time.monotonic() - started >= 43200 or stops[family].is_set():
            return
        reserved += 65536
    message = harness + "\n\n" + request["text"]
    save(directory / "input.json", {"request": request, "harness": harness, "system": SYSTEM, "message": message})
    result = None
    for attempt in range(2):
        target = directory / str(attempt + 1)
        target.mkdir(exist_ok=False)
        begin = time.monotonic()
        try:
            result = router(message, target, key) if family == "qwen" else cli(family, message, target, study)
        except (OSError, ValueError, KeyError, TimeoutError, urllib.error.URLError) as error:
            result = {"status": "error", "note": type(error).__name__, "transport_error": True}
        result["duration_ms"] = round((time.monotonic() - begin) * 1000)
        result["finished_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save(target / "outcome.json", result)
        with lock:
            tokens += result.get("tokens", 0)
        if result.get("halt"):
            stops[family].set()
        if not result.get("transport_error") or stops[family].is_set():
            break
    result["request_id"] = request["id"]
    save(result_path, result)
    with lock:
        reserved -= 65536
        complete = len(list((study / "runs" / family / "raw").glob("*/result.json")))
        print(f"{family}: {complete}/152 {result['status']} tokens={tokens}", flush=True)


def run_family(study, family, key):
    requests = json.loads((study / "runs" / family / "requests.json").read_text())
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        list(pool.map(lambda request: deliver(study, family, request, requests["harness_instruction"], key), requests["requests"]))


def main():
    global tokens, started
    parser = argparse.ArgumentParser()
    parser.add_argument("--study", type=pathlib.Path, required=True)
    parser.add_argument("--families", nargs="+", choices=list(MODELS), required=True)
    parser.add_argument("--router-env", type=pathlib.Path)
    args = parser.parse_args()
    study = args.study.resolve()
    freeze = json.loads((study / "freeze.json").read_text())
    for relative, expected in freeze["files"].items():
        actual = hashlib.sha256((study / relative).read_bytes()).hexdigest()
        if actual != expected:
            raise ValueError("freeze digest mismatch: " + relative)
    if hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest() != freeze["runner_sha256"]:
        raise ValueError("runner differs from freeze")
    (study / "empty").mkdir(exist_ok=True)
    start_path = study / "generation-start.json"
    if not start_path.exists():
        save(start_path, {"unix_seconds": time.time(), "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat()})
    started = time.monotonic() - (time.time() - json.loads(start_path.read_text())["unix_seconds"])
    key = None
    if "qwen" in args.families:
        key = next(line.split("=", 1)[1].strip().strip("\"'") for line in args.router_env.read_text().splitlines() if line.startswith("GPT_ROUTER_API_KEY="))
    tokens = sum(json.loads(p.read_text()).get("tokens", 0) for p in (study / "runs").glob("*/raw/*/*/outcome.json"))
    with concurrent.futures.ThreadPoolExecutor(max_workers=len(args.families)) as pool:
        list(pool.map(lambda family: run_family(study, family, key), args.families))


if __name__ == "__main__":
    main()
