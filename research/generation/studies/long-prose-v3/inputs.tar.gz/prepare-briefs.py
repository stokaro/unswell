"""Assemble curated notes and exact technical excerpts before model delivery."""
import argparse
import hashlib
import json
import pathlib
import re
import shutil


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def ranges(data, index):
    # Technical excerpts retain their bytes. Fences and tables are material,
    # not independently rewritten facts or new prose observations.
    lines = data.splitlines(keepends=True)
    offsets, offset = [], 0
    for line in lines:
        offsets.append(offset)
        offset += len(line)
    out, i = [], 0
    while i < len(lines):
        fence = re.match(rb"^\s{0,12}(`{3,}|~{3,})", lines[i])
        if fence:
            j = i + 1
            end = re.compile(rb"^\s{0,12}" + re.escape(fence[1][:1]) + rb"{" + str(len(fence[1])).encode() + rb",}\s*$")
            while j < len(lines) and not end.match(lines[j]):
                j += 1
            j = min(j + 1, len(lines))
            out.append((offsets[i], offsets[j] if j < len(lines) else len(data), "code example"))
            i = j
            continue
        table = b"|" in lines[i] and i + 1 < len(lines) and re.match(rb"^[\s|:-]+$", lines[i + 1]) and b"---" in lines[i + 1]
        indent = index in {6, 8, 17, 18, 28} and lines[i].startswith(b"        " if index == 18 else b"    ") and lines[i].strip()
        if table or indent:
            j = i + 1
            while j < len(lines) and (b"|" in lines[j] if table else lines[j].startswith(b"        " if index == 18 else b"    ") or not lines[j].strip()):
                j += 1
            out.append((offsets[i], offsets[j] if j < len(lines) else len(data), "table" if table else "indented example"))
            i = j
            continue
        i += 1
    # API signatures and attribution rosters require exact names, not a
    # paraphrase that drops people, licenses, or parameter types.
    extras = {
        6: [(b" - `VC=", b"## Static linking")],
        17: [(b"# 3. ACKNOWLEDGMENTS", None)],
        19: [(b"### Block level renderer methods", b"`slugger`"), (b"### Inline level renderer methods", b"<h2")],
        26: [(b"- Renderers:", b"### Upcoming"), (b"*Platinum-chocolate sponsors*", b"**THANK YOU"), (b"- [PVS-Studio]", b"Credits")],
        27: [(b"## Credits/Licenses For Fonts Included In Repository", b"##### [Return")],
    }
    for start, stop in extras.get(index, []):
        a = data.index(start)
        b = data.index(stop, a + len(start)) if stop else len(data)
        out.append((a, b, "API or attribution record"))
    return sorted({entry for entry in out if not any(a <= entry[0] and b >= entry[1] and (a, b) != entry[:2] for a, b, _ in out)})


def split_excerpt(data, a, b):
    # Split long exact excerpts only at line/UTF-8 boundaries.
    while b - a > 7800:
        end = data.rfind(b"\n", a + 1, a + 7800) + 1
        if end <= a:
            end = a + 7800
            while end > a and data[end] & 0xC0 == 0x80:
                end -= 1
        yield a, end
        a = end
    if a < b:
        yield a, b


def assemble(args):
    selected = json.loads((args.preparation / "selected-before-curation.json").read_text())
    notes = json.loads(args.notes.read_text())
    briefs, record, shards = [], [], []
    remove = {
        2: ["Describe these capabilities without importing current features absent from the historical snapshot.", "Keep optional steps optional."],
        3: ["Preserve the source protobuf field numbers and the distinction between container ID and exec ID."],
        4: ["Preserve this constraint when explaining upgrades or monitoring."],
        6: ["Preserve the option table from the source, including supported VC numbers, dependency paths, backend linking choices, architecture, debug symbols, and defaults."],
        9: ["Keep these as documentation examples, not commands to execute during generation."],
        12: ["Preserve the source's API names and historical version rather than substituting later APIs."],
        31: ["Sponsor and contributor identifiers remain recorded in the source metadata."],
    }
    for index, item in enumerate(selected):
        source = item["source"]
        checkout = args.work / "historical" / source["repository"].replace("/", "__")
        data = (checkout / source["path"]).read_bytes()
        assert digest(data) == source["sha256"] and len(data) == source["bytes"]
        note = notes[str(index)]
        facts = []
        for text in note["facts"]:
            for fragment in remove.get(index, []):
                text = text.replace(fragment, "")
            if text.strip():
                facts.append({"text": text.strip(), "span": {"start": 0, "end": len(data)}})
        excerpts = ranges(data, index)
        for a, b, kind in excerpts:
            for start, end in split_excerpt(data, a, b):
                facts.append({"text": "Technical source material (" + kind + "):\n" + data[start:end].decode(), "span": {"start": start, "end": end}})
        assert len(facts) <= 200, (index, len(facts))
        briefs.append({"version": "unswell-document-brief-v1", "source_id": source["id"], "source_sha256": source["sha256"], "reviewer": "agent", "purpose": note["purpose"], "facts": facts, "sha256": ""})
        record.append({"index": index, "source_id": source["id"], "source_sha256": source["sha256"], "repository": source["repository"], "path": source["path"], "words": item["words"], "paragraphs": item["paragraphs"], "role": source["role"], "rank": item["rank"], "curated_facts": len(note["facts"]), "technical_excerpts": len(facts) - len(note["facts"]), "summary_evidence_scope": "whole_document", "technical_evidence_scope": "exact_bytes"})

    for repo in sorted({item["source"]["repository"] for item in selected}):
        name = repo.replace("/", "__")
        checkout = args.work / "historical" / name
        manifest = json.loads((args.preparation / "pinned/shards" / ("long-inventory-" + name + ".json")).read_text())
        keep = {item["source"]["id"] for item in selected if item["source"]["repository"] == repo}
        manifest["sources"] = [s for s in manifest["sources"] if s["id"] in keep]
        manifest["id"] = "long-prose-v3-" + name
        notices = [p for p in checkout.iterdir() if p.is_file() and any(word in p.name.upper() for word in ["LICENSE", "COPYING", "NOTICE"]) ]
        for source in manifest["sources"]:
            source["notices"] = [{"path": p.name, "sha256": digest(p.read_bytes()), "bytes": p.stat().st_size} for p in sorted(notices)]
            source["rights"]["allowed_uses"] += ["redistribute_source", "redistribute_annotations"]
            source["rights"]["evidence"] += "; full root licenses and notices retained for the permitted research snapshot"
        path = args.output / "shards" / (manifest["id"] + ".json")
        save(path, manifest)
        shards.append({"path": "shards/" + path.name, "sha256": digest(path.read_bytes()), "bytes": path.stat().st_size})
        for relative in {s["path"] for s in manifest["sources"]} | {p.name for p in notices}:
            target = args.output / "sources/historical" / name / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(checkout / relative, target)
    dataset = json.loads((args.preparation / "dataset.json").read_text())
    dataset.update({key: manifest[key] for key in ("seed", "weights", "extraction_policy", "unit_kinds")})
    dataset.update(id="long-prose-v3", shards=shards)
    save(args.output / "dataset.json", dataset)
    save(args.output / "briefs.json", {"version": "unswell-document-briefs-v1", "briefs": briefs})
    save(args.output / "selection.json", record)
    print(json.dumps({"documents": len(briefs), "groups": len(shards), "facts": sum(len(b["facts"]) for b in briefs), "words": sum(r["words"] for r in record)}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    for flag in ["preparation", "notes", "work", "output"]:
        parser.add_argument("--" + flag, type=pathlib.Path, required=True)
    assemble(parser.parse_args())
