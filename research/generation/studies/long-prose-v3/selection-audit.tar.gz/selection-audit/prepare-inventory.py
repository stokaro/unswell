import json,pathlib,subprocess
r=pathlib.Path('/private/tmp/unswell-contextual-audit');d=r/'long-prose-preparation';tool=r/'corpus-groups'
def run(args,src,dst):
 with open(src,'rb') as i,open(dst,'wb') as o:
  subprocess.run([str(tool),*args],stdin=i,stdout=o,check=True)
run(['dataset','plan','--root',str(d)],d/'dataset.json',d/'dataset-plan.json')
run(['dataset','pin','--root',str(d),'--output',str(d/'pinned')],d/'dataset-plan.json',d/'pinned.json')
run(['dataset','verify','--root',str(d),'--pinned',str(d/'pinned')],d/'dataset-plan.json',d/'dataset-verification.json')
for name in ['plans','candidates','verifications']:(d/name).mkdir(exist_ok=True)
for p in sorted((d/'pinned').rglob('*.json')):
 m=json.loads(p.read_text());name=m['id'];checkout=r/'long-prose-work/historical'/m['sources'][0]['repository'].replace('/','__')
 run(['plan'],p,d/'plans'/(name+'.json'))
 run(['extract','--root',str(checkout)],d/'plans'/(name+'.json'),d/'candidates'/(name+'.json'))
 run(['verify','--root',str(checkout)],d/'candidates'/(name+'.json'),d/'verifications'/(name+'.json'))
 print(name,'extracted',flush=True)
