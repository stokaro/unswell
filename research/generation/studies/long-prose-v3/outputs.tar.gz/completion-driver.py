"""Complete the fixed request list with a declared reservation-budget amendment."""
import datetime
import hashlib
import importlib.util
import json
import pathlib
import sys

root = pathlib.Path('/private/tmp/unswell-contextual-audit')
study = root / 'long-prose-v3'
original = root / 'run-long-models.py'
freeze = json.loads((study / 'freeze.json').read_text())
assert hashlib.sha256(original.read_bytes()).hexdigest() == freeze['runner_sha256']
for relative, expected in freeze['files'].items():
    assert hashlib.sha256((study / relative).read_bytes()).hexdigest() == expected, relative
run = study / 'runs/haiku'
requests = json.loads((run / 'requests.json').read_text())
remaining = [r for r in requests['requests'] if not (run / 'raw' / r['id'] / 'result.json').exists()]
assert len(remaining) == 4
outcomes = [json.loads(p.read_text()) for p in (study / 'runs').glob('*/raw/*/*/outcome.json')]
assert not any(r.get('halt') for r in outcomes)
tokens = sum(r.get('tokens', 0) for r in outcomes)
assert tokens == 1962742
record_path = study / 'generation-completion.json'
assert not record_path.exists()
driver = pathlib.Path(__file__).read_bytes()
(study / 'completion-driver.py').write_bytes(driver)
record = dict(version='unswell-long-prose-completion-v1',
              recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              reason='Complete the four remaining, previously frozen requests. The original runner requires a 65,536-token reservation per call including a possible retry; reported tokens had not exhausted two million but the reservation blocked admission.',
              original_runner_sha256=freeze['runner_sha256'],
              completion_driver_sha256=hashlib.sha256(driver).hexdigest(),
              completed_before=148, reported_tokens_before=tokens,
              original_token_cap=2_000_000, amended_token_cap=2_150_000,
              elapsed_seconds_cap=43200, request_reservation=65536,
              max_attempts=2, max_concurrent=2, requests=[r['id'] for r in remaining],
              prior_exposure='All Qwen and Luna outputs were measured and construction cases inspected; historical measurements were inspected. Haiku usage and delivery status were inspected. The joint primary estimates and Holm decisions have not been computed.',
              unchanged='The 456-request sample, source groups, tasks, visible inputs, models, effort, CLI arguments, retry eligibility, deadline, hypotheses, statistical methods, thresholds, and exclusions.')
record_path.write_text(json.dumps(record, indent=2) + '\n')
spec = importlib.util.spec_from_file_location('frozen_delivery', original)
delivery = importlib.util.module_from_spec(spec)
spec.loader.exec_module(delivery)
# Keep the original source and its freeze intact. This explicit wrapper and
# amendment record disclose the sole changed execution setting.
delivery.LIMIT = 2_150_000
sys.argv = [str(original), '--study', str(study), '--families', 'haiku']
delivery.main()
