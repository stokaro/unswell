"""One local, offline inference per frozen editorial-judge request."""

import argparse
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import re
import resource
import signal
import socket
import time
import urllib.request

ROOT = Path(__file__).resolve().parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    with path.open("x") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")


def verify_freeze():
    freeze = read(ROOT / "freeze.json")
    for name, digest in freeze["files"].items():
        require(Path(name).name == name and sha((ROOT / name).read_bytes()) == digest, "Changed frozen input: " + name)
    return read(ROOT / "protocol.json")


def read_score(text, finish_reason):
    require(finish_reason == "stop", "Output did not finish with EOS")
    require(text.count("[RESULT]") == 1, "Missing or repeated result delimiter")
    match = re.fullmatch(r"(?s)(.+?)\[RESULT\]\s*([1-5])\s*", text)
    require(match is not None and len(match[1].strip()) >= 20, "Invalid result or missing substantive feedback")
    return int(match[2])


def preflight_decision(rows, expectations):
    require(len(rows) == len(expectations["cases"]) == 35, "Incomplete preflight inventory")
    require(len({r["id"] for r in rows}) == 35 and {r["id"] for r in rows} == set(expectations["cases"]), "Changed control identities")
    groups = {}
    for row in rows:
        expected = expectations["cases"][row["id"]]
        group = groups.setdefault(expected["group"], {"total": 0, "available": 0, "retained": 0, "correct": 0})
        group["total"] += 1
        group["available"] += row["status"] == "complete"
        group["retained"] += row["retained"]
        group["correct"] += row["status"] == "complete" and row["retained"] == expected["retain"]
    checks = {"useful_at_least_10_of_12": groups["useful"]["retained"] >= 10,
        "unsafe_at_most_1_of_12": groups["unsafe"]["retained"] <= 1 and groups["unsafe"]["available"] == 12,
        "optional_at_most_1_of_4": groups["optional"]["retained"] <= 1 and groups["optional"]["available"] == 4,
        "both_identifier_cases_correct": groups["identifier"]["correct"] == 2,
        "grammar_does_not_erase_rhetoric": groups["claim_loss"]["correct"] == 1,
        "context_at_least_3_of_4": groups["context"]["correct"] >= 3}
    return {"groups": groups, "checks": checks, "passed": all(checks.values()),
        "interpretation": "Constructed task-admission screen only, not real-document recall or product accuracy."}


def memory_guard(mx, protocol):
    limits = protocol["limits"]
    require(mx.get_peak_memory() <= limits["mlx_memory_bytes"], "MLX peak memory exceeded the fixed limit")
    require(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss <= limits["rss_peak_bytes"], "RSS peak exceeded the fixed limit")


def load_streamed(protocol):
    import mlx.core as mx
    from mlx_lm.models.llama import Model, ModelArgs
    from mlx_lm.utils import load_tokenizer

    require(importlib.metadata.version("mlx-lm") == protocol["backend"]["mlx_lm"], "Changed inference library")
    require(importlib.metadata.version("mlx") == protocol["backend"]["mlx"], "Changed tensor library")
    require(mx.metal.is_available(), "Metal backend unavailable")
    mx.set_memory_limit(protocol["limits"]["mlx_memory_bytes"])
    mx.set_cache_limit(protocol["limits"]["cache_bytes"])
    mx.random.seed(protocol["decoding"]["seed"])
    config = read(ROOT / "model/config.json")
    require(config["model_type"] == "mistral" and config.get("sliding_window") is None
        and config.get("torch_dtype") == "bfloat16" and "model_file" not in config
        and "auto_map" not in config and config["max_position_embeddings"] == 32768, "Unsupported checkpoint architecture")
    manifest = read(ROOT / "model-manifest.json")
    require(manifest["revision"] == protocol["revision"] and manifest["model"] == protocol["model"], "Changed checkpoint")
    for item in manifest["files"]:
        if item["kind"] == "metadata":
            require(sha((ROOT / "model" / item["name"]).read_bytes()) == item["sha256"], "Changed model metadata")
    weights, shards = {}, []
    started = time.monotonic()
    try:
        for item in manifest["files"]:
            if item["kind"] != "weight_shard":
                continue
            path = ROOT / "model" / item["name"]
            require(not path.exists(), "Never reuse a partial acquisition")
            url = "https://huggingface.co/" + manifest["model"] + "/resolve/" + manifest["revision"] + "/" + item["name"]
            digest, count = hashlib.sha256(), 0
            with urllib.request.urlopen(url, timeout=180) as response, path.open("xb") as handle:
                while chunk := response.read(2 * 1024**2):
                    count += len(chunk)
                    require(count <= item["bytes"], "Resource exceeds declared byte size")
                    digest.update(chunk)
                    handle.write(chunk)
            require(count == item["bytes"] and digest.hexdigest() == item["sha256"], "Checkpoint shard integrity failure")
            loaded = mx.load(str(path))
            require(not set(loaded).intersection(weights), "Duplicate checkpoint tensor")
            require(all(v.dtype == mx.bfloat16 for v in loaded.values()), "Unexpected checkpoint precision")
            mx.eval(list(loaded.values()))
            weights.update(loaded)
            path.unlink()
            shards.append({"name": item["name"], "bytes": count, "sha256": digest.hexdigest()})
            memory_guard(mx, protocol)
            print(json.dumps({"stage": "acquisition", "shard": item["name"], "verified": len(shards),
                "active_bytes": mx.get_active_memory(), "seconds": round(time.monotonic() - started, 2)}), flush=True)
        original_names = set(weights)
        index = read(ROOT / "model/model.safetensors.index.json")
        require(original_names == set(index["weight_map"]), "Incomplete original checkpoint")
        model = Model(ModelArgs.from_dict(config))
        sanitized = model.sanitize(weights)
        require(set(sanitized) == original_names, "Unexpected checkpoint-key transformation")
        model.load_weights(list(sanitized.items()), strict=True)
        model.eval()
        mx.eval(model.parameters())
        require(sum(v.nbytes for v in weights.values()) == index["metadata"]["total_size"], "Changed parameter inventory")
        record = {"model": protocol["model"], "revision": protocol["revision"], "shards": shards,
            "precision": "BF16, unquantized", "tensors": len(weights), "parameter_bytes": sum(v.nbytes for v in weights.values()),
            "temporary_shards_removed": True, "seconds": time.monotonic() - started,
            "mlx_peak_bytes": mx.get_peak_memory(), "rss_peak_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            "mlx_lm": importlib.metadata.version("mlx-lm"), "mlx": importlib.metadata.version("mlx")}
        write(ROOT / "acquisition-record.json", record)
        tokenizer = load_tokenizer(ROOT / "model", tokenizer_config_extra={"local_files_only": True, "trust_remote_code": False}, eos_token_ids=[2])
        require(tokenizer.bos_token_id == 1 and tokenizer.eos_token_id == 2, "Changed sequence boundary tokens")
        del sanitized, weights, loaded
        mx.clear_cache()
        memory_guard(mx, protocol)
        return model, tokenizer, mx
    finally:
        # Remove only scratch files acquired by this isolated task.
        for item in manifest["files"]:
            if item["kind"] == "weight_shard":
                path = ROOT / "model" / item["name"]
                if path.exists():
                    path.unlink()


def forbid_network():
    def denied(*args, **kwargs):
        raise RuntimeError("Network access is disabled during inference")
    socket.create_connection = denied
    socket.socket.connect = denied
    socket.socket.connect_ex = denied
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"


def timeout(*args):
    raise TimeoutError("Fixed inference time budget exhausted")


def execute_stage(name, requests, model, tokenizer, mx, protocol, seconds):
    from mlx_lm import stream_generate
    from mlx_lm.sample_utils import make_sampler
    started = time.monotonic()
    rows = []
    destination = ROOT / (name + "-predictions.jsonl")
    with destination.open("x") as handle:
        for request in requests:
            require(time.monotonic() - started < seconds, "Fixed stage budget exhausted")
            memory_guard(mx, protocol)
            row = {"id": request["id"], "request_sha256": sha(json.dumps(request, sort_keys=True).encode()),
                "status": "unavailable", "retained": False, "score": None}
            tic = time.monotonic()
            ids = tokenizer.apply_chat_template(request["messages"], tokenize=True, add_generation_prompt=True)
            row["input_tokens"] = len(ids)
            row["input_token_sha256"] = sha(json.dumps(ids).encode())
            if len(ids) + protocol["decoding"]["max_new_tokens"] > protocol["decoding"]["maximum_total_tokens"]:
                row["reason"] = "Complete source exceeds declared context; no truncation"
            else:
                text, last = "", None
                signal.setitimer(signal.ITIMER_REAL, min(protocol["limits"]["per_case_seconds"], seconds - (time.monotonic() - started)))
                try:
                    for last in stream_generate(model, tokenizer, ids, max_tokens=protocol["decoding"]["max_new_tokens"],
                            sampler=make_sampler(temp=0), prefill_step_size=protocol["decoding"]["prefill_step_size"]):
                        text += last.text
                        memory_guard(mx, protocol)
                    row["raw"] = text
                    row["finish_reason"] = last.finish_reason if last else None
                    row["output_tokens"] = last.generation_tokens if last else 0
                    try:
                        row["score"] = read_score(text, row["finish_reason"])
                        row.update(status="complete", retained=row["score"] >= 4)
                    except ValueError as error:
                        row["reason"] = str(error)
                finally:
                    signal.setitimer(signal.ITIMER_REAL, 0)
                    mx.clear_cache()
            row["seconds"] = time.monotonic() - tic
            if "page" in request:
                row["page"] = request["page"]
            handle.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
            handle.flush()
            rows.append(row)
            print(json.dumps({"stage": name, "completed": len(rows), "total": len(requests), "id": row["id"],
                "status": row["status"], "score": row["score"], "seconds": round(row["seconds"], 2)}), flush=True)
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute-local", action="store_true")
    args = parser.parse_args()
    protocol = verify_freeze()
    if not args.execute_local:
        print(json.dumps({"verified": True, "model_calls": 0, "phase": "offline preparation"}))
        return
    require(not (ROOT / "execution-started.json").exists(), "One execution only; do not retry a started run")
    write(ROOT / "execution-started.json", {"time": time.time(), "protocol_sha256": sha((ROOT / "protocol.json").read_bytes())})
    signal.signal(signal.SIGALRM, timeout)
    started = time.monotonic()
    record = {"version": "unswell-prometheus-necessity-run-v1", "status": "started", "phase": "acquisition", "new_external_model_calls": 0}
    try:
        model, tokenizer, mx = load_streamed(protocol)
        forbid_network()
        verify_freeze()
        record["phase"] = "preflight"
        controls = read(ROOT / "controls-requests.json")["requests"]
        rows = execute_stage("preflight", controls, model, tokenizer, mx, protocol, protocol["limits"]["preflight_seconds"])
        decision = preflight_decision(rows, read(ROOT / "control-expectations.json"))
        write(ROOT / "preflight-summary.json", decision)
        record["preflight"] = decision
        if decision["passed"]:
            record["phase"] = "development"
            requests = read(ROOT / "development-requests.json")["requests"]
            development = execute_stage("development", requests, model, tokenizer, mx, protocol, protocol["limits"]["development_seconds"])
            record["development"] = {"requests": len(development), "available": sum(r["status"] == "complete" for r in development),
                "retained": sum(r["retained"] for r in development), "quality_or_recall_claimed": False}
        else:
            record["development"] = {"requests": 0, "reason": "Fixed preflight failed; full development inference not started"}
        record.update(status="complete", phase="terminal", seconds=time.monotonic() - started,
            mlx_peak_bytes=mx.get_peak_memory(), rss_peak_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            product_qualified=False, prospective_pages_used=False)
        write(ROOT / "run-record.json", record)
        print(json.dumps(record, indent=2), flush=True)
    except BaseException as error:
        record.update(status="failed", error=type(error).__name__ + ": " + str(error), seconds=time.monotonic() - started,
            product_qualified=False, prospective_pages_used=False)
        write(ROOT / "run-record.json", record)
        raise


if __name__ == "__main__":
    main()
