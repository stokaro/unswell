"""Offline negative controls for the frozen experiment's decision boundary."""

import copy
import json
from pathlib import Path
import unittest

import run


class DecisionTests(unittest.TestCase):
    def checkpoint(self):
        root = Path(__file__).parent / "model"
        config = json.loads((root / "config.json").read_text())
        index = json.loads((root / "model.safetensors.index.json").read_text())
        hidden, intermediate, vocab = 4096, 14336, 32000
        shapes = {"model.embed_tokens.weight": (vocab, hidden), "lm_head.weight": (vocab, hidden), "model.norm.weight": (hidden,)}
        for layer in range(32):
            prefix = "model.layers.%d." % layer
            for projection in ["q", "o"]:
                shapes[prefix + "self_attn." + projection + "_proj.weight"] = (hidden, hidden)
            for projection in ["k", "v"]:
                shapes[prefix + "self_attn." + projection + "_proj.weight"] = (1024, hidden)
            for projection in ["gate", "up"]:
                shapes[prefix + "mlp." + projection + "_proj.weight"] = (intermediate, hidden)
            shapes[prefix + "mlp.down_proj.weight"] = (hidden, intermediate)
            for norm in ["input_layernorm", "post_attention_layernorm"]:
                shapes[prefix + norm + ".weight"] = (hidden,)
        return shapes, config, index

    def test_published_mergekit_index_without_optional_total_size(self):
        shapes, config, index = self.checkpoint()
        self.assertNotIn("total_size", index["metadata"])
        self.assertEqual(len(shapes), 291)
        self.assertEqual(run.verify_checkpoint_inventory(shapes, config, index), 14483464192)

    def test_wrong_shape_missing_tensor_or_conflicting_byte_count_rejected(self):
        shapes, config, index = self.checkpoint()
        altered = dict(shapes)
        altered["model.layers.0.self_attn.k_proj.weight"] = (4096, 4096)
        missing = dict(shapes)
        del missing["model.layers.0.self_attn.q_proj.weight"]
        conflicting = copy.deepcopy(index)
        conflicting["metadata"]["total_size"] = 1
        for shape_map, metadata in [(altered, index), (missing, index), (shapes, conflicting)]:
            with self.assertRaises(ValueError):
                run.verify_checkpoint_inventory(shape_map, config, metadata)

    def test_complete_integer_score(self):
        self.assertEqual(run.read_score("The criticism is grounded in the source and preserves its conditions. [RESULT] 4", "stop"), 4)

    def test_truncated_missing_repeated_or_out_of_range_score(self):
        for text, finish in [
            ("Enough feedback to describe this result. [RESULT] 4", "length"),
            ("Enough feedback but no final grade.", "stop"),
            ("Enough feedback. [RESULT] 4 [RESULT] 5", "stop"),
            ("Enough feedback to describe this result. [RESULT] 6", "stop"),
            ("Enough feedback to describe this result. [RESULT] 4.0", "stop"),
            ("Enough feedback to describe this result. [RESULT] 4 extra", "stop"),
            ("Good. [RESULT] 4", "stop"),
        ]:
            with self.subTest(text=text), self.assertRaises(ValueError):
                run.read_score(text, finish)

    def ideal(self):
        expectations = json.loads((Path(__file__).parent / "control-expectations.json").read_text())
        rows = [{"id": identity, "status": "complete", "retained": value["retain"]} for identity, value in expectations["cases"].items()]
        return rows, expectations

    def test_missing_or_duplicate_control_is_not_coverage(self):
        rows, expected = self.ideal()
        for altered in [rows[:-1], rows[:-1] + [rows[0]]]:
            with self.assertRaises(ValueError):
                run.preflight_decision(altered, expected)

    def test_two_unsafe_admissions_fail_the_fixed_screen(self):
        rows, expected = self.ideal()
        self.assertTrue(run.preflight_decision(rows, expected)["passed"])
        for row in [r for r in rows if expected["cases"][r["id"]]["group"] == "unsafe"][:2]:
            row["retained"] = True
        self.assertFalse(run.preflight_decision(rows, expected)["passed"])

    def test_unavailable_unsafe_case_is_not_a_safe_rejection(self):
        rows, expected = self.ideal()
        next(r for r in rows if expected["cases"][r["id"]]["group"] == "unsafe")["status"] = "unavailable"
        result = run.preflight_decision(rows, expected)
        self.assertFalse(result["checks"]["unsafe_at_most_1_of_12"])
        self.assertFalse(result["passed"])

    def test_grammar_only_resolution_and_identifier_loss_each_fail(self):
        original, expected = self.ideal()
        targets = [identity for identity, case in expected["cases"].items()
            if case["group"] == "claim_loss" or case["group"] == "identifier" and not case["retain"]]
        for identity in targets:
            rows = copy.deepcopy(original)
            next(r for r in rows if r["id"] == identity)["retained"] = True
            with self.subTest(identity=identity):
                self.assertFalse(run.preflight_decision(rows, expected)["passed"])


if __name__ == "__main__":
    unittest.main()
