package unswell_test

import (
	"strings"
	"testing"

	qt "github.com/frankban/quicktest"
)

func TestSubjectCleftWording(t *testing.T) {
	for _, text := range []string{
		"The marker is what prevents the older version from returning.",
		"The coordinator is what selects the next worker.",
		"The callbacks are what keep the stream open.",
		"The marker was what selected the older version.",
		"The result includes the version, which is what makes the entry reproducible.",
		"The marker is what selects `version_2` after the update.",
	} {
		t.Run(text, func(t *testing.T) {
			c := qt.New(t)
			r := singleRuleResult(t, "syntax.subject-cleft", text, "", "")
			c.Assert(r.Findings, qt.HasLen, 1)
			f := r.Findings[0]
			c.Assert(text[f.Primary.Span.Start:f.Primary.Span.End], qt.Equals, f.Primary.Snippet)
			c.Assert(f.Evidence.Suggestion, qt.Not(qt.Equals), "")
		})
	}
}

func TestSubjectCleftControls(t *testing.T) {
	for _, text := range []string{
		"The marker is what the reader checks.",
		"The response is what a server returns.",
		"The marker is what was selected.",
		"The marker is not what selects the version.",
		"The marker, not the filename, is what selects the version.",
		"The scope selector is what makes the result valid — an empty directory passes only with the selector.",
		"The reader does not guess the version — guessing is what makes the result stale.",
		"Each member keeps its own renderer, which is what lets one dialect use bare names while the rest quote.",
		"The first pass writes a report; the second pass is what fails the step, but only when violations remain.",
		"Only the marker is what selects the version.",
		"The term is what means a stored version.",
		"The marker is what `selects` the version.",
		"The marker is `what selects` the version.",
		"The guide says the marker is what selects the version.",
		"\"The marker is what selects the version.\"",
		"Is the marker what selects the version?",
		"The marker selects the version.",
		"This is what matters.",
	} {
		t.Run(text, func(t *testing.T) {
			qt.New(t).Assert(singleRuleResult(t, "syntax.subject-cleft", text, "", "").Findings, qt.HasLen, 0)
		})
	}
}

func TestRedundantGrammaticalSupport(t *testing.T) {
	for _, text := range []string{
		"The renderer also supports custom labels as well.",
		"Also, connectors can be used in reverse directions as well.",
		"In addition to labels, the renderer also supports colors.",
		"Use separators like, for example, blank lines.",
		"Create a worker and then finally start the listener.",
	} {
		t.Run(text, func(t *testing.T) {
			qt.New(t).Assert(singleRuleResult(t, "repetition.redundant-support", text, "", "").Findings, qt.HasLen, 1)
		})
	}
}

func TestRedundantGrammaticalSupportControls(t *testing.T) {
	for _, text := range []string{
		"The renderer also supports custom labels as well as colors.",
		"The renderer also parses labels, but the reader accepts colors as well.",
		"The renderer supports labels, and the reader supports them as well.",
		"The renderer also supports labels that the reader parses as well.",
		"The renderer does not support labels as well as the reader.",
		"In addition to labels, the renderer supports colors.",
		"The payload looks like, for example, an event.",
		"Start the worker, then connect, and finally close the stream.",
		"The renderer `also` supports labels as well.",
		"The renderer also supports labels `as well`.",
		"The guide says the renderer also supports labels as well.",
		"\"The renderer also supports labels as well.\"",
	} {
		t.Run(text, func(t *testing.T) {
			qt.New(t).Assert(singleRuleResult(t, "repetition.redundant-support", text, "", "").Findings, qt.HasLen, 0)
		})
	}
}

func TestStructuralWordingMappingAndExemptions(t *testing.T) {
	for _, row := range []struct{ id, text string }{
		{"syntax.subject-cleft", "The café marker is what selects the version"},
		{"repetition.redundant-support", "The renderer also supports café labels as well"},
	} {
		c := qt.New(t)
		text := "\ufeff" + strings.Replace(row.text, "café", "**café**", 1) + ".\r\n"
		r := singleRuleResult(t, row.id, text, "", "")
		c.Assert(r.Findings, qt.HasLen, 1)
		c.Assert(r.Findings[0].Primary.Span.Start, qt.Equals, len("\ufeff"))
		c.Assert(r.Findings[0].Primary.Snippet, qt.Equals, strings.TrimSuffix(strings.TrimPrefix(text, "\ufeff"), ".\r\n"))
		c.Assert(singleRuleResult(t, row.id, row.text+".", "", windowTerm(row.id, row.text)).Findings, qt.HasLen, 0)
		c.Assert(singleRuleResult(t, row.id, row.text+".", "{allowed_occurrences: 1, saturation_occurrences: 2}", "").Findings,
			qt.HasLen, 0)
	}
}
