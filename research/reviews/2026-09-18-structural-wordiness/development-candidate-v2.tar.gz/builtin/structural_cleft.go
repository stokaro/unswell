package builtin

import "github.com/stokaro/unswell/document"

func subjectCleft(clauses []frameClause, index int) (rhetoricalFrame, bool) {
	c := clauses[index]
	if !c.eligible() || len(c.sentence.Tokens) > 96 || rhetoricQuoted(c) || rhetoricAttributed(c) {
		return rhetoricalFrame{}, false
	}
	tokens := c.tokens()
	if cleftFocus(c.sentence.Tokens) {
		return rhetoricalFrame{}, false
	}
	for i := 1; i+3 < len(tokens); i++ {
		if cleftPredicate(tokens[i:]) {
			if start, ok := cleftSubject(tokens[:i]); ok {
				return localFrame(c, start)
			}
		}
	}
	return rhetoricalFrame{}, false
}

func cleftPredicate(tokens []document.Token) bool {
	return frameWord(tokens[0], "is", "are", "was", "were") && frameWord(tokens[1], "what") &&
		cleftAction(tokens[2:])
}

func cleftSubject(tokens []document.Token) (int, bool) {
	for i := len(tokens) - 1; i > 0; i-- {
		if frameWord(tokens[i], "which") && frameWord(tokens[i-1], ",") {
			return i, i+1 == len(tokens)
		}
	}
	if len(tokens) == 1 && frameWord(tokens[0], "which") {
		return 0, true
	}
	return 0, len(tokens) <= 12 && projectionSubject(tokens) &&
		!frameWord(tokens[0], "this", "that", "it", "what", "who")
}

func cleftAction(tokens []document.Token) bool {
	if len(tokens) < 2 || tokens[0].Protected || !tokens[0].Word {
		return false
	}
	if frameWord(tokens[0], "is", "are", "was", "were", "be", "has", "have", "had",
		"means", "mean", "meant", "seems", "seem", "does", "do", "did", "matters", "exists") {
		return false
	}
	return (finiteWord(tokens[0]) && tokens[0].Tag != "MD" || tokens[0].Tag == "VB") && actionOperand(tokens)
}

func finiteWord(token document.Token) bool {
	return !token.Protected && token.Word &&
		(token.Tag == "VBZ" || token.Tag == "VBP" || token.Tag == "VBD" || token.Tag == "MD")
}

func cleftFocus(tokens []document.Token) bool {
	for _, token := range tokens {
		if frameWord(token, "only", "not", "n't", "never", "rather", "instead", "unlike", "whereas", "while", "but",
			"exactly", "precisely", "sole", "definition", "defined", "called", "term") {
			return true
		}
	}
	return false
}
