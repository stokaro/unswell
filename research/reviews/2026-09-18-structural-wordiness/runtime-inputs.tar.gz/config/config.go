// Package config compiles strict, offline YAML policy against an explicit catalog.
package config

import (
	"bytes"
	"errors"
	"fmt"
	"io"
	"slices"
	"strings"

	"go.yaml.in/yaml/v3"

	"github.com/stokaro/unswell/extract"
	"github.com/stokaro/unswell/rule"
	"github.com/stokaro/unswell/ruleset"
)

// Threshold gates eligible units at or above FailAt index points.
type Threshold struct {
	FailAt   int `json:"fail_at"   yaml:"fail_at"`
	MinWords int `json:"min_words" yaml:"min_words"`
}

// ProbabilityGate fails a run on a calibrated revision probability. It is absent
// unless a policy configures it, so gate identities are otherwise unchanged.
// Require covers an absent estimate that the pack's own applicability policy
// does not explain, such as an unavailable column or a score outside the fitted
// calibration range. Declared limits, a short unit or another unit kind, stay
// expected abstentions and never fail this gate.
type ProbabilityGate struct {
	FailAt  float64 `json:"fail_at" yaml:"fail_at"`
	Require bool    `json:"require" yaml:"require"`
}

// Gate is independent of reporter filtering and severity.
type Gate struct {
	Mode             string           `json:"mode"              yaml:"mode"`
	Sentence         Threshold        `json:"sentence_score"     yaml:"sentence_score"`
	Paragraph        Threshold        `json:"paragraph_score"    yaml:"paragraph_score"`
	Probability      *ProbabilityGate `json:"probability,omitempty" yaml:"probability,omitempty"`
	FailOnEmpty      bool             `json:"fail_on_empty"      yaml:"fail_on_empty"`
	FailOnIncomplete bool             `json:"fail_on_incomplete" yaml:"fail_on_incomplete"`
}

// Analysis bounds the amount of work performed on untrusted documents.
type Analysis struct {
	NLP             string `json:"nlp"              yaml:"nlp"`
	RequireComplete bool   `json:"require_complete" yaml:"require_complete"`
	MaxFileBytes    int    `json:"max_file_bytes"   yaml:"max_file_bytes"`
	MaxTotalBytes   int    `json:"max_total_bytes"  yaml:"max_total_bytes"`
	MaxBlocks       int    `json:"max_blocks"       yaml:"max_blocks"`
	MaxTokens       int    `json:"max_tokens"       yaml:"max_tokens"`
	MaxFindings     int    `json:"max_findings"     yaml:"max_findings"`
	MaxCandidates   int    `json:"max_candidates"   yaml:"max_candidates"`
	IncludeQuotes   bool   `json:"include_quotes"   yaml:"include_quotes"`
}

// Files controls recursive discovery in the CLI. Library calls use explicit sources.
type Files struct {
	Include []string `json:"include" yaml:"include"`
	Exclude []string `json:"exclude" yaml:"exclude"`
}

// Suppressions controls explicit source permissions without changing raw evidence.
type Suppressions struct {
	RequireReason bool `json:"require_reason" yaml:"require_reason"`
	AllowFileWide bool `json:"allow_file_wide" yaml:"allow_file_wide"`
	RejectUnused  bool `json:"reject_unused" yaml:"reject_unused"`
}

// Calibration selects an explicitly supplied revision-probability pack. It is
// absent unless a policy requests one, so model-free identities are unchanged.
// OnIncompatible chooses between an unavailable estimate and an operational
// failure when a source's effective measurement inputs differ from the pack.
type Calibration struct {
	Model              string `json:"model"`
	OnIncompatible     string `json:"on_incompatible"`
	AcceptExperimental bool   `json:"accept_experimental"`
}

// Origin selects an explicitly supplied origin pack. The channel is off unless a
// policy requests it. An origin estimate is a similarity to a defined training
// class, never a quality judgment and never a share of a text written by a tool.
// It cannot decide a gate, so this section has no threshold.
type Origin struct {
	Model              string `json:"model"`
	OnIncompatible     string `json:"on_incompatible"`
	AcceptExperimental bool   `json:"accept_experimental"`
}

// Policy is an effective policy with provenance and a canonical content hash.
type Policy struct {
	Identity         string                   `json:"identity"`
	Version          int                      `json:"version"`
	Profile          string                   `json:"profile"`
	Language         string                   `json:"language"`
	Rules            map[string]rule.Settings `json:"rules"`
	Gate             Gate                     `json:"gate"`
	Analysis         Analysis                 `json:"analysis"`
	Files            Files                    `json:"files"`
	Extraction       extract.Policy           `json:"extraction"`
	GroupCaps        map[string]int           `json:"group_caps"`
	Origins          map[string]string        `json:"origins"`
	Hash             string                   `json:"hash"`
	RuleSets         []rule.Origin            `json:"rule_sets,omitempty"`
	Vocabulary       Vocabulary               `json:"vocabulary"`
	Suppressions     Suppressions             `json:"suppressions"`
	Calibration      *Calibration             `json:"calibration,omitempty"`
	Origin           *Origin                  `json:"origin,omitempty"`
	Sources          []SourceIdentity         `json:"sources,omitempty"`
	Overrides        []OverrideIdentity       `json:"overrides,omitempty"`
	AppliedOverrides []string                 `json:"applied_overrides,omitempty"`
}

type input struct {
	Version      int                  `yaml:"version"`
	Extends      []string             `yaml:"extends"`
	Language     string               `yaml:"language"`
	Rules        map[string]yaml.Node `yaml:"rules"`
	Gate         yaml.Node            `yaml:"gate"`
	Analysis     yaml.Node            `yaml:"analysis"`
	Files        yaml.Node            `yaml:"files"`
	Extraction   yaml.Node            `yaml:"extraction"`
	RuleSets     []yaml.Node          `yaml:"rule_sets"`
	Vocabulary   yaml.Node            `yaml:"vocabulary"`
	Suppressions yaml.Node            `yaml:"suppressions"`
	Overrides    []overrideInput      `yaml:"overrides"`
	Calibration  struct {
		Model              string `yaml:"model"`
		OnIncompatible     string `yaml:"on_incompatible"`
		AcceptExperimental bool   `yaml:"accept_experimental"`
	} `yaml:"calibration"`
	Origin struct {
		Model              string `yaml:"model"`
		OnIncompatible     string `yaml:"on_incompatible"`
		AcceptExperimental bool   `yaml:"accept_experimental"`
	} `yaml:"origin"`
}

// Load returns the base policy for a single in-memory configuration. Use
// CompileBundle for local dependencies and per-file resolution, or Compile when
// the caller also needs implementations from inline rule_sets.
func Load(data []byte, catalog []rule.Descriptor) (Policy, error) {
	policy, _, err := Compile(data, catalog)
	return policy, err
}

// Compile returns the effective policy and additional rules declared in rule_sets.
// The caller supplies the existing catalog; duplicate IDs always fail. All input
// and ruleset definitions are bytes in memory, with no implicit file loading.
func Compile(data []byte, catalog []rule.Descriptor) (Policy, []rule.Rule, error) {
	plan, additional, err := CompileBundle(Bundle{Root: ".unswell.yaml", Files: map[string][]byte{".unswell.yaml": data}}, catalog)
	if err != nil {
		return Policy{}, nil, err
	}
	policy, err := plan.Policy()
	return policy, additional, err
}

func compileRuleSets(nodes []yaml.Node) ([]rule.Rule, error) {
	if len(nodes) > 10 {
		return nil, fmt.Errorf("configuration exceeds 10 rule_sets")
	}
	var implementations []rule.Rule
	for _, node := range nodes {
		data, err := yaml.Marshal(node)
		if err != nil {
			return nil, err
		}
		set, err := ruleset.Load(data)
		if err != nil {
			return nil, err
		}
		implementations = append(implementations, set.Rules()...)
	}
	return implementations, nil
}

func catalogOrigins(catalog []rule.Descriptor) []rule.Origin {
	var origins []rule.Origin
	for _, descriptor := range catalog {
		if descriptor.Origin != nil && !slices.Contains(origins, *descriptor.Origin) {
			origins = append(origins, *descriptor.Origin)
		}
	}
	slices.SortFunc(origins, func(a, b rule.Origin) int {
		return strings.Compare(a.Namespace+"/"+a.Version+"/"+a.Hash, b.Namespace+"/"+b.Version+"/"+b.Hash)
	})
	return origins
}

func loadInput(data []byte) (input, error) {
	var raw input
	if len(data) > 1<<20 {
		return raw, fmt.Errorf("configuration exceeds 1 MiB")
	}
	if len(bytes.TrimSpace(data)) == 0 {
		raw.Version = 1
		return raw, nil
	}
	if err := validateYAML(data); err != nil {
		return raw, err
	}
	if err := decode(data, &raw); err != nil {
		return raw, err
	}
	return raw, validateInput(raw)
}

func validateYAML(data []byte) error {
	var node yaml.Node
	if err := decode(data, &node); err != nil {
		return err
	}
	return rejectAliasesAndNull(&node, 0)
}

func validateInput(raw input) error {
	if raw.Version != 1 {
		return fmt.Errorf("unsupported config version %d", raw.Version)
	}
	if raw.Language != "" && raw.Language != "en" {
		return fmt.Errorf("unsupported language %q", raw.Language)
	}
	if err := validateCalibration(raw); err != nil {
		return err
	}
	return validateOrigin(raw)
}

func decode(data []byte, target any) error {
	decoder := yaml.NewDecoder(bytes.NewReader(data))
	decoder.KnownFields(true)
	if err := decoder.Decode(target); err != nil {
		return fmt.Errorf("configuration: %w", err)
	}
	var extra yaml.Node
	if err := decoder.Decode(&extra); !errors.Is(err, io.EOF) {
		if err != nil {
			return fmt.Errorf("configuration: %w", err)
		}
		return fmt.Errorf("configuration must contain one YAML document")
	}
	return nil
}

func resolveProfile(extends []string) (string, error) {
	profile := "technical"
	if len(extends) > 1 {
		return "", fmt.Errorf("alpha configuration accepts one builtin profile")
	}
	if len(extends) == 1 {
		if !strings.HasPrefix(extends[0], "builtin:") {
			return "", fmt.Errorf("alpha extends requires a builtin profile")
		}
		profile = strings.TrimPrefix(extends[0], "builtin:")
		profile = strings.TrimSuffix(profile, "-v1")
	}
	if !slices.Contains([]string{"technical", "strict", "minimal", "business", "reference", "custom"}, profile) {
		return "", fmt.Errorf("unknown profile %q", profile)
	}
	return profile, nil
}

func defaults(profile string, catalog []rule.Descriptor) (Policy, error) {
	policy := Policy{
		Identity:     "unswell-config-bundle-v1",
		Version:      1,
		Profile:      profile + "-v1",
		Language:     "en",
		Extraction:   extract.Policy{Contexts: extract.DefaultContexts(), GitHubActions: "shell", GoComments: "godoc"},
		Rules:        make(map[string]rule.Settings),
		Origins:      make(map[string]string),
		Suppressions: Suppressions{RequireReason: true, RejectUnused: true},
		Gate: Gate{
			Mode:             "all",
			Sentence:         Threshold{FailAt: 80, MinWords: 12},
			Paragraph:        Threshold{FailAt: 65, MinWords: 30},
			FailOnEmpty:      true,
			FailOnIncomplete: true,
		},
		Analysis: Analysis{
			NLP:             "builtin-en",
			RequireComplete: true,
			MaxFileBytes:    2 << 20,
			MaxTotalBytes:   100 << 20,
			MaxBlocks:       10000,
			MaxTokens:       200000,
			MaxFindings:     10000,
			MaxCandidates:   100000,
		},
		Files: Files{
			Include: defaultIncludes(),
			Exclude: []string{".git/**", "vendor/**", "testdata/**", "artifacts/**", "dist/**", "rules/**", "**/*.generated.go"},
		},
		GroupCaps: map[string]int{
			"scaffolding":         40,
			"inflation":           35,
			"rhetorical-patterns": 35,
			"syntax-load":         40,
			"repetition":          45,
			"readability":         25,
		},
	}
	for _, descriptor := range catalog {
		if _, exists := policy.Rules[descriptor.ID]; exists {
			return Policy{}, fmt.Errorf("duplicate rule ID %q", descriptor.ID)
		}
		settings := descriptor.Defaults
		applyProfile(profile, descriptor.ID, &settings)
		policy.Rules[descriptor.ID] = settings
		policy.Origins["rules."+descriptor.ID] = "builtin:" + profile + "-v1"
		if descriptor.Origin != nil {
			policy.Origins["rules."+descriptor.ID] = "ruleset:" + descriptor.Origin.Namespace + "@" + descriptor.Origin.Version
		}
	}
	if profile == "strict" {
		policy.Gate.Paragraph.FailAt = 50
		policy.Gate.Sentence.FailAt = 65
	}
	return policy, nil
}

func defaultIncludes() []string {
	return []string{
		"**/*.md", "**/*.markdown", "**/*.mdx", "**/*.txt", "**/*.go", "**/*.js", "**/*.jsx", "**/*.mjs", "**/*.cjs",
		"**/*.ts", "**/*.mts", "**/*.cts", "**/*.tsx", "**/*.py", "**/*.pyi", "**/*.rs", "**/*.java",
		"**/*.c", "**/*.h", "**/*.C", "**/*.cc", "**/*.cpp", "**/*.cxx", "**/*.hpp", "**/*.hh", "**/*.hxx",
		"**/*.cs", "**/*.csx", "**/*.yaml", "**/*.yml",
		"**/*.sh", "**/*.bash", "**/*.zsh", "**/*.fish", "**/*.ps1", "**/*.psm1", "**/*.psd1",
		"**/.bashrc", "**/.bash_profile", "**/.bash_login", "**/.bash_logout", "**/.profile",
		"**/.zshrc", "**/.zprofile", "**/.zshenv", "**/.zlogin", "**/.zlogout",
	}
}

func applyProfile(profile, id string, settings *rule.Settings) {
	switch profile {
	case "strict":
		applyStrict(id, settings)
	case "minimal":
		settings.Enabled = settings.Gate == "forbid" || id == "repetition.exact-sentence"
	case "business":
		if slices.Contains([]string{"scaffold.follow-up-offer", "scaffold.chat-preamble"}, id) {
			settings.Enabled = false
		}
	case "reference":
		if referenceDisabled(id) {
			settings.Enabled = false
		}
	case "custom":
		settings.Enabled = false
	}
}

// applyStrict raises the rules a strict reader expects: the stock assistant
// tells become gate failures, and the one surface measurement that separates
// generated prose from human prose is turned on.
func applyStrict(id string, settings *rule.Settings) {
	if strictForbid(id) {
		settings.Gate = "forbid"
		settings.Severity = "error"
	}
	if strictSurface(id) {
		settings.Enabled = true
	}
}

// strictSurface names the surface measurements the strict profile turns on.
// Surface measurements are opt-in because they establish no error and no need
// for revision, and that stays true here: this one is a warning, carries no
// score, and decides no gate. It is on in the strict profile because it is the
// one measurement that separates generated prose from human prose on every
// corpus measured. Per thousand prose words: 11.3 em dashes in a documentation
// tree stated to be generated and never proofread, 0.8 in a second generated
// corpus, 0.0 in human specification prose, 0.04 in human code comments. It
// counts density rather than presence, so a paragraph with one em dash is never
// reported.
func strictSurface(id string) bool {
	return id == "format.em-dash-density"
}

func strictForbid(id string) bool {
	return strings.HasPrefix(id, "scaffold.") ||
		slices.Contains([]string{"filler.announced-importance", "filler.modern-world-opening"}, id)
}

func referenceDisabled(id string) bool {
	return strings.HasPrefix(id, "repetition.") && id != "repetition.exact-sentence"
}

func applyNodes(raw input, policy *Policy, catalog []rule.Descriptor) error {
	ids := make([]string, 0, len(raw.Rules))
	for id := range raw.Rules {
		ids = append(ids, id)
	}
	slices.Sort(ids)
	for _, id := range ids {
		node := raw.Rules[id]
		settings, ok := policy.Rules[id]
		if !ok {
			return fmt.Errorf("unknown rule ID %q", id)
		}
		if err := validateRuleNode(id, node, catalog); err != nil {
			return err
		}
		if err := mergeNode(node, &settings); err != nil {
			return fmt.Errorf("%s: %w", id, err)
		}
		policy.Rules[id] = settings
		policy.Origins["rules."+id] = "project configuration"
	}
	if err := applyPolicyNodes(raw, policy); err != nil {
		return err
	}
	applyCalibration(raw, policy)
	applyOrigin(raw, policy)
	return nil
}

// applyOrigin keeps an absent origin channel out of the policy identity, so a
// run without it preserves its existing hashes and accepted debt.
func applyOrigin(raw input, policy *Policy) {
	switch raw.Origin.Model {
	case "pack":
		policy.Origin = &Origin{Model: "pack", OnIncompatible: incompatibilityPolicy(raw.Origin.OnIncompatible),
			AcceptExperimental: raw.Origin.AcceptExperimental}
	case "none":
		policy.Origin = nil
	}
}

// applyCalibration keeps an absent model out of the policy identity, so
// model-free runs preserve their existing hashes and accepted debt.
func applyCalibration(raw input, policy *Policy) {
	switch raw.Calibration.Model {
	case "pack":
		policy.Calibration = &Calibration{Model: "pack", OnIncompatible: incompatibilityPolicy(raw.Calibration.OnIncompatible),
			AcceptExperimental: raw.Calibration.AcceptExperimental}
	case "none":
		policy.Calibration = nil
	}
}

func incompatibilityPolicy(value string) string {
	if value == "" {
		return "unavailable"
	}
	return value
}

// validateOrigin accepts the same explicit shape as calibration. The channel is
// experimental research and never gates, so it has no threshold to validate.
func validateOrigin(raw input) error {
	origin := raw.Origin
	if !slices.Contains([]string{"", "none", "pack"}, origin.Model) {
		return fmt.Errorf("unsupported origin model %q", origin.Model)
	}
	if !slices.Contains([]string{"", "unavailable", "fail"}, origin.OnIncompatible) {
		return fmt.Errorf("invalid origin incompatibility policy %q", origin.OnIncompatible)
	}
	if origin.Model != "pack" && (origin.OnIncompatible != "" || origin.AcceptExperimental) {
		return fmt.Errorf("origin options require an explicit model")
	}
	return nil
}

func validateCalibration(raw input) error {
	calibration := raw.Calibration
	if !slices.Contains([]string{"", "none", "pack"}, calibration.Model) {
		return fmt.Errorf("unsupported calibration model %q", calibration.Model)
	}
	if !slices.Contains([]string{"", "unavailable", "fail"}, calibration.OnIncompatible) {
		return fmt.Errorf("invalid calibration incompatibility policy %q", calibration.OnIncompatible)
	}
	if calibration.Model != "pack" && (calibration.OnIncompatible != "" || calibration.AcceptExperimental) {
		return fmt.Errorf("calibration options require an explicit model")
	}
	return nil
}

func validateRuleNode(id string, node yaml.Node, catalog []rule.Descriptor) error {
	for _, descriptor := range catalog {
		if descriptor.ID != id {
			continue
		}
		if err := validateParameterNames(node, descriptor.Parameters); err != nil {
			return fmt.Errorf("%s: %w", id, err)
		}
	}
	return nil
}

func applyPolicyNodes(raw input, policy *Policy) error {
	for _, item := range []struct {
		node   yaml.Node
		target any
	}{{raw.Gate, &policy.Gate}, {raw.Analysis, &policy.Analysis}, {raw.Files, &policy.Files}, {raw.Extraction, &policy.Extraction},
		{raw.Vocabulary, &policy.Vocabulary}, {raw.Suppressions, &policy.Suppressions}} {
		if item.node.Kind != 0 {
			if err := mergeNode(item.node, item.target); err != nil {
				return err
			}
		}
	}
	return nil
}

func mergeNode(node yaml.Node, target any) error {
	if err := rejectAliasesAndNull(&node, 0); err != nil {
		return err
	}
	var base yaml.Node
	if err := base.Encode(target); err != nil {
		return err
	}
	mergeMapping(&base, node)
	data, err := yaml.Marshal(base)
	if err != nil {
		return err
	}
	return decode(data, target)
}

// mergeMapping preserves map entries recursively; scalars and lists replace.
func mergeMapping(base *yaml.Node, overlay yaml.Node) {
	if base.Kind != yaml.MappingNode || overlay.Kind != yaml.MappingNode {
		*base = overlay
		return
	}
	for i := 0; i+1 < len(overlay.Content); i += 2 {
		key, value := overlay.Content[i], overlay.Content[i+1]
		old := nodeField(*base, key.Value)
		if old == nil {
			base.Content = append(base.Content, key, value)
		} else {
			mergeMapping(old, *value)
		}
	}
}

func rejectAliasesAndNull(node *yaml.Node, depth int) error {
	if depth > 32 {
		return fmt.Errorf("YAML nesting exceeds 32")
	}
	if node.Kind == yaml.AliasNode || node.Tag == "!!null" {
		return fmt.Errorf("YAML aliases and null overrides are not supported")
	}
	if node.Kind == yaml.MappingNode {
		if err := validateMappingKeys(node); err != nil {
			return err
		}
	}
	for _, child := range node.Content {
		if err := rejectAliasesAndNull(child, depth+1); err != nil {
			return err
		}
	}
	return nil
}

func validateMappingKeys(node *yaml.Node) error {
	seen := make(map[string]bool)
	for i := 0; i+1 < len(node.Content); i += 2 {
		key := node.Content[i]
		if key.Kind != yaml.ScalarNode || key.Tag != "!!str" {
			return fmt.Errorf("configuration mapping keys must be strings")
		}
		if seen[key.Value] {
			return fmt.Errorf("duplicate configuration key %q", key.Value)
		}
		seen[key.Value] = true
	}
	return nil
}

func validateParameterNames(node yaml.Node, allowed []string) error {
	for i := 0; i+1 < len(node.Content); i += 2 {
		if node.Content[i].Value != "parameters" {
			continue
		}
		params := node.Content[i+1]
		for j := 0; j+1 < len(params.Content); j += 2 {
			if !slices.Contains(allowed, params.Content[j].Value) {
				return fmt.Errorf("unknown parameter %q", params.Content[j].Value)
			}
		}
	}
	return nil
}
