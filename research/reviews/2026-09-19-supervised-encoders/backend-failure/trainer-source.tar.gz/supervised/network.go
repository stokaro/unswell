package main

import (
	"context"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"slices"

	"github.com/gomlx/compute/dtypes"
	"github.com/gomlx/gomlx/core/graph"
	"github.com/gomlx/gomlx/core/tensors"
	"github.com/gomlx/gomlx/ml/model"
	"github.com/gomlx/gomlx/ml/train"
	"github.com/gomlx/gomlx/ml/train/loss"
	"github.com/gomlx/gomlx/ml/train/optimizer"
	"github.com/knights-analytics/hugot"
	"github.com/knights-analytics/hugot/backends"
	"github.com/knights-analytics/hugot/pipelines"
)

type head struct {
	Weights [][]float32 `json:"weights"`
	Bias    []float32   `json:"bias"`
	Scales  [][]float32 `json:"scales"`
}
type network struct {
	session    *hugot.Session
	graph      *backends.GoMLXModel
	exec       *model.Exec
	trainer    *train.Trainer
	names      []string
	original   []byte
	parameters map[string]bool
}

func rawHead(p parameters) head {
	h := head{Weights: make([][]float32, 128), Scales: make([][]float32, 128), Bias: []float32{0}}
	bias := p.Intercept
	for i := range h.Weights {
		h.Weights[i] = []float32{float32(p.Weights[i] / p.Scales[i])}
		h.Scales[i] = []float32{float32(p.Scales[i])}
		bias -= p.Weights[i] * p.Means[i] / p.Scales[i]
	}
	h.Bias[0] = float32(bias)
	return h
}
func newNetwork(ctx context.Context, dir, filename, kind string, h head) (*network, *pipelines.FeatureExtractionPipeline, error) {
	s, err := hugot.NewGoSession(ctx)
	if err != nil {
		return nil, nil, err
	}
	p, err := hugot.NewPipeline(s, hugot.FeatureExtractionConfig{ModelPath: dir, OnnxFilename: filename, Name: "supervised"})
	if err != nil {
		_ = s.Destroy()
		return nil, nil, err
	}
	n := &network{session: s, graph: p.Model.GoMLXModel}
	g := n.graph
	g.OnnxModel.DisableFusion()
	n.original, err = os.ReadFile(filepath.Join(dir, filename))
	if err != nil {
		_ = s.Destroy()
		return nil, nil, err
	}
	n.parameters, err = parameterNames(n.original)
	if err != nil {
		_ = s.Destroy()
		return nil, nil, err
	}
	g.Store.SetParam(model.ParamInitialSeed, int64(42))
	for variable := range g.Store.IterVariables() {
		active := kind == "FT" && n.parameters[variable.Name()]
		variable.SetTrainable(active)
		if active {
			n.names = append(n.names, variable.Name())
		}
	}
	slices.Sort(n.names)
	fn := func(scope *model.Scope, inputs []*graph.Node) []*graph.Node {
		hidden := g.Call(scope, inputs)[0]
		// Importer-created constants are never neural parameters.
		for variable := range g.Store.RootScope().In("ONNX").IterVariables() {
			variable.SetTrainable(kind == "FT" && n.parameters[variable.Name()])
		}
		bs, seq := inputs[0].Shape().Dim(0), inputs[0].Shape().Dim(1)
		mask := graph.ConvertDType(graph.BroadcastToShape(graph.Reshape(inputs[1], bs, seq, 1), hidden.Shape()), dtypes.Bool)
		pooled := graph.L2Normalize(graph.MaskedReduceMean(hidden, mask, 1), -1)
		hs := scope.In("editorial_head")
		w := hs.VariableWithValue("weights", h.Weights).NodeValue(inputs[0].Graph())
		b := hs.VariableWithValue("bias", h.Bias).NodeValue(inputs[0].Graph())
		scales := graph.Const(inputs[0].Graph(), h.Scales)
		train.AddRegularizationLoss(graph.MulScalar(graph.ReduceAllSum(graph.Square(graph.Mul(w, scales))), .005))
		y := graph.MatMul(pooled, w)
		return []*graph.Node{graph.Add(y, graph.ExpandLeftToRank(b, y.Rank()))}
	}
	n.exec, err = model.NewExec(g.Backend, g.Store, fn)
	if err != nil {
		_ = s.Destroy()
		return nil, nil, err
	}
	n.exec.SetMaxCache(16)
	n.trainer = train.NewTrainer(g.Backend, g.Store, func(scope *model.Scope, _ any, inputs []*graph.Node) []*graph.Node { return fn(scope, inputs) }, loss.BinaryCrossentropyLogits, optimizer.Adam().LearningRate(1e-4).Betas(.9, .999).Epsilon(1e-7).WeightDecay(0).WithBackoffSteps(0).Done(), nil, nil)
	return n, p, nil
}
func (n *network) close() { n.exec.Finalize(); _ = n.session.Destroy() }
func inputs(rows []example, indices []int) []*tensors.Tensor {
	maxLength := 0
	for _, i := range indices {
		maxLength = max(maxLength, len(rows[i].ids))
	}
	width := 32
	for width < maxLength {
		width *= 2
	}
	ids, mask, types := make([][]int64, len(indices)), make([][]int64, len(indices)), make([][]int64, len(indices))
	for j, i := range indices {
		ids[j], mask[j], types[j] = make([]int64, width), make([]int64, width), make([]int64, width)
		copy(ids[j], rows[i].ids)
		for k := range rows[i].ids {
			mask[j][k] = 1
		}
	}
	return []*tensors.Tensor{tensors.FromValue(ids), tensors.FromValue(mask), tensors.FromValue(types)}
}
func (n *network) scores(ctx context.Context, rows []example, indices []int) ([]float64, error) {
	result := make([]float64, len(indices))
	for start := 0; start < len(indices); start += 4 {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		end := min(start+4, len(indices))
		in := inputs(rows, indices[start:end])
		out, err := n.exec.Exec(in)
		for _, t := range in {
			t.FinalizeAll()
		}
		if err != nil {
			return nil, err
		}
		values := out[0].Value().([][]float32)
		for j, r := range values {
			x := float64(r[0])
			if math.IsNaN(x) || math.IsInf(x, 0) {
				return nil, fmt.Errorf("nonfinite score")
			}
			result[start+j] = x
		}
		for _, t := range out {
			t.FinalizeAll()
		}
	}
	return result, nil
}
func (n *network) save(path string, h head) error {
	if err := n.saveOriginal(filepath.Join(path, "selected.onnx")); err != nil {
		return err
	}
	scope := n.graph.Store.RootScope().In("editorial_head")
	w, err := scope.VariableWithValue("weights", h.Weights).Value()
	if err != nil {
		return err
	}
	b, err := scope.VariableWithValue("bias", h.Bias).Value()
	if err != nil {
		return err
	}
	h.Weights = w.Value().([][]float32)
	h.Bias = b.Value().([]float32)
	raw, err := json.Marshal(h)
	if err != nil {
		return err
	}
	return os.WriteFile(filepath.Join(path, "head.json"), raw, 0600)
}
