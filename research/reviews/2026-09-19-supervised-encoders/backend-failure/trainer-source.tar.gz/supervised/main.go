// Command supervised compares matched head-only and transformer training.
package main

import (
	"context"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"os/signal"
	"path/filepath"
	"slices"
	"strconv"
	"time"
)

type example struct {
	Page      string `json:"page"`
	Unit      int    `json:"unit"`
	Hash      string `json:"text_sha256"`
	Text      string `json:"text"`
	Fold      int    `json:"fold"`
	Group     string `json:"group"`
	Cohort    string `json:"cohort"`
	Label     *int   `json:"label"`
	Words     int    `json:"words"`
	ids       []int64
	reference []float64
}
type dataset struct {
	Version int       `json:"version"`
	Hash    string    `json:"input_sha256"`
	Rows    []example `json:"rows"`
}
type parameters struct {
	Means, Scales, Weights []float64
	Intercept              float64
}
type warmModel struct {
	Fold       int        `json:"fold"`
	Parameters parameters `json:"parameters"`
	Groups     []string   `json:"training_groups"`
}
type warmInput struct {
	Version int         `json:"version"`
	Hash    string      `json:"input_sha256"`
	Encoder string      `json:"encoder_sha256"`
	Models  []warmModel `json:"models"`
}
type vectors struct {
	Version int    `json:"version"`
	Hash    string `json:"input_sha256"`
	Encoder string `json:"encoder_sha256"`
	Rows    []struct {
		Page   string    `json:"page"`
		Unit   int       `json:"unit"`
		Hash   string    `json:"text_sha256"`
		Values []float64 `json:"values"`
	} `json:"rows"`
}
type prediction struct {
	Page     string   `json:"page"`
	Unit     int      `json:"unit"`
	Words    int      `json:"words"`
	Cohort   string   `json:"cohort"`
	Label    *int     `json:"label"`
	Score    *float64 `json:"raw_score"`
	Selected bool     `json:"selected"`
	Reason   string   `json:"reason,omitempty"`
}
type point struct {
	Available bool     `json:"available"`
	Threshold *float64 `json:"threshold"`
	Positive  int      `json:"development_positives"`
	Negative  int      `json:"development_negatives"`
	True      int      `json:"development_true"`
	False     int      `json:"development_false"`
	Reason    string   `json:"reason,omitempty"`
}
type checkpoint struct {
	Epoch       int          `json:"epoch"`
	Point       point        `json:"operating_point"`
	Predictions []prediction `json:"development_predictions"`
}
type report struct {
	Basis       string       `json:"basis"`
	Mode        string       `json:"kind"`
	Fold        int          `json:"evaluation_fold"`
	Input       string       `json:"input_sha256"`
	Encoder     string       `json:"encoder_sha256"`
	Parity      float64      `json:"initial_max_score_error"`
	Rows        int          `json:"training_rows"`
	Groups      []string     `json:"training_groups"`
	Names       []string     `json:"trainable_encoder_variables"`
	Losses      []float64    `json:"epoch_mean_losses"`
	Checkpoints []checkpoint `json:"checkpoints"`
	Epoch       int          `json:"selected_epoch"`
	Point       point        `json:"operating_point"`
	Predictions []prediction `json:"predictions"`
	Seconds     float64      `json:"elapsed_seconds"`
	Snapshot    string       `json:"snapshot_sha256"`
	ReloadError float64      `json:"reload_max_score_error"`
}

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}
}
func read(path string, limit int64, to any) error {
	info, err := os.Stat(path)
	if err != nil {
		return err
	}
	if info.Size() > limit {
		return fmt.Errorf("input too large")
	}
	b, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	return json.Unmarshal(b, to)
}
func run() error {
	if len(os.Args) != 8 {
		return fmt.Errorf("usage: supervised DATA WARM VECTORS MODEL OUT FOLD H|FT")
	}
	fold, err := strconv.Atoi(os.Args[6])
	if err != nil || fold < 0 || fold > 4 {
		return fmt.Errorf("invalid fold")
	}
	kind := os.Args[7]
	if kind != "H" && kind != "FT" {
		return fmt.Errorf("invalid mode")
	}
	var d dataset
	var w warmInput
	var v vectors
	if err = read(os.Args[1], 32<<20, &d); err != nil {
		return err
	}
	if err = read(os.Args[2], 1<<20, &w); err != nil {
		return err
	}
	if err = read(os.Args[3], 128<<20, &v); err != nil {
		return err
	}
	if d.Version != 1 || w.Version != 1 || v.Version != 1 || d.Hash != w.Hash || d.Hash != v.Hash || v.Encoder != w.Encoder || len(d.Rows) != len(v.Rows) {
		return fmt.Errorf("input identities disagree")
	}
	var warm *warmModel
	for i := range w.Models {
		if w.Models[i].Fold == fold {
			if warm != nil {
				return fmt.Errorf("duplicate warm model")
			}
			warm = &w.Models[i]
		}
	}
	if warm == nil {
		return fmt.Errorf("missing warm model")
	}
	if err = validateRows(d.Rows, v); err != nil {
		return err
	}
	if err = validateParameters(warm.Parameters); err != nil {
		return err
	}
	if err = os.Mkdir(os.Args[5], 0700); err != nil {
		return err
	}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
	defer stop()
	ctx, cancel := context.WithTimeout(ctx, 30*time.Minute)
	defer cancel()
	result, err := fit(ctx, d, *warm, os.Args[4], os.Args[5], fold, kind)
	if err != nil {
		return err
	}
	result.Encoder = w.Encoder
	raw, err := json.Marshal(result)
	if err != nil {
		return err
	}
	return os.WriteFile(filepath.Join(os.Args[5], "report.json"), append(raw, '\n'), 0600)
}
func validateRows(rows []example, v vectors) error {
	if len(rows) < 1 || len(rows) > 100000 {
		return fmt.Errorf("invalid rows")
	}
	seen := map[string]bool{}
	groups := map[string]int{}
	for i := range rows {
		r := &rows[i]
		e := v.Rows[i]
		key := fmt.Sprintf("%s/%d", r.Page, r.Unit)
		if r.Fold < 0 || r.Fold > 4 || r.Group == "" || r.Page == "" || r.Unit < 0 || seen[key] {
			return fmt.Errorf("invalid row")
		}
		seen[key] = true
		if f, ok := groups[r.Group]; ok && f != r.Fold {
			return fmt.Errorf("group crosses folds")
		}
		groups[r.Group] = r.Fold
		if r.Label != nil && *r.Label != 0 && *r.Label != 1 {
			return fmt.Errorf("invalid label")
		}
		if e.Page != r.Page || e.Unit != r.Unit || e.Hash != r.Hash || fmt.Sprintf("%x", sha256.Sum256([]byte(r.Text))) != r.Hash {
			return fmt.Errorf("text binding changed")
		}
		r.reference = e.Values
	}
	slices.SortFunc(rows, func(a, b example) int {
		if a.Page < b.Page {
			return -1
		}
		if a.Page > b.Page {
			return 1
		}
		return a.Unit - b.Unit
	})
	return nil
}
func validateParameters(p parameters) error {
	if len(p.Means) != 128 || len(p.Scales) != 128 || len(p.Weights) != 128 {
		return fmt.Errorf("bad warm dimensions")
	}
	for i, s := range p.Scales {
		if s <= 0 || math.IsNaN(s) || math.IsInf(s, 0) || math.IsNaN(p.Weights[i]) || math.IsInf(p.Weights[i], 0) {
			return fmt.Errorf("bad warm values")
		}
	}
	return nil
}
