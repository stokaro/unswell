package main

import (
	"encoding/binary"
	"fmt"
	"math"
	"os"
	"strings"

	"github.com/gomlx/compute-onnx/support/protos"
	"github.com/gomlx/gomlx/core/tensors"
	"google.golang.org/protobuf/proto"
)

// parameterNames reads the original export, not the importer's synthesized tensors.
// This probe supports only the pinned two-layer BERT artifact.
func parameterNames(raw []byte) (map[string]bool, error) {
	var p protos.ModelProto
	if err := proto.Unmarshal(raw, &p); err != nil {
		return nil, err
	}
	if p.Graph == nil {
		return nil, fmt.Errorf("missing graph")
	}
	names := map[string]bool{}
	embeddings := 0
	for _, t := range p.Graph.Initializer {
		if t.DataType != int32(protos.TensorProto_FLOAT) {
			continue
		}
		if strings.HasPrefix(t.Name, "/") {
			continue
		} // Exported graph constants.
		if strings.HasPrefix(t.Name, "embeddings.") {
			embeddings++
			continue
		}
		if !strings.HasPrefix(t.Name, "encoder.layer.") && !strings.HasPrefix(t.Name, "onnx::MatMul_") {
			return nil, fmt.Errorf("unrecognized neural initializer %q", t.Name)
		}
		if len(t.Dims) < 1 || len(t.Dims) > 2 || names[t.Name] {
			return nil, fmt.Errorf("invalid parameter %q", t.Name)
		}
		names[t.Name] = true
	}
	if len(names) != 32 || embeddings != 5 {
		return nil, fmt.Errorf("unexpected parameter set: %d transformer, %d embedding", len(names), embeddings)
	}
	return names, nil
}

// saveOriginal preserves the original computation graph and initializer order.
// The importer may add folded constants and fused tensors in nondeterministic order;
// those are not part of this training algorithm or its exported graph.
func (n *network) saveOriginal(path string) error {
	var p protos.ModelProto
	if err := proto.Unmarshal(n.original, &p); err != nil {
		return err
	}
	scope := n.graph.Store.RootScope().In("ONNX")
	for _, t := range p.Graph.Initializer {
		if !n.parameters[t.Name] {
			continue
		}
		v := scope.GetVariable(t.Name)
		if v == nil {
			return fmt.Errorf("missing original parameter %q", t.Name)
		}
		value, err := v.Value()
		if err != nil {
			return err
		}
		shape := value.Shape()
		if shape.Rank() != len(t.Dims) {
			return fmt.Errorf("parameter rank changed")
		}
		for i, d := range t.Dims {
			if int64(shape.Dim(i)) != d {
				return fmt.Errorf("parameter shape changed")
			}
		}
		err = tensors.ConstFlatData[float32](value, func(flat []float32) {
			t.RawData = make([]byte, len(flat)*4)
			for i, x := range flat {
				binary.LittleEndian.PutUint32(t.RawData[i*4:], math.Float32bits(x))
			}
		})
		if err != nil {
			return err
		}
		t.FloatData = nil
	}
	raw, err := (proto.MarshalOptions{Deterministic: true}).Marshal(&p)
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0600)
}
