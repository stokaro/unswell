package main

import (
	"context"
	"crypto/sha256"
	"fmt"
	"math"
	"math/rand"
	"os"
	"path/filepath"
	"slices"
	"time"

	"github.com/gomlx/gomlx/core/tensors"
	"github.com/gomlx/gomlx/ml/train"
)

func fit(ctx context.Context, d dataset, warm warmModel, modelDir, out string, fold int, kind string) (report, error) {
	start := time.Now()
	result := report{Basis: "exposed assistant development; selection is not diagnostic credit", Mode: kind, Fold: fold, Input: d.Hash}
	h := rawHead(warm.Parameters)
	n, p, err := newNetwork(ctx, modelDir, "model.onnx", kind, h)
	if err != nil {
		return result, err
	}
	defer n.close()
	for i := range d.Rows {
		if err := ctx.Err(); err != nil {
			return result, err
		}
		r := &d.Rows[i]
		encoding := p.Model.Tokenizer.GoTokenizer.Tokenizer.EncodeWithAnnotations(r.Text)
		if len(encoding.IDs) > 256 {
			if r.reference != nil {
				return result, fmt.Errorf("availability drift")
			}
			continue
		}
		if len(encoding.IDs) < 3 || len(r.reference) != 128 {
			return result, fmt.Errorf("tokenization or reference missing")
		}
		for _, id := range encoding.IDs {
			r.ids = append(r.ids, int64(id))
		}
	}
	training, development, evaluation := partition(d.Rows, fold)
	groups := map[string]bool{}
	for _, i := range training {
		groups[d.Rows[i].Group] = true
	}
	for group := range groups {
		result.Groups = append(result.Groups, group)
	}
	slices.Sort(result.Groups)
	if !slices.Equal(result.Groups, warm.Groups) {
		return result, fmt.Errorf("training groups changed")
	}
	result.Names = n.names
	result.Rows = len(training)
	initialIndices := append(slices.Clone(training), development...)
	scores, err := n.scores(ctx, d.Rows, initialIndices)
	if err != nil {
		return result, err
	}
	for j, i := range initialIndices {
		expected := referenceScore(d.Rows[i].reference, warm.Parameters)
		result.Parity = math.Max(result.Parity, math.Abs(scores[j]-expected))
	}
	if result.Parity > 1e-4 {
		return result, fmt.Errorf("warm-start numerical mismatch: %.9g", result.Parity)
	}
	fmt.Fprintf(os.Stderr, "%s fold%d initial parity %.9g, training %d, transformer variables %d\n", kind, fold, result.Parity, len(training), len(n.names))
	if err = copyMetadata(modelDir, out); err != nil {
		return result, err
	}
	rng := rand.New(rand.NewSource(int64(19092026 + fold)))
	for epoch := 0; epoch <= 5; epoch++ {
		if epoch > 0 {
			order := slices.Clone(training)
			rng.Shuffle(len(order), func(i, j int) { order[i], order[j] = order[j], order[i] })
			mean, err := trainEpoch(ctx, n, d.Rows, order)
			if err != nil {
				return result, err
			}
			result.Losses = append(result.Losses, mean)
			fmt.Fprintf(os.Stderr, "%s fold%d epoch%d loss %.7f elapsed %.1fs\n", kind, fold, epoch, mean, time.Since(start).Seconds())
		}
		if epoch == 2 || epoch == 4 {
			continue
		}
		dev, err := predict(ctx, n, d.Rows, development)
		if err != nil {
			return result, err
		}
		candidate := threshold(dev)
		result.Checkpoints = append(result.Checkpoints, checkpoint{Epoch: epoch, Point: candidate, Predictions: dev})
		if epoch == 0 || better(candidate, result.Point) {
			result.Epoch = epoch
			result.Point = candidate
			if err = n.save(out, h); err != nil {
				return result, err
			}
		}
	}
	var chosen head
	if err = read(filepath.Join(out, "head.json"), 1<<20, &chosen); err != nil {
		return result, err
	}
	selected, _, err := newNetwork(ctx, out, "selected.onnx", "H", chosen)
	if err != nil {
		return result, err
	}
	defer selected.close()
	reloaded, err := predict(ctx, selected, d.Rows, development)
	if err != nil {
		return result, err
	}
	for _, c := range result.Checkpoints {
		if c.Epoch != result.Epoch {
			continue
		}
		for i, r := range reloaded {
			prior := c.Predictions[i]
			if r.Page != prior.Page || r.Unit != prior.Unit {
				return result, fmt.Errorf("reload identity drift")
			}
			result.ReloadError = math.Max(result.ReloadError, math.Abs(*r.Score-*prior.Score))
			if result.Point.Available && (*r.Score >= *result.Point.Threshold) != (*prior.Score >= *result.Point.Threshold) {
				return result, fmt.Errorf("reload threshold drift")
			}
		}
	}
	if result.ReloadError > 1e-5 {
		return result, fmt.Errorf("reload score drift: %g", result.ReloadError)
	}
	result.Predictions, err = predict(ctx, selected, d.Rows, evaluation)
	if err != nil {
		return result, err
	}
	for i := range result.Predictions {
		r := &result.Predictions[i]
		r.Selected = r.Score != nil && result.Point.Available && *r.Score >= *result.Point.Threshold
	}
	raw, err := os.ReadFile(filepath.Join(out, "selected.onnx"))
	if err != nil {
		return result, err
	}
	result.Snapshot = fmt.Sprintf("%x", sha256.Sum256(raw))
	result.Seconds = time.Since(start).Seconds()
	return result, nil
}
func partition(rows []example, fold int) (training, development, evaluation []int) {
	for i, r := range rows {
		if r.Fold == fold {
			evaluation = append(evaluation, i)
			continue
		}
		if r.Label == nil || r.ids == nil {
			continue
		}
		if r.Fold == (fold+1)%5 {
			development = append(development, i)
		} else {
			training = append(training, i)
		}
	}
	return
}
func referenceScore(v []float64, p parameters) float64 {
	result := p.Intercept
	for i, x := range v {
		result += p.Weights[i] * (x - p.Means[i]) / p.Scales[i]
	}
	return result
}
func trainEpoch(ctx context.Context, n *network, rows []example, order []int) (float64, error) {
	total := 0.0
	for start := 0; start < len(order); start += 4 {
		if err := ctx.Err(); err != nil {
			return 0, err
		}
		batch := order[start:min(start+4, len(order))]
		labels := make([][]float32, len(batch))
		for j, i := range batch {
			labels[j] = []float32{float32(*rows[i].Label)}
		}
		metrics, err := n.trainer.TrainStep(train.Batch{Inputs: inputs(rows, batch), Labels: []*tensors.Tensor{tensors.FromValue(labels)}})
		if err != nil {
			return 0, err
		}
		value := float64(metrics[0].Value().(float32))
		for _, m := range metrics {
			m.FinalizeAll()
		}
		if math.IsNaN(value) || math.IsInf(value, 0) {
			return 0, fmt.Errorf("nonfinite training loss")
		}
		total += value * float64(len(batch))
	}
	return total / float64(len(order)), nil
}
func predict(ctx context.Context, n *network, rows []example, indices []int) ([]prediction, error) {
	var available []int
	for _, i := range indices {
		if rows[i].ids != nil {
			available = append(available, i)
		}
	}
	scores, err := n.scores(ctx, rows, available)
	if err != nil {
		return nil, err
	}
	values := map[int]float64{}
	for j, i := range available {
		values[i] = scores[j]
	}
	result := make([]prediction, 0, len(indices))
	for _, i := range indices {
		r := rows[i]
		p := prediction{Page: r.Page, Unit: r.Unit, Words: r.Words, Cohort: r.Cohort, Label: r.Label}
		if value, ok := values[i]; ok {
			p.Score = &value
		} else {
			p.Reason = "sequence_limit"
		}
		result = append(result, p)
	}
	return result, nil
}
func copyMetadata(from, to string) error {
	for _, name := range []string{"config.json", "tokenizer.json", "tokenizer_config.json", "special_tokens_map.json"} {
		data, err := os.ReadFile(filepath.Join(from, name))
		if err != nil {
			return err
		}
		if err = os.WriteFile(filepath.Join(to, name), data, 0600); err != nil {
			return err
		}
	}
	return nil
}
func threshold(rows []prediction) point {
	p := point{Reason: "no_operating_point"}
	ordered := slices.Clone(rows)
	for _, r := range rows {
		if r.Label == nil || r.Score == nil {
			panic("threshold requires available labeled rows")
		}
		if *r.Label == 1 {
			p.Positive++
		} else {
			p.Negative++
		}
	}
	slices.SortFunc(ordered, func(a, b prediction) int {
		if *a.Score > *b.Score {
			return -1
		}
		if *a.Score < *b.Score {
			return 1
		}
		return 0
	})
	tp, fp := 0, 0
	for i, r := range ordered {
		if *r.Label == 1 {
			tp++
		} else {
			fp++
		}
		if i+1 < len(ordered) && *ordered[i+1].Score == *r.Score {
			continue
		}
		if fp*100 > p.Negative || tp*100 < 85*(tp+fp) || tp == 0 {
			continue
		}
		if !p.Available || tp > p.True {
			x := *r.Score
			p.Available = true
			p.Reason = ""
			p.Threshold = &x
			p.True = tp
			p.False = fp
		}
	}
	return p
}
func better(candidate, current point) bool {
	return candidate.Available && (!current.Available || candidate.True > current.True || (candidate.True == current.True && candidate.False < current.False))
}
