module unswell-encoder-probe

go 1.27.0

require github.com/knights-analytics/hugot v0.7.8

require (
	github.com/daulet/tokenizers v1.27.0 // indirect
	github.com/go-logr/logr v1.4.4 // indirect
	github.com/gofrs/flock v0.13.1 // indirect
	github.com/gomlx/compute v0.1.6 // indirect
	github.com/gomlx/compute-onnx v0.1.5 // indirect
	github.com/gomlx/exceptions v0.0.3 // indirect
	github.com/gomlx/go-huggingface v0.4.3 // indirect
	github.com/gomlx/go-xla v0.4.5 // indirect
	github.com/gomlx/gomlx v0.28.8 // indirect
	github.com/gomlx/onnx-gomlx v0.5.5 // indirect
	github.com/google/uuid v1.6.0 // indirect
	github.com/knights-analytics/ortgenai v0.3.2 // indirect
	github.com/pkg/errors v0.9.1 // indirect
	github.com/yalue/onnxruntime_go v1.35.0 // indirect
	golang.org/x/exp v0.0.0-20260824195058-e88cd73687aa // indirect
	golang.org/x/image v0.45.0 // indirect
	golang.org/x/sync v0.22.0 // indirect
	golang.org/x/sys v0.47.0 // indirect
	golang.org/x/text v0.41.0 // indirect
	google.golang.org/protobuf v1.36.12 // indirect
	k8s.io/klog/v2 v2.140.0 // indirect
)
