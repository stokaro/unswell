// Command encoderprobe measures local pure-Go encoder feasibility.
package main

import (
	"context"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"runtime"
	"strings"
	"time"

	"github.com/knights-analytics/hugot"
	"github.com/knights-analytics/hugot/options"
	"github.com/knights-analytics/hugot/pipelines"
)

type observation struct {
	ModelPath string `json:"model_path"`
	Runtime   string `json:"runtime"
 "strings"`
	LoadSeconds float64     `json:"load_seconds"`
	RunSeconds  []float64   `json:"run_seconds"`
	Inputs      []string    `json:"inputs"`
	Embeddings  [][]float32 `json:"embeddings"`
	Cosines     [][]float64 `json:"cosines"`
	HeapBytes   uint64      `json:"heap_bytes"`
}

func run(ctx context.Context) error {
	if len(os.Args) < 2 || len(os.Args) > 3 {
		return fmt.Errorf("usage: encoderprobe MODEL_DIRECTORY [INPUT_JSON]")
	}
	start := time.Now()
	session, err := hugot.NewGoSession(ctx, options.WithGoMLXBatchBuckets([]int{1, 4}), options.WithGoMLXSequenceBuckets([]int{32, 64, 128, 256}))
	if err != nil {
		return err
	}
	defer session.Destroy()
	pipeline, err := hugot.NewPipeline(session, hugot.FeatureExtractionConfig{ModelPath: os.Args[1], Name: "encoder-probe", OnnxFilename: "model.onnx", Options: []hugot.FeatureExtractionOption{pipelines.WithNormalization()}})
	if err != nil {
		return err
	}
	result := observation{ModelPath: os.Args[1], Runtime: runtime.Version(), LoadSeconds: time.Since(start).Seconds(), Inputs: []string{
		"The client retries failed requests.",
		"Failed requests are retried by the client.",
		"The client never retries failed requests.",
		"The database stores migration history.",
	}}
	if len(os.Args) == 3 {
		raw, err := os.ReadFile(os.Args[2])
		if err != nil {
			return err
		}
		if len(raw) > 65536 {
			return fmt.Errorf("input exceeds 64 KiB")
		}
		if err := json.Unmarshal(raw, &result.Inputs); err != nil {
			return err
		}
	}
	if len(result.Inputs) == 0 || len(result.Inputs) > 4 {
		return fmt.Errorf("expected 1..4 probe texts")
	}
	for _, text := range result.Inputs {
		if strings.TrimSpace(text) == "" || len(text) > 8192 {
			return fmt.Errorf("invalid probe text length")
		}
		if len(pipeline.Model.Tokenizer.GoTokenizer.Tokenizer.EncodeWithAnnotations(text).IDs) > 256 {
			return fmt.Errorf("probe exceeds 256 wordpieces")
		}
	}
	for range 2 {
		start = time.Now()
		output, err := pipeline.RunPipeline(ctx, result.Inputs)
		if err != nil {
			return err
		}
		result.RunSeconds = append(result.RunSeconds, time.Since(start).Seconds())
		result.Embeddings = output.Embeddings
	}
	for _, a := range result.Embeddings {
		row := make([]float64, len(result.Embeddings))
		for j, b := range result.Embeddings {
			for k, v := range a {
				if math.IsNaN(float64(v)) || math.IsInf(float64(v), 0) {
					return fmt.Errorf("nonfinite output")
				}
				row[j] += float64(v) * float64(b[k])
			}
		}
		result.Cosines = append(result.Cosines, row)
	}
	var mem runtime.MemStats
	runtime.ReadMemStats(&mem)
	result.HeapBytes = mem.HeapAlloc
	return json.NewEncoder(os.Stdout).Encode(result)
}

func main() {
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
	defer cancel()
	if err := run(ctx); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}
}
