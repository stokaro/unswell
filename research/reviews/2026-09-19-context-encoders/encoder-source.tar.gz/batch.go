// Command encoderbatch runs the frozen local encoder over verified research text.
package main

import (
	"context"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"github.com/knights-analytics/hugot"
	"github.com/knights-analytics/hugot/options"
	"github.com/knights-analytics/hugot/pipelines"
	"math"
	"os"
	"runtime"
	"time"
)

type row struct {
	Page string `json:"page"`
	Unit int    `json:"unit"`
	Hash string `json:"text_sha256"`
	Text string `json:"text"`
}
type input struct {
	Version  int    `json:"version"`
	Hash     string `json:"input_sha256"`
	Contract string `json:"unit_contract"`
	Rows     []row  `json:"rows"`
}
type vector struct {
	Tokens int       `json:"tokens"`
	Reason string    `json:"reason,omitempty"`
	Values []float32 `json:"values"`
}
type result struct {
	Page string `json:"page"`
	Unit int    `json:"unit"`
	Hash string `json:"text_sha256"`
	vector
}
type output struct {
	Version int      `json:"version"`
	Hash    string   `json:"input_sha256"`
	Encoder string   `json:"encoder_sha256"`
	Rows    []result `json:"rows"`
}

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}
}
func run() error {
	if len(os.Args) != 4 {
		return fmt.Errorf("usage: encoderbatch MODEL_DIR MANIFEST INPUT")
	}
	raw, err := os.ReadFile(os.Args[3])
	if err != nil {
		return err
	}
	if len(raw) > 64<<20 {
		return fmt.Errorf("oversized text input")
	}
	var in input
	if err = json.Unmarshal(raw, &in); err != nil {
		return err
	}
	if in.Version != 1 || in.Contract != "eligible-piece-v1" || len(in.Rows) == 0 || len(in.Rows) > 100000 {
		return fmt.Errorf("invalid export")
	}
	manifest, err := os.ReadFile(os.Args[2])
	if err != nil {
		return err
	}
	out := output{Version: 1, Hash: in.Hash, Encoder: fmt.Sprintf("%x", sha256.Sum256(manifest))}
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Minute)
	defer cancel()
	start := time.Now()
	s, err := hugot.NewGoSession(ctx, options.WithGoMLXBatchBuckets([]int{1, 4}), options.WithGoMLXSequenceBuckets([]int{32, 64, 128, 256}))
	if err != nil {
		return err
	}
	defer s.Destroy()
	p, err := hugot.NewPipeline(s, hugot.FeatureExtractionConfig{ModelPath: os.Args[1], Name: "review-encoder", OnnxFilename: "model.onnx", Options: []hugot.FeatureExtractionOption{pipelines.WithNormalization()}})
	if err != nil {
		return err
	}
	cache := map[string]vector{}
	var pending []row
	flush := func() error {
		if len(pending) == 0 {
			return nil
		}
		texts := make([]string, len(pending))
		for i, r := range pending {
			texts[i] = r.Text
		}
		v, err := p.RunPipeline(ctx, texts)
		if err != nil {
			return err
		}
		if len(v.Embeddings) != len(pending) {
			return fmt.Errorf("batch output mismatch")
		}
		for i, r := range pending {
			values := v.Embeddings[i]
			if len(values) != 128 {
				return fmt.Errorf("wrong dimension")
			}
			var norm float64
			for _, x := range values {
				if math.IsNaN(float64(x)) || math.IsInf(float64(x), 0) {
					return fmt.Errorf("nonfinite vector")
				}
				norm += float64(x) * float64(x)
			}
			if math.Abs(norm-1) > 1e-4 {
				return fmt.Errorf("nonunit vector")
			}
			prior := cache[r.Hash]
			prior.Values = values
			cache[r.Hash] = prior
		}
		pending = nil
		return nil
	}
	for i, r := range in.Rows {
		if err := ctx.Err(); err != nil {
			return err
		}
		if r.Text == "" || len(r.Text) > 65536 || fmt.Sprintf("%x", sha256.Sum256([]byte(r.Text))) != r.Hash {
			return fmt.Errorf("invalid text hash %d", i)
		}
		if _, ok := cache[r.Hash]; ok {
			continue
		}
		n := len(p.Model.Tokenizer.GoTokenizer.Tokenizer.EncodeWithAnnotations(r.Text).IDs)
		v := vector{Tokens: n}
		if n > 256 {
			v.Reason = "sequence_limit"
		}
		if n < 3 {
			return fmt.Errorf("invalid token count")
		}
		cache[r.Hash] = v
		if v.Reason == "" {
			pending = append(pending, r)
			if len(pending) == 4 {
				if err = flush(); err != nil {
					return err
				}
			}
		}
		if i%1000 == 0 {
			fmt.Fprintf(os.Stderr, "encoded row %d/%d, unique %d, elapsed %.1fs\n", i, len(in.Rows), len(cache), time.Since(start).Seconds())
		}
	}
	if err = flush(); err != nil {
		return err
	}
	for _, r := range in.Rows {
		out.Rows = append(out.Rows, result{Page: r.Page, Unit: r.Unit, Hash: r.Hash, vector: cache[r.Hash]})
	}
	var m runtime.MemStats
	runtime.ReadMemStats(&m)
	fmt.Fprintf(os.Stderr, "complete rows=%d unique=%d elapsed=%.6f heap=%d\n", len(out.Rows), len(cache), time.Since(start).Seconds(), m.HeapAlloc)
	return json.NewEncoder(os.Stdout).Encode(out)
}
