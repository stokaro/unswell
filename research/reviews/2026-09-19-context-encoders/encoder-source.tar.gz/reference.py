"""Reference-only numerical check; not used by the product or Go probe."""
import hashlib,json,sys
from pathlib import Path
import numpy as np
import onnxruntime as ort
import tokenizers

path=Path(sys.argv[1] if len(sys.argv)>1 else 'smoke.json')
report=json.loads(path.read_text())
model_dir=Path(report['model_path'])
tokenizer=tokenizers.Tokenizer.from_file(str(model_dir/'tokenizer.json'))
tokenizer.enable_padding()
encoded=tokenizer.encode_batch(report['inputs'])
inputs={'input_ids':np.array([x.ids for x in encoded],dtype=np.int64),
        'attention_mask':np.array([x.attention_mask for x in encoded],dtype=np.int64),
        'token_type_ids':np.array([x.type_ids for x in encoded],dtype=np.int64)}
options=ort.SessionOptions();options.intra_op_num_threads=2;options.inter_op_num_threads=1
session=ort.InferenceSession(str(model_dir/'model.onnx'),options,providers=['CPUExecutionProvider'])
hidden=session.run(None,inputs)[0]
mask=inputs['attention_mask'][...,None].astype(np.float32)
pooled=(hidden*mask).sum(axis=1)/mask.sum(axis=1)
pooled/=np.linalg.norm(pooled,axis=1,keepdims=True)
actual=np.array(report['embeddings'],dtype=np.float32)
if actual.shape!=pooled.shape:raise ValueError('shape mismatch')
error=float(np.abs(actual-pooled).max())
result=dict(scope='numerical parity only; no editorial quality evidence',report=path.name,
            report_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),onnxruntime=ort.__version__,
            tokenizers=tokenizers.__version__,numpy=np.__version__,shape=list(actual.shape),
            tolerance=1e-4,max_absolute_error=error,passed=error<=1e-4,
            wordpieces=[len(x.ids) for x in encoded],reference_embeddings=pooled.tolist())
print(json.dumps(result))
if not result['passed']:sys.exit(1)
