"""Bounded local MiniCheck reference on previously fixed technical controls."""

import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import socket
import sys
import time

ROOT = Path(__file__).resolve().parent
CODE_REVISION = "b58b9fa69acbd1015ec970fa65dd752413a053d2"
MODEL_REVISION = "96eafd01cee2d16cf81aaa2fb226b14f422a37b3"
CONTROLS = ROOT.parent / "unswell-lens-salsa-20260930/controls.json"


def sha256(path):
    d = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            d.update(chunk)
    return d.hexdigest()


def freeze():
    protocol = {
        "version": "unswell-minicheck-technical-preflight-v1",
        "code_revision": CODE_REVISION,
        "model_revision": MODEL_REVISION,
        "controls_sha256": sha256(CONTROLS),
        "runner_sha256": sha256(Path(__file__)),
        "hypothesis": "A published pretrained grounding model may reject technical meaning changes that an edit-quality metric rewards.",
        "task": "Meaning preservation only; not editorial necessity or authorship detection.",
        "directions": ["revision claim grounded in original source", "original source claim grounded in revision"],
        "completeness": "Every ordinary control contains one sentence on each side. Case control has two source sentences and is reported separately with forward checks only. One complete short source chunk is passed to the unmodified upstream Inferencer.inference; long-input splitting is not reproduced or claimed.",
        "published_label_cutoff": 0.5,
        "pair_policy": "Both direction scores must exceed 0.5; this conjunction is an experimental Unswell policy, not an upstream guarantee.",
        "required_safe_pairs": 12,
        "required_unsafe_pairs": 12,
        "required_neutral_pairs": 4,
        "minimum_safe_pairs_retained": 10,
        "maximum_unsafe_pairs_retained": 1,
        "case_control": "Separate identifier-case stress test; a failing check prevents claiming identifier preservation.",
        "inference": {"device": "cpu", "threads": 4, "outbound_requests": 0, "timeout_seconds": 900, "max_rss_bytes": 12 * 1024 ** 3, "attempts": 1, "training": False},
        "labels": "Constructed assistant controls, inherited unchanged from the LENS-SALSA preflight; not independent human or final-test data.",
        "failure_policy": "Keep all failures and original denominators. Do not fit thresholds, rerun requests, reinterpret unavailable scores as safe, or claim new full-event detection coverage.",
    }
    with (ROOT / "protocol.json").open("x") as stream:
        json.dump(protocol, stream, indent=2)
        stream.write("\n")
    return protocol


def main():
    if "--freeze" in sys.argv:
        print(json.dumps({"protocol_sha256": sha256(ROOT / "protocol.json")} if (ROOT / "protocol.json").exists() else {"frozen": bool(freeze())}))
        return
    protocol = json.loads((ROOT / "protocol.json").read_text())
    if protocol["runner_sha256"] != sha256(Path(__file__)) or protocol["controls_sha256"] != sha256(CONTROLS):
        raise ValueError("The frozen inputs or implementation changed")
    acquisition = json.loads((ROOT / "acquisition.json").read_text())
    if acquisition["revision"] != MODEL_REVISION:
        raise ValueError("Model revision mismatch")
    for name, item in acquisition["files"].items():
        if sha256(ROOT / "model" / name) != item["sha256"]:
            raise ValueError(f"Model resource mismatch: {name}")
    started = time.monotonic()

    def timeout(*args):
        raise TimeoutError("Frozen 900-second inference budget expired")

    signal.signal(signal.SIGALRM, timeout)
    signal.alarm(900)
    for key in ["HF_HUB_OFFLINE", "TRANSFORMERS_OFFLINE", "HF_HUB_DISABLE_TELEMETRY"]:
        os.environ[key] = "1"
    os.environ["TOKENIZERS_PARALLELISM"] = "false"
    (ROOT / "cache").mkdir(exist_ok=True)
    os.environ["HF_HOME"] = str(ROOT / "cache")

    def reject(*args, **kwargs):
        raise RuntimeError("Outbound connections are prohibited for local inference")

    socket.socket.connect = reject
    socket.socket.connect_ex = reject
    socket.create_connection = reject
    import torch
    from transformers import AutoConfig, AutoTokenizer, AutoModelForSeq2SeqLM
    sys.path.insert(0, str(ROOT / "reference"))
    from minicheck.inference import Inferencer
    torch.set_num_threads(4)
    torch.set_num_interop_threads(1)
    torch.manual_seed(0)
    torch.use_deterministic_algorithms(True)
    config = AutoConfig.from_pretrained(str(ROOT / "model"), local_files_only=True, trust_remote_code=False)
    tokenizer = AutoTokenizer.from_pretrained(str(ROOT / "model"), local_files_only=True, trust_remote_code=False)
    state = torch.load(ROOT / "model/pytorch_model.bin", map_location="cpu", weights_only=True, mmap=True)
    model = AutoModelForSeq2SeqLM.from_config(config, trust_remote_code=False)
    loaded = model.load_state_dict(state, strict=True, assign=True)
    if loaded.missing_keys or loaded.unexpected_keys:
        raise ValueError("Strict checkpoint load failed")
    for name, parameter in model.named_parameters():
        if name not in state or not torch.equal(parameter, state[name]):
            raise ValueError(f"Incomplete parameter restoration: {name}")
    model.eval()
    scorer = Inferencer.__new__(Inferencer)
    scorer.model_name = "flan-t5-large"
    scorer.model = model
    scorer.tokenizer = tokenizer
    scorer.max_model_len = 2048
    scorer.batch_size = 1

    def score(doc, claim):
        full = "predict: " + doc + tokenizer.eos_token + claim
        ids = tokenizer.encode(full, truncation=False)
        if not doc.strip() or not claim.strip() or len(ids) > scorer.max_model_len:
            return {"available": False, "reason": "empty_or_would_truncate"}
        actual = scorer.batch_tokenize([doc], [claim])[0][0]
        actual_ids = actual["input_ids"][0][actual["attention_mask"][0].bool()].tolist()
        if ids != actual_ids:
            raise ValueError("Published preprocessing truncated or changed a complete input")
        output = scorer.inference([doc], [claim])
        probability = float(output["max_support_prob"])
        if not 0 <= probability <= 1:
            raise ValueError("Invalid support score")
        if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss > protocol["inference"]["max_rss_bytes"]:
            raise MemoryError("RSS budget exceeded")
        return {"available": True, "support_score": probability, "published_label": int(probability > 0.5), "input_tokens": len(ids), "all_input_tokens_retained": True}

    results = {"model_identity": {"model": acquisition["model"], "revision": MODEL_REVISION, "code_revision": CODE_REVISION, "strict_parameter_load": True, "parameter_count": sum(p.numel() for p in model.parameters()), "checkpoint_sha256": acquisition["files"]["pytorch_model.bin"]["sha256"], "device": "cpu", "input_lowercasing": False}, "protocol_sha256": sha256(ROOT / "protocol.json"), "controls_sha256": sha256(CONTROLS), "smoke": [], "groups": [], "neutral": [], "case": {}, "complete": False}
    try:
        doc = "A group of students gather in the school library to study for their upcoming final exams."
        for claim, expected in [("The students are preparing for an examination.", 0.9805923700332642), ("The students are on vacation.", 0.007121330592781305)]:
            output = score(doc, claim)
            output["expected_score"] = expected
            output["matches_published_example"] = abs(output["support_score"] - expected) <= 0.001
            results["smoke"].append(output)
        if not all(row["matches_published_example"] for row in results["smoke"]):
            raise ValueError("Published MiniCheck smoke scores did not match")
        controls = json.loads(CONTROLS.read_text())
        for group in controls["groups"]:
            row = {"id": group["id"]}
            for role in ["useful", "unsafe"]:
                forward, backward = score(group["source"], group[role]), score(group[role], group["source"])
                row[role] = {"forward": forward, "backward": backward, "pair_supported": forward["available"] and backward["available"] and forward["published_label"] == 1 and backward["published_label"] == 1}
            results["groups"].append(row)
            print(json.dumps({"completed_groups": len(results["groups"]), "required_groups": 12}), flush=True)
        for group in controls["neutral"]:
            forward, backward = score(group["source"], group["revision"]), score(group["revision"], group["source"])
            results["neutral"].append({"id": group["id"], "forward": forward, "backward": backward, "pair_supported": forward["available"] and backward["available"] and forward["published_label"] == 1 and backward["published_label"] == 1})
        group = controls["case_control"]
        results["case"] = {role: score(group["source"], group[role]) for role in ["useful", "unsafe"]}
        results["complete"] = True
    except Exception as exc:
        results["error"] = {"type": type(exc).__name__, "message": str(exc)}
        raise
    finally:
        signal.alarm(0)
        results["elapsed_seconds"] = time.monotonic() - started
        results["peak_rss_bytes"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        with (ROOT / "results.json").open("x") as stream:
            json.dump(results, stream, indent=2, allow_nan=False)
            stream.write("\n")
        print(json.dumps({key: results[key] for key in ["complete", "elapsed_seconds", "peak_rss_bytes"]}), flush=True)


if __name__ == "__main__":
    main()
