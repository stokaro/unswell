"""Compare the local loader against the authors' published inference example."""

import json
from pathlib import Path
import resource
import time

from local_model import LocalModel, ROOT, sha256

started = time.monotonic()
model = LocalModel()
source = "They are culturally akin to the coastal peoples of Papua New Guinea."
revision = "They are culturally similar to the people of Papua New Guinea."
result = model.score(source, revision)
expected = 72.40909337997437
result = {
    "published_example": "https://github.com/davidheineman/salsa#lens-salsa",
    "expected_score": expected,
    "absolute_tolerance": 0.001,
    "observed": result,
    "matches_published_score": result["available"] and abs(result["score"] - expected) <= 0.001,
    "model_identity": model.identity,
    "elapsed_seconds": time.monotonic() - started,
    "peak_rss_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    "implementation_sha256": sha256(Path(__file__)),
    "loader_sha256": sha256(ROOT / "local_model.py"),
}
with (ROOT / "smoke.json").open("x") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
    stream.write("\n")
print(json.dumps({key: result[key] for key in ["matches_published_score", "elapsed_seconds", "peak_rss_bytes"]}), flush=True)
print("observed", result["observed"]["score"], "expected", expected, flush=True)
if not result["matches_published_score"]:
    raise SystemExit("The published smoke score did not match; qualification is prohibited")
