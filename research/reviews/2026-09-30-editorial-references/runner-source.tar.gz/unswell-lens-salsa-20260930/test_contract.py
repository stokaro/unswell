"""Negative controls for denominator, score safety, and input completeness."""

import copy
import unittest

from evaluate import summarize_controls
from local_model import LocalModel
from run import jobs


class Tokenizer:
    def encode(self, text, add_special_tokens=True, truncation=False):
        values = [5] * len(text.split())
        return [0] + values + [2] if add_special_tokens else values

    def build_inputs_with_special_tokens(self, revision, source):
        return [0] + revision + [2, 2] + source + [2]


class ContractTest(unittest.TestCase):
    def setUp(self):
        self.controls = {
            "groups": [{"id": f"g{i}", "source": "source", "useful": "useful", "unsafe": "unsafe"} for i in range(12)],
            "neutral": [{"id": f"n{i}", "source": "source", "revision": "revision"} for i in range(4)],
            "case_control": {"source": "case", "useful": "same", "unsafe": "same", "expected_limitation": "case collision"},
        }
        self.protocol = {
            "fixed_gain_margin": 2.0,
            "preflight": {"minimum_useful_gain_count": 10, "maximum_neutral_gain_count": 1, "minimum_useful_above_unsafe_count": 10, "maximum_unsafe_gain_count_for_standalone_safety": 1},
        }
        self.predictions = {}
        for group in self.controls["groups"]:
            for role, score in [("identity", 50), ("useful", 53), ("unsafe", 49)]:
                self.predictions["control/" + group["id"] + "/" + role] = {"available": True, "score": score}
        for group in self.controls["neutral"]:
            for role in ["identity", "neutral"]:
                self.predictions["control/" + group["id"] + "/" + role] = {"available": True, "score": 50}
        for role in ["identity", "useful", "unsafe"]:
            self.predictions["control/case/" + role] = {"available": True, "score": 50}

    def test_unsafe_preferred_revision_fails_even_with_useful_gains(self):
        for key, value in self.predictions.items():
            if key.endswith("/unsafe") and "case" not in key:
                value["score"] = 54
        report = summarize_controls(self.controls, self.predictions, self.protocol)
        self.assertTrue(report["benefit_screen_pass"])
        self.assertFalse(report["relative_safety_ranking_pass"])
        self.assertFalse(report["standalone_safety_screen_pass"])
        self.assertFalse(report["combined_screen_pass"])

    def test_unavailable_group_is_not_removed_from_the_denominator(self):
        self.predictions["control/g0/useful"] = {"available": False, "reason": "would_truncate_published_input"}
        report = summarize_controls(self.controls, self.predictions, self.protocol)
        self.assertEqual(report["required_groups"], 12)
        self.assertEqual(report["available_groups"], 11)
        self.assertFalse(report["combined_screen_pass"])

    def test_optional_paraphrases_can_fail_the_benefit_screen(self):
        for key, value in self.predictions.items():
            if key.endswith("/neutral"):
                value["score"] = 53
        report = summarize_controls(self.controls, self.predictions, self.protocol)
        self.assertEqual(report["neutral_gain_count"], 4)
        self.assertFalse(report["benefit_screen_pass"])

    def test_duplicate_prediction_jobs_are_rejected(self):
        pair = {"id": "page/u0", "source": "a", "revision": "b"}
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            jobs(self.controls, {"pairs": [pair, copy.deepcopy(pair)]})

    def test_complete_source_and_revision_are_required(self):
        model = LocalModel.__new__(LocalModel)
        model.tokenizer = Tokenizer()
        model.model = type("Model", (), {"encoder": type("Encoder", (), {"max_positions": 512})()})()
        too_long = model.token_plan("word " * 280, "word " * 280)
        self.assertFalse(too_long["available"])
        self.assertEqual(too_long["reason"], "would_truncate_published_input")
        self.assertEqual(too_long["joint_tokens"], 564)
        short = model.token_plan("short source", "short revision")
        self.assertTrue(short["available"])
        self.assertEqual(short["joint_tokens"], 8)


if __name__ == "__main__":
    unittest.main()
