"""Execute the frozen preflight and descriptive pair comparison once, offline."""

import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import resource
import signal
import sys
import time

ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_frozen(protocol):
    for relative, expected in protocol["frozen_hashes"].items():
        if digest(ROOT / relative) != expected:
            raise ValueError(f"Frozen implementation/input changed: {relative}")
    for relative, expected in protocol["original_inputs"].items():
        if digest(ROOT.parent / relative) != expected:
            raise ValueError(f"Original packet changed: {relative}")


def jobs(controls, pairs):
    out = []
    for group in controls["groups"]:
        for role in ["identity", "useful", "unsafe"]:
            out.append({"id": "control/" + group["id"] + "/" + role, "source": group["source"], "revision": group["source"] if role == "identity" else group[role]})
    for group in controls["neutral"]:
        for role in ["identity", "neutral"]:
            out.append({"id": "control/" + group["id"] + "/" + role, "source": group["source"], "revision": group["source"] if role == "identity" else group["revision"]})
    for role in ["identity", "useful", "unsafe"]:
        group = controls["case_control"]
        out.append({"id": "control/case/" + role, "source": group["source"], "revision": group["source"] if role == "identity" else group[role]})
    for pair in pairs["pairs"]:
        for role in ["identity", "revision"]:
            out.append({"id": "existing/" + pair["id"] + "/" + role, "source": pair["source"], "revision": pair["source"] if role == "identity" else pair["revision"]})
    if len(out) != len({item["id"] for item in out}):
        raise ValueError("Duplicate inference IDs")
    return out


def main():
    protocol = json.loads((ROOT / "protocol.json").read_text())
    verify_frozen(protocol)
    smoke = json.loads((ROOT / "smoke.json").read_text())
    if not smoke["matches_published_score"] or smoke["loader_sha256"] != digest(ROOT / "local_model.py"):
        raise ValueError("A current matching reference smoke test is required")
    items = jobs(json.loads((ROOT / "controls.json").read_text()), json.loads((ROOT / "existing-pairs.json").read_text()))
    started = time.monotonic()

    def timeout(*args):
        raise TimeoutError("The preregistered 1,800-second time budget expired")

    signal.signal(signal.SIGALRM, timeout)
    signal.alarm(protocol["inference"]["timeout_seconds"])
    record = {
        "version": "unswell-lens-salsa-run-v1",
        "protocol_sha256": digest(ROOT / "protocol.json"),
        "smoke_sha256": digest(ROOT / "smoke.json"),
        "jobs_required": len(items),
        "jobs_completed": 0,
        "complete": False,
        "outbound_requests": 0,
        "environment": {dist.metadata["Name"]: dist.version for dist in importlib.metadata.distributions()},
        "python": sys.version,
        "platform": os.uname()._asdict() if hasattr(os.uname(), "_asdict") else list(os.uname()),
    }
    with (ROOT / "predictions.jsonl").open("x") as stream:
        try:
            from local_model import LocalModel
            model = LocalModel()
            record["model_identity"] = model.identity
            for item in items:
                result = model.score(item["source"], item["revision"])
                if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss > protocol["inference"]["max_rss_bytes"]:
                    raise MemoryError("The preregistered RSS budget was exceeded")
                stream.write(json.dumps({"id": item["id"], "result": result}, ensure_ascii=False, allow_nan=False) + "\n")
                stream.flush()
                record["jobs_completed"] += 1
                if record["jobs_completed"] % 25 == 0:
                    print(json.dumps({"completed": record["jobs_completed"], "required": len(items), "elapsed_seconds": time.monotonic() - started}), flush=True)
            verify_frozen(protocol)
            record["complete"] = True
        except Exception as exc:
            record["error"] = {"type": type(exc).__name__, "message": str(exc)}
            raise
        finally:
            signal.alarm(0)
            record["elapsed_seconds"] = time.monotonic() - started
            record["peak_rss_bytes"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            record["predictions_sha256"] = digest(ROOT / "predictions.jsonl")
            with (ROOT / "run-record.json").open("x") as output:
                json.dump(record, output, indent=2, allow_nan=False)
                output.write("\n")
            print(json.dumps({key: record[key] for key in ["complete", "jobs_completed", "jobs_required", "elapsed_seconds", "peak_rss_bytes"]}), flush=True)


if __name__ == "__main__":
    main()
