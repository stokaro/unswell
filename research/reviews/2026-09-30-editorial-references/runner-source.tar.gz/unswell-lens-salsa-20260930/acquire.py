"""Acquire pinned public reference artifacts; never read internal research data."""
import hashlib
import json
from pathlib import Path
import time
import urllib.request

ROOT = Path(__file__).resolve().parent
REVISION = "cc04094d084493e68bcd3eb196ff74e894cca00d"
MODEL = "davidheineman/lens-salsa"
WHEEL_URL = "https://files.pythonhosted.org/packages/dd/ad/0524956a3c43fdd20f643f66d7ecd4586e03e0a830166e9122581e30464b/lens_metric-0.2.0-py3-none-any.whl"
WHEEL_SHA = "e8bdc18a87a66875035187eb88e5f8f835aee975df8089e93f85102c45000f80"


def get_json(url):
    with urllib.request.urlopen(url, timeout=45) as response:
        return json.load(response)


def download(url, path, *, size=None, sha256=None, blob=None):
    if path.exists():
        raise ValueError("Acquisition does not overwrite artifacts")
    path.parent.mkdir(parents=True, exist_ok=True)
    digest = hashlib.sha256()
    count, started, progress = 0, time.monotonic(), 0
    with urllib.request.urlopen(url, timeout=90) as response, path.open("xb") as output:
        while chunk := response.read(4 << 20):
            count += len(chunk)
            if time.monotonic() - started > 900 or count > (size if size is not None else 8 << 20):
                raise ValueError("Download resource bound exceeded")
            digest.update(chunk)
            output.write(chunk)
            if count // (128 << 20) > progress:
                progress = count // (128 << 20)
                print(path.name, count, "bytes", flush=True)
    assert size is None or count == size
    value = digest.hexdigest()
    assert sha256 is None or value == sha256
    if blob is not None:
        raw = path.read_bytes()
        assert hashlib.sha1(f"blob {len(raw)}\0".encode() + raw).hexdigest() == blob
    return {"bytes": count, "sha256": value, "seconds": time.monotonic() - started}


def main():
    metadata = get_json(f"https://huggingface.co/api/models/{MODEL}/revision/{REVISION}?blobs=true")
    assert metadata["sha"] == REVISION and metadata["cardData"]["license"] == "apache-2.0"
    siblings = {r["rfilename"]: r for r in metadata["siblings"]}
    report = {"model": MODEL, "revision": REVISION,
              "code_repository": "davidheineman/salsa", "code_revision": "ce5ddba3d338704a20ceeaffbbb6382810c0c3e7",
              "declared_code_license": "Apache-2.0", "declared_model_license": "Apache-2.0",
              "domain": "Model card: English Wikipedia simplification; technical documentation untested.",
              "context7": "No matching library; unrelated Rust/Haskell Salsa/Lens results excluded.",
              "internal_data_transferred": False, "files": {}}
    with (ROOT / "model-metadata.json").open("x") as f:
        json.dump(metadata, f, indent=2)
    for name in ["README.md", "hparams.yaml", "checkpoints/model.ckpt"]:
        info = siblings[name]
        report["files"][name] = download(
            f"https://huggingface.co/{MODEL}/resolve/{REVISION}/{name}?download=true", ROOT / "model" / name,
            size=info["size"], sha256=info.get("lfs", {}).get("sha256"),
            blob=info["blobId"] if "lfs" not in info else None)
    report["files"]["lens_metric-0.2.0-py3-none-any.whl"] = download(
        WHEEL_URL, ROOT / "lens_metric-0.2.0-py3-none-any.whl", size=48077, sha256=WHEEL_SHA)
    base = get_json("https://huggingface.co/api/models/FacebookAI/roberta-large?blobs=true")
    report["base_tokenizer"] = {"model": "FacebookAI/roberta-large", "revision": base["sha"],
                                "declared_license": base.get("cardData", {}).get("license")}
    with (ROOT / "tokenizer-metadata.json").open("x") as f:
        json.dump(base, f, indent=2)
    available = {r["rfilename"]: r for r in base["siblings"]}
    for name in ["config.json", "tokenizer.json", "tokenizer_config.json", "vocab.json", "merges.txt", "special_tokens_map.json"]:
        if name not in available:
            continue
        info = available[name]
        report["files"]["tokenizer/" + name] = download(
            f"https://huggingface.co/FacebookAI/roberta-large/resolve/{base['sha']}/{name}",
            ROOT / "tokenizer" / name, size=info["size"], blob=info["blobId"])
    with (ROOT / "acquisition.json").open("x") as f:
        json.dump(report, f, indent=2)
        f.write("\n")
    print(json.dumps({k: v for k, v in report.items() if k != "files"}, indent=2))


if __name__ == "__main__":
    main()
