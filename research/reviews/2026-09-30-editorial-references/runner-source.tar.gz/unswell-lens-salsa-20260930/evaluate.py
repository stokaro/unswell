"""Recompute the fixed screens without modifying labels or selecting a cutoff."""

import hashlib
import json
import math
from pathlib import Path
import statistics

from run import jobs, verify_frozen

ROOT = Path(__file__).resolve().parent


def summarize_controls(controls, predictions, protocol):
    group_results = []
    margin = protocol["fixed_gain_margin"]
    for group in controls["groups"]:
        outputs = {role: predictions["control/" + group["id"] + "/" + role] for role in ["identity", "useful", "unsafe"]}
        available = all(row["available"] for row in outputs.values())
        result = {"id": group["id"], "available": available}
        if available:
            identity, useful, unsafe = (outputs[role]["score"] for role in ["identity", "useful", "unsafe"])
            result.update(identity_score=identity, useful_score=useful, unsafe_score=unsafe, useful_gain=useful - identity, unsafe_gain=unsafe - identity, useful_above_unsafe=useful > unsafe, useful_gain_pass=useful - identity > margin, unsafe_gain_pass=unsafe - identity > margin)
        group_results.append(result)
    neutral_results = []
    for group in controls["neutral"]:
        identity = predictions["control/" + group["id"] + "/identity"]
        revision = predictions["control/" + group["id"] + "/neutral"]
        result = {"id": group["id"], "available": identity["available"] and revision["available"]}
        if result["available"]:
            result.update(gain=revision["score"] - identity["score"], gain_pass=revision["score"] - identity["score"] > margin)
        neutral_results.append(result)
    all_available = all(row["available"] for row in group_results + neutral_results)
    useful = sum(row.get("useful_gain_pass", False) for row in group_results)
    unsafe = sum(row.get("unsafe_gain_pass", False) for row in group_results)
    neutral = sum(row.get("gain_pass", False) for row in neutral_results)
    ranks = sum(row.get("useful_above_unsafe", False) for row in group_results)
    gate = protocol["preflight"]
    benefit_pass = all_available and useful >= gate["minimum_useful_gain_count"] and neutral <= gate["maximum_neutral_gain_count"]
    ranking_pass = all_available and ranks >= gate["minimum_useful_above_unsafe_count"]
    safety_pass = all_available and unsafe <= gate["maximum_unsafe_gain_count_for_standalone_safety"]
    case_useful = predictions["control/case/useful"]
    case_unsafe = predictions["control/case/unsafe"]
    case_collision = case_useful == case_unsafe
    return {
        "groups": group_results,
        "neutral": neutral_results,
        "available_groups": sum(row["available"] for row in group_results),
        "required_groups": len(group_results),
        "useful_gain_count": useful,
        "unsafe_gain_count": unsafe,
        "neutral_gain_count": neutral,
        "useful_above_unsafe_count": ranks,
        "benefit_screen_pass": benefit_pass,
        "relative_safety_ranking_pass": ranking_pass,
        "standalone_safety_screen_pass": safety_pass,
        "combined_screen_pass": benefit_pass and ranking_pass and safety_pass,
        "case_control_identical_outputs": case_collision,
        "case_control_limit": controls["case_control"]["expected_limitation"],
        "product_qualified": False,
    }


def summary_stats(values):
    return {"count": len(values), "min": min(values), "median": statistics.median(values), "mean": statistics.mean(values), "max": max(values)} if values else {"count": 0}


def main():
    protocol = json.loads((ROOT / "protocol.json").read_text())
    verify_frozen(protocol)
    controls = json.loads((ROOT / "controls.json").read_text())
    pairs = json.loads((ROOT / "existing-pairs.json").read_text())
    record = json.loads((ROOT / "run-record.json").read_text())
    if not record["complete"] or hashlib.sha256((ROOT / "predictions.jsonl").read_bytes()).hexdigest() != record["predictions_sha256"]:
        raise ValueError("A complete, intact prediction record is required")
    raw = [json.loads(line) for line in (ROOT / "predictions.jsonl").read_text().splitlines()]
    predictions = {row["id"]: row["result"] for row in raw}
    expected_ids = {item["id"] for item in jobs(controls, pairs)}
    if set(predictions) != expected_ids or len(predictions) != len(raw):
        raise ValueError("Incomplete or duplicate prediction IDs")
    for output in predictions.values():
        if output["available"] and (not output["all_input_tokens_retained"] or not math.isfinite(output["score"])):
            raise ValueError("Invalid available score")
    preflight = summarize_controls(controls, predictions, protocol)
    gains = []
    reasons = {}
    per_page = {}
    for pair in pairs["pairs"]:
        identity = predictions["existing/" + pair["id"] + "/identity"]
        revision = predictions["existing/" + pair["id"] + "/revision"]
        row = per_page.setdefault(pair["page"], {"required": 0, "available": 0, "positive_gain": 0, "above_fixed_margin": 0})
        row["required"] += 1
        if identity["available"] and revision["available"]:
            gain = revision["score"] - identity["score"]
            gains.append(gain)
            row["available"] += 1
            row["positive_gain"] += int(gain > 0)
            row["above_fixed_margin"] += int(gain > protocol["fixed_gain_margin"])
        else:
            reason = identity.get("reason", revision.get("reason", "unknown"))
            reasons[reason] = reasons.get(reason, 0) + 1
    report = {
        "version": "unswell-lens-salsa-evaluation-v1",
        "preflight": preflight,
        "existing_pairs": {"required": len(pairs["pairs"]), "available": len(gains), "gain_statistics": summary_stats(gains), "positive_gain": sum(g > 0 for g in gains), "above_fixed_margin": sum(g > protocol["fixed_gain_margin"] for g in gains), "unavailable_reasons": reasons, "per_page": per_page, "qualification": protocol["existing_comparison"]["qualification"]},
        "integrity": {"frozen_inputs_unchanged": True, "all_expected_ids_present_once": True, "no_truncated_available_input": True, "protocol_sha256": hashlib.sha256((ROOT / "protocol.json").read_bytes()).hexdigest(), "run_record_sha256": hashlib.sha256((ROOT / "run-record.json").read_bytes()).hexdigest()},
        "decision": "proceed_to_a_separately_frozen_task_evaluation" if preflight["combined_screen_pass"] else "reject_as_a_general_technical_editorial_selector",
        "original_recall_objective_achieved": False,
    }
    with (ROOT / "evaluation.json").open("x") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"decision": report["decision"], "useful": preflight["useful_gain_count"], "unsafe": preflight["unsafe_gain_count"], "neutral": preflight["neutral_gain_count"], "safety_rank": preflight["useful_above_unsafe_count"], "existing_available": len(gains)}), flush=True)


if __name__ == "__main__":
    main()
