"""Freeze a bounded local edit-quality screen before observing its scores."""

import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parent


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(name, data):
    with (ROOT / name).open("x") as stream:
        json.dump(data, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write("\n")


GROUPS = [
    {
        "id": "negation",
        "source": "It is important to note that the client does not retry failed requests when retries are disabled.",
        "useful": "The client does not retry failed requests when retries are disabled.",
        "unsafe": "The client retries failed requests when retries are disabled.",
        "critical_difference": "The unsafe revision removes the prohibition on retrying.",
    },
    {
        "id": "conditional-wrapper",
        "source": "In this section, we will walk through the fact that the validator rejects the migration if any statement refers to a different database.",
        "useful": "The validator rejects the migration if any statement refers to a different database.",
        "unsafe": "The validator rejects the migration if every statement refers to a different database.",
        "critical_difference": "Any offending statement is sufficient; the unsafe revision requires all statements to offend.",
    },
    {
        "id": "redundant-required",
        "source": "The checkpoint is required, and it must be present, before the job can resume from the last completed batch.",
        "useful": "The checkpoint must be present before the job can resume from the last completed batch.",
        "unsafe": "The checkpoint may be present before the job can resume from the last completed batch.",
        "critical_difference": "The unsafe revision turns a required checkpoint into an optional one.",
    },
    {
        "id": "permission-obligation",
        "source": "It is worth noting that the worker may retry the request after a temporary error, but retrying is optional.",
        "useful": "The worker may retry the request after a temporary error; retrying is optional.",
        "unsafe": "The worker must retry the request after a temporary error; retrying is required.",
        "critical_difference": "The unsafe revision changes permission into an obligation.",
    },
    {
        "id": "unless",
        "source": "To put it another way, the cache retains the previous value unless the update succeeds.",
        "useful": "The cache retains the previous value unless the update succeeds.",
        "unsafe": "The cache retains the previous value if the update succeeds.",
        "critical_difference": "The unsafe revision reverses the update-success condition.",
    },
    {
        "id": "numeric-limit",
        "source": "There is a maximum limit in place: the server accepts a batch containing at most 64 rows.",
        "useful": "The server accepts batches containing at most 64 rows.",
        "unsafe": "The server accepts batches containing at most 128 rows.",
        "critical_difference": "The unsafe revision doubles the permitted row limit.",
    },
    {
        "id": "units",
        "source": "The timeout value is expressed as a duration of 30 seconds, meaning that the request is canceled after 30 seconds.",
        "useful": "The request is canceled after 30 seconds.",
        "unsafe": "The request is canceled after 30 milliseconds.",
        "critical_difference": "The unsafe revision changes the timeout unit by a factor of 1,000.",
    },
    {
        "id": "actor",
        "source": "The division of responsibilities is as follows: the parser validates syntax, and the scheduler selects the next job.",
        "useful": "The parser validates syntax; the scheduler selects the next job.",
        "unsafe": "The scheduler validates syntax; the parser selects the next job.",
        "critical_difference": "The unsafe revision exchanges the two components' responsibilities.",
    },
    {
        "id": "privacy-boundary",
        "source": "This is what makes the local endpoint private: requests go to localhost, and source text never leaves this machine.",
        "useful": "Requests go to localhost; source text never leaves this machine.",
        "unsafe": "Requests go to the hosted endpoint; source text leaves this machine.",
        "critical_difference": "The unsafe revision changes both the endpoint and the privacy boundary.",
    },
    {
        "id": "operation-order",
        "source": "The order matters here: the migration is recorded only after the shadow replay succeeds, and not before.",
        "useful": "The migration is recorded only after the shadow replay succeeds.",
        "unsafe": "The migration is recorded before the shadow replay succeeds.",
        "critical_difference": "The unsafe revision records the migration before successful verification.",
    },
    {
        "id": "version-boundary",
        "source": "The minimum supported version is a requirement, not a suggestion: this cleanup operation requires ClickHouse 24.11 or newer.",
        "useful": "This cleanup operation requires ClickHouse 24.11 or newer.",
        "unsafe": "This cleanup operation requires ClickHouse 23.11 or newer.",
        "critical_difference": "The unsafe revision falsely permits older server versions.",
    },
    {
        "id": "database-distinction",
        "source": "There are two distinct roles to keep in mind: the target database stores application data, while the shadow database verifies migrations.",
        "useful": "The target database stores application data; the shadow database verifies migrations.",
        "unsafe": "The target database verifies migrations; the shadow database stores application data.",
        "critical_difference": "The unsafe revision exchanges persistent and disposable database roles.",
    },
]

NEUTRAL = [
    {"id": "neutral-reader", "source": "The reader rejects invalid headers.", "revision": "Invalid headers are rejected by the reader."},
    {"id": "neutral-cache", "source": "The cache stores the latest value.", "revision": "The latest value is stored in the cache."},
    {"id": "neutral-token", "source": "The token is read when the request starts.", "revision": "When the request starts, the token is read."},
    {"id": "neutral-limit", "source": "Each batch contains at most 64 rows.", "revision": "A batch has no more than 64 rows."},
]


def main():
    if (ROOT / "predictions.jsonl").exists():
        raise ValueError("Cannot freeze a screen after observing its predictions")
    controls = {
        "version": "unswell-lens-salsa-controls-v1",
        "reviewer": "OpenAI assistant; constructed counterexamples, not independent human annotations",
        "groups": GROUPS,
        "neutral": NEUTRAL,
        "case_control": {
            "source": "Call parseURL after the credential resolves. Call it only once.",
            "useful": "Call parseURL once after the credential resolves.",
            "unsafe": "Call parseUrl once after the credential resolves.",
            "expected_limitation": "Published lowercasing maps the useful and unsafe revisions to exactly the same input; the model cannot distinguish these identifiers.",
        },
    }
    write("controls.json", controls)
    packet = WORKSPACE / "unswell-edit-pair-judgment-packet-v1"
    pairs = []
    source_hashes = {}
    for path in sorted((packet / "requests").glob("*.json")):
        data = json.loads(path.read_text())
        source = data["document"]["source"].encode("utf-8")
        if hashlib.sha256(source).hexdigest() != data["document"]["source_sha256"]:
            raise ValueError("Original source hash mismatch")
        spans = {unit["id"]: unit["span"] for unit in data["document"]["units"]}
        for pair in data["pairs"]:
            span = spans[pair["unit"]]
            raw = source[span["start"]:span["end"]].decode("utf-8")
            if raw != pair["before"] or pair["before"] == pair["after"]:
                raise ValueError("Pair no longer matches its changed original unit")
            pairs.append({
                "id": data["request"] + "/" + pair["unit"],
                "page": data["document"]["page"],
                "source_sha256": data["document"]["source_sha256"],
                "span": span,
                "source": pair["before"],
                "revision": pair["after"],
            })
        source_hashes[str(path.relative_to(WORKSPACE))] = digest(path)
    if len(pairs) != 142 or len({p["id"] for p in pairs}) != 142:
        raise ValueError("The unchanged 142-pair comparison pool is required")
    write("existing-pairs.json", {"version": "unswell-lens-salsa-existing-pairs-v1", "pairs": pairs})
    protocol = {
        "version": "unswell-lens-salsa-preflight-v1",
        "frozen_on": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "hypothesis": "The published pretrained edit-quality model may distinguish materially useful technical revisions from unsafe or merely optional changes; no training or threshold fitting is performed.",
        "roles": ["edit-benefit screen", "separate edit-safety stress test"],
        "inference": {"local_only": True, "external_requests": 0, "cpu_threads": 4, "batch_size": 1, "timeout_seconds": 1800, "max_rss_bytes": 12 * 1024 ** 3, "retries": 0, "model_training": False},
        "preprocessing": "Published lowercasing; unmodified published tokenization/forward; reject rather than silently score truncated source+revision pairs.",
        "score_definition": "Published regression output times 100; neither authorship nor revision-necessity probability.",
        "benefit_definition": "score(source, revision) - score(source, unchanged source)",
        "fixed_gain_margin": 2.0,
        "margin_basis": "An explicit exploratory practical margin on the published 100-point scale, fixed before these outcomes; not a published or calibrated product threshold.",
        "preflight": {
            "groups": 12,
            "useful_revisions": 12,
            "unsafe_revisions": 12,
            "neutral_revisions": 4,
            "minimum_useful_gain_count": 10,
            "maximum_neutral_gain_count": 1,
            "minimum_useful_above_unsafe_count": 10,
            "maximum_unsafe_gain_count_for_standalone_safety": 1,
            "case_control": "Report the known lowercasing collision separately; it cannot be passed by this model.",
            "full_combined_screen": "Benefit and standalone safety screens must both pass; otherwise do not use this as a general technical editorial selector.",
        },
        "existing_comparison": {
            "pairs": 142,
            "pages": 6,
            "purpose": "Descriptive score/coverage transfer check on already frozen proposed revisions, independent of preflight pass/fail.",
            "ground_truth": "No new labels. Previous emitted-diagnosis labels do not automatically label every proposed rewrite or all missing findings.",
            "qualification": "This exposed pool cannot establish full-event recall or product qualification. No new event credit, model-selection thresholds, or final-test claims.",
        },
        "failure_policy": "Retain partial execution and errors. No tuning, retries, seed search, or exclusion of unfavorable controls. Negative result is reported, not converted to completion of the recall objective.",
        "original_inputs": source_hashes,
        "frozen_hashes": {name: digest(ROOT / name) for name in ["controls.json", "existing-pairs.json", "local_model.py", "run.py", "evaluate.py", "test_contract.py", "prepare.py"]},
        "upstream_acquisition_sha256": digest(ROOT / "acquisition.json"),
    }
    write("protocol.json", protocol)
    print(json.dumps({"frozen": True, "protocol_sha256": digest(ROOT / "protocol.json"), "groups": 12, "pairs": len(pairs)}))


if __name__ == "__main__":
    main()
