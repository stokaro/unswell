"""Run the published LENS-SALSA inference code with pinned local resources."""

import hashlib
import importlib.metadata
import inspect
import os
from pathlib import Path
import socket
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
CHECKPOINT_SHA256 = "e62001fd8a91231be738f37ac02c9ffcf2d5bedb7ece5511c9bb96b52305ae68"


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def disable_network():
    """Reject outbound sockets as well as enabling the libraries' offline flags."""
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"
    os.environ["TOKENIZERS_PARALLELISM"] = "false"
    (ROOT / "cache").mkdir(exist_ok=True)
    os.environ["HF_HOME"] = str(ROOT / "cache")
    os.environ["TRANSFORMERS_CACHE"] = str(ROOT / "cache/transformers")

    def reject(*args, **kwargs):
        raise RuntimeError("Network access is prohibited for this local reference run")

    socket.socket.connect = reject
    socket.socket.connect_ex = reject
    socket.create_connection = reject


class LocalModel:
    def __init__(self):
        disable_network()
        import torch
        import yaml
        from transformers import AutoConfig, AutoModel, AutoTokenizer
        from lens.models.unified_metric import UnifiedMetric

        if importlib.metadata.version("lens-metric") != "0.2.0":
            raise ValueError("The pinned official LENS wheel is required")
        torch.set_num_threads(4)
        torch.set_num_interop_threads(1)
        torch.manual_seed(0)
        torch.use_deterministic_algorithms(True)
        self.torch = torch
        checkpoint_path = ROOT / "model/checkpoints/model.ckpt"
        if sha256(checkpoint_path) != CHECKPOINT_SHA256:
            raise ValueError("Checkpoint checksum mismatch")
        checkpoint = torch.load(
            checkpoint_path, map_location="cpu", weights_only=True, mmap=True
        )
        original_hparams = dict(checkpoint["hyper_parameters"])
        # Mirror the published loader's explicit YAML overrides. Only training paths
        # are cleared; no model formula, forward method, or tokenizer is replaced.
        hparams = dict(original_hparams)
        hparams.update(yaml.safe_load((ROOT / "model/hparams.yaml").read_text()))
        hparams["train_data"] = []
        hparams["validation_data"] = []
        accepted = inspect.signature(UnifiedMetric).parameters
        kwargs = {key: value for key, value in hparams.items() if key in accepted}
        config = AutoConfig.from_pretrained(
            str(ROOT / "tokenizer"), local_files_only=True, trust_remote_code=False
        )
        tokenizer = AutoTokenizer.from_pretrained(
            str(ROOT / "tokenizer"), local_files_only=True, trust_remote_code=False
        )
        if config.model_type != "roberta" or config.num_hidden_layers != 24:
            raise ValueError("Unexpected base encoder configuration")

        def local_tokenizer(name, *args, **kw):
            if name != "roberta-large" or args or kw:
                raise ValueError("Unexpected tokenizer loader request")
            return tokenizer

        def local_encoder(name, *args, **kw):
            if name != "roberta-large" or args or kw != {"add_pooling_layer": False}:
                raise ValueError("Unexpected encoder loader request")
            return AutoModel.from_config(
                config, add_pooling_layer=False, trust_remote_code=False
            )

        with patch.object(AutoTokenizer, "from_pretrained", local_tokenizer), patch.object(
            AutoModel, "from_pretrained", local_encoder
        ):
            model = UnifiedMetric(**kwargs)
        state = dict(checkpoint["state_dict"])
        # Transformers 4.36 regenerates this deterministic, nonpersistent buffer.
        # Check its exact value before excluding that single old checkpoint key.
        position_key = "encoder.model.embeddings.position_ids"
        positions = state.pop(position_key)
        if not torch.equal(positions, model.encoder.model.embeddings.position_ids):
            raise ValueError("Regenerated position IDs differ from the checkpoint")
        loaded = model.load_state_dict(state, strict=True, assign=True)
        if loaded.missing_keys or loaded.unexpected_keys:
            raise ValueError("Incomplete checkpoint load")
        for name, parameter in model.named_parameters():
            if name not in state or not torch.equal(parameter, state[name]):
                raise ValueError(f"Parameter was not restored exactly: {name}")
        model.eval()
        self.model = model
        self.tokenizer = model.encoder.tokenizer
        self.identity = {
            "checkpoint_sha256": CHECKPOINT_SHA256,
            "checkpoint_state_keys": len(checkpoint["state_dict"]),
            "loaded_state_keys": len(state),
            "regenerated_verified_buffer": position_key,
            "strict_load": True,
            "all_parameters_equal_checkpoint": True,
            "parameter_count": sum(p.numel() for p in model.parameters()),
            "official_package": "lens-metric==0.2.0",
            "published_score_scale": "raw model score multiplied by 100; not a probability",
            "published_preprocessing": "lowercase both source and revision",
            "effective_layer_transform": model.layerwise_attention.transform_fn.__name__,
            "declared_layer_transform": hparams["layer_transformation"],
            "forward_implementation": "unmodified published UnifiedMetric.predict_step",
            "network": "disabled and socket connections rejected",
            "device": "cpu",
            "threads": 4,
        }

    def token_plan(self, source, revision):
        if not isinstance(source, str) or not isinstance(revision, str):
            raise ValueError("Inputs must be strings")
        if not source.strip() or not revision.strip():
            return {"available": False, "reason": "empty_input"}
        if any(tag in text for text in (source, revision) for tag in ("<bad>", "</bad>")):
            return {"available": False, "reason": "reserved_tag_in_input"}
        src = self.tokenizer.encode(source.lower(), add_special_tokens=True, truncation=False)
        rev = self.tokenizer.encode(revision.lower(), add_special_tokens=True, truncation=False)
        joint = self.tokenizer.build_inputs_with_special_tokens(rev[1:-1], src[1:-1])
        result = {
            "available": True,
            "source_tokens": len(src),
            "revision_tokens": len(rev),
            "joint_tokens": len(joint),
        }
        if max(len(src), len(rev)) > self.model.encoder.max_positions - 2 or len(joint) > self.model.encoder.max_positions:
            result.update(available=False, reason="would_truncate_published_input")
        return result

    def score(self, source, revision):
        plan = self.token_plan(source, revision)
        if not plan["available"]:
            return plan
        sample = [{
            self.model.source_column: source.lower(),
            self.model.target_column: revision.lower(),
        }]
        batch = self.model.prepare_sample(sample, stage="predict")
        if len(batch) != 1:
            raise ValueError("Unexpected reference-free inference layout")
        ids = batch[0]["input_ids"][0][batch[0]["attention_mask"][0].bool()].tolist()
        expected = self.tokenizer.build_inputs_with_special_tokens(
            self.tokenizer.encode(revision.lower(), add_special_tokens=False),
            self.tokenizer.encode(source.lower(), add_special_tokens=False),
        )
        if ids != expected or len(ids) != plan["joint_tokens"]:
            raise ValueError("Published preprocessing altered or truncated the token sequence")
        with self.torch.inference_mode():
            prediction = self.model.predict_step(batch)
        score = float(prediction.scores[0]) * 100.0
        if not self.torch.isfinite(prediction.scores).all():
            raise ValueError("Nonfinite model score")
        tags = prediction.metadata.subword_scores["bad"][0]
        if len(tags) != len(ids) - 2:
            raise ValueError("Incomplete token error-tag output")
        result = dict(plan)
        result.update(score=score, bad_tags=tags, all_input_tokens_retained=True)
        return result
